// Exportação para o DB Dashboard (https://dbdashboard-o.lovable.app).
//
// O bot EMPURRA os dados; o site nunca puxa. Dois motivos:
//   1. o painel do bot fica atrás de um certificado autoassinado num IP puro —
//      uma edge function do Supabase recusaria a conexão;
//   2. empurrando, nada precisa ser aberto para a internet além do que já está.
//
// O envio é em LOTE (padrão: a cada 5 min) e é IDEMPOTENTE: cada serviço vai
// com o seu id e cada linha de operador com (dia, operador), e o outro lado faz
// upsert. Reenviar o mesmo lote não duplica nada — é isso que deixa a retentativa
// ser burra e segura.
//
// O que é enviado só é marcado como enviado DEPOIS que a resposta chega OK.
// Falha de rede não consome nada: o próximo ciclo manda tudo de novo.
import { getDb, saveDb, getConfig } from './db.js';
import { logger } from './logger.js';
import { rankingOperadores, dayKey } from './store.js';

export const INTERVALO_PADRAO_MIN = 5;
export const TIMEOUT_MS = 15_000;

// Tetos por lote: um envio nunca pode virar um payload de megabytes (o dia tem
// ~240 serviços; 300 cobre o pior dia com folga e ainda cabe numa requisição).
export const MAX_SERVICOS_LOTE = 300;
export const MAX_DIAS_LOTE = 7;
// Memória de dias já enviados: 90 dias de chaves é barato e cobre qualquer
// recorte que o site peça depois.
export const MAX_DIAS_MEMORIA = 90;

// Espera depois de uma falha: 1, 2, 4, 8, 16, 30, 30… minutos. Sem isto, um
// site fora do ar viraria uma tentativa a cada 60 s para sempre.
export const BACKOFF_MIN = [1, 2, 4, 8, 16, 30];

const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
const texto = (v, max = 200) => (v == null ? null : String(v).slice(0, max));

export function configExport(config = {}) {
  const intervalo = Number(config?.exportIntervaloMin);
  return {
    ligado: config?.exportEnabled === true,
    url: String(config?.exportUrl ?? '').trim(),
    segredo: String(config?.exportSegredo ?? ''),
    // Opcional: projetos que exigem JWT na edge function querem a anon key.
    apiKey: String(config?.exportApiKey ?? '').trim(),
    intervaloMin: Number.isFinite(intervalo) && intervalo > 0 ? Math.round(intervalo) : INTERVALO_PADRAO_MIN,
  };
}

/* ═══════════ O que mudou desde o último envio ═══════════ */

/**
 * "Versão" de um serviço: o que muda nele e importa para o site. Um serviço
 * caminha de aguardando → atendido → validado (ou expira), e cada passo tem de
 * chegar lá. Comparar a versão gravada com a atual é o que evita reenviar os
 * 240 serviços do dia a cada 5 minutos.
 */
export function versaoServico(s) {
  return [
    s?.status ?? '',
    s?.atendimento?.msgId ?? '',
    s?.atendimento?.casamento ?? '',
    s?.comprovante?.msgId ?? '',
  ].join('|');
}

// Serviços que mudaram (ou nunca foram) desde o último envio bem-sucedido.
export function servicosPendentes(servicos = [], limite = MAX_SERVICOS_LOTE) {
  const fora = [];
  for (let i = servicos.length - 1; i >= 0 && fora.length < limite; i--) {
    const s = servicos[i];
    if (s.exportadoVersao !== versaoServico(s)) fora.push(s);
  }
  return fora.reverse(); // do mais antigo para o mais novo
}

// Assinatura do ranking de um dia: se ela não mudou, o dia não precisa ir de
// novo. É barata e não depende de ordem de chaves.
export function assinaturaDia(linhas = []) {
  return linhas
    .map((l) => [l.operador_id, l.servicos, l.validados, l.montante_validado, l.contas_pegas_qtd, l.lancamentos, l.montante_lancado].join(':'))
    .sort()
    .join('|');
}

/* ═══════════ As linhas que vão no corpo ═══════════ */

export function linhaServico(s) {
  const a = s?.atendimento ?? null;
  return {
    id: s.id,
    dia: s.day,
    status: s.status,
    tipo: s.tipo,
    sessao_id: s.sessaoId ?? null,
    grupo_id: s.groupId ?? null,
    grupo_nome: texto(s.groupName, 120),
    brogueira_nome: texto(s.brogueiraNome, 120),
    brogueira_pn: texto(s.brogueiraPn, 60),
    pedido_texto: texto(s.pedidoTexto, 200),
    pedido_ts: s.pedidoTs ?? null,
    montante_pedido: num(s.montantePedido),
    contas_pedidas: num(s.contasPedidas),
    operador_id: a?.operatorId ?? null,
    operador_pn: texto(a?.operatorPn, 60),
    operador_nome: texto(a?.operatorName, 120),
    atendimento_ts: a?.ts ?? null,
    // montante e contas como o painel os mede: o R$ do montante e o R$
    // rotulado "Valor:" (a série "Contas (R$)" do quadro azul).
    montante: num(a?.montante),
    contas_qtd: num(a?.contasQtd),
    contas_valor: num(a?.contasTotal),
    casamento: a?.casamento ?? null,
    comprovante_ts: s.comprovante?.ts ?? null,
    comprovante_tipo: s.comprovante?.tipo ?? null,
  };
}

export function linhaOperador(o, dia) {
  return {
    dia,
    operador_id: texto(o.id ?? o.nome, 80),
    operador_pn: texto(o.pn, 60),
    operador_nome: texto(o.nome, 120),
    servicos: num(o.servicos),
    validados: num(o.validados),
    aguardando: num(o.aguardando),
    sem_comprovante: num(o.semComprovante),
    taxa: Math.round(num(o.taxa) * 1000) / 1000,
    montante_validado: num(o.montanteValidado),
    montante_atendido: num(o.montanteAtendido),
    montante_lancado: num(o.montanteLancado),
    lancamentos: num(o.lancamentos),
    contas_pegas_qtd: num(o.contasPegasQtd),
    contas_pegas_valor: num(o.contasPegasValor),
    contas_validadas_qtd: num(o.contasValidadasQtd),
    contas_validadas_valor: num(o.contasValidadasValor),
    contas_lancadas_qtd: num(o.contasQtd),
    contas_lancadas_valor: num(o.contasValor),
    casamento_citacao: num(o.casamento?.citacao),
    casamento_valor: num(o.casamento?.valor),
    casamento_tempo: num(o.casamento?.tempo),
    brogueiras: num(o.brogueiras),
  };
}

/* ═══════════ Estado do exportador (db.export) ═══════════ */

export function estadoExport() {
  const db = getDb();
  if (!db.export || typeof db.export !== 'object') {
    db.export = { dias: {}, ultimoEnvioEm: null, ultimoErro: null, tentativas: 0, proximaEm: null, enviados: 0 };
  }
  if (!db.export.dias || typeof db.export.dias !== 'object') db.export.dias = {};
  return db.export;
}

// Quando o próximo envio pode acontecer, considerando o intervalo e o backoff.
export function proximaJanela(estado, cfg, agora = Date.now()) {
  if (estado.proximaEm && Date.parse(estado.proximaEm) > agora) return Date.parse(estado.proximaEm);
  const ultimo = estado.ultimoEnvioEm ? Date.parse(estado.ultimoEnvioEm) : 0;
  return ultimo + cfg.intervaloMin * 60_000;
}

function esperaBackoff(tentativas) {
  return BACKOFF_MIN[Math.min(tentativas, BACKOFF_MIN.length - 1)] * 60_000;
}

/* ═══════════ Montagem e envio do lote ═══════════ */

/**
 * Monta o lote a enviar. Devolve `null` quando não há nada novo — é o caso
 * comum (o grupo passa horas parado) e não deve virar requisição nenhuma.
 *
 * Os dias que entram são os dos serviços que mudaram MAIS o dia de hoje: o
 * ranking de hoje muda a cada lançamento, mesmo sem serviço novo.
 */
export function montarLote({ servicos = [], estado, agora = Date.now(), rankingDe = rankingOperadores } = {}) {
  const pendentes = servicosPendentes(servicos);
  const hoje = dayKey(agora);
  const dias = [...new Set([...pendentes.map((s) => s.day), hoje])]
    .filter(Boolean)
    .sort()
    .slice(-MAX_DIAS_LOTE);

  const operadores = [];
  const assinaturas = {};
  for (const dia of dias) {
    const linhas = (rankingDe({ day: dia })?.operadores ?? []).map((o) => linhaOperador(o, dia));
    const assinatura = assinaturaDia(linhas);
    // Dia sem nada e que já foi assim da última vez não precisa viajar.
    if (estado?.dias?.[dia] === assinatura) continue;
    assinaturas[dia] = assinatura;
    operadores.push(...linhas);
  }

  if (!pendentes.length && !operadores.length) return null;

  return {
    lote: {
      origem: 'whatsapp-server',
      versao: 1,
      enviado_em: new Date(agora).toISOString(),
      operadores,
      servicos: pendentes.map(linhaServico),
    },
    pendentes,
    assinaturas,
  };
}

/**
 * POST no endpoint do site. Devolve { ok, status, corpo } e NUNCA lança —
 * quem chama decide o que fazer com a falha (e o bot não pode cair porque o
 * site saiu do ar).
 */
export async function postar(corpo, cfg, { fetchImpl = globalThis.fetch, timeoutMs = TIMEOUT_MS } = {}) {
  if (!cfg.url) return { ok: false, status: 0, erro: 'sem URL de destino configurada' };
  const ctrl = new AbortController();
  const t = setTimeout(() => ctrl.abort(), timeoutMs);
  try {
    const headers = { 'content-type': 'application/json' };
    if (cfg.segredo) headers['x-db-secret'] = cfg.segredo;
    // Projeto que exige JWT na função quer a anon key nos dois cabeçalhos.
    if (cfg.apiKey) {
      headers.apikey = cfg.apiKey;
      headers.authorization = `Bearer ${cfg.apiKey}`;
    }
    const res = await fetchImpl(cfg.url, {
      method: 'POST',
      headers,
      body: JSON.stringify(corpo),
      signal: ctrl.signal,
    });
    const texto = await res.text().catch(() => '');
    if (!res.ok) return { ok: false, status: res.status, erro: `HTTP ${res.status} ${texto.slice(0, 200)}`.trim() };
    return { ok: true, status: res.status, corpo: texto.slice(0, 500) };
  } catch (err) {
    const erro = err?.name === 'AbortError' ? `sem resposta em ${Math.round(timeoutMs / 1000)}s` : String(err?.message ?? err);
    return { ok: false, status: 0, erro };
  } finally {
    clearTimeout(t);
  }
}

// Poda a memória de dias — 90 dias bastam e o db.json não pode crescer sem fim.
function podarDias(estado) {
  const chaves = Object.keys(estado.dias).sort();
  for (const k of chaves.slice(0, Math.max(0, chaves.length - MAX_DIAS_MEMORIA))) delete estado.dias[k];
}

/**
 * Um ciclo: monta, envia e — só se deu certo — marca o que foi.
 *
 * `forcar` ignora o intervalo (é o botão "Sincronizar agora" do painel).
 * Devolve um resumo do que aconteceu, que é o que o painel mostra.
 */
export async function sincronizarExport({ agora = Date.now(), forcar = false, deps = {} } = {}) {
  const cfg = configExport(getConfig());
  if (!cfg.ligado) return { ok: false, motivo: 'desligado' };
  if (!cfg.url) return { ok: false, motivo: 'sem URL' };

  const estado = estadoExport();
  if (!forcar && proximaJanela(estado, cfg, agora) > agora) return { ok: true, motivo: 'ainda no intervalo', enviados: 0 };

  const db = getDb();
  const montado = montarLote({ servicos: db.servicos, estado, agora, ...(deps.rankingDe ? { rankingDe: deps.rankingDe } : {}) });
  if (!montado) {
    estado.ultimoEnvioEm = new Date(agora).toISOString();
    estado.tentativas = 0;
    estado.proximaEm = null;
    saveDb();
    return { ok: true, motivo: 'nada novo', enviados: 0 };
  }

  const res = await postar(montado.lote, cfg, deps);

  if (!res.ok) {
    estado.tentativas = num(estado.tentativas) + 1;
    estado.proximaEm = new Date(agora + esperaBackoff(estado.tentativas)).toISOString();
    estado.ultimoErro = { em: new Date(agora).toISOString(), erro: res.erro, status: res.status };
    saveDb();
    logger.warn(
      { erro: res.erro, tentativa: estado.tentativas, proximaEm: estado.proximaEm },
      'exportação falhou — nada foi marcado como enviado',
    );
    return { ok: false, motivo: res.erro, enviados: 0 };
  }

  // Só agora o que foi vira "enviado".
  for (const s of montado.pendentes) s.exportadoVersao = versaoServico(s);
  Object.assign(estado.dias, montado.assinaturas);
  podarDias(estado);
  estado.ultimoEnvioEm = new Date(agora).toISOString();
  estado.ultimoErro = null;
  estado.tentativas = 0;
  estado.proximaEm = null;
  estado.enviados = num(estado.enviados) + montado.lote.servicos.length;
  saveDb();

  logger.info(
    { servicos: montado.lote.servicos.length, operadores: montado.lote.operadores.length },
    'exportação enviada ao DB Dashboard',
  );
  return {
    ok: true,
    enviados: montado.lote.servicos.length,
    operadores: montado.lote.operadores.length,
    resposta: res.corpo,
  };
}

/**
 * Envio de teste: um lote vazio marcado como `teste`, que o outro lado
 * responde sem gravar nada. Serve para conferir URL e segredo no painel sem
 * sujar o banco do site.
 */
export async function testarExport(deps = {}) {
  const cfg = configExport(getConfig());
  if (!cfg.url) return { ok: false, erro: 'configure a URL de destino primeiro' };
  const res = await postar(
    { origem: 'whatsapp-server', versao: 1, teste: true, enviado_em: new Date().toISOString(), operadores: [], servicos: [] },
    cfg,
    deps,
  );
  return res.ok ? { ok: true, status: res.status, resposta: res.corpo } : { ok: false, erro: res.erro, status: res.status };
}

// Situação atual, para o card do painel.
export function statusExport() {
  const cfg = configExport(getConfig());
  const estado = estadoExport();
  const pendentes = servicosPendentes(getDb().servicos, MAX_SERVICOS_LOTE + 1).length;
  return {
    ligado: cfg.ligado,
    url: cfg.url,
    intervaloMin: cfg.intervaloMin,
    temSegredo: Boolean(cfg.segredo),
    ultimoEnvioEm: estado.ultimoEnvioEm,
    ultimoErro: estado.ultimoErro,
    tentativas: num(estado.tentativas),
    proximaEm: estado.proximaEm,
    totalEnviados: num(estado.enviados),
    pendentes,
  };
}

/* ═══════════ Relógio ═══════════ */

let timer = null;

/**
 * Tique de 60 s que pergunta "já é hora?". É mais simples (e mais robusto) do
 * que um cron reagendado a cada mudança de configuração: mexer no intervalo no
 * painel passa a valer no minuto seguinte, sem reiniciar nada.
 */
export function iniciarExportador({ intervaloTiqueMs = 60_000 } = {}) {
  pararExportador();
  timer = setInterval(() => {
    sincronizarExport().catch((err) => logger.error(err, 'erro no ciclo de exportação'));
  }, intervaloTiqueMs);
  if (timer.unref) timer.unref(); // não segura o processo no ar
  logger.info({ tiqueMs: intervaloTiqueMs }, 'exportador ligado (verifica a cada tique)');
  return timer;
}

export function pararExportador() {
  if (timer) clearInterval(timer);
  timer = null;
}
