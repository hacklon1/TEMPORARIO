"""Cadastro de hosts SSH e execucao de comandos pontuais."""
from __future__ import annotations

import os

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel, Field

from .. import db
from ..config import settings
from ..deps import admin_user, client_ip
from ..services import sshmgr

router = APIRouter(prefix="/api/hosts", tags=["hosts"])


class HostIn(BaseModel):
    name: str = Field(min_length=1, max_length=64)
    hostname: str = Field(min_length=1, max_length=255)
    port: int = Field(default=22, ge=1, le=65535)
    username: str = Field(default="root", max_length=64)
    key_path: str = ""
    is_default: bool = False


class CommandIn(BaseModel):
    command: str = Field(min_length=1, max_length=8000)
    host_id: int | None = None
    timeout: int = Field(default=60, ge=1, le=600)


@router.get("")
async def list_hosts(user: dict = Depends(admin_user)):
    rows = await db.fetch_all("SELECT * FROM hosts ORDER BY is_default DESC, name")
    return {
        "hosts": rows,
        "fallback": {
            "hostname": settings.ssh_host, "port": settings.ssh_port,
            "username": settings.ssh_user, "key_path": settings.ssh_key,
            "key_present": os.path.isfile(settings.ssh_key),
        },
    }


@router.post("")
async def create_host(body: HostIn, request: Request, user: dict = Depends(admin_user)):
    key = body.key_path or settings.ssh_key
    if not os.path.isfile(key):
        raise HTTPException(status_code=400, detail=f"chave SSH nao encontrada: {key}")
    if body.is_default:
        await db.execute("UPDATE hosts SET is_default=0")
    try:
        host_id = await db.execute(
            "INSERT INTO hosts (name, hostname, port, username, key_path, is_default) VALUES (?,?,?,?,?,?)",
            (body.name, body.hostname, body.port, body.username, key, 1 if body.is_default else 0),
        )
    except Exception as exc:  # nome duplicado
        raise HTTPException(status_code=400, detail="ja existe um host com esse nome") from exc
    await db.audit("host.create", username=user["username"], ip=client_ip(request), target=body.name)
    return {"ok": True, "id": host_id}


@router.delete("/{host_id}")
async def delete_host(host_id: int, request: Request, user: dict = Depends(admin_user)):
    row = await db.fetch_one("SELECT name FROM hosts WHERE id=?", (host_id,))
    if not row:
        raise HTTPException(status_code=404, detail="host nao encontrado")
    await db.execute("DELETE FROM hosts WHERE id=?", (host_id,))
    await db.audit("host.delete", username=user["username"], ip=client_ip(request), target=row["name"])
    return {"ok": True}


@router.post("/{host_id}/check")
async def check_host(host_id: int, user: dict = Depends(admin_user)):
    host = await sshmgr.get_host(host_id or None)
    return await sshmgr.check(host)


@router.post("/check")
async def check_default(user: dict = Depends(admin_user)):
    host = await sshmgr.get_host(None)
    res = await sshmgr.check(host)
    return {"host": host.hostname, "user": host.username, "key": host.key_path, **res}


@router.post("/exec")
async def exec_command(body: CommandIn, request: Request, user: dict = Depends(admin_user)):
    host = await sshmgr.get_host(body.host_id)
    res = await sshmgr.run_command(host, body.command, timeout=body.timeout)
    await db.audit("ssh.exec", username=user["username"], ip=client_ip(request),
                   target=f"{host.username}@{host.hostname}", ok=res["ok"], detail=body.command[:300])
    return res
