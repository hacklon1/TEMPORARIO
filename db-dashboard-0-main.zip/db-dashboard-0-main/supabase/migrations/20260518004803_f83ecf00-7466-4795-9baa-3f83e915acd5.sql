
REVOKE EXECUTE ON FUNCTION public.log_operation_change() FROM PUBLIC, anon, authenticated;
