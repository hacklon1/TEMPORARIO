// Os cinco temas do painel.
//
// Dois riscos que este arquivo cobre: (1) um tema novo esquecer de redefinir
// algum token — a tela sai com metade das cores do tema anterior; (2) a
// escolha não sobreviver ao reload, que é o que o usuário percebe primeiro.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const PUBLIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
const CSS = fs.readFileSync(path.join(PUBLIC, 'style.css'), 'utf8');

const TEMAS = ['noir', 'dourado', 'azul'];       // os três novos
const TODOS = ['dark', 'light', ...TEMAS];

// Tokens que TODO tema precisa redefinir: são os que dependem da superfície.
// Ficam de fora os estruturais (--font, --radius) e os de STATUS
// (--good/--warning/--critical), que são fixos por decisão de paleta — o verde
// de "ok" não vira a cor da marca do tema; quando um tema precisa escurecê-los
// para ter contraste, ele redefine (é o caso do Branco & Dourado).
const TOKENS_OBRIGATORIOS = [
  '--page', '--surface', '--surface-2', '--surface-3',
  '--ink', '--ink-2', '--muted',
  '--line', '--line-strong', '--grid', '--axis',
  '--s1', '--s2', '--s3', '--seq-100', '--seq-700', '--seq-zero',
  '--accent-soft', '--rep-mesma', '--rep-outra',
  '--sv-ok', '--sv-pend', '--sv-pend-linha', '--s2-claro',
  '--shadow', '--gradient-primary', '--gradient-bg', '--gradient-card', '--glow', '--shadow-card',
];

function blocoDoTema(tema) {
  const alvo = tema === 'dark' ? ':root {' : `:root[data-theme="${tema}"] {`;
  const i = CSS.indexOf(alvo);
  assert.ok(i >= 0, `bloco do tema ${tema} não existe no style.css`);
  return CSS.slice(i, CSS.indexOf('\n}', i));
}

test('cada tema redefine todos os tokens de cor', () => {
  for (const tema of TODOS) {
    const bloco = blocoDoTema(tema);
    const faltando = TOKENS_OBRIGATORIOS.filter((t) => !bloco.includes(`${t}:`));
    assert.deepEqual(faltando, [], `tema "${tema}" não define: ${faltando.join(', ')}`);
  }
});

test('os três temas novos trazem a própria paleta de status e acento', () => {
  // Eles não são variações do tema de sempre: têm cor de marca própria, então
  // precisam declarar acento e status em vez de herdar o azul/verde do :root.
  for (const tema of TEMAS) {
    const bloco = blocoDoTema(tema);
    for (const token of ['--accent', '--good', '--warning', '--critical']) {
      assert.ok(bloco.includes(`${token}:`), `tema "${tema}" não define ${token}`);
    }
  }
});

test('o acento do tema claro de sempre acompanha a série 1 (indireção proposital)', () => {
  // Ele não redefine --accent porque o :root já aponta para var(--s1), que o
  // próprio tema troca. Se isso mudar, o acento sairia com a cor errada.
  assert.match(blocoDoTema('dark'), /--accent:\s*var\(--s1\)/);
});

test('os temas claros declaram color-scheme light (e os escuros, dark)', () => {
  assert.match(blocoDoTema('dourado'), /color-scheme:\s*light/);
  assert.match(blocoDoTema('light'), /color-scheme:\s*light/);
  assert.match(blocoDoTema('noir'), /color-scheme:\s*dark/);
  assert.match(blocoDoTema('azul'), /color-scheme:\s*dark/);
});

test('as séries dos gráficos não são repintadas com o acento do tema', () => {
  // A paleta categórica é validada (contraste + daltonismo): cada tema usa a
  // variação escura ou clara dela, nunca a cor da marca do tema.
  for (const tema of TODOS) {
    const bloco = blocoDoTema(tema);
    const s1 = /--s1:\s*([^;]+);/.exec(bloco)[1].trim();
    assert.ok(['#3987e5', '#2a78d6'].includes(s1), `tema "${tema}" trocou a série 1 por ${s1}`);
  }
});

async function montar(temaSalvo) {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;
  window.Element.prototype.getBoundingClientRect = () => ({ left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0 });
  window.Element.prototype.scrollIntoView = () => {};
  if (temaSalvo) window.localStorage.setItem('ws_theme', temaSalvo);
  window.fetch = async () => ({ ok: true, status: 200, json: async () => ({ ok: true, recursos: [], sessoes: [], conflitos: [] }) });
  for (const arquivo of ['app.js', 'relatorios.js']) {
    const tag = window.document.createElement('script');
    tag.textContent = fs.readFileSync(path.join(PUBLIC, arquivo), 'utf8');
    window.document.body.appendChild(tag);
  }
  return { window, doc: window.document, fechar: async () => { await new Promise((r) => setTimeout(r, 20)); dom.window.close(); } };
}

test('o menu lista os cinco temas, cada um com quatro amostras', async () => {
  const { doc, fechar } = await montar();
  try {
    const itens = [...doc.querySelectorAll('#tema-menu .tema-item')];
    assert.equal(itens.length, 5);
    assert.deepEqual(itens.map((b) => b.dataset.tema), TODOS);
    for (const item of itens) {
      assert.equal(item.querySelectorAll('.tema-amostras i').length, 4, 'cada tema mostra 4 cores');
      assert.ok(item.querySelector('.nome').textContent.trim().length > 2);
    }
  } finally { await fechar(); }
});

test('escolher um tema aplica no <html>, marca o ativo e guarda a escolha', async () => {
  const { window, doc, fechar } = await montar();
  try {
    assert.equal(doc.documentElement.dataset.theme, 'dark', 'sem escolha, o padrão');

    doc.querySelector('#tema-menu .tema-item[data-tema="azul"]').onclick();
    assert.equal(doc.documentElement.dataset.theme, 'azul');
    assert.equal(window.localStorage.getItem('ws_theme'), 'azul');

    const marcados = [...doc.querySelectorAll('#tema-menu .tema-item')]
      .filter((b) => b.getAttribute('aria-checked') === 'true');
    assert.deepEqual(marcados.map((b) => b.dataset.tema), ['azul'], 'só o ativo fica marcado');
    // e o menu fecha ao escolher
    assert.equal(doc.getElementById('tema-menu').classList.contains('hidden'), true);
  } finally { await fechar(); }
});

test('a escolha sobrevive ao reload', async () => {
  const { doc, fechar } = await montar('dourado');
  try {
    assert.equal(doc.documentElement.dataset.theme, 'dourado');
    assert.equal(doc.querySelector('#tema-menu .tema-item[data-tema="dourado"]').getAttribute('aria-checked'), 'true');
  } finally { await fechar(); }
});

test('tema desconhecido no localStorage cai no padrão, sem quebrar a tela', async () => {
  const { doc, fechar } = await montar('roxo-neon');
  try {
    assert.equal(doc.documentElement.dataset.theme, 'dark');
  } finally { await fechar(); }
});

test('o botão abre e fecha o menu, e clicar fora fecha', async () => {
  const { window, doc, fechar } = await montar();
  try {
    const botao = doc.getElementById('theme-btn');
    const menu = doc.getElementById('tema-menu');
    assert.equal(menu.classList.contains('hidden'), true);

    botao.onclick({ stopPropagation() {} });
    assert.equal(menu.classList.contains('hidden'), false);
    assert.equal(botao.getAttribute('aria-expanded'), 'true');

    doc.body.dispatchEvent(new window.Event('click', { bubbles: true }));
    assert.equal(menu.classList.contains('hidden'), true);
    assert.equal(botao.getAttribute('aria-expanded'), 'false');
  } finally { await fechar(); }
});
