# VPS Manager

Painel web para **baixar por completo os projetos de `/opt`** e **controlar a VPS por SSH**
(terminal interativo no navegador, autenticado por chave RSA).

- URL: **https://179.197.231.192:7443** (certificado auto-assinado — o navegador vai avisar; aceite)
- Usuário inicial: **admin** — senha em `/etc/vps-manager/.admin_bootstrap_pw` (troque no painel, botão “Trocar senha”)

---

## Arquitetura

```
navegador ──HTTPS/WSS 7443──> nginx ──> gunicorn 127.0.0.1:8200 (2 workers uvicorn)
                                             │
                                             ├─ tar/zip em streaming  → downloads de /opt
                                             ├─ asyncssh → PTY root@127.0.0.1:22  (terminal)
                                             └─ systemctl / psutil     → serviços e métricas
```

| Item | Caminho |
|---|---|
| Código | `/opt/vps-manager` |
| Config | `/etc/vps-manager/.env` (600) → symlink em `/opt/vps-manager/.env` |
| Banco | `/opt/vps-manager/var/vpsmgr.db` (SQLite/WAL) |
| Chave SSH do painel | `/etc/vps-manager/keys/id_rsa` (RSA 4096) |
| TLS | `/etc/vps-manager/certs/server.{crt,key}` (SAN `IP:179.197.231.192`, validade 10 anos) |
| Senha inicial | `/etc/vps-manager/.admin_bootstrap_pw` (600) |
| Logs | `/opt/vps-manager/logs/{access,error}.log` |
| Unidade | `systemctl {status,restart,reload} vps-manager` |
| Nginx | `/etc/nginx/sites-available/vps-manager.conf` |

Stack: Python 3.13 (venv próprio), FastAPI, asyncssh, aiosqlite, psutil, xterm.js (vendorizado em
`web/vendor/`, sem CDN).

---

## Telas

**Visão geral** — CPU, RAM, disco, rede, carga, uptime, top processos e portas em escuta.
Atualiza sozinho a cada 5 s.

**Projetos** — cada pasta de `/opt` com dois tamanhos calculados: *enxuto* e *completo*.
Botões por projeto (`.tar.gz`, `.zip`, cópia integral) e **Baixar todos** num pacote único.
Tudo em streaming: nada é gravado em disco antes de enviar.

- **Enxuto** (padrão) pula: `.venv`, `node_modules`, `__pycache__`, `.git`, `.pytest_cache`,
  `.npm`, `*.pyc`, `venv`, `dist`, `build`. Ex.: findash cai de 78 MB para 242 KB.
- **Cópia integral** leva tudo, byte a byte. Ex.: `/opt` inteiro ≈ 5,6 GB.
- A lista de exclusões fica em `EXCLUDES_DEFAULT` no `.env`.

**Arquivos** — navega o disco inteiro, mostra dono/permissões, visualiza texto (até 512 KB),
baixa arquivo isolado ou pasta compactada, e envia arquivos (até 512 MB) para a pasta atual.

**Terminal SSH** — shell root de verdade, com PTY (`xterm-256color`), redimensionamento
dinâmico, histórico de 8000 linhas e botões de atalho. Roda sobre WebSocket → asyncssh →
`root@127.0.0.1:22` usando a chave RSA do painel.

**Serviços** — as unidades listadas em `MANAGED_UNITS` (`delta-cpa`, `findash`,
`whatsapp-server`, `nginx`, `postgresql`, `redis-server`, `vps-manager`): estado, iniciar,
parar, reiniciar e ver `journalctl`. Serviço fora da lista é recusado (inclusive `ssh`, de
propósito — para não trancar o acesso à máquina).

**Hosts SSH** — cadastre outros servidores (endereço, porta, usuário, chave) e use o mesmo
terminal neles. Botão “Testar” valida a conexão antes.

**Auditoria** — toda ação passa por aqui: login, download, upload, comando SSH, ação em serviço.

---

## Interface

Um painel de instrumentos, não um site. As vitais da máquina (CPU, memória, disco, carga,
uptime, processos) ficam numa régua fixa no topo de **todas** as telas — você está dentro do
terminal e continua vendo a carga subir.

Regras que o visual segue:

- **Cor é informação.** Ciano é tudo que se clica. Verde, âmbar e vermelho são
  exclusivamente estado da máquina — rodando, atenção, falhou. Nunca decoração.
- **Duas famílias, dois papéis.** Fira Sans para a língua da interface; Fira Code para tudo
  que a *máquina* disse: caminhos, tamanhos, PIDs, portas, comandos, horários.
- **A borda esquerda colorida** das linhas (serviços, auditoria, processos quentes) carrega
  estado; ela não aparece quando não há estado para mostrar.
- Ícones são SVG desenhados no próprio HTML, nada de emoji. Fontes e xterm.js são servidos
  da própria VPS — **nenhuma requisição a CDN**, o painel funciona com a internet ruim.
- Ícone da guia em `web/favicon.svg` (+ `.ico` e `apple-touch-icon.png` gerados por
  `scripts/mkicon.py`, rasterizador em Python puro, sem dependências).

Verificado com Chromium headless em 390, 768, 1024 e 1440 px: nenhuma tela tem rolagem
horizontal, e os alvos de toque ficam em 38 px ou mais no celular.

---

## Segurança

- Login com **Argon2id**, sessão **JWT** em cookie `HttpOnly` + `Secure` + `SameSite=Lax` (4 h).
- Rate limit de 8 logins/min por IP; 8 senhas erradas bloqueiam a conta por 15 min.
- Todas as rotas exigem sessão; o WebSocket valida o mesmo cookie antes de abrir o SSH.
- Travessia de caminho bloqueada em duas camadas (`resolve_project` e `safe_path`).
- A chave do painel está autorizada em `/root/.ssh/authorized_keys` com `from="127.0.0.1,::1"`
  — só funciona a partir da própria VPS, não serve para entrar de fora.
- Segredos (`.env`, chave privada, senha inicial) em 600; nada de senha em log.

**O que isso significa na prática:** quem entra no painel tem shell root na VPS. A senha do
`admin` é, para todos os efeitos, a senha de root da máquina. Troque a inicial e use uma senha
longa. Se quiser fechar mais, restrinja a porta 7443 ao seu IP:

```bash
ufw delete allow 7443/tcp
ufw allow from SEU.IP.AQUI to any port 7443 proto tcp
```

---

## Operação

```bash
systemctl status vps-manager          # estado
systemctl restart vps-manager         # reiniciar
journalctl -u vps-manager -n 100      # log da unidade
tail -f /opt/vps-manager/logs/error.log

# recriar a senha do admin (apaga o usuário e deixa o serviço gerar outra)
sqlite3 /opt/vps-manager/var/vpsmgr.db "DELETE FROM users WHERE username='admin';"
systemctl restart vps-manager && cat /etc/vps-manager/.admin_bootstrap_pw
```

Editou algo em `deploy/`? Instale de verdade e confira o que está em uso:

```bash
install -m644 deploy/nginx-vps-manager.conf /etc/nginx/sites-available/vps-manager.conf
nginx -t && systemctl reload nginx
install -m644 deploy/vps-manager.service /etc/systemd/system/vps-manager.service
systemctl daemon-reload && systemctl restart vps-manager
```

---

## API

Autenticação por cookie de sessão ou `Authorization: Bearer <token>`.

| Método | Rota | O que faz |
|---|---|---|
| POST | `/api/auth/login` | login (devolve cookie + token) |
| POST | `/api/auth/logout` · `/api/auth/password` | sair · trocar senha |
| GET | `/api/auth/me` · `/api/auth/audit` | sessão atual · trilha de auditoria |
| GET | `/api/system` · `/processes` · `/ports` | métricas, processos, portas |
| GET | `/api/system/services` | unidades systemd |
| POST | `/api/system/services/{nome}` | `{"action":"restart"}` (start/stop/restart/reload/enable/disable) |
| GET | `/api/system/services/{nome}/logs?lines=300` | journalctl |
| GET | `/api/projects` | projetos com tamanho enxuto e completo |
| GET | `/api/projects/{nome}/download?fmt=tar.gz&full=false` | baixa um projeto |
| GET | `/api/projects/download-all?fmt=tar.gz&full=false` | baixa todos num pacote |
| GET | `/api/files/list` · `/view` · `/download` · `/stat` · `/disk` | gerenciador de arquivos |
| POST | `/api/files/upload` | envio (multipart: `dest`, `file`) |
| GET/POST/DELETE | `/api/hosts` · `/api/hosts/{id}` | hosts SSH |
| POST | `/api/hosts/check` · `/api/hosts/exec` | testar conexão · rodar comando |
| WS | `/ws/terminal?cols=&rows=&host_id=` | terminal interativo |

Exemplo fora do navegador:

```bash
TOKEN=$(curl -sk -X POST https://179.197.231.192:7443/api/auth/login \
  -H 'Content-Type: application/json' \
  -d '{"username":"admin","password":"SUA_SENHA"}' | python3 -c 'import sys,json;print(json.load(sys.stdin)["token"])')

curl -sk -H "Authorization: Bearer $TOKEN" \
  -o delta-cpa.tar.gz \
  "https://179.197.231.192:7443/api/projects/delta-cpa/download?root=/opt&fmt=tar.gz&full=false"
```

---

## Verificado em 05/09/2026

Login e rejeição de senha errada. Sessão obrigatória em todas as rotas (401 sem cookie).
Travessia de caminho bloqueada. Download `.tar.gz` e `.zip` com exclusões aplicadas (74
arquivos, 0 de `.venv`). `download-all` em streaming a ~32 MB/s. Terminal SSH abrindo PTY
como root, com redimensionamento. `reload` do nginx pelo painel. Recusa de serviço fora da
lista. Leitura, visualização e envio de arquivos. Auditoria gravando tudo.

Corrigidos durante o redesenho:

- **Processos apareciam todos com 0,0% de CPU** — o psutil precisa de duas amostras; agora
  `top_processes` zera o contador, espera 0,25 s e mede. A espera roda em thread
  (`asyncio.to_thread`), senão travaria o laço de eventos e engasgaria os terminais abertos
  naquele worker.
- **Voltar/avançar do navegador não trocava de tela** — faltava ouvir `hashchange`.
- **A régua de vitais sumia** ao abrir direto numa tela que não fosse a Visão geral; agora
  ela carrega no início, qualquer que seja a tela.
- **Rolagem horizontal no celular** — itens de grid nascem com `min-width:auto` e eram
  esticados pelas tabelas; resolvido com `min-width:0` na cadeia inteira.
- **SVG sem tamanho base** estourava para 300×150 dentro dos títulos.
