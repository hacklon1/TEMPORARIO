import { NavLink, useLocation } from "react-router-dom";
import { LayoutDashboard, Wallet, Users, LogOut, Sparkles, BarChart3, Download, Table as TableIcon } from "lucide-react";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarHeader,
  SidebarFooter,
  useSidebar,
} from "@/components/ui/sidebar";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";

export function AppSidebar() {
  const { state } = useSidebar();
  const collapsed = state === "collapsed";
  const { pathname } = useLocation();
  const { isAdmin, isDono, operatorType, username, signOut, user } = useAuth();

  // Dono e Admin não têm categoria; para o Operador ela vai junto do cargo.
  const cargo = isDono
    ? "Dono"
    : isAdmin
      ? "Administrador"
      : operatorType === "montante"
        ? "Operador de Montante"
        : operatorType === "contas"
          ? "Operador de Contas"
          : "Operador BI";

  const items = [
    { title: "Dashboard", url: "/", icon: LayoutDashboard, show: true },
    { title: "Operações", url: "/operations", icon: Wallet, show: true },
    { title: "Exportar", url: "/export", icon: Download, show: true },
    { title: "Tabelas", url: "/tables", icon: TableIcon, show: true },
    { title: "Relatórios", url: "/reports", icon: BarChart3, show: isAdmin },
    { title: "Usuários", url: "/users", icon: Users, show: isAdmin },
  ].filter((i) => i.show);

  const isActive = (path: string) =>
    path === "/" ? pathname === "/" : pathname.startsWith(path);

  return (
    <Sidebar collapsible="icon" className="border-r border-sidebar-border">
      <SidebarHeader className="border-b border-sidebar-border">
        <div className="flex items-center gap-3 px-2 py-3">
          <div className="relative flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-gradient-primary shadow-glow">
            <Sparkles className="h-5 w-5 text-primary-foreground" />
          </div>
          {!collapsed && (
            <div className="flex flex-col leading-tight">
              <span className="text-lg font-extrabold tracking-tight text-gradient">DB</span>
              <span className="text-[10px] uppercase tracking-widest text-muted-foreground">
                Fintech Suite
              </span>
            </div>
          )}
        </div>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {items.map((item) => (
                <SidebarMenuItem key={item.title}>
                  <SidebarMenuButton asChild isActive={isActive(item.url)}>
                    <NavLink
                      to={item.url}
                      end={item.url === "/"}
                      className={({ isActive: a }) =>
                        `flex items-center gap-3 rounded-lg px-3 py-2.5 transition-all ${
                          a
                            ? "bg-primary/15 text-primary shadow-[inset_0_0_0_1px_hsl(var(--primary)/0.4)]"
                            : "hover:bg-sidebar-accent"
                        }`
                      }
                    >
                      <item.icon className="h-4 w-4" />
                      {!collapsed && <span className="font-medium">{item.title}</span>}
                    </NavLink>
                  </SidebarMenuButton>
                </SidebarMenuItem>
              ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter className="border-t border-sidebar-border p-2">
        {!collapsed && user && (
          <div className="px-2 pb-2 pt-1">
            <p className="truncate text-xs font-semibold text-foreground">
              {username || user.email}
            </p>
            <p className="text-[10px] uppercase tracking-wider text-primary">
              {cargo}
            </p>
          </div>
        )}
        <Button
          variant="ghost"
          size="sm"
          onClick={signOut}
          className="w-full justify-start gap-2 text-muted-foreground hover:text-destructive"
        >
          <LogOut className="h-4 w-4" />
          {!collapsed && "Sair"}
        </Button>
      </SidebarFooter>
    </Sidebar>
  );
}
