
-- 1) salario_contas in operations
ALTER TABLE public.operations
  ADD COLUMN IF NOT EXISTS salario_contas numeric NOT NULL DEFAULT 0;

-- 2) global PIX template
ALTER TABLE public.app_settings
  ADD COLUMN IF NOT EXISTS pix_template_global text;

-- 3) image_shortcuts
CREATE TABLE IF NOT EXISTS public.image_shortcuts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo text NOT NULL,
  image_url text NOT NULL,
  ordem integer NOT NULL DEFAULT 0,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.image_shortcuts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated view shortcuts"
  ON public.image_shortcuts FOR SELECT
  TO authenticated USING (true);

CREATE POLICY "Admins insert shortcuts"
  ON public.image_shortcuts FOR INSERT
  TO authenticated WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins update shortcuts"
  ON public.image_shortcuts FOR UPDATE
  TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins delete shortcuts"
  ON public.image_shortcuts FOR DELETE
  TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE TRIGGER trg_image_shortcuts_updated_at
  BEFORE UPDATE ON public.image_shortcuts
  FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Bucket for shortcut images (public read)
INSERT INTO storage.buckets (id, name, public)
VALUES ('shortcut-images', 'shortcut-images', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public read shortcut-images"
  ON storage.objects FOR SELECT
  USING (bucket_id = 'shortcut-images');

CREATE POLICY "Admins upload shortcut-images"
  ON storage.objects FOR INSERT
  TO authenticated
  WITH CHECK (bucket_id = 'shortcut-images' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins update shortcut-images"
  ON storage.objects FOR UPDATE
  TO authenticated
  USING (bucket_id = 'shortcut-images' AND public.has_role(auth.uid(), 'admin'));

CREATE POLICY "Admins delete shortcut-images"
  ON storage.objects FOR DELETE
  TO authenticated
  USING (bucket_id = 'shortcut-images' AND public.has_role(auth.uid(), 'admin'));

-- 4) Operation audit
CREATE TABLE IF NOT EXISTS public.operation_audit (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  operation_id uuid NOT NULL,
  user_id uuid NOT NULL,
  acao text NOT NULL CHECK (acao IN ('EDITADA','APAGADA')),
  snapshot jsonb NOT NULL,
  changed_by uuid,
  changed_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.operation_audit ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Admins view audit"
  ON public.operation_audit FOR SELECT
  TO authenticated USING (public.has_role(auth.uid(), 'admin'));

CREATE OR REPLACE FUNCTION public.log_operation_change()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF TG_OP = 'UPDATE' THEN
    INSERT INTO public.operation_audit (operation_id, user_id, acao, snapshot, changed_by)
    VALUES (NEW.id, NEW.user_id, 'EDITADA', to_jsonb(NEW), auth.uid());
    RETURN NEW;
  ELSIF TG_OP = 'DELETE' THEN
    INSERT INTO public.operation_audit (operation_id, user_id, acao, snapshot, changed_by)
    VALUES (OLD.id, OLD.user_id, 'APAGADA', to_jsonb(OLD), auth.uid());
    RETURN OLD;
  END IF;
  RETURN NULL;
END;
$$;

DROP TRIGGER IF EXISTS trg_log_operation_update ON public.operations;
CREATE TRIGGER trg_log_operation_update
  AFTER UPDATE ON public.operations
  FOR EACH ROW EXECUTE FUNCTION public.log_operation_change();

DROP TRIGGER IF EXISTS trg_log_operation_delete ON public.operations;
CREATE TRIGGER trg_log_operation_delete
  AFTER DELETE ON public.operations
  FOR EACH ROW EXECUTE FUNCTION public.log_operation_change();
