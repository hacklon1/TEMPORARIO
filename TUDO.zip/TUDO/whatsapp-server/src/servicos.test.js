// Validação de serviço em 3 passos.
//
// Duas metades: as regras PURAS de casamento (sem disco) e o ciclo completo
// passando pelo handler, com o db num diretório temporário — o db.json de
// produção não pode ser tocado por teste.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

import {
  configServicos, detectarComprovante, citacaoDe, valoresBatem,
  escolherAtendimento, escolherComprovante, contasDaResposta, tipoDaResposta, STATUS,
} from './servicos.js';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-servicos-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb, getConfigSessao } = await import('./db.js');
const { processMessage } = await import('./handler.js');
const { limparCacheMembros } = await import('./membros.js');
const { relatorioServicos } = await import('./store.js');

loadDb();

const CFG = configServicos({});

/* ═══════════ Regras puras ═══════════ */

test('config: padrões são 60 min e 120 min, modo cascata', () => {
  assert.equal(CFG.janelaAtendimentoMin, 60);
  assert.equal(CFG.janelaComprovanteMin, 120);
  assert.equal(CFG.modo, 'cascata');
  assert.equal(CFG.janelaComprovanteMs, 120 * 60_000);
  assert.equal(CFG.ligado, true);
});

test('comprovante: imagem e PDF valem; figurinha e áudio não', () => {
  assert.deepEqual(detectarComprovante({ message: { imageMessage: { mimetype: 'image/jpeg' } } }).tipo, 'imagem');
  assert.equal(
    detectarComprovante({ message: { documentMessage: { mimetype: 'application/pdf', fileName: 'comprovante.pdf' } } }).tipo,
    'pdf',
  );
  // Só o nome do arquivo já basta (nem todo celular manda o mimetype certo).
  assert.equal(detectarComprovante({ message: { documentMessage: { fileName: 'recibo.PDF' } } }).tipo, 'pdf');
  assert.equal(detectarComprovante({ message: { stickerMessage: {} } }), null);
  assert.equal(detectarComprovante({ message: { audioMessage: {} } }), null);
  assert.equal(detectarComprovante({ message: { conversation: 'oi' } }), null);
});

test('comprovante: descasca os embrulhos do Baileys (documento com legenda, ver-uma-vez)', () => {
  const doc = {
    message: {
      documentWithCaptionMessage: {
        message: { documentMessage: { mimetype: 'application/pdf', caption: 'pago' } },
      },
    },
  };
  assert.equal(detectarComprovante(doc).tipo, 'pdf');
  assert.equal(detectarComprovante(doc).legenda, 'pago');

  const efemera = { message: { ephemeralMessage: { message: { imageMessage: { mimetype: 'image/png' } } } } };
  assert.equal(detectarComprovante(efemera).tipo, 'imagem');
});

test('citação: lê o stanzaId de qualquer tipo de mensagem', () => {
  const texto = { message: { extendedTextMessage: { text: 'ok', contextInfo: { stanzaId: 'ABC', participant: '1@lid' } } } };
  assert.deepEqual(citacaoDe(texto), { stanzaId: 'ABC', participant: '1@lid' });
  const imagem = { message: { imageMessage: { contextInfo: { stanzaId: 'XYZ' } } } };
  assert.equal(citacaoDe(imagem).stanzaId, 'XYZ');
  assert.equal(citacaoDe({ message: { conversation: 'sem citação' } }), null);
});

test('valores batem: montante igual, ou quantidade de contas igual num pedido de conta', () => {
  assert.equal(valoresBatem({ montantePedido: 400 }, { montante: 400 }), true);
  assert.equal(valoresBatem({ montantePedido: 400 }, { montante: 300 }), false);
  assert.equal(valoresBatem({ tipo: 'conta', contasPedidas: 7 }, { contasQtd: 7 }), true);
  // Pedido de montante com divisão ("520 em 4") não casa pelo 4.
  assert.equal(valoresBatem({ tipo: 'montante', montantePedido: 520, contasPedidas: 4 }, { contasQtd: 4 }), false);
  assert.equal(valoresBatem({ montantePedido: 0 }, { montante: 0 }), false);
});

test('contas da resposta: o "Até N contas" anunciado, senão os rótulos "Valor:"', () => {
  assert.equal(contasDaResposta({ contasOferecidas: 2, contasQtd: 1 }), 2);
  // Histórico antigo (sem o campo gravado): relê do texto da mensagem.
  assert.equal(contasDaResposta({ text: '🔸 Montante: 200\n💸 R$ 40\n📊 𝗔𝘁é 2 𝗰𝗼𝗻𝘁𝗮𝘀' }), 2);
  assert.equal(contasDaResposta({ contasQtd: 3, text: 'Valor: 10 Valor: 10 Valor: 10' }), 3);
  assert.equal(contasDaResposta({ montante: 300 }), 0);
});

test('valores batem: pedido de conta casa com o "Até N contas" da resposta', () => {
  // Era esse o buraco: a resposta do Operador nunca traz "7 contas" como
  // rótulo de valor, então pedido de conta jamais casava por valor.
  assert.equal(valoresBatem({ tipo: 'conta', contasPedidas: 2 }, { montante: 200, contasQtd: 1, contasOferecidas: 2 }), true);
  assert.equal(valoresBatem({ tipo: 'conta', contasPedidas: 5 }, { montante: 200, contasQtd: 1, contasOferecidas: 2 }), false);
  // O "Até 2 contas" não transforma pedido de montante em pedido de conta.
  assert.equal(valoresBatem({ tipo: 'montante', montantePedido: 520, contasPedidas: 2 }, { contasOferecidas: 2 }), false);
});

test('tipo da resposta: o montante manda; sem montante, o "Valor" é conta', () => {
  assert.equal(tipoDaResposta({ montante: 200, contasOferecidas: 2 }), 'montante');
  assert.equal(tipoDaResposta({ montante: 0, contasQtd: 1, contasTotal: 25 }), 'conta');
  assert.equal(tipoDaResposta({ montante: 0, contasQtd: 0 }), null);
});

const AGORA = Date.parse('2026-08-27T12:00:00.000Z');
const min = (n) => new Date(AGORA - n * 60_000).toISOString();

function pedidoAberto(over = {}) {
  return {
    id: 's1', groupId: 'G', status: STATUS.AGUARDANDO_ATENDIMENTO,
    pedidoMsgId: 'M1', pedidoTs: min(10), brogueiraId: 'B@lid',
    tipo: 'montante', montantePedido: 300, contasPedidas: 2,
    ...over,
  };
}

test('passo 2: a citação vence o valor e a proximidade', () => {
  const abertos = [
    pedidoAberto({ id: 'antigo', pedidoMsgId: 'M-ANTIGO', pedidoTs: min(30), montantePedido: 500 }),
    pedidoAberto({ id: 'recente', pedidoMsgId: 'M-RECENTE', pedidoTs: min(2), montantePedido: 100 }),
  ];
  const entrada = { montante: 100, contasQtd: 0, operatorId: 'OP@lid' };
  const escolha = escolherAtendimento(abertos, {
    entrada, citacao: { stanzaId: 'M-ANTIGO' }, agora: AGORA, cfg: CFG,
  });
  assert.equal(escolha.servico.id, 'antigo');
  assert.equal(escolha.casamento, 'citacao');
});

test('passo 2: sem citação, casa pelo valor — mesmo não sendo o mais recente', () => {
  const abertos = [
    pedidoAberto({ id: 'bate', pedidoTs: min(30), montantePedido: 500 }),
    pedidoAberto({ id: 'recente', pedidoTs: min(2), montantePedido: 100 }),
  ];
  const escolha = escolherAtendimento(abertos, {
    entrada: { montante: 500, operatorId: 'OP@lid' }, agora: AGORA, cfg: CFG,
  });
  assert.equal(escolha.servico.id, 'bate');
  assert.equal(escolha.casamento, 'valor');
});

test('passo 2: sem citação e sem valor batendo, fica com o pedido em aberto mais recente', () => {
  const abertos = [
    pedidoAberto({ id: 'antigo', pedidoTs: min(30) }),
    pedidoAberto({ id: 'recente', pedidoTs: min(2) }),
  ];
  const escolha = escolherAtendimento(abertos, {
    entrada: { montante: 77, operatorId: 'OP@lid' }, agora: AGORA, cfg: CFG,
  });
  assert.equal(escolha.servico.id, 'recente');
  assert.equal(escolha.casamento, 'tempo');
});

test('passo 2: na proximidade, a oferta de conta procura pedido de CONTA', () => {
  // Sem o desempate por tipo, a oferta de conta levava o pedido de montante só
  // por ser o mais recente — e o pedido de conta expirava "sem atendimento".
  const abertos = [
    pedidoAberto({ id: 'conta', tipo: 'conta', montantePedido: 0, contasPedidas: 9, pedidoTs: min(20) }),
    pedidoAberto({ id: 'montante', pedidoTs: min(2), montantePedido: 700 }),
  ];
  const oferta = { montante: 0, contasQtd: 1, contasTotal: 25, operatorId: 'OP@lid' };
  const escolha = escolherAtendimento(abertos, { entrada: oferta, agora: AGORA, cfg: CFG });
  assert.equal(escolha.servico.id, 'conta');
  assert.equal(escolha.casamento, 'tempo');

  // E a oferta de montante continua indo para o pedido de montante.
  const inverso = escolherAtendimento(abertos, {
    entrada: { montante: 700, operatorId: 'OP@lid' }, agora: AGORA, cfg: CFG,
  });
  assert.equal(inverso.servico.id, 'montante');
});

test('passo 2: sem pedido do mesmo tipo, ainda vale o mais recente', () => {
  const abertos = [
    pedidoAberto({ id: 'antigo', pedidoTs: min(30) }),
    pedidoAberto({ id: 'recente', pedidoTs: min(2) }),
  ];
  const escolha = escolherAtendimento(abertos, {
    entrada: { montante: 0, contasQtd: 1, contasTotal: 25, operatorId: 'OP@lid' }, agora: AGORA, cfg: CFG,
  });
  assert.equal(escolha.servico.id, 'recente');
  assert.equal(escolha.casamento, 'tempo');
});

test('passo 2: fora do prazo não casa de jeito nenhum (nem com citação)', () => {
  const abertos = [pedidoAberto({ pedidoTs: min(90) })]; // prazo é 60 min
  assert.equal(escolherAtendimento(abertos, { entrada: { montante: 300 }, agora: AGORA, cfg: CFG }), null);
  assert.equal(
    escolherAtendimento(abertos, { entrada: { montante: 300 }, citacao: { stanzaId: 'M1' }, agora: AGORA, cfg: CFG }),
    null,
  );
});

test('passo 2: o Operador não fecha o próprio pedido', () => {
  const abertos = [pedidoAberto({ brogueiraId: 'OP@lid' })];
  assert.equal(
    escolherAtendimento(abertos, { entrada: { montante: 300, operatorId: 'OP@lid' }, agora: AGORA, cfg: CFG }),
    null,
  );
});

test('passo 2: modo "citacao" recusa valor e proximidade; modo "valor" recusa proximidade', () => {
  const abertos = [pedidoAberto()];
  const soCitacao = configServicos({ servicosModoCasamento: 'citacao' });
  const soValor = configServicos({ servicosModoCasamento: 'valor' });
  const entrada = { montante: 300, operatorId: 'OP@lid' };
  assert.equal(escolherAtendimento(abertos, { entrada, agora: AGORA, cfg: soCitacao }), null);
  assert.equal(escolherAtendimento(abertos, { entrada, agora: AGORA, cfg: soValor }).casamento, 'valor');
  assert.equal(
    escolherAtendimento(abertos, { entrada: { montante: 9, operatorId: 'OP@lid' }, agora: AGORA, cfg: soValor }),
    null,
  );
});

test('passo 3: comprovante fecha o atendimento mais recente dentro do prazo', () => {
  const pendentes = [
    { id: 'a', atendimento: { ts: min(100), msgId: 'MA' } },
    { id: 'b', atendimento: { ts: min(10), msgId: 'MB' } },
  ];
  assert.equal(escolherComprovante(pendentes, { agora: AGORA, cfg: CFG }).servico.id, 'b');
  // Citando o atendimento antigo, é ele que fecha.
  assert.equal(
    escolherComprovante(pendentes, { citacao: { stanzaId: 'MA' }, agora: AGORA, cfg: CFG }).servico.id, 'a',
  );
  // Prazo do comprovante é 120 min.
  const velho = [{ id: 'c', atendimento: { ts: min(200), msgId: 'MC' } }];
  assert.equal(escolherComprovante(velho, { agora: AGORA, cfg: CFG }), null);
});

/* ═══════════ Ciclo completo pelo handler ═══════════ */

const GRUPO = '120363000000000000@g.us';
const OPERADOR = '111111111111111@lid';
const BROGUEIRA = '222222222222222@lid';
const OUTRA = '333333333333333@lid';

const MEMBROS = [
  { id: OPERADOR, lid: OPERADOR, pn: '5573981810457@s.whatsapp.net', admin: 'admin' },
  { id: BROGUEIRA, lid: BROGUEIRA, pn: '5573999999999@s.whatsapp.net', admin: null },
  { id: OUTRA, lid: OUTRA, pn: '5573988888888@s.whatsapp.net', admin: null },
];

const deps = () => ({
  reply: async () => {},
  getGroupName: async () => 'DB Contas e Montantes',
  getGroupMembers: async () => MEMBROS,
  getGroupParticipants: async () => [],
});

function preparar() {
  const db = getDb();
  db.messages = [];
  db.pedidos = [];
  db.servicos = [];
  db.stats = { totalMessages: 0, totalGroups: 0, totalMontante: 0, totalContasValor: 0, totalContasQtd: 0, startedAt: null };
  Object.assign(getConfigSessao(), { monitorMode: 'all', autoReplyEnabled: false, welcomeEnabled: false });
  Object.assign(db.config, {
    servicosEnabled: true,
    servicosJanelaAtendimentoMin: 60,
    servicosJanelaComprovanteMin: 120,
    servicosModoCasamento: 'cascata',
  });
  limparCacheMembros();
  return db;
}

const texto = (de, t, id) => ({
  key: { remoteJid: GRUPO, participant: de, fromMe: false, id },
  pushName: de === OPERADOR ? 'Operador' : 'Brogueira',
  message: { conversation: t },
});

const imagem = (de, id) => ({
  key: { remoteJid: GRUPO, participant: de, fromMe: false, id },
  pushName: de === OPERADOR ? 'Operador' : 'Brogueira',
  message: { imageMessage: { mimetype: 'image/jpeg' } },
});

const PEDIDO = 'https://okokathena.win/?id=393339299\n400 montante 2 contas';
const ATENDIMENTO = '✅ ATENDIMENTO DE MONTANTE\n𝗠𝗼𝗻𝘁𝗮𝗻𝘁𝗲: R$ 400,00\n💸 𝗩𝗮𝗹𝗼𝗿 R$ 8,00';

test('ciclo completo: pedido → atendimento → comprovante vira serviço validado', async () => {
  const db = preparar();
  await processMessage(texto(BROGUEIRA, PEDIDO, 'M1'), deps());
  assert.equal(db.servicos.length, 1);
  assert.equal(db.servicos[0].status, STATUS.AGUARDANDO_ATENDIMENTO);
  assert.equal(db.servicos[0].montantePedido, 400);

  await processMessage(texto(OPERADOR, ATENDIMENTO, 'M2'), deps());
  assert.equal(db.servicos[0].status, STATUS.AGUARDANDO_COMPROVANTE);
  assert.equal(db.servicos[0].atendimento.operatorId, OPERADOR);
  // O valor confere com o pedido — não precisou de citação nem de proximidade.
  assert.equal(db.servicos[0].atendimento.casamento, 'valor');
  // O lançamento continua sendo gravado normalmente (quadro antigo intacto).
  assert.equal(db.messages.length, 1);
  assert.equal(db.messages[0].montante, 400);

  await processMessage(imagem(BROGUEIRA, 'M3'), deps());
  assert.equal(db.servicos[0].status, STATUS.VALIDADO);
  assert.equal(db.servicos[0].comprovante.tipo, 'imagem');
  assert.ok(db.servicos[0].validadoEm);

  const rel = relatorioServicos('today');
  assert.equal(rel.resumo.validados, 1);
  assert.equal(rel.resumo.montanteValidado, 400);
  assert.equal(rel.resumo.taxa, 1);
  assert.equal(rel.operadores[0].nome, 'Operador');
  assert.equal(rel.operadores[0].montanteValidado, 400);
  assert.equal(rel.servicos[0].brogueiraNome, 'Brogueira');
});

const PEDIDO_CONTA = 'https://670win.me/?id=357497224\n7 contas de 10';
const ATENDIMENTO_CONTA = '📌 PIX CELULAR\n💠 CHAVE 71992378148\n💸 𝗩𝗮𝗹𝗼𝗿: R$ 35,00\n📊 𝗔𝘁é 7 𝗰𝗼𝗻𝘁𝗮𝘀';

test('ciclo completo de CONTA: valida e conta as contas do pedido', async () => {
  const db = preparar();
  await processMessage(texto(BROGUEIRA, PEDIDO_CONTA, 'C1'), deps());
  assert.equal(db.servicos[0].tipo, 'conta');
  assert.equal(db.servicos[0].contasPedidas, 7);

  await processMessage(texto(OPERADOR, ATENDIMENTO_CONTA, 'C2'), deps());
  assert.equal(db.servicos[0].status, STATUS.AGUARDANDO_COMPROVANTE);
  // Casou por VALOR: as 7 contas pedidas são as 7 que ele anunciou entregar.
  assert.equal(db.servicos[0].atendimento.casamento, 'valor');
  assert.equal(db.messages[0].contasOferecidas, 7);

  await processMessage(imagem(BROGUEIRA, 'C3'), deps());
  assert.equal(db.servicos[0].status, STATUS.VALIDADO);

  const rel = relatorioServicos('today');
  assert.equal(rel.resumo.validados, 1);
  // As contas validadas são as 7 PEDIDAS — não o único rótulo "Valor:" da
  // resposta, que é o preço (R$ 35) e não uma conta.
  assert.equal(rel.resumo.contasValidadasQtd, 7);
  assert.equal(rel.resumo.contasValidadasValor, 35);
  assert.equal(rel.operadores[0].contasQtd, 7);
  assert.equal(rel.servicos[0].contasQtd, 7);
  assert.equal(rel.servicos[0].contasCotadas, 1);
});

test('comprovante de OUTRA brogueira não valida o serviço alheio', async () => {
  const db = preparar();
  await processMessage(texto(BROGUEIRA, PEDIDO, 'M1'), deps());
  await processMessage(texto(OPERADOR, ATENDIMENTO, 'M2'), deps());
  await processMessage(imagem(OUTRA, 'M3'), deps());
  assert.equal(db.servicos[0].status, STATUS.AGUARDANDO_COMPROVANTE);

  const rel = relatorioServicos('today');
  assert.equal(rel.resumo.validados, 0);
  assert.equal(rel.resumo.atendidos, 1);
  assert.equal(rel.resumo.montanteNaoValidado, 400);
  assert.equal(rel.operadores[0].aguardando, 1);
});

test('mensagem financeira sem pedido em aberto não inventa serviço', async () => {
  const db = preparar();
  await processMessage(texto(OPERADOR, ATENDIMENTO, 'M2'), deps());
  assert.equal(db.messages.length, 1); // o lançamento entra
  assert.equal(db.servicos.length, 0); // mas não há serviço nenhum
});

test('o mesmo comprovante não valida dois serviços (mesmo id de mensagem)', async () => {
  const db = preparar();
  await processMessage(texto(BROGUEIRA, PEDIDO, 'M1'), deps());
  await processMessage(texto(OPERADOR, ATENDIMENTO, 'M2'), deps());
  await processMessage(texto(BROGUEIRA, 'https://670win.me/?id=1\n7 contas', 'M4'), deps());
  await processMessage(texto(OPERADOR, '💸 𝗩𝗮𝗹𝗼𝗿 R$ 6,00\nValor R$ 6,00\nValor R$ 6,00\nValor R$ 6,00\nValor R$ 6,00\nValor R$ 6,00\nValor R$ 6,00', 'M5'), deps());
  assert.equal(db.servicos.filter((s) => s.status === STATUS.AGUARDANDO_COMPROVANTE).length, 2);

  await processMessage(imagem(BROGUEIRA, 'M3'), deps());
  await processMessage(imagem(BROGUEIRA, 'M3'), deps()); // reentrega da mesma mensagem
  assert.equal(db.servicos.filter((s) => s.status === STATUS.VALIDADO).length, 1);
});

test('pedido de Operador não abre serviço (é divulgação, não pedido)', async () => {
  const db = preparar();
  await processMessage(texto(OPERADOR, 'https://okokathena.win/?id=1\n400 montante', 'M9'), deps());
  assert.equal(db.pedidos.length, 1);
  assert.equal(db.servicos.length, 0);
});

test('desligado em Configurações, nada é casado (mas o pedido continua sendo gravado)', async () => {
  const db = preparar();
  db.config.servicosEnabled = false;
  await processMessage(texto(BROGUEIRA, PEDIDO, 'M1'), deps());
  await processMessage(texto(OPERADOR, ATENDIMENTO, 'M2'), deps());
  await processMessage(imagem(BROGUEIRA, 'M3'), deps());
  assert.equal(db.pedidos.length, 1);
  assert.equal(db.servicos.length, 1);
  assert.equal(db.servicos[0].status, STATUS.AGUARDANDO_ATENDIMENTO);
});
