import { useEffect, useState } from "react";
import { Calculator as CalculatorIcon, Copy } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatBRL } from "@/lib/format";
import { cn } from "@/lib/utils";
import { maxContasFromMontante, distribuirAleatorio } from "@/lib/contas";
import { toast } from "sonner";

export function DepositSplitter() {
  const [divTotal, setDivTotal] = useState("");
  const [divCount, setDivCount] = useState("5");
  const [divMin, setDivMin] = useState<string>(() => {
    if (typeof window === "undefined") return "60";
    return localStorage.getItem("div:min") ?? "60";
  });
  const [divValues, setDivValues] = useState<number[]>([]);

  useEffect(() => {
    try { localStorage.setItem("div:min", divMin); } catch {}
  }, [divMin]);

  const divCountNum = Math.max(1, Math.floor(Number(divCount) || 0));
  const sugestaoContas = maxContasFromMontante(Number(divTotal) || 0);
  const excedeSugestao = divCountNum > sugestaoContas && (Number(divTotal) || 0) > 0;

  const distribuir = () => {
    const total = Number(divTotal) || 0;
    const n = divCountNum;
    const m = Math.max(1, Math.floor(Number(divMin) || 1));
    setDivValues(distribuirAleatorio(total, n, m));
  };

  const copiarDistribuicao = async () => {
    if (!divValues.length) return;
    const total = divValues.reduce((a, b) => a + b, 0);
    const txt =
      divValues.map((v, i) => `Conta ${i + 1}: ${formatBRL(v)}`).join("\n") +
      `\nTotal: ${formatBRL(total)}`;
    try {
      await navigator.clipboard.writeText(txt);
      toast.success("Copiado para a área de transferência");
    } catch {
      toast.error("Não foi possível copiar");
    }
  };

  return (
    <div className="glass-strong space-y-4 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 to-primary/5 p-4">
      <div className="flex items-center gap-2">
        <CalculatorIcon className="h-4 w-4 text-primary" />
        <h3 className="text-xs font-bold uppercase tracking-wider text-primary">
          Divisor de depósito
        </h3>
      </div>

      <div className="space-y-3">
        <div className="space-y-1.5">
          <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Valor total</Label>
          <Input
            type="number"
            step="0.01"
            inputMode="decimal"
            placeholder="500"
            value={divTotal}
            onChange={(e) => setDivTotal(e.target.value)}
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Quantas contas</Label>
          <Input
            type="number"
            min={1}
            value={divCount}
            onChange={(e) => setDivCount(e.target.value)}
          />
          {(Number(divTotal) || 0) > 0 && (
            <p className={cn("text-[10px]", excedeSugestao ? "text-warning" : "text-muted-foreground")}>
              Sugestão para R$ {Number(divTotal) || 0}: até <span className="font-bold">{sugestaoContas}</span> {sugestaoContas === 1 ? "conta" : "contas"}
              {excedeSugestao && " — acima do recomendado"}
            </p>
          )}
          <div className="flex flex-wrap gap-1 pt-1">
            {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
              <button
                key={n}
                type="button"
                onClick={() => setDivCount(String(n))}
                className={cn(
                  "rounded-md border px-2 py-0.5 text-[10px] font-medium transition-colors",
                  divCount === String(n)
                    ? "border-primary bg-primary/20 text-primary"
                    : "border-border text-muted-foreground hover:border-primary/50",
                )}
              >
                {n}
              </button>
            ))}
          </div>
        </div>
        <div className="space-y-1.5">
          <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">
            Valor mínimo por conta (R$)
          </Label>
          <Input
            type="number"
            min={1}
            step="1"
            value={divMin}
            onChange={(e) => setDivMin(e.target.value)}
            placeholder="60"
          />
          <p className="text-[10px] text-muted-foreground">
            Padrão sugerido: <span className="font-semibold text-foreground">R$ 60</span>. Cada conta receberá pelo menos esse valor.
          </p>
        </div>
        <p className="text-[10px] text-muted-foreground">
          Cada clique em <span className="font-bold text-foreground">Distribuir</span> gera valores aleatórios diferentes.
        </p>
      </div>

      <Button type="button" size="sm" onClick={distribuir} className="w-full">
        <CalculatorIcon className="h-3 w-3" /> Distribuir
      </Button>

      {divValues.length > 0 && (
        <div className="space-y-2 rounded-xl border border-primary/20 bg-background/60 p-3">
          <div className="flex items-center justify-between">
            <span className="text-[10px] font-bold uppercase tracking-wider text-primary">Resultado</span>
            <Button type="button" size="sm" variant="ghost" onClick={copiarDistribuicao} className="h-6 px-1.5">
              <Copy className="h-3 w-3" />
            </Button>
          </div>
          <div className="space-y-1">
            {divValues.map((v, i) => (
              <div key={i} className="flex items-center justify-between rounded-lg border border-border bg-card px-2 py-1.5 text-xs">
                <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-primary/15 text-[10px] font-bold text-primary">
                  {i + 1}
                </span>
                <span className="number-tabular font-bold">{formatBRL(v)}</span>
              </div>
            ))}
          </div>
          <div className="flex items-center justify-between border-t border-border/50 pt-2 text-[11px]">
            <span className="text-muted-foreground">Soma</span>
            <span className="number-tabular font-bold">
              {formatBRL(divValues.reduce((a, b) => a + b, 0))}
            </span>
          </div>
        </div>
      )}
    </div>
  );
}
