# Diagnóstico do coletor — `179.197.231.192:8080`

> **HISTÓRICO — resolvido em 2026-09-01.** O coletor trocou de fonte de dados e
> corrigiu os itens 1 (dados vazios), 4 (`/operadores` sob o middleware do
> painel, agora também em `/api/v1/relatorios/...`) e 5 (`data` inválida agora
> devolve 400). Os itens 2 e 3 (porta TLS-only e certificado autoassinado)
> ficaram para trás em 2026-09-02: o servidor passou a ser acessado por um
> túnel Cloudflare com certificado válido (secret `WHATSAPP_SERVER_URL`) e o
> pinning foi removido. Mantido como registro.

Levantado em **2026-09-01 07:52 (-03:00)**, sondando o servidor em produção de
fora, com o `RELATORIOS_TOKEN` válido. Tudo abaixo é resposta real do servidor,
não suposição. Nos comandos, `$TOKEN` é o `RELATORIOS_TOKEN`.

O lado do Dash já foi ajustado e está pronto — os problemas listados aqui são
**do coletor**.

---

## 1. BLOQUEADOR — os três relatórios vêm vazios em todos os dias

Varri 21 dias seguidos (2026-08-12 → 2026-09-01). **Todos** respondem 200 com
tudo zerado e listas vazias:

```
2026-09-01  totais:{pedidos:0,deposito:0,saque:0,blogueira:0,comissao:0,lucro:0}  itens:[]  operadores:[]
2026-08-31  totais:{pedidos:0,deposito:0,saque:0,blogueira:0,comissao:0,lucro:0}  itens:[]  operadores:[]
...  (idêntico nos 21 dias)
2026-08-12  totais:{pedidos:0,deposito:0,saque:0,blogueira:0,comissao:0,lucro:0}  itens:[]  operadores:[]
```

**Não é o filtro de data.** Com uma janela absurdamente larga o resultado é o
mesmo:

```bash
curl -sk -H "Authorization: Bearer $TOKEN" \
  "https://179.197.231.192:8080/api/relatorios/montante?data=2026-09-01&inicio=2000-01-01T00:00:00-03:00&fim=2030-01-01T00:00:00-03:00"
# "totais":{"pedidos":0,"deposito":0,"saque":0,"blogueira":0,"comissao":0,"lucro":0}
```

**A prova de que há um bug, e não apenas ausência de movimento:** a própria
especificação diz que `/operadores` devolve **todos os usuários cadastrados**,
inclusive quem não operou no dia. Ela devolve `"operadores": []`. Ou o cadastro
está vazio, ou a consulta dos operadores está presa ao mesmo filtro do
movimento — e nesse caso o problema é o mesmo que zera Montante e Contas.

**O que investigar no coletor, nesta ordem:**

1. A rota de relatórios está lendo o **mesmo banco/tenant** que o painel? O
   painel em `/` tem tela de operadores, montante e contas — compare a consulta
   das duas.
2. O filtro `inicio <= timestamp < fim` está comparando **o mesmo tipo/fuso**
   dos registros gravados? Comparar `timestamptz` com string, ou `DATE` com
   `DATETIME`, zera tudo silenciosamente.
3. A consulta de `/operadores` deve listar o **cadastro** (LEFT JOIN com o
   movimento do dia), não INNER JOIN com as operações — senão dia parado devolve
   lista vazia, que é exatamente o sintoma.

Enquanto isso não fechar, os itens "campo `comissao` em contas", "categoria" e
"usuario_removido" **não puderam ser verificados** — nunca chega uma linha.

---

## 2. A porta 8080 não fala HTTP puro (a orientação que circulou está errada)

```bash
curl -v "http://179.197.231.192:8080/api/relatorios/montante"
# * Established connection to 179.197.231.192 port 8080
# * Empty reply from server
# curl: (52) Empty reply from server
```

Foi passado ao time do Dash que bastava usar `http://` para escapar do problema
de certificado. **Não funciona**: a porta só responde TLS. Quem configurar o
secret com `http://` fica sem relatório nenhum.

Escolham uma das duas e avisem:

- expor HTTP puro numa porta separada (só faz sentido em rede fechada); ou
- manter só HTTPS — nesse caso ver o item 3.

---

## 3. Certificado autoassinado emitido para IP

```
subject = CN=179.197.231.192
issuer  = CN=179.197.231.192      <- autoassinado
validade: 2026-07-23 → 2036-07-20
SAN: IP Address:179.197.231.192
```

O `fetch` do Deno (Supabase Edge Functions) recusa emissor desconhecido e **não
tem flag para ignorar** em runtime hospedado.

Contorno já aplicado no Dash: o PEM foi fixado (pinning) via secret
`RELATORIOS_CA_CERT`. Isso funciona, mas **quebra silenciosamente no dia em que
o coletor gerar outro certificado** — se isso acontecer, avisem.

Correção definitiva do lado do coletor: um domínio com certificado válido
(Let's Encrypt) ou um Cloudflare Tunnel na frente. Aí o pinning some.

---

## 4. `/api/relatorios/operadores` está atrás do middleware do painel

As três rotas com token correto devolvem o contrato certo. O problema aparece
no erro — e ele denuncia que a rota está sob outra guarda:

| Rota | Sem token / token errado |
| --- | --- |
| `/api/relatorios/montante` | `401` `{"error":"unauthorized"}` ✅ contrato |
| `/api/relatorios/contas` | `401` `{"error":"unauthorized"}` ✅ contrato |
| `/api/relatorios/operadores` | `401` `{"ok":false,"error":"não autorizado"}` ⚠️ formato do painel |

Todo o resto de `/api/*` responde o mesmo `{"ok":false,"error":"não autorizado"}`
— ou seja, `/operadores` está caindo no middleware de sessão do painel, e não no
guard do token de relatórios como as outras duas.

Hoje isso não derruba o Dash (ele decide pelo **status** 401/403, não pelo corpo),
mas é frágil: qualquer mudança na ordem das rotas do Express pode fazer o painel
capturar a rota inteira e devolver **200 com o formato dele**, que o Dash vai
rejeitar como fora do contrato.

**Correção sugerida:** registrar as três rotas de relatório no mesmo router,
antes do middleware do painel, e devolver `{"error":"unauthorized"}` nas três.
Se der para versionar (`/api/v1/relatorios/...`), melhor ainda — separa de vez
do namespace do painel.

---

## 5. O parâmetro `data` não é validado

```bash
curl -sk -H "Authorization: Bearer $TOKEN" ".../api/relatorios/montante?data=abacaxi"
# 200 {"data":"2026-09-01", ...}      <- ignorou e usou hoje

curl -sk -H "Authorization: Bearer $TOKEN" ".../api/relatorios/montante?data=2026-13-45"
# 200 {"data":"2026-13-45", ...}      <- ecoou uma data que não existe
```

Data inválida devendo virar `400 {"error":"..."}`. Ecoar `2026-13-45` como se
fosse um dia real é pior que o erro: some com a falha em vez de mostrá-la.

---

## 6. A especificação que circulou não bate com o que o servidor emite

O servidor está **certo**; o texto que chegou ao Dash é que está errado. Vale
corrigir a documentação para não induzir o próximo integrador ao erro:

| Circulou como | O servidor emite |
| --- | --- |
| `totais.pendidos` | `totais.pedidos` |
| `totais.bloqueio` | `totais.blogueira` |
| `por_hora` dentro de `totais` | `por_hora` na **raiz** do objeto |

---

## O que está correto (verificado, não mexer)

- `Content-Type: application/json; charset=utf-8` nas três rotas; `/health` → `{"ok":true}`.
- `por_hora` com as **24 horas** do dia operacional, na ordem `05:00` → `04:00`,
  zeradas inclusive. Confirmado: 24 entradas, primeira `05:00`, última `04:00`.
- Timestamps em ISO 8601 com offset `-03:00` (`gerado_em`, `atualizado_em`).
- Dia sem movimento devolve 200 com zeros, nunca 404.
- Resposta bem abaixo do limite de 15s do Dash (~75 ms, dominado pela latência
  de rede).

---

## Como reproduzir tudo

```bash
TOKEN=<RELATORIOS_TOKEN>
B=https://179.197.231.192:8080

# 1. vazio em qualquer dia
for i in $(seq 0 20); do D=$(date -d "-$i day" +%Y-%m-%d)
  echo "$D $(curl -sk -H "Authorization: Bearer $TOKEN" "$B/api/relatorios/montante?data=$D" | grep -o '"totais":{[^}]*}')"
done

# 2. HTTP puro não responde
curl -v "http://179.197.231.192:8080/api/relatorios/montante"

# 3. certificado autoassinado
echo | openssl s_client -connect 179.197.231.192:8080 2>/dev/null | openssl x509 -noout -subject -issuer -dates

# 4. formato do 401 diferente em /operadores
for r in montante contas operadores; do echo "$r: $(curl -sk "$B/api/relatorios/$r")"; done

# 5. data inválida aceita
curl -sk -H "Authorization: Bearer $TOKEN" "$B/api/relatorios/montante?data=2026-13-45"
```

---

## Prioridade

1. **Item 1** — sem dado, a integração não entrega nada. É o único bloqueador.
2. **Itens 2 e 3** — transporte. Hoje contornados no Dash, mas frágeis.
3. **Itens 4, 5 e 6** — robustez e documentação; não impedem o funcionamento.
