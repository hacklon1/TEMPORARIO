import { useEffect, useState, type FormEvent, Fragment } from "react";
import { Plus, Trash2, Pencil, FileText, Upload, Download, Copy, Image as ImageIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { toast } from "sonner";
import { formatDate } from "@/lib/format";
import { PixTemplatesAdmin } from "@/components/PixTemplatesAdmin";
import { PromocaoAdmin } from "@/components/PromocaoAdmin";


type AdminTable = {
  id: string;
  titulo: string;
  descricao: string | null;
  content_type: string; // 'file' | 'text'
  content_text: string | null;
  file_url: string | null;
  ordem: number;
  created_at: string;
};

export default function Tables() {
  const { isAdmin, user } = useAuth();
  const [items, setItems] = useState<AdminTable[]>([]);
  const [loading, setLoading] = useState(true);
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<AdminTable | null>(null);
  const [contentType, setContentType] = useState<"file" | "text">("file");
  const [titulo, setTitulo] = useState("");
  const [descricao, setDescricao] = useState("");
  const [ordem, setOrdem] = useState("0");
  const [file, setFile] = useState<File | null>(null);
  const [contentText, setContentText] = useState("");
  const [submitting, setSubmitting] = useState(false);
  const [preview, setPreview] = useState<AdminTable | null>(null);

  const fetchAll = async () => {
    setLoading(true);
    const { data, error } = await (supabase as any)
      .from("admin_tables")
      .select("*")
      .order("ordem", { ascending: true })
      .order("created_at", { ascending: false });
    if (error) toast.error("Erro ao carregar tabelas");
    setItems((data ?? []) as AdminTable[]);
    setLoading(false);
  };

  useEffect(() => {
    fetchAll();
  }, []);

  const openCreate = () => {
    setEditing(null);
    setContentType("file");
    setTitulo("");
    setDescricao("");
    setOrdem("0");
    setFile(null);
    setContentText("");
    setOpen(true);
  };

  const openEdit = (t: AdminTable) => {
    setEditing(t);
    setContentType(t.content_type === "text" ? "text" : "file");
    setTitulo(t.titulo);
    setDescricao(t.descricao ?? "");
    setOrdem(String(t.ordem));
    setFile(null);
    setContentText(t.content_text ?? "");
    setOpen(true);
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    setSubmitting(true);
    try {
      const payload: any = {
        titulo: titulo.trim(),
        descricao: descricao.trim() || null,
        ordem: Number(ordem) || 0,
        content_type: contentType,
        created_by: user.id,
      };

      if (contentType === "text") {
        if (!contentText.trim()) {
          toast.error("Digite o texto");
          setSubmitting(false);
          return;
        }
        payload.content_text = contentText;
        payload.file_url = editing?.file_url ?? null;
      } else {
        let file_url = editing?.file_url ?? "";
        if (file) {
          const ext = file.name.split(".").pop() ?? "bin";
          const path = `${user.id}/${Date.now()}.${ext}`;
          const { error: upErr } = await supabase.storage
            .from("tables-files")
            .upload(path, file, { cacheControl: "3600", upsert: false });
          if (upErr) throw upErr;
          const { data: pub } = supabase.storage.from("tables-files").getPublicUrl(path);
          file_url = pub.publicUrl;
        }
        if (!file_url) {
          toast.error("Selecione um arquivo");
          setSubmitting(false);
          return;
        }
        payload.file_url = file_url;
        payload.content_text = null;
      }

      if (editing) {
        const { error } = await (supabase as any).from("admin_tables").update(payload).eq("id", editing.id);
        if (error) throw error;
        toast.success("Tabela atualizada");
      } else {
        const { error } = await (supabase as any).from("admin_tables").insert(payload);
        if (error) throw error;
        toast.success("Tabela adicionada");
      }
      setOpen(false);
      fetchAll();
    } catch (err: any) {
      toast.error("Erro", { description: err.message });
    } finally {
      setSubmitting(false);
    }
  };

  const onDelete = async (t: AdminTable) => {
    if (!confirm(`Remover "${t.titulo}"?`)) return;
    const { error } = await (supabase as any).from("admin_tables").delete().eq("id", t.id);
    if (error) return toast.error("Erro ao remover");
    toast.success("Removida");
    fetchAll();
  };

  const isImage = (url: string | null) => !!url && /\.(png|jpe?g|gif|webp|svg)(\?|$)/i.test(url);

  const copyText = async (txt: string) => {
    try {
      await navigator.clipboard.writeText(txt);
      toast.success("Copiado para a área de transferência");
    } catch {
      toast.error("Não foi possível copiar");
    }
  };

  const copyImage = async (url: string) => {
    try {
      const resp = await fetch(url, { mode: "cors" });
      const srcBlob = await resp.blob();

      // Converte qualquer formato (jpg, webp, etc) para PNG, pois a Clipboard API
      // só aceita image/png de forma confiável na maioria dos navegadores.
      const toPngBlob = (blob: Blob) =>
        new Promise<Blob>((resolve, reject) => {
          const img = new Image();
          img.crossOrigin = "anonymous";
          const objUrl = URL.createObjectURL(blob);
          img.onload = () => {
            const canvas = document.createElement("canvas");
            canvas.width = img.naturalWidth;
            canvas.height = img.naturalHeight;
            const ctx = canvas.getContext("2d");
            if (!ctx) return reject(new Error("no ctx"));
            ctx.drawImage(img, 0, 0);
            URL.revokeObjectURL(objUrl);
            canvas.toBlob((b) => (b ? resolve(b) : reject(new Error("no blob"))), "image/png");
          };
          img.onerror = (e) => {
            URL.revokeObjectURL(objUrl);
            reject(e);
          };
          img.src = objUrl;
        });

      // Safari exige que o ClipboardItem seja criado de forma síncrona,
      // então passamos a Promise diretamente.
      const pngPromise = srcBlob.type === "image/png" ? Promise.resolve(srcBlob) : toPngBlob(srcBlob);

      try {
        // @ts-ignore
        await navigator.clipboard.write([new ClipboardItem({ "image/png": pngPromise })]);
        toast.success("Imagem copiada");
      } catch {
        // fallback: tenta com o blob original já resolvido
        const pngBlob = await pngPromise;
        // @ts-ignore
        await navigator.clipboard.write([new ClipboardItem({ "image/png": pngBlob })]);
        toast.success("Imagem copiada");
      }
    } catch (e) {
      console.error("copyImage failed", e);
      toast.error("Não foi possível copiar a imagem");
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold md:text-3xl">Tabelas</h1>
          <p className="text-sm text-muted-foreground">
            {isAdmin
              ? "Publique imagens, PDFs ou textos para os usuários consultarem."
              : "Tabelas e textos publicados pelos administradores."}
          </p>
        </div>
        {isAdmin && (
          <Button onClick={openCreate} className="bg-gradient-primary shadow-glow">
            <Plus className="mr-2 h-4 w-4" /> Novo item
          </Button>
        )}
      </div>
      {isAdmin && <PromocaoAdmin />}
      {isAdmin && <PixTemplatesAdmin />}


      {loading ? (
        <div className="glass-strong rounded-2xl p-8 text-center text-muted-foreground">Carregando...</div>
      ) : items.length === 0 ? (
        <div className="glass-strong rounded-2xl p-12 text-center text-muted-foreground">
          Nada publicado ainda.
        </div>
      ) : (
        <div className="space-y-6">
          {/* Bloco de imagens/arquivos */}
          {items.some((i) => i.content_type !== "text") && (
            <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {items
                .filter((t) => t.content_type !== "text")
                .map((t) => (
                  <div key={t.id} className="glass-strong group overflow-hidden rounded-2xl">
                    <button
                      type="button"
                      onClick={() => setPreview(t)}
                      className="block aspect-video w-full overflow-hidden bg-muted/40"
                    >
                      {isImage(t.file_url) ? (
                        <img
                          src={t.file_url!}
                          alt={t.titulo}
                          className="h-full w-full object-cover transition group-hover:scale-105"
                          loading="lazy"
                        />
                      ) : (
                        <div className="flex h-full w-full items-center justify-center text-muted-foreground">
                          <FileText className="h-12 w-12" />
                        </div>
                      )}
                    </button>
                    <div className="space-y-1 p-4">
                      <h3 className="font-semibold">{t.titulo}</h3>
                      {t.descricao && <p className="text-xs text-muted-foreground line-clamp-2">{t.descricao}</p>}
                      <p className="pt-1 text-[10px] text-muted-foreground">
                        Ordem {t.ordem} • {formatDate(t.created_at)}
                      </p>
                      <div className="flex flex-wrap gap-1 pt-2">
                        <Button asChild size="sm" variant="secondary">
                          <a href={t.file_url ?? "#"} target="_blank" rel="noopener noreferrer">
                            <Download className="h-3 w-3" /> Abrir
                          </a>
                        </Button>
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => (isImage(t.file_url) ? copyImage(t.file_url!) : copyText(t.file_url ?? ""))}
                        >
                          <Copy className="h-3 w-3" /> Copiar
                        </Button>
                        {isAdmin && (
                          <>
                            <Button size="sm" variant="ghost" onClick={() => openEdit(t)}>
                              <Pencil className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-destructive hover:text-destructive"
                              onClick={() => onDelete(t)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                  </div>
                ))}
            </div>
          )}

          {/* Divisor entre arquivos e textos */}
          {items.some((i) => i.content_type !== "text") &&
            items.some((i) => i.content_type === "text") && (
              <div className="flex items-center gap-3">
                <div className="h-px flex-1 bg-border" />
                <span className="text-[11px] uppercase tracking-wider text-muted-foreground">Textos</span>
                <div className="h-px flex-1 bg-border" />
              </div>
            )}

          {/* Bloco de textos */}
          {items.some((i) => i.content_type === "text") && (
            <div className="grid gap-4 md:grid-cols-2">
              {items
                .filter((t) => t.content_type === "text")
                .map((t) => (
                  <div key={t.id} className="glass-strong space-y-2 rounded-2xl p-4">
                    <div className="flex items-start justify-between gap-2">
                      <div className="min-w-0">
                        <h3 className="truncate font-semibold">{t.titulo}</h3>
                        {t.descricao && (
                          <p className="text-xs text-muted-foreground">{t.descricao}</p>
                        )}
                        <p className="pt-1 text-[10px] text-muted-foreground">
                          Ordem {t.ordem} • {formatDate(t.created_at)}
                        </p>
                      </div>
                      <div className="flex shrink-0 gap-1">
                        <Button size="sm" variant="secondary" onClick={() => copyText(t.content_text ?? "")}>
                          <Copy className="h-3 w-3" /> Copiar
                        </Button>
                        {isAdmin && (
                          <>
                            <Button size="sm" variant="ghost" onClick={() => openEdit(t)}>
                              <Pencil className="h-3 w-3" />
                            </Button>
                            <Button
                              size="sm"
                              variant="ghost"
                              className="text-destructive hover:text-destructive"
                              onClick={() => onDelete(t)}
                            >
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </>
                        )}
                      </div>
                    </div>
                    <pre className="max-h-64 overflow-auto whitespace-pre-wrap rounded-lg bg-background/60 p-3 text-xs leading-relaxed">
                      {t.content_text}
                    </pre>
                  </div>
                ))}
            </div>
          )}
        </div>
      )}

      {/* Preview dialog */}
      <Dialog open={!!preview} onOpenChange={(o) => !o && setPreview(null)}>
        <DialogContent className="max-w-4xl">
          <DialogHeader>
            <DialogTitle>{preview?.titulo}</DialogTitle>
          </DialogHeader>
          {preview && preview.file_url && (
            <div className="max-h-[70vh] overflow-auto">
              {isImage(preview.file_url) ? (
                <img src={preview.file_url} alt={preview.titulo} className="w-full" />
              ) : (
                <iframe src={preview.file_url} className="h-[70vh] w-full" title={preview.titulo} />
              )}
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Form dialog */}
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="glass-strong">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar item" : "Novo item"}</DialogTitle>
          </DialogHeader>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label>Tipo</Label>
              <Select value={contentType} onValueChange={(v) => setContentType(v as "file" | "text")}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="file">
                    <span className="inline-flex items-center gap-2"><ImageIcon className="h-3 w-3" /> Imagem ou PDF</span>
                  </SelectItem>
                  <SelectItem value="text">
                    <span className="inline-flex items-center gap-2"><FileText className="h-3 w-3" /> Texto</span>
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label>Título</Label>
              <Input value={titulo} onChange={(e) => setTitulo(e.target.value)} required />
            </div>
            <div className="space-y-1.5">
              <Label>Descrição</Label>
              <Textarea value={descricao} onChange={(e) => setDescricao(e.target.value)} rows={2} />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label>Ordem</Label>
                <Input type="number" value={ordem} onChange={(e) => setOrdem(e.target.value)} />
              </div>
              {contentType === "file" && (
                <div className="space-y-1.5">
                  <Label>
                    Arquivo {editing && <span className="text-xs text-muted-foreground">(opcional)</span>}
                  </Label>
                  <Input
                    type="file"
                    accept="image/*,application/pdf"
                    onChange={(e) => setFile(e.target.files?.[0] ?? null)}
                  />
                </div>
              )}
            </div>
            {contentType === "text" && (
              <div className="space-y-1.5">
                <Label>Texto</Label>
                <Textarea
                  value={contentText}
                  onChange={(e) => setContentText(e.target.value)}
                  rows={8}
                  placeholder="Digite o texto que ficará disponível para os usuários..."
                />
              </div>
            )}
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setOpen(false)}>Cancelar</Button>
              <Button type="submit" disabled={submitting} className="bg-gradient-primary shadow-glow">
                <Upload className="h-4 w-4" /> {submitting ? "Salvando..." : "Salvar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
