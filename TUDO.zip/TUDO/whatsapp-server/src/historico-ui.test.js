// O navegador de dias do painel, num DOM real (jsdom).
//
// A regra que este arquivo protege: enquanto um dia do passado está na tela,
// o que chega pelo socket (que é sempre o dia corrente) NÃO pode mexer nos
// números — senão o painel volta para hoje sozinho no meio da conferência.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const PUBLIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

const HOJE = new Date();
const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
const diasAtras = (n) => { const d = new Date(HOJE); d.setDate(d.getDate() - n); return iso(d); };
const HOJE_ISO = iso(HOJE);
const ONTEM = diasAtras(1);

const CALENDARIO = {
  ok: true, hoje: HOJE_ISO, primeiro: diasAtras(5), ultimo: HOJE_ISO,
  dias: [
    { day: HOJE_ISO, lancamentos: 4, pedidos: 2, servicos: 1, indicacoes: 0, montante: 400 },
    { day: ONTEM, lancamentos: 9, pedidos: 5, servicos: 3, indicacoes: 1, montante: 1900 },
    { day: diasAtras(5), lancamentos: 1, pedidos: 0, servicos: 0, indicacoes: 0, montante: 80 },
  ],
};

const snapshotDe = (dia) => ({
  ok: true,
  connection: 'open', role: 'admin', sessaoFiltro: null, sessoes: [],
  stats: { totalMessages: 120, totalMontante: 9000, totalContasValor: 300, totalContasQtd: 40 },
  periodo: dia
    ? { valor: dia, rotulo: dia, de: dia, ate: dia, historico: true }
    : { valor: 'today', rotulo: 'Hoje', de: HOJE_ISO, ate: HOJE_ISO, historico: false },
  hoje: {
    totais: {
      qtdEntradas: dia ? 9 : 4, montante: dia ? 1900 : 400, contasValor: dia ? 190 : 40,
      contasQtd: dia ? 19 : 4, qtdOperadores: dia ? 3 : 1, grupos: [],
    },
    operadores: [],
  },
  ultimasMensagens: [], analytics: { porHora: Array(24).fill(0), porDia: [] },
  servicos: { resumo: {}, operadores: [], servicos: [] },
  configs: {}, configGlobal: {}, export: null, conflitos: [], schedules: [],
});

async function montarPainel() {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;
  window.Element.prototype.getBoundingClientRect = () => ({ left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0 });
  window.Element.prototype.scrollIntoView = () => {};
  const pedidos = [];
  window.fetch = async (url) => {
    const u = String(url);
    pedidos.push(u);
    const corpo = () => {
      if (u.includes('/api/dias')) return CALENDARIO;
      if (u.includes('/api/snapshot')) {
        const m = u.match(/period=(\d{4}-\d{2}-\d{2})/);
        return snapshotDe(m ? m[1] : null);
      }
      if (u.includes('/api/sessoes')) return { ok: true, recursos: [], sessoes: [], conflitos: [] };
      return { ok: true, resumo: {}, brogueiras: [], operadores: [], ranking: [], indicadoras: [], plataformas: [], repetidos: { resumo: {}, grupos: [], autores: [] } };
    };
    return { ok: true, status: 200, json: async () => corpo() };
  };
  const tag = window.document.createElement('script');
  tag.textContent = fs.readFileSync(path.join(PUBLIC, 'app.js'), 'utf8');
  window.document.body.appendChild(tag);
  return {
    window,
    doc: window.document,
    pedidos,
    espera: () => new Promise((r) => setTimeout(r, 20)),
    fechar: async () => { await new Promise((r) => setTimeout(r, 30)); dom.window.close(); },
  };
}

test('o painel nasce ao vivo: sem dia escolhido e sem aviso de histórico', async () => {
  const { doc, fechar } = await montarPainel();
  try {
    assert.equal(doc.getElementById('dia-painel').value, '');
    assert.equal(doc.getElementById('dia-nav').classList.contains('ativo'), false);
    assert.equal(doc.getElementById('hist-aviso').classList.contains('hidden'), true);
  } finally { await fechar(); }
});

test('escolher um dia liga o modo histórico e busca o painel daquele dia', async () => {
  const { window, doc, pedidos, espera, fechar } = await montarPainel();
  try {
    window.aplicarDiaPainel(ONTEM);
    await espera();

    assert.ok(pedidos.some((u) => u.includes('/api/snapshot') && u.includes('period=' + ONTEM)),
      pedidos.join(' | '));
    assert.equal(doc.getElementById('dia-nav').classList.contains('ativo'), true);
    assert.equal(doc.getElementById('dia-painel').value, ONTEM);
    assert.equal(doc.getElementById('hist-aviso').classList.contains('hidden'), false);
    // Os números na tela são os do dia pedido.
    assert.equal(doc.getElementById('s-contas').textContent, 'R$ 190');
    // E os rótulos param de dizer "hoje".
    assert.ok(doc.getElementById('lbl-montante').textContent.startsWith('Montante validado em '));
  } finally { await fechar(); }
});

test('o aviso conta o que aquele dia tem', async () => {
  const { window, doc, espera, fechar } = await montarPainel();
  try {
    await espera(); // deixa o calendário chegar
    window.carregarCalendario && await window.carregarCalendario();
    window.aplicarDiaPainel(ONTEM);
    await espera();
    const texto = doc.getElementById('hist-detalhe').textContent;
    assert.match(texto, /9 lançamentos/);
    assert.match(texto, /sem atualização ao vivo/);
  } finally { await fechar(); }
});

test('o socket não arrasta o painel de volta para hoje', async () => {
  const { window, doc, espera, fechar } = await montarPainel();
  try {
    window.aplicarDiaPainel(ONTEM);
    await espera();
    const antes = doc.getElementById('s-contas').textContent;

    // Chega uma mensagem nova: o servidor empurra o snapshot de HOJE.
    window.renderSnapshot(snapshotDe(null));
    assert.equal(doc.getElementById('s-contas').textContent, antes,
      'os números do dia escolhido não podem ser trocados pelos de hoje');
    assert.equal(doc.getElementById('hist-aviso').classList.contains('hidden'), false);
  } finally { await fechar(); }
});

test('voltar para hoje devolve o painel ao vivo', async () => {
  const { window, doc, pedidos, espera, fechar } = await montarPainel();
  try {
    window.aplicarDiaPainel(ONTEM);
    await espera();
    doc.getElementById('hist-voltar').onclick();
    await espera();

    assert.equal(doc.getElementById('dia-nav').classList.contains('ativo'), false);
    assert.equal(doc.getElementById('hist-aviso').classList.contains('hidden'), true);
    assert.equal(doc.getElementById('lbl-montante').textContent, 'Montante validado hoje');
    assert.equal(doc.getElementById('lbl-cval').textContent, 'Contas validadas hoje');
    assert.equal(doc.getElementById('s-ops'), null, 'o KPI de Operadores saiu da fileira');
    // A última busca de painel foi sem recorte de dia.
    const ultima = pedidos.filter((u) => u.includes('/api/snapshot')).at(-1);
    assert.ok(!ultima.includes('period='), ultima);
    assert.equal(doc.getElementById('s-contas').textContent, 'R$ 40');
  } finally { await fechar(); }
});

test('as setas andam um dia por vez e não passam de hoje', async () => {
  const { window, doc, espera, fechar } = await montarPainel();
  try {
    await espera();
    window.aplicarDiaPainel(ONTEM);
    await espera();
    doc.getElementById('dia-ant').onclick();
    await espera();
    assert.equal(doc.getElementById('dia-painel').value, diasAtras(2));

    doc.getElementById('dia-prox').onclick();
    await espera();
    assert.equal(doc.getElementById('dia-painel').value, ONTEM);

    // Avançar a partir de ontem volta para o modo ao vivo (hoje não é histórico).
    doc.getElementById('dia-prox').onclick();
    await espera();
    assert.equal(doc.getElementById('dia-painel').value, '');
    assert.equal(doc.getElementById('dia-nav').classList.contains('ativo'), false);
  } finally { await fechar(); }
});

test('o dia escolhido vale para as abas de relatório', async () => {
  const { window, doc, pedidos, espera, fechar } = await montarPainel();
  try {
    window.abrirAba('brogueiras');
    window.aplicarDiaPainel(ONTEM);
    await espera();
    assert.ok(pedidos.some((u) => u.includes('/api/brogueiras') && u.includes('period=' + ONTEM)),
      pedidos.join(' | '));
    // O navegador de dias da aba Operadores acompanha o do topo.
    assert.equal(doc.getElementById('op-dia').value, ONTEM);
    // E os botões de período das abas ficam travados enquanto o dia manda.
    assert.equal(doc.getElementById('bg-periodo').classList.contains('travado'), true);
  } finally { await fechar(); }
});

test('a aba Brogueiras tem o seu navegador de dias, igual ao dos Operadores', async () => {
  const { window, doc, pedidos, espera, fechar } = await montarPainel();
  try {
    window.abrirAba('brogueiras');
    await espera();
    // Nasce ao vivo: campo vazio e seta de avançar apagada (não existe amanhã).
    assert.equal(doc.getElementById('bg-dia').value, '');
    assert.equal(doc.getElementById('bg-dia-prox').disabled, true);

    doc.getElementById('bg-dia-ant').onclick();   // ‹ = ontem
    await espera();
    assert.equal(doc.getElementById('bg-dia').value, ONTEM);
    assert.equal(doc.getElementById('bg-dia-nav').classList.contains('ativo'), true);
    assert.ok(pedidos.some((u) => u.includes('/api/brogueiras') && u.includes('period=' + ONTEM)),
      pedidos.join(' | '));
    // O dia é um só: o seletor do topo e o da aba Operadores acompanham.
    assert.equal(doc.getElementById('dia-painel').value, ONTEM);
    assert.equal(doc.getElementById('op-dia').value, ONTEM);

    doc.getElementById('bg-dia-prox').onclick();  // › a partir de ontem = ao vivo
    await espera();
    assert.equal(doc.getElementById('bg-dia').value, '');
    assert.equal(doc.getElementById('bg-dia-nav').classList.contains('ativo'), false);
  } finally { await fechar(); }
});

test('a aba Indicações navega pelos dias e escolher a data no campo vale', async () => {
  const { window, doc, pedidos, espera, fechar } = await montarPainel();
  try {
    window.abrirAba('indicacoes');
    await window.carregarCalendario();
    const campo = doc.getElementById('ind-dia');
    campo.value = diasAtras(2);
    campo.onchange({ target: campo });
    await espera();

    assert.ok(pedidos.some((u) => u.includes('/api/indicacoes') && u.includes('period=' + diasAtras(2))),
      pedidos.join(' | '));
    assert.equal(doc.getElementById('dia-painel').value, diasAtras(2));
    assert.equal(doc.getElementById('ind-periodo').classList.contains('travado'), true);

    // O calendário limita o passeio: nada antes do primeiro dia gravado.
    window.aplicarDiaPainel(diasAtras(5));
    await espera();
    assert.equal(doc.getElementById('ind-dia-ant').disabled, true);
  } finally { await fechar(); }
});
