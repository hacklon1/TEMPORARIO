# Plano de ajustes

## 1. Divisor de Depósito — voltar a ser aleatório
**Arquivo:** `src/lib/contas.ts`, `src/pages/Operations.tsx`

- Substituir `distribuirComDiferencaMinima` por `distribuirAleatorio(total, n)`:
  - Gera N pesos aleatórios (`Math.random()`), normaliza para somar `total`, arredonda para inteiros e ajusta sobra na última conta.
  - Garante valor mínimo ≥ 1 por conta.
- Cada clique em **Distribuir** gera valores novos (sem seed).
- Remover o texto "diferença mínima de R$ 10" do bloco e o cálculo associado.
- Manter sugestão de nº de contas pelo montante (já existente).

## 2. Operações — tirar edição de comissão pelo usuário
**Arquivo:** `src/pages/Operations.tsx`

- Comissão (Montante) e Comissão (Contas) deixam de ser `Input` editável → exibidos como **valor calculado read-only** (badge/texto), sempre derivados do `commission_percent` / `commission_contas_percent` do perfil.
- Remover estados `comissaoTouched` e `comissaoContasTouched`.
- ADM continua podendo editar tudo via futuro fluxo de edição (mantém inputs só quando `isAdmin === true`).
- No `onSubmit`, comissão sempre recalculada no cliente a partir das fórmulas:
  - `comissao = blogueira × pct/100`
  - `comissao_contas = max(0, saque_contas − deposito_contas + salario_contas) × pctContas/100`

## 3. Contas não contabilizando no Relatório/Dashboard
**Causa raiz:** coluna `operations.lucro` é GENERATED e calcula apenas `(saque − deposito) + blogueira`. Nada de contas entra nela, então Dashboard, Ranking e Relatórios ignoram as operações de contas.

**Migration:**
- Adicionar coluna gerada `lucro_contas numeric GENERATED ALWAYS AS ((saque_contas + salario_contas) - deposito_contas) STORED`.
- Atualizar a função `get_user_ranking()` para somar `lucro + lucro_contas` como lucro total e somar `deposito + deposito_contas` e `saque + saque_contas` nos respectivos campos.

**Frontend:**
- `Dashboard.tsx`, `Operations.tsx`, `Reports.tsx`, `Export.tsx`: ler `lucro_contas` e considerar **lucro total = lucro + lucro_contas** em todas as somas, gráficos, ranking, CSV e tabelas.
- Fórmula de Contas exibida na UI: `Lucro Contas = (Saque + Salário) − Depósito` (igual ao padrão de Montante: investido `dep+salário` × retorno `saque`).

## 4. Dashboard — seletor de modo de lucro por usuário
**Arquivo:** `src/pages/Dashboard.tsx`

- Novo seletor no topo do Dashboard: **Montantes / Contas / Ambos (separados)**.
- Persistência: `localStorage` por navegador (`db:profitMode`).
- Cards `StatCard`, gráfico "Lucro diário por usuário", "Lucro do Dia" e tabela "Histórico de ganhos" reagem ao modo:
  - **Montantes** → usa `lucro` (atual).
  - **Contas** → usa `lucro_contas`.
  - **Ambos** → exibe duas colunas/barras (Montantes vs Contas) separadas, e total combinado.

## 5. Ranking só para ADM
**Arquivo:** `src/pages/Dashboard.tsx`

- Renderizar o bloco "Ranking de usuários" (barras verdes) **somente se `isAdmin`**.
- Usuário comum continua vendo apenas o card "Seu desempenho" (extraído do mesmo bloco) ou nada.

## 6. Botão de Trocar Tema (canto sup. dir.)
**Arquivos:** `src/index.css`, `src/components/AppLayout.tsx`, novo `src/components/ThemeSwitcher.tsx`

- 3 temas via classe no `<html>`:
  - `theme-dark` (atual — dourado/azul/vermelho sobre preto).
  - `theme-light` — fundo branco, texto preto, primário dourado, detalhes vermelho/preto.
  - `theme-blue` — fundo azul profundo, primário azul claro, accent vermelho.
- Tokens HSL definidos em `:root.theme-*` em `src/index.css` (sem hardcode em componentes).
- `ThemeSwitcher` (dropdown com 3 opções) montado no header de `AppLayout` à direita do `SidebarTrigger`. Persistência em `localStorage` (`db:theme`).

## 7. Aviso global da Dashboard (ADM)
**Arquivos:** `src/pages/Users.tsx` (ou Dashboard ADM), `src/pages/Dashboard.tsx`

- Campo `app_settings.aviso_dashboard` **já existe** no schema.
- Em **Usuários (ADM)** adicionar bloco "Aviso na Dashboard" com `Textarea` + botão Salvar (update no `app_settings`).
- No `Dashboard`, buscar `aviso_dashboard` e exibir banner destacado no topo quando preenchido (ícone de alerta + botão fechar local via `localStorage` para não ficar fixo eternamente).

## 8. Remover Sessão de Proxy
**Arquivo:** `src/pages/Operations.tsx`

- Remover o bloco "Sessão de Proxy" (linhas ~623-646) e o estado `proxyActive`.

---

## Detalhes técnicos

**Migration única:**
```sql
ALTER TABLE public.operations
  ADD COLUMN lucro_contas numeric
  GENERATED ALWAYS AS ((saque_contas + salario_contas) - deposito_contas) STORED;

CREATE OR REPLACE FUNCTION public.get_user_ranking()
RETURNS TABLE(user_id uuid, nome text, lucro numeric, deposito numeric, saque numeric, pedidos bigint)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT o.user_id,
         COALESCE(p.nome, '—'),
         COALESCE(SUM(o.lucro + o.lucro_contas), 0),
         COALESCE(SUM(o.deposito + o.deposito_contas), 0),
         COALESCE(SUM(o.saque + o.saque_contas), 0),
         COUNT(*)::bigint
  FROM public.operations o
  LEFT JOIN public.profiles p ON p.id = o.user_id
  GROUP BY o.user_id, p.nome
  ORDER BY 3 DESC
$$;
```

**Arquivos editados / criados:**
- `src/lib/contas.ts` — nova `distribuirAleatorio`.
- `src/pages/Operations.tsx` — remover Proxy, comissão read-only, usar novo distribuidor.
- `src/pages/Dashboard.tsx` — seletor de modo, banner de aviso, ranking só ADM, somar `lucro_contas`.
- `src/pages/Reports.tsx`, `src/pages/Export.tsx` — incluir `lucro_contas` nas somas/CSV.
- `src/pages/Users.tsx` — editor de `aviso_dashboard`.
- `src/index.css` — 3 conjuntos de tokens (`theme-dark`, `theme-light`, `theme-blue`).
- `src/components/AppLayout.tsx` — montar `ThemeSwitcher` no header.
- **Novo:** `src/components/ThemeSwitcher.tsx`.
- Migration SQL acima.

## Fora do escopo
- Não mexer em autenticação, RLS ou roles.
- Sem backfill — `lucro_contas` é coluna gerada e recalcula sozinha para todas as linhas existentes.
- Calculadora % e Template PIX permanecem como estão.
