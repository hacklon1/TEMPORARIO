// Pedidos das Brogueiras: link + o que ela quer naquele link.
//
// As duas formas que aparecem no grupo:
//
//   CONTAS                            MONTANTE
//   https://670win.me/?id=357497224   https://okokathena.win/?id=393339299
//   7 contas variadas                 520 em 4
//   → 7 contas                        → R$ 520 divididos em 4 contas
//
// O que separa um do outro é ESTRUTURAL, não o tamanho do número: em "7 contas
// variadas" o 7 é a quantidade de contas (nada antes dele); em "200 2 contas" o
// 200 vem ANTES da quantidade, e um número antes da quantidade só pode ser valor.
//
// Os links são removidos do texto antes de olhar os números — "?id=357497224"
// tem 9 dígitos e viraria um montante gigante.
import { desestilizar, parseBrazilianNumber } from './parser.js';

// http(s) explícito ou domínio nu (as Brogueiras às vezes colam sem o https://).
const RE_LINK = /\b(?:https?:\/\/|www\.)[^\s<>"']+|\b[a-z0-9][a-z0-9-]*\.(?:com|net|org|bet|vip|win|me|co|app|cc|io|br|xyz|club|live|site|online|fun)(?:\.[a-z]{2})?\/[^\s<>"']*/gi;

// "<n> contas" / "<n> conta" / "<n> cts"
const RE_QTD_CONTAS = /(\d[\d.,]*)\s*(?:contas?|cts?)\b/i;
// "520 em 4", "200/2", "300 x 2" — valor e em quantas contas dividir
const RE_VALOR_EM = /(\d[\d.,]*)\s*(?:em|por|\/|x)\s*(\d[\d.,]*)/i;
// Palavras que denunciam um montante mesmo sem número de contas
const RE_PALAVRA_MONTANTE = /\bmontante/i;
const RE_NUMERO = /\d[\d.,]*/g;

export function extrairLinks(texto) {
  const t = desestilizar(texto);
  const achados = t.match(RE_LINK) ?? [];
  // Sem duplicatas e sem pontuação final grudada ("...id=123." / "link,")
  return [...new Set(achados.map((l) => l.replace(/[.,;:)\]]+$/, '')))];
}

// Domínio do link, para agrupar "quais plataformas ela mandou".
export function dominioDoLink(link) {
  const t = String(link ?? '').replace(/^https?:\/\//i, '').replace(/^www\./i, '');
  return t.split('/')[0].toLowerCase() || null;
}

// Analisa uma mensagem de pedido. Devolve null se não houver link nenhum
// (sem link não é pedido — é conversa).
export function analisarPedido(texto) {
  const t = desestilizar(texto);
  const links = extrairLinks(t);
  if (!links.length) return null;

  // Tira os links: os dígitos do "?id=" não podem virar valor.
  let corpo = t;
  for (const link of links) corpo = corpo.split(link).join(' ');
  corpo = corpo.replace(RE_LINK, ' ').replace(/\s+/g, ' ').trim();

  const resultado = classificarPedido(corpo);
  return {
    ...resultado,
    links,
    dominios: [...new Set(links.map(dominioDoLink).filter(Boolean))],
    pedido: corpo.slice(0, 200),
  };
}

// Um pedido é curto: o link e uma linha dizendo o que ela quer. Textão com
// link é divulgação de operador ("PAGO 10 NA DE 50 ... ✅DEPÓSITO R$10"), e sem
// este limite o primeiro número dali virava "montante 10" no relatório.
// 10 é folgado para os pedidos reais (o maior tem 7 palavras: "400 montante 2
// contas nas 2 por favor") e já corta os anúncios curtos de operador
// ("MEIA BANCA ... SOMENTE 3 VAGAS ... Valor: 50/10 Me chama" = 11).
export const MAX_PALAVRAS_PEDIDO = 10;

export function contarPalavras(texto) {
  return String(texto ?? '').trim().split(/\s+/).filter(Boolean).length;
}

// Só a parte textual (já sem links). Exportada para teste direto.
// "1mil" / "2 mil" viram 1000 / 2000 — senão o regex de número lê só o "1".
export function expandirMil(texto) {
  return String(texto ?? '').replace(/(\d+(?:[.,]\d+)?)\s*mil\b/gi, (_, n) => {
    const base = parseBrazilianNumber(n);
    return base == null ? _ : String(base * 1000);
  });
}

export function classificarPedido(corpo) {
  // desestilizar de novo é barato e idempotente — protege quem chame direto
  // com o texto cru (𝟳 𝗰𝗼𝗻𝘁𝗮𝘀 não casaria com /contas/).
  const texto = expandirMil(desestilizar(corpo));

  if (contarPalavras(texto) > MAX_PALAVRAS_PEDIDO) {
    return { tipo: 'indefinido', montante: 0, contas: null, motivo: 'texto longo' };
  }
  const mQtd = RE_QTD_CONTAS.exec(texto);

  if (mQtd) {
    const qtd = parseBrazilianNumber(mQtd[1]);
    // Um número antes da quantidade de contas é o valor do montante. Havendo
    // mais de um ("1 montante 500 / 5 contas"), o montante é o MAIOR: o outro
    // é uma contagem ("1 montante"), sempre menor que o valor em reais.
    const antes = texto.slice(0, mQtd.index);
    const numAntes = (antes.match(RE_NUMERO) ?? []).map(parseBrazilianNumber).filter((n) => n != null);
    if (numAntes.length) {
      return { tipo: 'montante', montante: Math.max(...numAntes), contas: qtd ?? null };
    }
    if (qtd != null) return { tipo: 'conta', montante: 0, contas: qtd };
  }

  // Sem a palavra "contas": "520 em 4", "200/2"
  const mEm = RE_VALOR_EM.exec(texto);
  if (mEm) {
    const valor = parseBrazilianNumber(mEm[1]);
    const partes = parseBrazilianNumber(mEm[2]);
    if (valor != null) return { tipo: 'montante', montante: valor, contas: partes ?? null };
  }

  // Um número solto ("Quero 400", "400") é montante — pedido de conta sempre
  // traz a palavra "contas" (é ela que diz o que aquele número significa).
  const numeros = texto.match(RE_NUMERO);
  if (numeros?.length) {
    const valor = parseBrazilianNumber(numeros[0]);
    if (valor != null) return { tipo: 'montante', montante: valor, contas: null };
  }

  // Link sem pedido legível: registrado como indefinido em vez de descartado —
  // some da conta da Brogueira sem ninguém perceber seria pior.
  return { tipo: 'indefinido', montante: 0, contas: null };
}
