// Persistência em arquivo JSON (data/db.json) — sem banco SQL.
// Estrutura: { config, sessoes, stats, messages, schedules, meta }.
//   config  → o que é GLOBAL (fuso, janela de análise dos repetidos)
//   sessoes → os até 3 números, cada um com config e recursos próprios
// saveDb() é debounced para não escrever a cada evento.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { logger } from './logger.js';
import {
  defaultConfigSessao, normalizarSessoes, sessoesIniciais, sessoesDe, sessaoDe, configSessao,
  SESSAO_PADRAO,
} from './sessoes.js';
import {
  JANELA_ATENDIMENTO_PADRAO, JANELA_COMPROVANTE_PADRAO, MODO_CASAMENTO_PADRAO, MODOS_CASAMENTO,
} from './servicos.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
// Sobrescrevível por DATA_DIR (como AUTH_DIR): os testes apontam para um
// diretório temporário para nunca tocarem no histórico de produção.
const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : path.resolve(__dirname, '..', 'data');
const DB_PATH = path.join(DATA_DIR, 'db.json');

// Config GLOBAL — vale para o servidor inteiro, não para um número.
// O fuso agrupa os relatórios de todos os números por dia; a janela dos
// repetidos é critério de análise do painel (que soma os 3 números).
export const defaultConfigGlobal = {
  repetidosJanelaHoras: 0,
  timezone: 'America/Sao_Paulo',
  // Validação de serviço em 3 passos (pedido → resposta do Operador →
  // comprovante PIX). É critério de ANÁLISE, igual à janela dos repetidos:
  // vale para o servidor inteiro, não para um número.
  servicosEnabled: true,
  servicosJanelaAtendimentoMin: JANELA_ATENDIMENTO_PADRAO,
  servicosJanelaComprovanteMin: JANELA_COMPROVANTE_PADRAO,
  servicosModoCasamento: MODO_CASAMENTO_PADRAO,
  // Exportação para o DB Dashboard (site Lovable). Global: é o servidor que
  // exporta, somando os números, não um número específico.
  exportEnabled: false,
  exportUrl: '',
  exportSegredo: '',
  exportApiKey: '',
  exportIntervaloMin: 5,
  // Cobrança da comissão pelo WhatsApp: a mensagem que o bot manda para o
  // Operador quando o dono clica em "Cobrar" na linha dele. É global porque a
  // cobrança é da casa, não de um número específico.
  comissaoMensagem: [
    'Olá {operador}, tudo certo?',
    '',
    'Fechando a semana ({periodo}):',
    '• Serviços validados: {servicos}',
    '• Salário recebido: {salario}',
    '• Comissão ({pct}%): *{valor}*',
    '',
    'Pode me confirmar o pagamento por aqui, por favor?',
  ].join('\n'),
};

// União (global + de sessão). Continua exportada porque server.js usa a lista
// de chaves permitidas na hora de validar o POST /api/config.
export const defaultConfig = { ...defaultConfigGlobal, ...defaultConfigSessao };

export const CHAVES_CONFIG_GLOBAL = Object.keys(defaultConfigGlobal);

function emptyDb() {
  return {
    config: { ...defaultConfigGlobal },
    // Os até 3 números. Numa instalação nova o Número 1 já nasce ativo e com
    // todos os recursos — é o bot de sempre.
    sessoes: sessoesIniciais({}),
    stats: {
      totalMessages: 0,
      totalGroups: 0,
      totalMontante: 0,
      totalContasValor: 0,
      totalContasQtd: 0,
      startedAt: null,
    },
    messages: [], // histórico de entradas processadas (financeiras)
    pedidos: [], // pedidos de link das Brogueiras (contas/montante)
    indicacoes: [], // "vim por @fulana" — quem trouxe quem
    // Serviços em validação de 3 passos: cada registro amarra o pedido da
    // Brogueira, a resposta do Operador e o comprovante PIX dela.
    servicos: [],
    // Quem é quem: nome ↔ número de cada pessoa já vista nos grupos. É o que
    // permite mostrar "Ana" no lugar de "@5511999999999" numa indicação feita
    // a alguém que ainda não falou no painel.
    pessoas: {},
    // O que já foi alertado (link repetido): índice de deduplicação, para o
    // aviso não sair de novo pelo mesmo caso a cada mensagem nova.
    alertas: { links: {}, dias: {}, ultimo: null },
    schedules: [], // agendamentos node-cron
    // Estado da exportação: o que já foi enviado ao site, quando, e o último
    // erro. Fica no db para sobreviver a um restart — senão o bot reenviaria
    // o histórico inteiro toda vez que subisse.
    export: { dias: {}, ultimoEnvioEm: null, ultimoErro: null, tentativas: 0, proximaEm: null, enviados: 0 },

    /* ── Relatórios por usuário (aba Relatórios) ──────────────────────
       Livro-caixa dos operadores: uma linha por operação, com as pessoas
       (`usuarios`), as metas (`appSettings`), o backup das comissões zeradas
       (`commissionResets`) e o log de edição/exclusão (`operationAudit`).
       Vive no mesmo db.json do resto — é o "banco" deste servidor. */
    usuarios: [],          // { id, nome, email, papel: 'owner'|'admin'|'user' }
    operations: [],        // ver src/operacoes.js
    appSettings: { metaDiariaBlogueira: 0, metaSemanalBlogueira: 0 },
    commissionResets: [],  // backup do que foi zerado (permite desfazer)
    operationAudit: [],    // EDITADA | APAGADA, com o valor antigo

    /* Comissão cobrada dos Operadores: a porcentagem de cada um sobre o
       salário que ele recebeu das Brogueiras (o `Valor` da mensagem dele),
       contada só nos serviços validados. Ver src/comissoes.js. */
    comissoesConfig: { padraoPct: 0, porOperador: {} },
    comissoesCobradas: [], // o que já foi cobrado, com a lista de serviços
    meta: { version: 8 },
  };
}

let db = emptyDb();

const numeroFinito = (v, padrao = 0) => (Number.isFinite(Number(v)) ? Number(v) : padrao);

// Reconcilia o que veio do arquivo com a forma esperada. Um db.json de uma
// versão anterior (ou truncado) não pode virar NaN nos totais nem quebrar as
// agregações que assumem arrays.
function normalizar(parsed) {
  const base = emptyDb();
  const out = { ...base, ...(parsed && typeof parsed === 'object' ? parsed : {}) };

  const configArquivo = parsed?.config && typeof parsed.config === 'object' ? parsed.config : {};

  // ── Sessões (até 3 números) ──────────────────────────────────────
  // Arquivo da versão de um número só (sem `sessoes`): a config que estava
  // valendo vira a do Número 1, com todos os recursos ligados. Nada muda de
  // comportamento — o bot continua fazendo exatamente o que fazia.
  if (Array.isArray(parsed?.sessoes) && parsed.sessoes.length) {
    out.sessoes = normalizarSessoes(parsed.sessoes);
  } else {
    out.sessoes = sessoesIniciais(configArquivo);
    if (Object.keys(configArquivo).length) {
      logger.warn('db.json de um número só — config migrada para o Número 1');
    }
  }

  // Config global: só o que é do servidor. As chaves de comportamento que
  // existiam aqui já foram para dentro de cada número (acima).
  out.config = { ...defaultConfigGlobal };
  for (const chave of CHAVES_CONFIG_GLOBAL) {
    if (configArquivo[chave] !== undefined) out.config[chave] = configArquivo[chave];
  }
  out.config.repetidosJanelaHoras = numeroFinito(out.config.repetidosJanelaHoras, 0);
  out.config.exportEnabled = out.config.exportEnabled === true;
  out.config.exportIntervaloMin = Math.max(1, Math.round(numeroFinito(out.config.exportIntervaloMin, 5)));
  out.config.servicosEnabled = out.config.servicosEnabled !== false;
  out.config.servicosJanelaAtendimentoMin = numeroFinito(out.config.servicosJanelaAtendimentoMin, JANELA_ATENDIMENTO_PADRAO);
  out.config.servicosJanelaComprovanteMin = numeroFinito(out.config.servicosJanelaComprovanteMin, JANELA_COMPROVANTE_PADRAO);
  if (!MODOS_CASAMENTO.includes(out.config.servicosModoCasamento)) {
    out.config.servicosModoCasamento = MODO_CASAMENTO_PADRAO;
  }

  out.stats = { ...base.stats, ...(parsed?.stats ?? {}) };
  for (const chave of ['totalMessages', 'totalGroups', 'totalMontante', 'totalContasValor', 'totalContasQtd']) {
    out.stats[chave] = numeroFinito(out.stats[chave]);
  }

  if (!Array.isArray(out.messages)) out.messages = [];
  if (!Array.isArray(out.pedidos)) out.pedidos = [];
  if (!Array.isArray(out.indicacoes)) out.indicacoes = [];
  if (!Array.isArray(out.servicos)) out.servicos = [];
  if (!Array.isArray(out.schedules)) out.schedules = [];
  // Agendamento gravado antes dos múltiplos números dispara pelo Número 1.
  for (const s of out.schedules) if (!s.sessaoId) s.sessaoId = SESSAO_PADRAO;
  if (!out.pessoas || typeof out.pessoas !== 'object' || Array.isArray(out.pessoas)) out.pessoas = {};
  if (!out.alertas || typeof out.alertas !== 'object' || Array.isArray(out.alertas)) out.alertas = { ...base.alertas };
  if (!out.alertas.links || typeof out.alertas.links !== 'object') out.alertas.links = {};
  if (!out.alertas.dias || typeof out.alertas.dias !== 'object') out.alertas.dias = {};
  // db.json de antes da exportação (v5): nasce zerado, e o primeiro ciclo
  // manda o histórico que ainda está na janela de serviços.
  if (!out.export || typeof out.export !== 'object' || Array.isArray(out.export)) out.export = { ...base.export };
  if (!out.export.dias || typeof out.export.dias !== 'object') out.export.dias = {};

  // db.json de antes da aba Relatórios (v6): as coleções nascem vazias e as
  // metas em zero — a tela abre pedindo para cadastrar, não quebra.
  for (const chave of ['usuarios', 'operations', 'commissionResets', 'operationAudit', 'comissoesCobradas']) {
    if (!Array.isArray(out[chave])) out[chave] = [];
  }
  // Sem config de comissão (db de antes da v8): ninguém é cobrado até o dono
  // escolher a porcentagem — nunca inventar um percentual padrão.
  if (!out.comissoesConfig || typeof out.comissoesConfig !== 'object' || Array.isArray(out.comissoesConfig)) {
    out.comissoesConfig = { ...base.comissoesConfig };
  }
  out.comissoesConfig.padraoPct = numeroFinito(out.comissoesConfig.padraoPct);
  if (!out.comissoesConfig.porOperador || typeof out.comissoesConfig.porOperador !== 'object') {
    out.comissoesConfig.porOperador = {};
  }
  out.appSettings = { ...base.appSettings, ...(parsed?.appSettings ?? {}) };
  out.appSettings.metaDiariaBlogueira = numeroFinito(out.appSettings.metaDiariaBlogueira);
  out.appSettings.metaSemanalBlogueira = numeroFinito(out.appSettings.metaSemanalBlogueira);
  // A versão do esquema é deste código, não do arquivo — senão um db antigo
  // congelaria o número para sempre e a próxima migração leria errado.
  out.meta = { ...base.meta, ...(parsed?.meta ?? {}), version: base.meta.version };
  return out;
}

export function loadDb() {
  try {
    if (fs.existsSync(DB_PATH)) {
      const raw = fs.readFileSync(DB_PATH, 'utf8');
      const parsed = JSON.parse(raw);
      db = normalizar(parsed);
      logger.info({ mensagens: db.messages.length }, 'db.json carregado');
    } else {
      fs.mkdirSync(DATA_DIR, { recursive: true });
      persist();
      logger.info('db.json criado (vazio)');
    }
  } catch (err) {
    // Não descartar dados em silêncio: o próximo save sobrescreveria o
    // histórico inteiro. Guardamos o arquivo ilegível para inspeção.
    try {
      if (fs.existsSync(DB_PATH)) {
        const backup = `${DB_PATH}.corrompido-${Date.now()}`;
        fs.copyFileSync(DB_PATH, backup);
        logger.error({ backup }, 'db.json ilegível — cópia preservada');
      }
    } catch (errBackup) {
      logger.error(errBackup, 'falha ao preservar db.json corrompido');
    }
    logger.error(err, 'falha ao carregar db.json — usando db vazio');
    db = emptyDb();
  }
  return db;
}

export function getDb() {
  return db;
}

/* ═══════════ Atalhos das sessões (números) ═══════════
   Os módulos que só precisam ler a config de um número passam pelo aqui em vez
   de mexer na forma do db — quem muda a estrutura é este arquivo. */

export function getSessoes() {
  return sessoesDe(db);
}

export function getSessao(id = SESSAO_PADRAO) {
  return sessaoDe(db, id);
}

// Config VIVA de um número (objeto gravável, sem o que é global).
export function getConfigSessao(id = SESSAO_PADRAO) {
  return configSessao(db, id);
}

/**
 * Config COMPLETA para consumo: o que é do número por cima do que é global.
 * É uma cópia — para gravar, use getConfigSessao(id).
 */
export function getConfig(id = SESSAO_PADRAO) {
  return { ...db.config, ...configSessao(db, id) };
}

// Escrita atômica (grava em .tmp e renomeia).
function persist() {
  const tmp = DB_PATH + '.tmp';
  fs.mkdirSync(DATA_DIR, { recursive: true });
  fs.writeFileSync(tmp, JSON.stringify(db, null, 2));
  fs.renameSync(tmp, DB_PATH);
}

// Backups mantidos em data/. Cada um é uma cópia integral do db (~1MB hoje),
// então guardamos uma janela curta em vez de crescer sem limite.
const MAX_BACKUPS = 10;

function podarBackups() {
  try {
    // O carimbo é ISO, então ordem alfabética == ordem cronológica.
    const antigos = fs
      .readdirSync(DATA_DIR)
      .filter((n) => /^backup-.*\.json$/.test(n))
      .sort()
      .slice(0, -MAX_BACKUPS);
    for (const nome of antigos) fs.rmSync(path.join(DATA_DIR, nome), { force: true });
  } catch (err) {
    logger.error(err, 'falha ao podar backups antigos');
  }
}

// Cópia integral do db antes de uma operação destrutiva. Devolve o caminho.
export function backupDb() {
  fs.mkdirSync(DATA_DIR, { recursive: true });
  const carimbo = new Date().toISOString().replace(/[:.]/g, '-');
  // Dois backups no mesmo milissegundo colidiriam no nome e um sobrescreveria
  // o outro em silêncio — justamente o dado que se queria preservar.
  let destino = path.join(DATA_DIR, `backup-${carimbo}.json`);
  for (let n = 1; fs.existsSync(destino); n++) {
    destino = path.join(DATA_DIR, `backup-${carimbo}-${n}.json`);
  }
  fs.writeFileSync(destino, JSON.stringify(db, null, 2));
  podarBackups();
  logger.warn({ backup: destino }, 'backup do db criado');
  return destino;
}

// Backups disponíveis para restauração manual, do mais recente para o mais antigo.
export function listarBackups() {
  try {
    return fs
      .readdirSync(DATA_DIR)
      .filter((n) => /^backup-.*\.json$/.test(n))
      .sort()
      .reverse()
      .map((nome) => {
        const { size, mtime } = fs.statSync(path.join(DATA_DIR, nome));
        return { nome, tamanho: size, criadoEm: mtime.toISOString() };
      });
  } catch (err) {
    logger.error(err, 'falha ao listar backups');
    return [];
  }
}

let saveTimer = null;
export function saveDb({ immediate = false } = {}) {
  if (immediate) {
    if (saveTimer) {
      clearTimeout(saveTimer);
      saveTimer = null;
    }
    // Nunca propagar: saveDb({immediate}) é chamado de rotas HTTP e do
    // handler de SIGTERM — lançar aqui abortaria o shutdown limpo.
    try {
      persist();
    } catch (err) {
      logger.error(err, 'falha ao salvar db.json');
    }
    return;
  }
  if (saveTimer) return; // já há uma escrita agendada
  saveTimer = setTimeout(() => {
    saveTimer = null;
    try {
      persist();
    } catch (err) {
      logger.error(err, 'falha ao salvar db.json');
    }
  }, 1000);
}
