// Geração dos relatórios em texto (enviados no WhatsApp e exibidos no painel).
import {
  filtrarEntradas, agregarTotais, agregarOperadores, montantesValidados,
  relatorioIndicacoes, rotuloPeriodo,
} from './store.js';

const fmtBRL = (n) =>
  Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

/* ═══════════ Montante = montante VALIDADO ═══════════
   Todo "Montante" que o bot responde no PV e que o Painel mostra é o que fechou
   os 3 passos (pedido → atendimento → comprovante). O lançamento bruto continua
   somado e vai junto como `montanteLancado`, para quem precisar da diferença,
   mas o número em destaque é o validado — era o que inflava o relatório.

   As listas (grupos, operadores) continuam vindo dos lançamentos: é ali que
   estão os nomes e as contas. Só o campo `montante` de cada linha é substituído
   pelo validado daquela chave. */
export function agregados(period = 'today', { sessao = null } = {}) {
  const entradas = filtrarEntradas(period, sessao);
  const totais = agregarTotais(entradas);
  const operadores = agregarOperadores(entradas);
  const v = montantesValidados(period, sessao);

  const trocar = (linha, valor) => ({
    ...linha,
    montante: valor,
    montanteLancado: linha.montante,
  });

  return {
    totais: {
      ...trocar(totais, v.total),
      servicosValidados: v.servicos,
      grupos: totais.grupos
        .map((g) => trocar(g, v.grupos.get(g.id ?? null) ?? 0))
        .sort((a, b) => b.montante - a.montante),
    },
    operadores: operadores
      .map((o) => trocar(o, v.operadores.get(o.id ?? null) ?? 0))
      .sort((a, b) => b.montante - a.montante || b.contasValor - a.contasValor),
  };
}

// !RELATORIO — resumo do dia (ou período): montantes, contas e quebra por grupo.
// `sessao` restringe a um número; sem ela o relatório soma os três (é o que os
// comandos do WhatsApp usam — a operação é uma só, os números é que são vários).
export function relatorioGeral(period = 'today', { sessao = null } = {}) {
  const t = agregados(period, { sessao }).totais;
  const titulo = rotuloPeriodo(period);

  const linhas = [
    `📊 *RELATÓRIO — ${titulo}*`,
    ``,
    `• Montante validado: *${fmtBRL(t.montante)}* (${t.servicosValidados} serviço(s))`,
    `• Contas: *${t.contasQtd}* (soma ${fmtBRL(t.contasValor)})`,
    `• Lançamentos: ${t.qtdEntradas}`,
    `• Operadores ativos: ${t.qtdOperadores}`,
  ];

  if (t.grupos.length > 0) {
    linhas.push('', '*Por grupo:*');
    for (const g of t.grupos) {
      linhas.push(`  - ${g.nome}: ${fmtBRL(g.montante)} | ${g.contasQtd} contas`);
    }
  }
  return linhas.join('\n');
}

// !OPERADORES — desempenho por operador no período.
export function relatorioOperadores(period = 'today', { sessao = null } = {}) {
  const ops = agregados(period, { sessao }).operadores;
  const titulo = rotuloPeriodo(period);

  const linhas = [`👥 *OPERADORES — ${titulo}*`, `_montante validado_`, ``];
  if (ops.length === 0) {
    linhas.push('_Nenhum lançamento no período._');
  } else {
    ops.forEach((o, i) => {
      linhas.push(
        `${i + 1}. *${o.nome}* — ${fmtBRL(o.montante)} | ${o.contasQtd} contas (${fmtBRL(o.contasValor)})`,
      );
    });
  }
  return linhas.join('\n');
}

// !INDICACOES — ranking de quem trouxe mais Brogueiras no período.
export function relatorioIndicacoesTexto(period = 'today', { limite = 10, sessao = null } = {}) {
  const { resumo, ranking } = relatorioIndicacoes(period, { sessao });
  const titulo = rotuloPeriodo(period);

  const linhas = [`🏆 *INDICAÇÕES — ${titulo}*`, ''];
  if (ranking.length === 0) {
    linhas.push('_Nenhuma indicação no período._');
    return linhas.join('\n');
  }

  const medalha = ['🥇', '🥈', '🥉'];
  ranking.slice(0, limite).forEach((r, i) => {
    const plural = r.indicacoes === 1 ? 'indicação' : 'indicações';
    linhas.push(`${medalha[i] ?? `${i + 1}.`} *${r.nome}* — ${r.indicacoes} ${plural}`);
    // Quem ela trouxe: é a informação que o grupo confere na hora.
    linhas.push(`    _${r.indicadas.map((x) => x.nome).slice(0, 6).join(', ')}${r.indicadas.length > 6 ? '…' : ''}_`);
  });

  if (ranking.length > limite) linhas.push(`_…e mais ${ranking.length - limite} indicadora(s)._`);
  linhas.push('', `Total: ${resumo.indicacoes} indicações · ${resumo.indicadoras} indicadoras`);
  return linhas.join('\n');
}

// Versões estruturadas (para o dashboard).
export function dadosRelatorio(period = 'today', { sessao = null } = {}) {
  return agregados(period, { sessao });
}
