import { useEffect, useState, type FormEvent } from "react";
import { Plus, Pencil, Trash2, Shield, Crown, Eye, EyeOff, User as UserIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Dialog,
  DialogContent,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogDescription,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Badge } from "@/components/ui/badge";
import { toast } from "sonner";
import { useAuth } from "@/contexts/AuthContext";
import { ImageShortcutsAdmin } from "@/components/ImageShortcutsAdmin";
import { formatBRL } from "@/lib/format";

async function extractFnError(data: any, error: any): Promise<string | null> {
  if (data?.error) return String(data.error);
  if (!error) return null;
  try {
    const resp = (error as any)?.context?.response;
    if (resp && typeof resp.json === "function") {
      const body = await resp.clone().json();
      if (body?.error) return String(body.error);
    }
  } catch { /* ignore */ }
  return error.message ?? "Erro desconhecido";
}


// "owner" é o valor no banco; o rótulo exibido é "Dono".
type AppRole = "owner" | "admin" | "user";
type OperatorType = "bi" | "montante" | "contas";

const OPERATOR_LABEL: Record<OperatorType, string> = {
  bi: "Operador BI",
  montante: "Operador de Montante",
  contas: "Operador de Contas",
};

type AdminUser = {
  id: string;
  email: string;
  username: string;
  role: AppRole;
  operator_type: OperatorType;
  /** Cópia legível da senha. Vazia para contas cuja senha nunca foi redefinida. */
  password: string;
  created_at: string;
  commission_percent: number | null;
  commission_contas_percent: number | null;
  daily_goal: number | null;
};

export default function Users() {
  const { user: me, isDono } = useAuth();
  const [users, setUsers] = useState<AdminUser[]>([]);
  const [stats, setStats] = useState<Record<string, { lucro: number; ops: number; dep: number; saq: number }>>({});
  const [loading, setLoading] = useState(true);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<AdminUser | null>(null);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<AppRole>("user");
  const [operatorType, setOperatorType] = useState<OperatorType>("bi");
  const [commissionPct, setCommissionPct] = useState<string>("");
  const [commissionContasPct, setCommissionContasPct] = useState<string>("");
  const [dailyGoal, setDailyGoal] = useState<string>("");
  const [submitting, setSubmitting] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const fetchStats = async () => {
    const { data } = await supabase
      .from("operations")
      .select("user_id, lucro, deposito, saque");
    const map: Record<string, { lucro: number; ops: number; dep: number; saq: number }> = {};
    (data ?? []).forEach((o: any) => {
      const k = o.user_id;
      if (!map[k]) map[k] = { lucro: 0, ops: 0, dep: 0, saq: 0 };
      map[k].lucro += Number(o.lucro) || 0;
      map[k].dep += Number(o.deposito) || 0;
      map[k].saq += Number(o.saque) || 0;
      map[k].ops += 1;
    });
    setStats(map);
  };

  const fetchUsers = async () => {
    setLoading(true);
    const { data, error } = await supabase.functions.invoke("admin-users", {
      body: { action: "list" },
    });
    if (error) toast.error("Erro ao carregar usuários");
    setUsers(data?.users ?? []);
    await fetchStats();
    setLoading(false);
  };

  useEffect(() => {
    fetchUsers();
  }, []);

  const openCreate = () => {
    setEditing(null);
    setShowPassword(false);
    setUsername("");
    setPassword("");
    setRole("user");
    setOperatorType("bi");
    // Padrões do negócio — o admin pode alterar antes de salvar.
    setCommissionPct("15");
    setCommissionContasPct("20");
    setDailyGoal("");
    setDialogOpen(true);
  };

  const openEdit = (u: AdminUser) => {
    setEditing(u);
    setShowPassword(false);
    setUsername(u.username ?? "");
    // Senha atual já preenchida, para o olho poder revelá-la.
    setPassword(u.password ?? "");
    setRole(u.role);
    setOperatorType(u.operator_type ?? "bi");
    setCommissionPct(u.commission_percent != null ? String(u.commission_percent) : "");
    setCommissionContasPct(u.commission_contas_percent != null ? String(u.commission_contas_percent) : "");
    setDailyGoal(u.daily_goal != null ? String(u.daily_goal) : "");
    setDialogOpen(true);
  };

  // A edge function publicada rebaixa o usuário para minúsculo antes de gravar,
  // e a grafia original se perde no caminho. Regravamos aqui a que foi digitada.
  // O admin tem permissão de UPDATE em profiles pelo RLS, então isso independe
  // de a função estar atualizada no Supabase.
  const gravarGrafiaDoUsuario = async (userId: string | undefined, digitado: string) => {
    if (!userId) return;
    const grafia = digitado
      .trim()
      .normalize("NFD")
      .replace(/[̀-ͯ]/g, "")
      .replace(/[^A-Za-z0-9._-]+/g, "")
      .replace(/^[._-]+|[._-]+$/g, "");
    if (!grafia) return;
    const { error } = await supabase
      .from("profiles")
      .update({ username: grafia, nome: grafia })
      .eq("id", userId);
    if (error) {
      toast.error("Usuário salvo, mas as maiúsculas não puderam ser aplicadas", {
        description: error.message,
      });
    }
  };

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setSubmitting(true);
    if (editing) {
      const body: Record<string, unknown> = {
        action: "update",
        user_id: editing.id,
        // Nome e usuário são equivalentes: o nome segue o login.
        nome: username,
        username,
        role,
        operator_type: operatorType,
        commission_percent: commissionPct === "" ? null : Number(commissionPct),
        commission_contas_percent: commissionContasPct === "" ? null : Number(commissionContasPct),
        daily_goal: dailyGoal === "" ? 0 : Number(dailyGoal),
      };
      // Só envia se mudou: o Supabase recusa reenviar a senha atual.
      if (password && password !== editing.password) body.password = password;
      const { data, error } = await supabase.functions.invoke("admin-users", { body });
      const errMsg = await extractFnError(data, error);
      if (errMsg) {
        toast.error("Erro ao atualizar", { description: errMsg });
      } else {
        await gravarGrafiaDoUsuario(editing.id, username);
        toast.success("Usuário atualizado");
        setDialogOpen(false);
        fetchUsers();
      }
    } else {
      if (password.length < 6) {
        toast.error("Senha precisa ter ao menos 6 caracteres");
        setSubmitting(false);
        return;
      }
      if (username.trim().length < 3) {
        toast.error("Usuário precisa ter ao menos 3 caracteres");
        setSubmitting(false);
        return;
      }
      const { data, error } = await supabase.functions.invoke("admin-users", {
        body: {
          action: "create", nome: username, username, password, role,
          operator_type: operatorType,
          commission_percent: commissionPct === "" ? null : Number(commissionPct),
          commission_contas_percent: commissionContasPct === "" ? null : Number(commissionContasPct),
          daily_goal: 0,
        },
      });
      if (error || data?.error) {
        toast.error("Erro ao criar", { description: data?.error ?? error?.message });
      } else {
        await gravarGrafiaDoUsuario(data?.user_id, username);
        toast.success("Usuário criado");
        setDialogOpen(false);
        fetchUsers();
      }
    }
    setSubmitting(false);
  };

  const onDelete = async (u: AdminUser) => {
    if (u.id === me?.id) return toast.error("Você não pode deletar a si mesmo");
    if (u.role === "owner" && !isDono) {
      return toast.error("Apenas um DONO pode remover um DONO");
    }
    if (!confirm(`Remover ${u.email}?`)) return;
    const { data, error } = await supabase.functions.invoke("admin-users", {
      body: { action: "delete", user_id: u.id },
    });
    if (error || data?.error) {
      toast.error("Erro ao remover", { description: data?.error ?? error?.message });
    } else {
      toast.success("Usuário removido");
      fetchUsers();
    }
  };

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold md:text-3xl">Usuários</h1>
          <p className="text-sm text-muted-foreground">
            Gerencie quem tem acesso à plataforma e seus papéis.
          </p>
        </div>
        <Button onClick={openCreate} className="bg-gradient-primary shadow-glow">
          <Plus className="mr-2 h-4 w-4" /> Novo usuário
        </Button>
      </div>

      <div className="glass-strong overflow-hidden rounded-2xl">
        <Table>
          <TableHeader>
            <TableRow className="border-border hover:bg-transparent">
              <TableHead>Usuário</TableHead>
              <TableHead>Email</TableHead>
              <TableHead>Tipo</TableHead>
              <TableHead className="text-right">% Montante</TableHead>
              <TableHead className="text-right">% Contas</TableHead>
              <TableHead className="text-right">Meta diária</TableHead>
              <TableHead className="text-right">Operações</TableHead>
              <TableHead className="text-right">Lucro</TableHead>
              <TableHead className="text-right">Ações</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {loading ? (
              <TableRow>
                <TableCell colSpan={9} className="text-center text-muted-foreground">
                  Carregando...
                </TableCell>
              </TableRow>
            ) : users.length === 0 ? (
              <TableRow>
                <TableCell colSpan={9} className="py-12 text-center text-muted-foreground">
                  Nenhum usuário.
                </TableCell>
              </TableRow>
            ) : (
              users.map((u) => {
                const s = stats[u.id] ?? { lucro: 0, ops: 0, dep: 0, saq: 0 };
                return (
                <TableRow key={u.id} className="border-border/60">
                  <TableCell className="font-medium">{u.username || "—"}</TableCell>
                  <TableCell className="text-muted-foreground">{u.email}</TableCell>
                  <TableCell>
                    {u.role === "owner" ? (
                      <Badge className="gap-1 bg-warning/15 text-warning ring-1 ring-warning/30 hover:bg-warning/20">
                        <Crown className="h-3 w-3" /> Dono
                      </Badge>
                    ) : u.role === "admin" ? (
                      <Badge className="gap-1 bg-primary/15 text-primary ring-1 ring-primary/30 hover:bg-primary/20">
                        <Shield className="h-3 w-3" /> Admin
                      </Badge>
                    ) : (
                      <Badge variant="secondary" className="gap-1">
                        <UserIcon className="h-3 w-3" />
                        {OPERATOR_LABEL[u.operator_type ?? "bi"]}
                      </Badge>
                    )}
                  </TableCell>
                  <TableCell className="number-tabular text-right">
                    {u.commission_percent != null ? (
                      <span className="font-semibold text-primary">{u.commission_percent}%</span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="number-tabular text-right">
                    {u.commission_contas_percent != null ? (
                      <span className="font-semibold text-accent">{u.commission_contas_percent}%</span>
                    ) : (
                      <span className="text-muted-foreground">—</span>
                    )}
                  </TableCell>
                  <TableCell className="number-tabular text-right">
                    {u.daily_goal ? formatBRL(u.daily_goal) : <span className="text-muted-foreground">—</span>}
                  </TableCell>
                  <TableCell className="number-tabular text-right text-muted-foreground">{s.ops}</TableCell>
                  <TableCell className={`number-tabular text-right font-bold ${s.lucro >= 0 ? "text-success" : "text-destructive"}`}>
                    {formatBRL(s.lucro)}
                  </TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1">
                      <Button
                        size="icon"
                        variant="ghost"
                        onClick={() => openEdit(u)}
                        disabled={u.role === "owner" && !isDono}
                        title={u.role === "owner" && !isDono ? "Apenas um DONO pode editar um DONO" : undefined}
                      >
                        <Pencil className="h-4 w-4" />
                      </Button>
                      <Button
                        size="icon"
                        variant="ghost"
                        className="text-destructive hover:text-destructive"
                        onClick={() => onDelete(u)}
                        disabled={u.id === me?.id || (u.role === "owner" && !isDono)}
                        title={u.role === "owner" && !isDono ? "Apenas um DONO pode remover um DONO" : undefined}
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>

      <ImageShortcutsAdmin />

      <Dialog open={dialogOpen} onOpenChange={setDialogOpen}>
        <DialogContent className="glass-strong">
          <DialogHeader>
            <DialogTitle>{editing ? "Editar usuário" : "Criar usuário"}</DialogTitle>
            <DialogDescription>
              {editing
                ? "Deixe a senha em branco para mantê-la."
                : "O usuário poderá entrar imediatamente após a criação."}
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="u-username">Usuário (login)</Label>
              <Input
                id="u-username"
                type="text"
                autoCapitalize="none"
                autoCorrect="off"
                spellCheck={false}
                placeholder="joao.silva"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                required
              />
              <p className="text-[11px] text-muted-foreground">
                É com isso que a pessoa entra no sistema, e também é o nome que
                aparece nas telas. Letras, números, ponto, hífen e underscore.
              </p>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="u-pass">Senha</Label>
              <div className="relative">
                <Input
                  id="u-pass"
                  type={showPassword ? "text" : "password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder={editing ? "Sem senha registrada — defina uma nova" : "Mínimo 6 caracteres"}
                  className="pr-10"
                  required={!editing}
                  minLength={editing ? undefined : 6}
                  autoComplete="new-password"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
                  aria-label={showPassword ? "Ocultar senha" : "Mostrar senha"}
                >
                  {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
              </div>
              {editing && !editing.password && (
                <p className="text-[10px] text-warning">
                  Esta conta é anterior ao registro de senhas, então não há o que
                  exibir. Defina uma nova para que ela passe a aparecer aqui.
                </p>
              )}
            </div>
            <div className="space-y-1.5">
              <Label>Tipo</Label>
              {/* DONO não é concedido pela tela. Ao editar um DONO existente o
                  campo vira leitura, para não rebaixá-lo sem querer ao salvar. */}
              {role === "owner" ? (
                <div className="flex h-10 items-center rounded-md border border-border bg-muted/40 px-3 text-sm font-medium">
                  Dono
                </div>
              ) : (
                <Select value={role} onValueChange={(v) => setRole(v as AppRole)}>
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="user">Operador</SelectItem>
                    <SelectItem value="admin">Administrador</SelectItem>
                  </SelectContent>
                </Select>
              )}
            </div>
            {role === "user" && (
            <div className="space-y-1.5">
              <Label>Categoria do Operador</Label>
              <Select value={operatorType} onValueChange={(v) => setOperatorType(v as OperatorType)}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="bi">Operador BI</SelectItem>
                  <SelectItem value="montante">Operador de Montante</SelectItem>
                  <SelectItem value="contas">Operador de Contas</SelectItem>
                </SelectContent>
              </Select>
              <p className="text-[11px] text-muted-foreground">
                BI enxerga o dashboard completo. Montante e Contas ficam restritos
                às funcionalidades e comissões da sua área.
              </p>
            </div>
            )}
            <div className="grid grid-cols-2 gap-3">
              <div className="space-y-1.5">
                <Label htmlFor="u-pct">% Comissão Blogueira</Label>
                <Input
                  id="u-pct"
                  type="number"
                  min={0}
                  max={100}
                  step="0.01"
                  placeholder="ex: 15"
                  value={commissionPct}
                  onChange={(e) => setCommissionPct(e.target.value)}
                />
                <p className="text-[10px] text-muted-foreground">Cobrada sobre o salário das blogueiras. Vazio = não cobrar.</p>
              </div>
              <div className="space-y-1.5">
                <Label htmlFor="u-pct-contas">% Comissão Contas</Label>
                <Input
                  id="u-pct-contas"
                  type="number"
                  min={0}
                  max={100}
                  step="0.01"
                  placeholder="ex: 20"
                  value={commissionContasPct}
                  onChange={(e) => setCommissionContasPct(e.target.value)}
                />
                <p className="text-[10px] text-muted-foreground">Aplicada sobre o lucro líquido das operações de Contas.</p>
              </div>
              {/* Meta diária não é definida na criação: nasce em 0 e é ajustada
                  depois, aqui na edição ou pelo próprio usuário no Dashboard. */}
              {editing && (
                <div className="space-y-1.5 col-span-2">
                  <Label htmlFor="u-meta">Meta diária (R$)</Label>
                  <Input
                    id="u-meta"
                    type="number"
                    min={0}
                    step="0.01"
                    placeholder="0,00"
                    value={dailyGoal}
                    onChange={(e) => setDailyGoal(e.target.value)}
                  />
                  <p className="text-[10px] text-muted-foreground">Usada no gráfico de Lucro do Dia.</p>
                </div>
              )}
            </div>
            <DialogFooter>
              <Button type="button" variant="ghost" onClick={() => setDialogOpen(false)}>
                Cancelar
              </Button>
              <Button type="submit" disabled={submitting} className="bg-gradient-primary shadow-glow">
                {submitting ? "Salvando..." : editing ? "Salvar" : "Criar"}
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
