// Agendamentos de mensagens (node-cron). Persistidos em db.schedules.
import cron from 'node-cron';
import { getDb, saveDb, getSessao } from './db.js';
import { IDS_SESSOES, SESSAO_PADRAO } from './sessoes.js';
import { logger } from './logger.js';
import { sendText, sendImage, groupParticipants } from './whatsapp.js';
import { emitUpdate } from './realtime.js';
import { caminhoMidia, normalizarMidia, midiaExiste, removerMidia } from './midia.js';

const jobs = new Map(); // id -> cron task

// Cada agendamento pertence a UM número — é ele que envia. Um número desligado
// (ou sem o recurso "Agendamentos") não dispara: o erro fica gravado no próprio
// agendamento e aparece como ⚠ no painel, em vez de sumir num log.
function sessaoDoDisparo(schedule) {
  const id = IDS_SESSOES.includes(schedule.sessaoId) ? schedule.sessaoId : SESSAO_PADRAO;
  const sessao = getSessao(id);
  if (!sessao.ativa) throw new Error(`${sessao.nome} está desligado — o agendamento não foi enviado`);
  if (!sessao.recursos?.agendamentos) {
    throw new Error(`${sessao.nome} está sem o recurso "Agendamentos" ligado`);
  }
  return id;
}

// Dispara um agendamento: com imagem vira "imagem + legenda" (uma mensagem só).
async function disparar(schedule) {
  const sessaoId = sessaoDoDisparo(schedule);
  // "Marcar todos": os participantes entram em `mentions`, então todo mundo é
  // notificado sem encher a mensagem de @número. A lista é buscada na hora —
  // o grupo muda de membros entre um disparo e outro.
  const mentions = schedule.mentionAll ? await groupParticipants(sessaoId, schedule.to) : undefined;

  if (schedule.media?.file) {
    if (!midiaExiste(schedule.media)) throw new Error(`imagem ausente em uploads/ (${schedule.media.file})`);
    return sendImage(sessaoId, schedule.to, caminhoMidia(schedule.media.file), {
      caption: schedule.message,
      mimetype: schedule.media.mime,
      mentions,
    });
  }
  return sendText(sessaoId, schedule.to, schedule.message, { mentions });
}

function timezone() {
  return getDb().config.timezone || 'America/Sao_Paulo';
}

function agendar(schedule) {
  if (!schedule.enabled) return;
  if (!cron.validate(schedule.cron)) {
    logger.warn({ id: schedule.id, cron: schedule.cron }, 'expressão cron inválida — ignorada');
    return;
  }
  const task = cron.schedule(
    schedule.cron,
    async () => {
      try {
        await disparar(schedule);
        schedule.lastRun = new Date().toISOString();
        schedule.lastError = null;
        logger.info(
          { id: schedule.id, sessao: schedule.sessaoId, to: schedule.to, comImagem: Boolean(schedule.media) },
          'agendamento disparado',
        );
      } catch (err) {
        // Guarda o erro no próprio agendamento: sem isso a falha só aparecia
        // no log e o painel seguia mostrando o agendamento como saudável.
        schedule.lastError = { em: new Date().toISOString(), erro: err.message };
        logger.error(err, `falha no agendamento ${schedule.id}`);
      }
      saveDb();
      emitUpdate();
    },
    { timezone: timezone() },
  );
  jobs.set(schedule.id, task);
}

// (Re)carrega todos os cron jobs a partir do db.
export function iniciarAgendamentos() {
  for (const t of jobs.values()) t.stop();
  jobs.clear();
  for (const s of getDb().schedules) agendar(s);
  logger.info({ total: jobs.size }, 'agendamentos ativos');
}

// Multipart e JSON chegam com tipos diferentes ("false" string x false).
const ehVerdade = (v) => v === true || v === 'true' || v === 'on' || v === 1 || v === '1';

function validarCron(expr) {
  if (!cron.validate(expr)) throw new Error('expressão cron inválida');
  return expr;
}

// O número que vai enviar. Só os três ids conhecidos; vazio = Número 1.
function validarSessao(sessaoId) {
  const id = String(sessaoId ?? '').trim() || SESSAO_PADRAO;
  if (!IDS_SESSOES.includes(id)) throw new Error(`número inválido: ${sessaoId}`);
  return id;
}

function validarDestino(to) {
  const destino = String(to ?? '').trim();
  if (!destino) throw new Error('destino obrigatório');
  // Um destino sem "@" e sem dígitos (ex.: "SSSS") só falharia na hora do
  // disparo, meses depois — o agendamento parece saudável no painel até lá.
  if (!destino.includes('@') && !/\d/.test(destino)) {
    throw new Error('destino inválido: escolha um grupo monitorado ou informe um número');
  }
  return destino;
}

// "Marcar todos" só faz sentido em grupo — num privado não há quem marcar.
function validarMencao(mentionAll, destino) {
  const marcar = ehVerdade(mentionAll);
  if (marcar && !String(destino).endsWith('@g.us')) {
    throw new Error('"marcar todos" só funciona em grupo');
  }
  return marcar;
}

export function adicionarAgendamento({
  name, cron: expr, to, message, enabled = true, media = null, mentionAll = false, sessaoId = SESSAO_PADRAO,
}) {
  validarCron(expr);
  const sessao = validarSessao(sessaoId);
  const destino = validarDestino(to);
  const marcarTodos = validarMencao(mentionAll, destino);
  const midia = normalizarMidia(media);
  const texto = String(message ?? '').trim();
  // Sem imagem o texto é a mensagem inteira; com imagem ele é só a legenda.
  if (!texto && !midia) throw new Error('mensagem ou imagem obrigatória');
  const db = getDb();
  const schedule = {
    id: `sch_${Date.now()}`,
    name: name || 'sem nome',
    sessaoId: sessao,
    cron: expr,
    to: destino,
    message: texto,
    media: midia,
    mentionAll: marcarTodos,
    enabled: enabled !== false && enabled !== 'false',
    lastRun: null,
    lastError: null,
    createdAt: new Date().toISOString(),
  };
  db.schedules.push(schedule);
  saveDb({ immediate: true });
  agendar(schedule);
  emitUpdate(); // o painel lista os agendamentos pelo snapshot — sem isto só aparecia no próximo evento
  return schedule;
}

// Edita um agendamento existente. Só os campos presentes em `dados` mudam.
// Devolve o agendamento atualizado, ou null se o id não existir.
//
// A validação acontece TODA antes de qualquer mutação: um pedido inválido não
// pode deixar o agendamento meio editado (nem apagar a imagem antiga à toa).
export function atualizarAgendamento(id, dados = {}) {
  const db = getDb();
  const s = db.schedules.find((x) => x.id === id);
  if (!s) return null;

  const expr = dados.cron !== undefined ? validarCron(String(dados.cron)) : s.cron;
  const sessao = dados.sessaoId !== undefined ? validarSessao(dados.sessaoId) : validarSessao(s.sessaoId);
  const destino = dados.to !== undefined ? validarDestino(dados.to) : s.to;
  const texto = dados.message !== undefined ? String(dados.message).trim() : s.message;
  const nome = dados.name !== undefined ? String(dados.name).trim() || 'sem nome' : s.name;
  const marcarTodos = dados.mentionAll !== undefined ? validarMencao(dados.mentionAll, destino) : validarMencao(s.mentionAll, destino);
  const habilitado = dados.enabled !== undefined ? ehVerdade(dados.enabled) : s.enabled;

  // A imagem tem três desfechos: trocar, remover ou manter.
  const novaMidia = dados.media ? normalizarMidia(dados.media) : null;
  const removendo = ehVerdade(dados.removerImagem);
  const midiaFinal = novaMidia ?? (removendo ? null : s.media);
  if (!texto && !midiaFinal) throw new Error('mensagem ou imagem obrigatória');

  // Validado: agora sim mexe no disco e no estado.
  const antiga = s.media;
  if (antiga && midiaFinal?.file !== antiga.file) removerMidia(antiga);
  Object.assign(s, {
    name: nome,
    sessaoId: sessao,
    cron: expr,
    to: destino,
    message: texto,
    media: midiaFinal,
    mentionAll: marcarTodos,
    enabled: habilitado,
  });

  // Reagenda: o cron/horário podem ter mudado e a task antiga segue viva.
  jobs.get(id)?.stop();
  jobs.delete(id);
  agendar(s);
  saveDb({ immediate: true });
  emitUpdate();
  return s;
}

export function removerAgendamento(id) {
  const db = getDb();
  const idx = db.schedules.findIndex((s) => s.id === id);
  if (idx === -1) return false;
  jobs.get(id)?.stop();
  jobs.delete(id);
  const [removido] = db.schedules.splice(idx, 1);
  // A imagem só existia para este agendamento — sem isso uploads/ cresce sem fim.
  if (removido?.media) removerMidia(removido.media);
  saveDb({ immediate: true });
  emitUpdate();
  return true;
}

export function alternarAgendamento(id, enabled) {
  const db = getDb();
  const s = db.schedules.find((x) => x.id === id);
  if (!s) return false;
  s.enabled = enabled;
  jobs.get(id)?.stop();
  jobs.delete(id);
  if (enabled) agendar(s);
  saveDb({ immediate: true });
  emitUpdate();
  return true;
}
