// Links repetidos: o mesmo link pedido mais de uma vez no grupo.
//
// Um link de plataforma carrega o id da conta ("?id=357497224") — mandá-lo de
// novo é pedir de novo a MESMA conta. Acontece de dois jeitos, e o painel
// separa os dois porque significam coisas diferentes:
//
//   mesma Brogueira  → ela reenviou o próprio link (insistência/cobrança)
//   outra Brogueira  → o link de uma apareceu na mão de outra (o caso que
//                      interessa: duas pessoas cobrando pela mesma conta)
//
// A comparação é pela chave normalizada do link, não pelo texto cru: o mesmo
// link vem ora com https://, ora com www., ora com barra no fim.
import { desestilizar } from './parser.js';

// Convite de grupo/Telegram não é pedido de conta — é divulgação, e é o link
// mais repetido do grupo (17× no histórico, por 8 pessoas diferentes). Ficaria
// no topo do painel todo dia escondendo os repetidos de verdade.
export const DOMINIOS_IGNORADOS = [
  'chat.whatsapp.com',
  'api.whatsapp.com',
  'wa.me',
  'whatsapp.com',
  't.me',
  'telegram.me',
];

// Chave de comparação. Minúsculas no todo: os ids destas plataformas são
// numéricos, então não há caminho sensível a maiúsculas para preservar.
export function chaveLink(link) {
  let t = desestilizar(String(link ?? '')).trim().toLowerCase();
  if (!t) return null;
  t = t.replace(/^https?:\/\//, '').replace(/^www\./, '');
  t = t.split('#')[0]; // o fragmento não muda o destino
  t = t.replace(/[.,;:)\]]+$/, ''); // pontuação grudada ("...id=1.")
  t = t.replace(/\/+$/, ''); // barra final
  return t || null;
}

export function dominioDaChave(chave) {
  return String(chave ?? '').split('/')[0] || null;
}

export function ehLinkIgnorado(link) {
  const dominio = dominioDaChave(chaveLink(link));
  return dominio ? DOMINIOS_IGNORADOS.includes(dominio) : true;
}

// Identidade de quem mandou o pedido, para saber se a repetição é da mesma
// pessoa. O LID é o que o WhatsApp entrega hoje; o telefone e o nome entram
// como reserva para registros antigos que só têm um deles.
export function chaveAutor(p) {
  return p?.autorId ?? p?.autorPn ?? p?.autorNome ?? null;
}

function mesmaPessoa(a, b) {
  const x = chaveAutor(a);
  const y = chaveAutor(b);
  return Boolean(x && y && x === y);
}

const HORA_MS = 3600 * 1000;

// Corta o histórico na janela configurada (0/ausente = tudo o que está salvo).
export function dentroDaJanela(ts, { janelaHoras = 0, agora = Date.now() } = {}) {
  if (!janelaHoras || janelaHoras <= 0) return true;
  const t = Date.parse(ts);
  if (!Number.isFinite(t)) return true; // sem data legível, não descarta
  return t >= agora - janelaHoras * HORA_MS;
}

/**
 * Repetições de um pedido que ACABOU de chegar, contra o histórico anterior.
 * `historico` vem em ordem cronológica (é a ordem em que db.pedidos cresce).
 * Devolve uma entrada por link repetido — vazio quando não há repetição.
 */
export function detectarRepeticoes(pedido, historico = [], { janelaHoras = 0, agora = Date.now() } = {}) {
  const saida = [];
  for (const link of pedido?.links ?? []) {
    if (ehLinkIgnorado(link)) continue;
    const chave = chaveLink(link);
    if (!chave) continue;

    const anteriores = historico.filter(
      (p) => p !== pedido
        && dentroDaJanela(p.ts, { janelaHoras, agora })
        && (p.links ?? []).some((l) => chaveLink(l) === chave),
    );
    if (!anteriores.length) continue;

    const primeiro = anteriores[0];
    const deOutra = anteriores.some((p) => !mesmaPessoa(p, pedido));
    saida.push({
      link,
      chave,
      dominio: dominioDaChave(chave),
      vezes: anteriores.length + 1, // esta inclusive
      deOutra,
      mesmaAutora: !deOutra,
      primeiroEm: primeiro.ts ?? null,
      primeiroPor: primeiro.autorNome ?? null,
      primeiroPorId: chaveAutor(primeiro),
      primeiroPedidoId: primeiro.id ?? null,
    });
  }
  return saida;
}

/**
 * Agrupa um conjunto de pedidos por link, para o painel.
 *
 * `noPeriodo` decide quais envios contam como "aconteceu no período olhado" —
 * o grupo aparece se pelo menos UM envio caiu ali. É de propósito: um link
 * mandado ontem e repetido hoje é justamente o que se quer ver em "Hoje", e
 * um filtro que jogasse fora o envio de ontem esconderia a repetição inteira.
 */
export function agruparRepetidos(pedidos = [], { noPeriodo = null, janelaHoras = 0, agora = Date.now() } = {}) {
  const grupos = new Map();

  for (const p of pedidos) {
    if (!dentroDaJanela(p.ts, { janelaHoras, agora })) continue;
    // Um mesmo pedido pode trazer o mesmo link duas vezes no texto; extrairLinks
    // já deduplica o texto cru, mas duas grafias ("www." e sem) chegam iguais só
    // depois da normalização.
    const vistas = new Set();
    for (const link of p.links ?? []) {
      if (ehLinkIgnorado(link)) continue;
      const chave = chaveLink(link);
      if (!chave || vistas.has(chave)) continue;
      vistas.add(chave);

      const g = grupos.get(chave) ?? { chave, link, dominio: dominioDaChave(chave), envios: [] };
      g.envios.push({
        pedidoId: p.id ?? null,
        ts: p.ts ?? null,
        day: p.day ?? null,
        autorChave: chaveAutor(p),
        autorNome: p.autorNome ?? 'desconhecida',
        autorPn: p.autorPn ?? null,
        papel: p.papel ?? 'desconhecido',
        groupName: p.groupName ?? null,
        tipo: p.tipo ?? 'indefinido',
        montante: p.montante ?? 0,
        contas: p.contas ?? null,
        pedido: p.pedido ?? '',
        noPeriodo: noPeriodo ? noPeriodo.has(p.id) : true,
      });
      grupos.set(chave, g);
    }
  }

  const repetidos = [];
  for (const g of grupos.values()) {
    if (g.envios.length < 2) continue;
    if (!g.envios.some((e) => e.noPeriodo)) continue;
    g.envios.sort((a, b) => String(a.ts).localeCompare(String(b.ts)));
    const autoras = new Set(g.envios.map((e) => e.autorChave ?? e.autorNome));
    repetidos.push({
      ...g,
      vezes: g.envios.length,
      repeticoes: g.envios.length - 1, // envios além do primeiro
      autoras: autoras.size,
      deOutras: autoras.size > 1,
      primeiroEm: g.envios[0].ts,
      ultimoEm: g.envios[g.envios.length - 1].ts,
      envios: g.envios.map((e, i) => ({ ...e, ordem: i + 1 })),
    });
  }

  // Mais repetido primeiro; empate resolve por quem repetiu mais recentemente.
  repetidos.sort((a, b) => b.vezes - a.vezes || String(b.ultimoEm).localeCompare(String(a.ultimoEm)));
  return repetidos;
}
