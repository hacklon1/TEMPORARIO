// O painel é a única parte do sistema sem cobertura automática, e o relógio /
// construtor de cron do agendamento é lógica de verdade (não só layout).
// Aqui o index.html + app.js sobem num DOM real (jsdom) e o teste opera os
// controles como um usuário faria: clicar no mostrador, marcar dias, ler o cron.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const PUBLIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

// Um clique no mostrador: converte (hora do relógio, anel) em coordenadas de
// tela e despacha o pointerdown/up que o componente escuta.
function clicarNoDial(win, doc, posicao, { interno = false } = {}) {
  const svg = doc.getElementById('clk-dial');
  const raio = interno ? 62 : 94;
  const ang = (posicao / 12) * 2 * Math.PI - Math.PI / 2;
  const x = 120 + raio * Math.cos(ang);
  const y = 120 + raio * Math.sin(ang);
  for (const tipo of ['pointerdown', 'pointerup']) {
    const ev = new win.Event(tipo, { bubbles: true });
    // jsdom não implementa PointerEvent; o componente só lê clientX/clientY/pointerId.
    Object.assign(ev, { clientX: x, clientY: y, pointerId: 1 });
    svg.dispatchEvent(ev);
  }
}

async function montarPainel() {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  // 'dangerously' só habilita os scripts que o próprio teste injeta: o jsdom não
  // busca recursos externos, então as tags <script src> da página são ignoradas.
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;

  // O jsdom não tem layout nem pointer capture — o mostrador depende dos dois.
  window.Element.prototype.getBoundingClientRect = () => ({
    left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0,
  });
  window.Element.prototype.setPointerCapture = () => {};
  window.Element.prototype.releasePointerCapture = () => {};

  // Injetado como <script> (e não window.eval) para que as funções de topo do
  // app.js virem globais mesmo com o 'use strict' do arquivo.
  const tag = window.document.createElement('script');
  tag.textContent = fs.readFileSync(path.join(PUBLIC, 'app.js'), 'utf8');
  window.document.body.appendChild(tag);
  return { window, doc: window.document };
}

test('app.js carrega sem erro e desenha o relógio', async () => {
  const { doc } = await montarPainel();
  const dial = doc.getElementById('clk-dial');
  assert.ok(dial.innerHTML.includes('clk-hand'), 'ponteiro desenhado');
  assert.ok(dial.innerHTML.includes('clk-face'), 'mostrador desenhado');
  // 12 números no anel de fora + 12 no de dentro (24h no mesmo mostrador)
  assert.equal((dial.innerHTML.match(/class="clk-num/g) || []).length, 24);
  assert.equal(doc.getElementById('clk-h').textContent, '09'); // padrão 09:00
  assert.equal(doc.getElementById('clk-m').textContent, '00');
  assert.match(doc.getElementById('sch-resumo').textContent, /Todo dia às 09:00/);
});

test('clicar no mostrador escolhe hora e depois minutos', async () => {
  const { window, doc } = await montarPainel();

  clicarNoDial(window, doc, 7); // anel de fora, posição 7 => 07h
  assert.equal(doc.getElementById('clk-h').textContent, '07');
  // depois da hora o mostrador passa sozinho para os minutos
  assert.ok(doc.getElementById('clk-m').classList.contains('active'));

  clicarNoDial(window, doc, 6); // posição 6 no anel de minutos => 30 min
  assert.equal(doc.getElementById('clk-m').textContent, '30');
  assert.match(doc.getElementById('sch-resumo').textContent, /Todo dia às 07:30/);
  assert.match(doc.getElementById('sch-resumo').textContent, /30 7 \* \* \*/);
});

test('anel de dentro seleciona as horas de 13 a 00', async () => {
  const { window, doc } = await montarPainel();
  clicarNoDial(window, doc, 8, { interno: true }); // 12 + 8 = 20h
  assert.equal(doc.getElementById('clk-h').textContent, '20');

  doc.getElementById('clk-h').click(); // volta para o modo hora (o clique acima já passou p/ minutos)
  clicarNoDial(window, doc, 0, { interno: true }); // topo do anel de dentro = 00h
  assert.equal(doc.getElementById('clk-h').textContent, '00');
});

test('setas do teclado ajustam o valor do modo atual', async () => {
  const { window, doc } = await montarPainel();
  const dial = doc.getElementById('clk-dial');
  const tecla = (key) => dial.dispatchEvent(new window.KeyboardEvent('keydown', { key, bubbles: true }));
  tecla('ArrowUp');
  assert.equal(doc.getElementById('clk-h').textContent, '10');
  tecla('Enter'); // alterna para minutos
  tecla('ArrowDown');
  assert.equal(doc.getElementById('clk-m').textContent, '59');
});

test('dias da semana viram a lista do cron', async () => {
  const { doc } = await montarPainel();
  doc.querySelector('#sch-freq button[data-freq="semana"]').click();
  assert.ok(!doc.getElementById('freq-semana').classList.contains('hidden'));

  // sem dia marcado o formulário avisa em vez de montar um cron inválido
  assert.match(doc.getElementById('sch-resumo').textContent, /pelo menos um dia/);

  doc.querySelector('#sch-dias button[data-dow="1"]').click();
  doc.querySelector('#sch-dias button[data-dow="5"]').click();
  const resumo = doc.getElementById('sch-resumo').textContent;
  assert.match(resumo, /Seg, Sex às 09:00/);
  assert.match(resumo, /0 9 \* \* 1,5/);
});

test('intervalo monta */N e valida o limite', async () => {
  const { doc } = await montarPainel();
  doc.querySelector('#sch-freq button[data-freq="intervalo"]').click();
  assert.match(doc.getElementById('sch-resumo').textContent, /A cada 30 minutos.*\*\/30 \* \* \* \*/s);

  const cada = doc.getElementById('sch-cada');
  cada.value = '2';
  doc.getElementById('sch-unidade').value = 'hora';
  doc.getElementById('sch-unidade').dispatchEvent(new doc.defaultView.Event('change'));
  assert.match(doc.getElementById('sch-resumo').textContent, /A cada 2 horas.*0 \*\/2 \* \* \*/s);

  cada.value = '99'; // acima do teto de horas
  cada.dispatchEvent(new doc.defaultView.Event('input'));
  assert.match(doc.getElementById('sch-resumo').textContent, /intervalo deve ser de 1 a 23/);
});

test('cron manual substitui o relógio', async () => {
  const { doc } = await montarPainel();
  const campo = doc.getElementById('sch-cron');
  campo.value = '15 4 * * 0';
  campo.dispatchEvent(new doc.defaultView.Event('input'));
  assert.match(doc.getElementById('sch-resumo').textContent, /Cron manual.*15 4 \* \* 0/s);
});

test('o destino sai da configuração de monitoramento', async () => {
  const { window } = await montarPainel();
  const grupos = [
    { id: 'a@g.us', nome: 'Contas BM' },
    { id: 'b@g.us', nome: 'Montante BR' },
    { id: 'c@g.us', nome: 'Off-topic' },
  ];
  // O spread recria o array neste realm — um Array vindo do jsdom tem outro
  // prototype e o deepEqual estrito reclamaria disso, não do conteúdo.
  const ids = (lista) => [...lista].map((g) => g.id);

  // 'all': todo grupo do bot é monitorado
  assert.deepEqual(ids(window.gruposMonitorados(grupos, { monitorMode: 'all' })), ['a@g.us', 'b@g.us', 'c@g.us']);
  // 'specific': só os marcados na aba Grupos
  assert.deepEqual(
    ids(window.gruposMonitorados(grupos, { monitorMode: 'specific', monitoredGroups: ['b@g.us'] })),
    ['b@g.us'],
  );
  // 'none' (ou sem config): nada para agendar
  // (ids() também normaliza o array vindo do realm do jsdom)
  assert.deepEqual(ids(window.gruposMonitorados(grupos, { monitorMode: 'none' })), []);
  assert.deepEqual(ids(window.gruposMonitorados(grupos, undefined)), []);
  assert.deepEqual(ids(window.gruposMonitorados(undefined, { monitorMode: 'all' })), []);
});

test('a tabela mostra o nome do grupo, não o JID', async () => {
  const { window, doc } = await montarPainel();
  window.definirNomesGrupos([{ id: '120363@g.us', nome: 'Op. Contas e Montante BM' }]);
  window.renderSchedules([
    { id: 'a', name: 'Diário', cron: '0 9 * * *', to: '120363@g.us', enabled: true },
    { id: 'b', name: 'Antigo', cron: '0 9 * * *', to: '5511999999999', enabled: true },
  ]);
  const linhas = [...doc.querySelectorAll('#tbl-sch tbody tr')].map((tr) => tr.textContent);
  assert.match(linhas[0], /Op\. Contas e Montante BM/);
  assert.ok(!linhas[0].includes('120363@g.us'));
  assert.match(linhas[1], /5511999999999/); // destino desconhecido continua legível
});

test('painel das Brogueiras renderiza totais, tabela e detalhe por dia', async () => {
  const { window, doc } = await montarPainel();
  window.renderBrogueiras({
    resumo: { pedidos: 5, brogueirasAtivas: 2, montanteTotal: 1920, montantePedidos: 3, contasTotal: 15, contasPedidos: 2, links: 5, indefinidos: 0 },
    brogueiras: [
      {
        id: 'ana@lid', nome: 'Ana', papel: 'brogueira', pedidos: 3, montanteTotal: 520,
        contasTotal: 15, links: ['https://670win.me/?id=1'],
        dias: [{
          day: '2026-08-02',
          pedidos: [
            { id: 'p1', ts: '2026-08-02T12:00:00Z', tipo: 'conta', montante: 0, contas: 7, links: ['https://670win.me/?id=1'], pedido: '7 contas variadas' },
            { id: 'p2', ts: '2026-08-02T13:00:00Z', tipo: 'montante', montante: 520, contas: 4, links: ['https://okokathena.win/?id=2'], pedido: '520 em 4' },
          ],
        }],
      },
      { id: 'bia@lid', nome: 'Bia', papel: 'brogueira', pedidos: 2, montanteTotal: 1400, contasTotal: 0, links: [], dias: [] },
    ],
    plataformas: [{ dominio: 'lasanhapg.co', qtd: 2 }, { dominio: '670win.me', qtd: 1 }],
  });

  assert.equal(doc.getElementById('bg-kpi-pedidos').textContent, '5');
  assert.match(doc.getElementById('bg-kpi-montante').textContent, /1,9 mil/);
  assert.equal(doc.getElementById('bg-kpi-contas').textContent, '15');
  assert.equal(doc.querySelectorAll('#tbl-bg tbody tr').length, 2);
  assert.match(doc.querySelector('#tbl-bg tbody tr').textContent, /Ana/);
  assert.equal(doc.querySelectorAll('#bg-plataformas .plat-row').length, 2);

  // clicar na linha abre o detalhe com os links daquele dia
  assert.ok(doc.getElementById('bg-detalhe').classList.contains('hidden'));
  doc.querySelector('#tbl-bg tbody tr').click();
  assert.ok(!doc.getElementById('bg-detalhe').classList.contains('hidden'));
  const detalhe = doc.getElementById('bg-detalhe-corpo').textContent;
  assert.match(detalhe, /2026-08-02/);
  assert.match(detalhe, /7 contas variadas/);
  assert.match(detalhe, /520 em 4/);
  // o link é clicável e não vaza referrer para a plataforma
  const a = doc.querySelector('#bg-detalhe-corpo a.link-ped');
  assert.equal(a.getAttribute('href'), 'https://670win.me/?id=1');
  assert.match(a.getAttribute('rel'), /noopener/);
  // tipos marcados com rótulo, não só com cor
  const tipos = [...doc.querySelectorAll('#bg-detalhe-corpo .tag-tipo')].map((t) => t.textContent);
  assert.deepEqual(tipos, ['Conta', 'Montante']);

  doc.getElementById('bg-fechar').click();
  assert.ok(doc.getElementById('bg-detalhe').classList.contains('hidden'));
});

test('links repetidos aparecem no painel com quem mandou primeiro', async () => {
  const { window, doc } = await montarPainel();
  const repetidos = {
    resumo: { links: 2, envios: 5, repeticoes: 3, deOutras: 1, mesmaAutora: 1, brogueiras: 2 },
    grupos: [
      {
        chave: 'okok.com/?id=5', link: 'https://okok.com/?id=5', dominio: 'okok.com',
        vezes: 3, repeticoes: 2, autoras: 2, deOutras: true,
        primeiroEm: '2026-08-02T12:00:00Z', ultimoEm: '2026-08-02T15:00:00Z',
        envios: [
          { pedidoId: 'p1', ts: '2026-08-02T12:00:00Z', autorChave: 'ana@lid', autorNome: 'Ana', papel: 'brogueira', tipo: 'conta', montante: 0, contas: 7, pedido: '7 contas', noPeriodo: false, ordem: 1 },
          { pedidoId: 'p2', ts: '2026-08-02T14:00:00Z', autorChave: 'bia@lid', autorNome: 'Bia', papel: 'brogueira', tipo: 'montante', montante: 300, contas: null, pedido: '300', noPeriodo: true, ordem: 2 },
          { pedidoId: 'p3', ts: '2026-08-02T15:00:00Z', autorChave: 'ana@lid', autorNome: 'Ana', papel: 'brogueira', tipo: 'conta', montante: 0, contas: 2, pedido: '2 contas', noPeriodo: true, ordem: 3 },
        ],
      },
      {
        chave: 'so-dela.com/?id=9', link: 'https://so-dela.com/?id=9', dominio: 'so-dela.com',
        vezes: 2, repeticoes: 1, autoras: 1, deOutras: false,
        primeiroEm: '2026-08-02T09:00:00Z', ultimoEm: '2026-08-02T10:00:00Z',
        envios: [
          { pedidoId: 'p4', ts: '2026-08-02T09:00:00Z', autorChave: 'ana@lid', autorNome: 'Ana', papel: 'brogueira', tipo: 'conta', montante: 0, contas: 1, pedido: '1 conta', noPeriodo: true, ordem: 1 },
          { pedidoId: 'p5', ts: '2026-08-02T10:00:00Z', autorChave: 'ana@lid', autorNome: 'Ana', papel: 'brogueira', tipo: 'conta', montante: 0, contas: 1, pedido: 'de novo', noPeriodo: true, ordem: 2 },
        ],
      },
    ],
    autores: [{ chave: 'bia@lid', nome: 'Bia', repeticoes: 1, deOutras: 1, links: ['https://okok.com/?id=5'] }],
  };

  window.renderBrogueiras({
    resumo: { pedidos: 5, brogueirasAtivas: 2, montanteTotal: 300, montantePedidos: 1, contasTotal: 10, contasPedidos: 4, links: 5, indefinidos: 0, linksRepetidos: 2, repeticoes: 3, repeticoesDeOutras: 1 },
    brogueiras: [
      {
        id: 'bia@lid', nome: 'Bia', papel: 'brogueira', pedidos: 1, montanteTotal: 300, contasTotal: 0,
        repetidos: 1, repetidosDeOutra: 1, links: ['https://okok.com/?id=5'],
        dias: [{
          day: '2026-08-02',
          pedidos: [{
            id: 'p2', ts: '2026-08-02T14:00:00Z', tipo: 'montante', montante: 300, contas: null,
            links: ['https://okok.com/?id=5'], pedido: '300',
            repeticao: { vezes: 3, ordem: 2, deOutra: true, link: 'https://okok.com/?id=5', primeiroEm: '2026-08-02T12:00:00Z', primeiroPor: 'Ana' },
          }],
        }],
      },
    ],
    plataformas: [],
    repetidos,
  });

  // KPI e alerta visual (só acende com repetição de uma para outra)
  assert.equal(doc.getElementById('bg-kpi-repetidos').textContent, '2');
  assert.match(doc.getElementById('bg-kpi-repetidos-sub').textContent, /3 reenvios · 1 de outra/);
  assert.ok(doc.getElementById('bg-kpi-card-rep').classList.contains('alerta'));

  // Um bloco por link, o mais repetido primeiro, com quem mandou e quem repetiu
  const itens = doc.querySelectorAll('#bg-repetidos .rep-item');
  assert.equal(itens.length, 2);
  assert.match(itens[0].querySelector('.rep-link').textContent, /okok\.com/);
  assert.match(itens[0].querySelector('.rep-quem').textContent, /Ana.*Bia/);
  assert.ok(itens[0].classList.contains('outra'));
  assert.ok(itens[1].classList.contains('mesma'));
  // O envio de fora do período entra esmaecido, como contexto da repetição
  assert.equal(itens[0].querySelectorAll('tbody tr.fora').length, 1);

  // Filtro "só de outra" esconde o reenvio do próprio link
  doc.querySelector('#bg-rep-filtro button[data-filtro="outras"]').click();
  assert.equal(doc.querySelectorAll('#bg-repetidos .rep-item').length, 1);
  doc.querySelector('#bg-rep-filtro button[data-filtro="todos"]').click();
  assert.equal(doc.querySelectorAll('#bg-repetidos .rep-item').length, 2);

  // Selo na linha do pedido, dentro do detalhe da Brogueira
  doc.querySelector('#tbl-bg tbody tr').click();
  const selo = doc.querySelector('#bg-detalhe-corpo .tag-rep');
  assert.match(selo.textContent, /2ª vez · de outra/);
  assert.match(selo.getAttribute('title'), /1ª vez foi de Ana/);
});

test('aviso ao vivo de link repetido aparece e leva para a aba', async () => {
  const { window, doc } = await montarPainel();
  window.avisarRepetido({
    id: 'p9', ts: '2026-08-02T14:00:00Z', autorNome: 'Bia', papel: 'brogueira',
    repeticoes: [{
      link: 'https://okok.com/?id=5', chave: 'okok.com/?id=5', vezes: 2, deOutra: true,
      primeiroEm: '2026-08-02T12:00:00Z', primeiroPor: 'Ana',
    }],
  });

  const toast = doc.querySelector('#avisos .aviso-toast');
  assert.ok(toast, 'o aviso aparece em qualquer aba');
  assert.match(toast.textContent, /Bia/);
  assert.match(toast.textContent, /okok\.com/);
  assert.match(toast.textContent, /1ª vez foi de Ana/);
  assert.ok(toast.classList.contains('outra'));

  // Clicar leva para a aba Brogueiras e tira o aviso da tela
  toast.click();
  assert.ok(!doc.getElementById('tab-brogueiras').classList.contains('hidden'));
  assert.equal(doc.querySelectorAll('#avisos .aviso-toast').length, 0);
});

test('lerCron é o caminho de volta do montarAgenda', async () => {
  const { window } = await montarPainel();
  // o JSON traz o objeto para este realm (o jsdom tem outros prototypes)
  const ler = (expr) => JSON.parse(JSON.stringify(window.lerCron(expr) ?? null));
  assert.deepEqual(ler('30 7 * * *'), { freq: 'dia', h: 7, m: 30 });
  assert.deepEqual(ler('0 8 * * 1,3'), { freq: 'semana', h: 8, m: 0, dias: [1, 3] });
  assert.deepEqual(ler('*/15 * * * *'), { freq: 'intervalo', unidade: 'min', cada: 15, h: 0, m: 0 });
  assert.deepEqual(ler('30 */2 * * *'), { freq: 'intervalo', unidade: 'hora', cada: 2, h: 0, m: 30 });
  // o que não cabe no relógio cai no campo de cron manual
  assert.equal(ler('0 9 1 * *'), null); // dia do mês
  assert.equal(ler('0 9 * 3 *'), null); // mês específico
  assert.equal(ler('99 99 * * *'), null); // fora da faixa
  assert.equal(ler('nada'), null);
});

test('editar carrega o agendamento no formulário e volta ao normal ao cancelar', async () => {
  const { window, doc } = await montarPainel();
  window.definirNomesGrupos([{ id: 'g1@g.us', nome: 'Grupo Um' }]);
  window.renderSchedules([
    { id: 'sch_1', name: 'Promo', cron: '0 8 * * 1,5', to: 'g1@g.us', message: 'bom dia', enabled: true, mentionAll: true },
  ]);

  doc.querySelector('.sch-edit').click();

  assert.match(doc.getElementById('sch-titulo').textContent, /Editando: Promo/);
  assert.equal(doc.getElementById('sch-add').textContent, 'Salvar alterações');
  assert.ok(!doc.getElementById('sch-cancel').classList.contains('hidden'));
  assert.equal(doc.getElementById('sch-name').value, 'Promo');
  assert.equal(doc.getElementById('sch-msg').value, 'bom dia');
  assert.equal(doc.getElementById('sch-mention').checked, true);
  // destino fora da lista de monitorados é preservado, não trocado em silêncio
  assert.equal(doc.getElementById('sch-to').value, 'g1@g.us');
  assert.match(doc.querySelector('#sch-to option').textContent, /fora do monitoramento/);
  // o relógio e a frequência assumem o cron do agendamento
  assert.equal(doc.getElementById('clk-h').textContent, '08');
  assert.equal(doc.getElementById('clk-m').textContent, '00');
  assert.ok(doc.querySelector('#sch-freq button[data-freq="semana"]').classList.contains('active'));
  assert.equal(doc.querySelectorAll('#sch-dias button.active').length, 2);
  assert.match(doc.getElementById('sch-resumo').textContent, /Seg, Sex às 08:00/);

  doc.getElementById('sch-cancel').click();
  assert.equal(doc.getElementById('sch-titulo').textContent, 'Novo agendamento');
  assert.equal(doc.getElementById('sch-add').textContent, 'Agendar');
  assert.ok(doc.getElementById('sch-cancel').classList.contains('hidden'));
  assert.equal(doc.getElementById('sch-name').value, '');
  assert.equal(doc.getElementById('sch-mention').checked, false);
});

test('cron que não cabe no relógio vai para o campo manual', async () => {
  const { window, doc } = await montarPainel();
  window.renderSchedules([{ id: 'sch_2', name: 'Mensal', cron: '0 9 1 * *', to: 'g1@g.us', message: 'oi', enabled: true }]);
  doc.querySelector('.sch-edit').click();
  assert.equal(doc.getElementById('sch-cron').value, '0 9 1 * *');
  assert.ok(doc.querySelector('.avancado').open, 'a seção avançada abre sozinha');
  assert.match(doc.getElementById('sch-resumo').textContent, /Cron manual/);
});

test('a tabela marca quem notifica todo o grupo', async () => {
  const { window, doc } = await montarPainel();
  window.renderSchedules([
    { id: 'a', name: 'Com todos', cron: '0 9 * * *', to: 'g@g.us', enabled: true, mentionAll: true },
    { id: 'b', name: 'Sem todos', cron: '0 9 * * *', to: 'g@g.us', enabled: true },
  ]);
  const linhas = [...doc.querySelectorAll('#tbl-sch tbody tr')];
  assert.equal(linhas[0].querySelectorAll('.tag-todos').length, 1);
  assert.equal(linhas[1].querySelectorAll('.tag-todos').length, 0);
  assert.equal(doc.querySelectorAll('#tbl-sch .sch-edit').length, 2);
});

test('a tabela traduz o cron de volta para linguagem humana', async () => {
  const { window, doc } = await montarPainel();
  window.renderSchedules([
    { id: 'a', name: 'Diário', cron: '30 9 * * *', to: '551199', enabled: true },
    { id: 'b', name: 'Semanal', cron: '0 8 * * 1,3', to: '551199', enabled: false },
    { id: 'c', name: 'Intervalo', cron: '*/15 * * * *', to: '551199', enabled: true },
    { id: 'd', name: 'Com foto', cron: '0 7 * * *', to: '551199', enabled: true, media: { file: 'x', mime: 'image/png', nome: 'f.png' } },
    { id: 'e', name: 'Falhou', cron: '0 7 * * *', to: '551199', enabled: true, lastError: { erro: 'sem conexão' } },
  ]);
  const linhas = [...doc.querySelectorAll('#tbl-sch tbody tr')].map((tr) => tr.textContent);
  assert.match(linhas[0], /Todo dia às 09:30/);
  assert.match(linhas[1], /Seg, Qua às 08:00/);
  assert.match(linhas[2], /A cada 15 min/);
  // agendamento com imagem ganha miniatura; o que falhou ganha o aviso
  assert.equal(doc.querySelectorAll('#tbl-sch .sch-thumb').length, 1);
  assert.equal(doc.querySelector('#tbl-sch .sch-erro').getAttribute('title'), 'sem conexão');
});
