import { useState } from "react";
import {
  Check,
  Copy,
  Download,
  Eraser,
  PlugZap,
  ScrollText,
  Wifi,
  X,
} from "lucide-react";
import { toast } from "sonner";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useColetor } from "@/hooks/useColetor";
import { limparLog, type LogEntrada } from "@/lib/coletorStore";
import { testarConexao, type Diagnostico } from "@/lib/coletorDiagnostico";
import {
  diaOperacional,
  RELATORIOS_BASE_URL,
  RELATORIOS_MODO,
  RELATORIOS_PATH,
  type RelatorioTipo,
} from "@/lib/relatoriosExternos";

/** A URL do WhatsApp Server mora só no secret da Edge Function; o front-end
 *  fica sabendo dela pela resposta do diagnóstico. */
function descreverBase(diagnostico: Diagnostico | null): string {
  const base = diagnostico?.base || RELATORIOS_BASE_URL;
  if (base) return `${base}${RELATORIOS_PATH}`;
  return RELATORIOS_MODO === "proxy"
    ? `via Edge Function relatorios-externos · ${RELATORIOS_PATH}`
    : `VITE_RELATORIOS_URL não configurada · ${RELATORIOS_PATH}`;
}

const TIPOS: RelatorioTipo[] = ["montante", "contas", "operadores"];

const corPorNivel: Record<LogEntrada["nivel"], string> = {
  ok: "text-success",
  erro: "text-destructive",
  info: "text-muted-foreground",
};

function hora(ts: string): string {
  const d = new Date(ts);
  return Number.isNaN(d.getTime()) ? "--:--:--" : d.toLocaleTimeString("pt-BR");
}

function tamanho(bytes?: number): string {
  if (bytes === undefined) return "—";
  return bytes < 1024 ? `${bytes} B` : `${(bytes / 1024).toFixed(1)} kB`;
}

/** Painel de conexão com o coletor externo: testa as três rotas, mostra o log
 *  de tudo que o Dash já pediu nesta sessão e guarda o JSON cru recebido, para
 *  que outras telas possam reaproveitar sem refazer a requisição. */
export function ConexaoColetor() {
  const [data, setData] = useState<string>(() => diaOperacional());
  const [testando, setTestando] = useState(false);
  const [diagnostico, setDiagnostico] = useState<Diagnostico | null>(null);
  const [aba, setAba] = useState<"log" | "dados">("log");
  const [rotaVisivel, setRotaVisivel] = useState<RelatorioTipo>("montante");
  const { log, respostas } = useColetor();

  const resposta = respostas[rotaVisivel];
  const json = resposta ? JSON.stringify(resposta.bruto, null, 2) : "";

  async function executarTeste() {
    setTestando(true);
    try {
      const d = await testarConexao(data);
      setDiagnostico(d);
      const oks = d.rotas.filter((r) => r.ok).length;
      if (oks === d.rotas.length) toast.success(`Coletor respondeu as ${oks} rotas em ${d.ms_total} ms`);
      else if (oks === 0) toast.error("Coletor não respondeu nenhuma rota");
      else toast.warning(`Apenas ${oks} de ${d.rotas.length} rotas responderam`);
    } finally {
      setTestando(false);
    }
  }

  async function copiar() {
    try {
      await navigator.clipboard.writeText(json);
      toast.success(`JSON de ${rotaVisivel} copiado`);
    } catch {
      toast.error("O navegador bloqueou a cópia");
    }
  }

  function baixar() {
    const blob = new Blob([json], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `coletor-${rotaVisivel}-${data}.json`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <section className="glass-strong space-y-4 rounded-2xl p-5">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="flex items-center gap-2">
          <PlugZap className="h-4 w-4 text-primary" />
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider">Conexão com o coletor</h2>
            <p className="text-[11px] text-muted-foreground">
              {descreverBase(diagnostico)} · modo {RELATORIOS_MODO}
            </p>
          </div>
        </div>
        <div className="flex items-end gap-2">
          <div className="flex flex-col">
            <Label htmlFor="conexao-data" className="text-xs">Dia</Label>
            <Input
              id="conexao-data"
              type="date"
              value={data}
              onChange={(e) => setData(e.target.value)}
              className="h-9 w-40"
            />
          </div>
          <Button size="sm" onClick={executarTeste} disabled={testando}>
            <Wifi className={`mr-2 h-4 w-4 ${testando ? "animate-pulse" : ""}`} />
            {testando ? "Testando…" : "Testar conexão"}
          </Button>
        </div>
      </div>

      {/* Resultado do último teste */}
      {diagnostico && (
        <div className="space-y-2">
          <div className="grid gap-2 sm:grid-cols-3">
            {diagnostico.rotas.map((r) => (
              <div
                key={r.tipo}
                className={`rounded-xl border p-3 ${r.ok ? "border-success/40 bg-success/5" : "border-destructive/40 bg-destructive/5"}`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="text-xs font-semibold uppercase tracking-wide">{r.tipo}</span>
                  {r.ok ? (
                    <Check className="h-4 w-4 text-success" />
                  ) : (
                    <X className="h-4 w-4 text-destructive" />
                  )}
                </div>
                <div className="mt-1 number-tabular text-[11px] text-muted-foreground">
                  HTTP {r.status ?? "—"} · {r.ms} ms · {tamanho(r.bytes)}
                </div>
                {r.erro && <p className="mt-1 text-[11px] text-destructive">{r.erro}</p>}
                {r.amostra && (
                  <p className="mt-1 truncate font-mono text-[10px] text-muted-foreground" title={r.amostra}>
                    {r.amostra}
                  </p>
                )}
              </div>
            ))}
          </div>
          <div className="flex flex-wrap gap-2 text-[10px] uppercase tracking-wide text-muted-foreground">
            <span className="rounded-full bg-muted/50 px-2 py-0.5">total {diagnostico.ms_total} ms</span>
            {diagnostico.token_configurado !== undefined && (
              <span className="rounded-full bg-muted/50 px-2 py-0.5">
                token {diagnostico.token_configurado ? "configurado" : "ausente"}
              </span>
            )}
            {diagnostico.timeout_ms !== undefined && (
              <span className="rounded-full bg-muted/50 px-2 py-0.5">
                timeout {Math.round(diagnostico.timeout_ms / 1000)}s · {diagnostico.tentativas ?? 1} tentativa{(diagnostico.tentativas ?? 1) > 1 ? "s" : ""}
              </span>
            )}
          </div>
        </div>
      )}

      {/* Abas */}
      <div className="flex items-center gap-1 border-b border-border/60">
        <button
          type="button"
          onClick={() => setAba("log")}
          className={`flex items-center gap-1.5 px-3 py-2 text-xs font-semibold transition ${aba === "log" ? "border-b-2 border-primary text-foreground" : "text-muted-foreground hover:text-foreground"}`}
        >
          <ScrollText className="h-3.5 w-3.5" />
          Log
          <span className="text-[10px] text-muted-foreground">({log.length})</span>
        </button>
        <button
          type="button"
          onClick={() => setAba("dados")}
          className={`px-3 py-2 text-xs font-semibold transition ${aba === "dados" ? "border-b-2 border-primary text-foreground" : "text-muted-foreground hover:text-foreground"}`}
        >
          Dados recebidos
        </button>
        {aba === "log" && log.length > 0 && (
          <Button variant="ghost" size="sm" className="ml-auto h-7 text-xs" onClick={limparLog}>
            <Eraser className="mr-1 h-3.5 w-3.5" />
            Limpar
          </Button>
        )}
      </div>

      {aba === "log" ? (
        <div className="max-h-64 overflow-y-auto rounded-xl bg-background/40 p-2 font-mono text-[11px]">
          {log.length === 0 ? (
            <p className="py-6 text-center font-sans text-xs text-muted-foreground">
              Nada registrado ainda. Toda chamada ao coletor — desta área ou da página de
              Relatórios — aparece aqui.
            </p>
          ) : (
            <ul className="space-y-0.5">
              {log.map((e) => (
                <li key={e.id} className="flex flex-wrap items-baseline gap-x-2 border-b border-border/20 py-1">
                  <span className="text-muted-foreground">{hora(e.ts)}</span>
                  <span className={`font-semibold ${corPorNivel[e.nivel]}`}>
                    {e.nivel === "ok" ? "OK " : e.nivel === "erro" ? "ERR" : "···"}
                  </span>
                  <span className="text-primary">{e.rota}</span>
                  <span className="text-muted-foreground">
                    {e.status ? `${e.status} · ` : ""}{e.ms} ms{e.bytes !== undefined ? ` · ${tamanho(e.bytes)}` : ""}
                  </span>
                  <span className="text-foreground/80">{e.mensagem}</span>
                  {e.codigo && <span className="text-warning">[{e.codigo}]</span>}
                  <span className="ml-auto text-[10px] text-muted-foreground">{e.origem}</span>
                </li>
              ))}
            </ul>
          )}
        </div>
      ) : (
        <div className="space-y-2">
          <div className="flex flex-wrap items-center gap-2">
            {TIPOS.map((t) => (
              <button
                key={t}
                type="button"
                onClick={() => setRotaVisivel(t)}
                className={`rounded-lg px-3 py-1.5 text-xs font-semibold transition ${rotaVisivel === t ? "bg-primary text-primary-foreground" : "bg-background/50 text-muted-foreground hover:text-foreground"}`}
              >
                {t}
                {respostas[t] && <span className="ml-1.5 text-[10px] opacity-70">{tamanho(respostas[t]!.bytes)}</span>}
              </button>
            ))}
            {resposta && (
              <div className="ml-auto flex gap-2">
                <Button variant="outline" size="sm" className="h-7 text-xs" onClick={copiar}>
                  <Copy className="mr-1 h-3.5 w-3.5" />
                  Copiar
                </Button>
                <Button variant="outline" size="sm" className="h-7 text-xs" onClick={baixar}>
                  <Download className="mr-1 h-3.5 w-3.5" />
                  Baixar
                </Button>
              </div>
            )}
          </div>

          {resposta ? (
            <>
              <p className="text-[11px] text-muted-foreground">
                Recebido às {hora(resposta.ts)} · {resposta.ms} ms · {tamanho(resposta.bytes)} — JSON cru,
                do jeito que o coletor mandou. Outras telas leem o mesmo dado com{" "}
                <code className="rounded bg-muted/50 px-1">ultimaResposta("{rotaVisivel}")</code>.
              </p>
              <pre className="max-h-80 overflow-auto rounded-xl bg-background/40 p-3 font-mono text-[11px] leading-relaxed">
                {json}
              </pre>
            </>
          ) : (
            <p className="py-6 text-center text-xs text-muted-foreground">
              Nenhuma resposta de <span className="font-semibold">{rotaVisivel}</span> nesta sessão.
              Rode o teste de conexão ou abra a página de Relatórios.
            </p>
          )}
        </div>
      )}
    </section>
  );
}
