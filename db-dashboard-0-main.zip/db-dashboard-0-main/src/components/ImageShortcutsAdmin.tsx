import { useState, type ChangeEvent } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Images, Trash2, Upload, Pencil, Check, X } from "lucide-react";
import { toast } from "sonner";

type Shortcut = {
  id: string;
  titulo: string;
  image_url: string;
  ordem: number;
};

export function ImageShortcutsAdmin() {
  const { user } = useAuth();
  const qc = useQueryClient();
  const [titulo, setTitulo] = useState("");
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [editingName, setEditingName] = useState("");

  const { data: shortcuts = [] } = useQuery({
    queryKey: ["image-shortcuts-admin"],
    queryFn: async () => {
      const { data } = await supabase
        .from("image_shortcuts")
        .select("id, titulo, image_url, ordem")
        .order("ordem", { ascending: true })
        .order("created_at", { ascending: true });
      return (data ?? []) as Shortcut[];
    },
  });

  const refresh = () => {
    qc.invalidateQueries({ queryKey: ["image-shortcuts-admin"] });
    qc.invalidateQueries({ queryKey: ["image-shortcuts"] });
  };

  const onFile = (e: ChangeEvent<HTMLInputElement>) => {
    setFile(e.target.files?.[0] ?? null);
  };

  const upload = async () => {
    if (!file || !titulo.trim() || !user) {
      toast.error("Informe título e selecione uma imagem");
      return;
    }
    setUploading(true);
    try {
      const ext = file.name.split(".").pop() ?? "jpg";
      const path = `${user.id}/${Date.now()}.${ext}`;
      const { error: upErr } = await supabase.storage
        .from("shortcut-images")
        .upload(path, file, { upsert: false, contentType: file.type });
      if (upErr) throw upErr;
      const { data: urlData } = supabase.storage.from("shortcut-images").getPublicUrl(path);
      const nextOrdem = (shortcuts[shortcuts.length - 1]?.ordem ?? 0) + 1;
      const { error: insErr } = await supabase.from("image_shortcuts").insert({
        titulo: titulo.trim(),
        image_url: urlData.publicUrl,
        ordem: nextOrdem,
        created_by: user.id,
      });
      if (insErr) throw insErr;
      toast.success("Atalho criado");
      setTitulo("");
      setFile(null);
      refresh();
    } catch (e: any) {
      toast.error("Erro ao enviar", { description: e.message });
    } finally {
      setUploading(false);
    }
  };

  const rename = async (id: string) => {
    if (!editingName.trim()) return;
    const { error } = await supabase
      .from("image_shortcuts")
      .update({ titulo: editingName.trim() })
      .eq("id", id);
    if (error) return toast.error("Erro ao renomear");
    toast.success("Atalho atualizado");
    setEditingId(null);
    refresh();
  };

  const remove = async (s: Shortcut) => {
    if (!confirm(`Remover "${s.titulo}"?`)) return;
    // try delete storage object (best-effort)
    try {
      const url = new URL(s.image_url);
      const idx = url.pathname.indexOf("/shortcut-images/");
      if (idx >= 0) {
        const path = url.pathname.slice(idx + "/shortcut-images/".length);
        await supabase.storage.from("shortcut-images").remove([decodeURIComponent(path)]);
      }
    } catch {}
    const { error } = await supabase.from("image_shortcuts").delete().eq("id", s.id);
    if (error) return toast.error("Erro ao remover");
    toast.success("Removido");
    refresh();
  };

  const move = async (s: Shortcut, dir: -1 | 1) => {
    const idx = shortcuts.findIndex((x) => x.id === s.id);
    const swap = shortcuts[idx + dir];
    if (!swap) return;
    await supabase.from("image_shortcuts").update({ ordem: swap.ordem }).eq("id", s.id);
    await supabase.from("image_shortcuts").update({ ordem: s.ordem }).eq("id", swap.id);
    refresh();
  };

  return (
    <div className="glass-strong rounded-2xl p-4">
      <div className="mb-3 flex items-center gap-2">
        <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent/15 text-accent ring-1 ring-accent/30">
          <Images className="h-3.5 w-3.5" />
        </div>
        <div>
          <h2 className="text-sm font-bold uppercase tracking-wider">Atalhos de imagens</h2>
          <p className="text-[11px] text-muted-foreground">
            Cadastre fotos e nomes que aparecem como botões na tela inicial.
          </p>
        </div>
      </div>

      <div className="grid gap-3 sm:grid-cols-[1fr_1fr_auto] sm:items-end">
        <div className="space-y-1.5">
          <Label className="text-xs">Título</Label>
          <Input value={titulo} onChange={(e) => setTitulo(e.target.value)} placeholder="ex: Cardápio promo" />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">Imagem</Label>
          <Input type="file" accept="image/*" onChange={onFile} />
        </div>
        <Button onClick={upload} disabled={uploading} className="bg-gradient-primary shadow-glow">
          <Upload className="h-4 w-4" /> {uploading ? "Enviando..." : "Adicionar"}
        </Button>
      </div>

      {shortcuts.length > 0 && (
        <ul className="mt-4 divide-y divide-border/50 rounded-xl border border-border/50">
          {shortcuts.map((s, i) => (
            <li key={s.id} className="flex items-center gap-3 p-2">
              <img src={s.image_url} alt={s.titulo} className="h-10 w-10 rounded-md object-cover" />
              {editingId === s.id ? (
                <Input
                  value={editingName}
                  onChange={(e) => setEditingName(e.target.value)}
                  className="h-8 flex-1"
                  autoFocus
                />
              ) : (
                <span className="flex-1 truncate text-sm font-medium">{s.titulo}</span>
              )}
              <div className="flex items-center gap-1">
                <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === 0} onClick={() => move(s, -1)}>
                  ↑
                </Button>
                <Button size="icon" variant="ghost" className="h-7 w-7" disabled={i === shortcuts.length - 1} onClick={() => move(s, 1)}>
                  ↓
                </Button>
                {editingId === s.id ? (
                  <>
                    <Button size="icon" variant="ghost" className="h-7 w-7 text-success" onClick={() => rename(s.id)}>
                      <Check className="h-4 w-4" />
                    </Button>
                    <Button size="icon" variant="ghost" className="h-7 w-7" onClick={() => setEditingId(null)}>
                      <X className="h-4 w-4" />
                    </Button>
                  </>
                ) : (
                  <Button
                    size="icon"
                    variant="ghost"
                    className="h-7 w-7"
                    onClick={() => {
                      setEditingId(s.id);
                      setEditingName(s.titulo);
                    }}
                  >
                    <Pencil className="h-4 w-4" />
                  </Button>
                )}
                <Button
                  size="icon"
                  variant="ghost"
                  className="h-7 w-7 text-destructive"
                  onClick={() => remove(s)}
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>
            </li>
          ))}
        </ul>
      )}
    </div>
  );
}
