CREATE OR REPLACE FUNCTION public.get_user_ranking()
RETURNS TABLE(user_id uuid, nome text, lucro numeric, deposito numeric, saque numeric, pedidos bigint)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT o.user_id,
         COALESCE(p.nome, '—') AS nome,
         COALESCE(SUM(o.lucro), 0) AS lucro,
         COALESCE(SUM(o.deposito), 0) AS deposito,
         COALESCE(SUM(o.saque), 0) AS saque,
         COUNT(*)::bigint AS pedidos
  FROM public.operations o
  LEFT JOIN public.profiles p ON p.id = o.user_id
  GROUP BY o.user_id, p.nome
  ORDER BY lucro DESC
$$;
GRANT EXECUTE ON FUNCTION public.get_user_ranking() TO authenticated;