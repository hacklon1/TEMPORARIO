// Links repetidos: normalização, detecção no ato e o relatório do painel.
// DATA_DIR aponta para um diretório temporário ANTES de importar db.js.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-rep-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb } = await import('./db.js');
const { registrarPedido, relatorioBrogueiras, relatorioRepetidos } = await import('./store.js');
const { analisarPedido } = await import('./pedidos.js');
const {
  chaveLink, ehLinkIgnorado, detectarRepeticoes, agruparRepetidos,
} = await import('./repetidos.js');

loadDb();

function limpar() {
  getDb().pedidos = [];
  getDb().config.repetidosJanelaHoras = 0;
}

// Registra uma mensagem como se tivesse chegado do grupo.
function receber(autor, texto, { papel = 'brogueira', ts = null } = {}) {
  const pedido = analisarPedido(texto);
  assert.ok(pedido, `texto sem link não vira pedido: ${texto}`);
  return registrarPedido({
    groupId: 'g1@g.us',
    groupName: 'DB Contas e Montantes',
    autorId: `${autor}@lid`,
    autorNome: autor,
    papel,
    pedido,
    text: texto,
    ts,
  });
}

/* ── normalização ── */

test('o mesmo link em grafias diferentes tem a mesma chave', () => {
  const esperada = '670win.me/?id=357497224';
  assert.equal(chaveLink('https://670win.me/?id=357497224'), esperada);
  assert.equal(chaveLink('http://www.670win.me/?id=357497224'), esperada);
  assert.equal(chaveLink('670WIN.me/?id=357497224/'), esperada);
  assert.equal(chaveLink('https://670win.me/?id=357497224#topo'), esperada);
  assert.equal(chaveLink('https://670win.me/?id=357497224.'), esperada);
});

test('id diferente é outro link', () => {
  assert.notEqual(chaveLink('https://670win.me/?id=1'), chaveLink('https://670win.me/?id=2'));
});

test('convite de grupo do WhatsApp não conta como link repetido', () => {
  assert.equal(ehLinkIgnorado('https://chat.whatsapp.com/HZ3Q9ECWXUK6VBECPGUCW2'), true);
  assert.equal(ehLinkIgnorado('https://wa.me/5511999999999'), true);
  assert.equal(ehLinkIgnorado('https://670win.me/?id=1'), false);
});

/* ── detecção no ato do registro ── */

test('primeiro envio não é repetição; o segundo é', () => {
  limpar();
  const um = receber('Ana', 'https://670win.me/?id=1\n7 contas');
  assert.equal(um.repetido, false);
  assert.deepEqual(um.repeticoes, []);

  const dois = receber('Ana', 'https://www.670win.me/?id=1/\nmais 3 contas');
  assert.equal(dois.repetido, true);
  assert.equal(dois.repetidoDeOutra, false, 'ela repetiu o próprio link');
  assert.equal(dois.repeticoes[0].vezes, 2);
  assert.equal(dois.repeticoes[0].primeiroPor, 'Ana');
});

test('link de uma Brogueira na mão de outra vem marcado como "de outra"', () => {
  limpar();
  receber('Ana', 'https://boispin.bet/?id=9\n300 2 contas');
  const bia = receber('Bia', 'https://boispin.bet/?id=9\n200');
  assert.equal(bia.repetido, true);
  assert.equal(bia.repetidoDeOutra, true);
  assert.equal(bia.repeticoes[0].primeiroPor, 'Ana');
  assert.equal(bia.repeticoes[0].vezes, 2);
});

test('a janela de horas limita o que conta como já mandado', () => {
  limpar();
  const ontem = Date.now() - 30 * 3600 * 1000;
  receber('Ana', 'https://a.com/?id=1\n7 contas', { ts: ontem });

  getDb().config.repetidosJanelaHoras = 24;
  const dentroDe24h = receber('Ana', 'https://a.com/?id=1\n7 contas');
  assert.equal(dentroDe24h.repetido, false, '30 h atrás está fora da janela de 24 h');

  getDb().config.repetidosJanelaHoras = 0; // 0 = histórico inteiro
  const semJanela = receber('Ana', 'https://a.com/?id=1\n7 contas');
  assert.equal(semJanela.repetido, true);
  assert.equal(semJanela.repeticoes[0].vezes, 3);
});

test('convite de grupo repetido não vira alerta', () => {
  limpar();
  receber('Ana', 'https://chat.whatsapp.com/ABC123\nentra aí');
  const segundo = receber('Bia', 'https://chat.whatsapp.com/ABC123\nentra aí');
  assert.equal(segundo.repetido, false);
});

test('link que veio de Operador não marca a Brogueira como repetidora', () => {
  limpar();
  receber('Chefe', 'https://divulga.com/?id=1\nPAGO 10 NA DE 50', { papel: 'operador' });
  const ana = receber('Ana', 'https://divulga.com/?id=1\n2 contas');
  // O painel das Brogueiras não mostra o envio do Operador; avisar aqui seria
  // apontar uma repetição sem lugar nenhum onde conferi-la.
  assert.equal(ana.repetido, false);
  assert.equal(relatorioRepetidos('all').grupos.length, 0);
});

test('detectarRepeticoes ignora o próprio pedido dentro do histórico', () => {
  const pedido = { id: 'p1', ts: new Date().toISOString(), autorId: 'a@lid', links: ['https://a.com/?id=1'] };
  assert.deepEqual(detectarRepeticoes(pedido, [pedido]), [], 'ele mesmo não é uma repetição anterior');
});

/* ── relatório do painel ── */

test('o relatório agrupa por link, em ordem cronológica', () => {
  limpar();
  receber('Ana', 'https://okok.com/?id=5\n7 contas');
  receber('Bia', 'https://okok.com/?id=5\n300');
  receber('Ana', 'https://okok.com/?id=5\n2 contas');
  receber('Ana', 'https://sozinho.com/?id=7\n1 conta'); // mandado uma vez só

  const r = relatorioRepetidos('all');
  assert.equal(r.grupos.length, 1, 'link sem repetição fica fora');
  const [g] = r.grupos;
  assert.equal(g.vezes, 3);
  assert.equal(g.repeticoes, 2);
  assert.equal(g.autoras, 2);
  assert.equal(g.deOutras, true);
  assert.deepEqual(g.envios.map((e) => e.autorNome), ['Ana', 'Bia', 'Ana']);
  assert.deepEqual(g.envios.map((e) => e.ordem), [1, 2, 3]);

  assert.equal(r.resumo.links, 1);
  assert.equal(r.resumo.repeticoes, 2);
  assert.equal(r.resumo.deOutras, 1);
  // Bia repetiu o link da Ana; a Ana repetiu o próprio.
  const bia = r.autores.find((a) => a.nome === 'Bia');
  assert.equal(bia.repeticoes, 1);
  assert.equal(bia.deOutras, 1);
  const ana = r.autores.find((a) => a.nome === 'Ana');
  assert.equal(ana.repeticoes, 1);
  assert.equal(ana.deOutras, 0, 'repetir o próprio link não conta como "de outra"');
});

test('link mandado ontem e repetido hoje aparece no período de hoje', () => {
  limpar();
  const ontem = Date.now() - 26 * 3600 * 1000;
  receber('Ana', 'https://ontem.com/?id=1\n7 contas', { ts: ontem });
  receber('Bia', 'https://ontem.com/?id=1\n300');

  const hoje = relatorioRepetidos('today');
  assert.equal(hoje.grupos.length, 1, 'a repetição é de hoje, mesmo com o 1º envio de ontem');
  const [g] = hoje.grupos;
  assert.equal(g.envios.length, 2);
  assert.equal(g.envios[0].noPeriodo, false, 'o envio de ontem entra como contexto');
  assert.equal(g.envios[1].noPeriodo, true);
});

test('repetição só de ontem não polui o painel de hoje', () => {
  limpar();
  const ontem = Date.now() - 26 * 3600 * 1000;
  receber('Ana', 'https://so-ontem.com/?id=1\n7 contas', { ts: ontem });
  receber('Ana', 'https://so-ontem.com/?id=1\n8 contas', { ts: ontem + 60000 });

  assert.equal(relatorioRepetidos('today').grupos.length, 0);
  assert.equal(relatorioRepetidos('all').grupos.length, 1);
});

test('operador fica de fora, como no resto do relatório das Brogueiras', () => {
  limpar();
  receber('Chefe', 'https://divulga.com/?id=1\nPAGO 10 NA DE 50', { papel: 'operador' });
  receber('Chefe', 'https://divulga.com/?id=1\nPAGO 10 NA DE 50', { papel: 'operador' });

  assert.equal(relatorioRepetidos('all').grupos.length, 0);
  assert.equal(relatorioRepetidos('all', { incluirOperadores: true }).grupos.length, 1);
});

test('o relatório das Brogueiras leva os repetidos junto', () => {
  limpar();
  receber('Ana', 'https://x.com/?id=1\n7 contas');
  receber('Bia', 'https://x.com/?id=1\n300');

  const r = relatorioBrogueiras('today');
  assert.equal(r.resumo.linksRepetidos, 1);
  assert.equal(r.resumo.repeticoes, 1);
  assert.equal(r.resumo.repeticoesDeOutras, 1);
  assert.equal(r.repetidos.grupos.length, 1);

  const bia = r.brogueiras.find((b) => b.nome === 'Bia');
  assert.equal(bia.repetidos, 1);
  assert.equal(bia.repetidosDeOutra, 1);
  const ana = r.brogueiras.find((b) => b.nome === 'Ana');
  assert.equal(ana.repetidos, 0, 'quem mandou primeiro não repetiu nada');

  // A linha do pedido dela leva o selo pronto para o painel.
  const linha = bia.dias[0].pedidos[0];
  assert.equal(linha.repeticao.ordem, 2);
  assert.equal(linha.repeticao.deOutra, true);
  assert.equal(linha.repeticao.primeiroPor, 'Ana');
  assert.equal(ana.dias[0].pedidos[0].repeticao, null);

  // porPedido é um Map (índice interno) e não pode vazar para o JSON da API.
  assert.equal(JSON.parse(JSON.stringify(r)).repetidos.porPedido, undefined);
});

test('o mesmo link duas vezes na mesma mensagem não vira repetição', () => {
  limpar();
  const grupos = agruparRepetidos([
    { id: 'p1', ts: '2026-08-01T10:00:00.000Z', autorId: 'a@lid', autorNome: 'Ana', links: ['https://a.com/?id=1', 'https://www.a.com/?id=1/'] },
  ]);
  assert.deepEqual(grupos, [], 'um envio só, ainda que o texto traga o link duas vezes');
});
