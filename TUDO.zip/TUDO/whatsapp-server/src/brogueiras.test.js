// Relatório das Brogueiras: da mensagem crua até os totais por pessoa.
// DATA_DIR aponta para um diretório temporário ANTES de importar db.js.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-brog-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb } = await import('./db.js');
const { registrarPedido, relatorioBrogueiras, filtrarPedidos, dayKey } = await import('./store.js');
const { analisarPedido } = await import('./pedidos.js');
const { papelDoRemetente, invalidarGrupo, OPERADOR, BROGUEIRA, DESCONHECIDO } = await import('./membros.js');

loadDb();

const HOJE = dayKey();

function limpar() {
  getDb().pedidos = [];
}

// Registra uma mensagem como se tivesse chegado do grupo.
function receber(autor, texto, { papel = 'brogueira', dia = null } = {}) {
  const pedido = analisarPedido(texto);
  assert.ok(pedido, `texto sem link não vira pedido: ${texto}`);
  const entrada = registrarPedido({
    groupId: 'g1@g.us',
    groupName: 'DB Contas e Montantes',
    autorId: `${autor}@lid`,
    autorNome: autor,
    papel,
    pedido,
    text: texto,
  });
  if (dia) entrada.day = dia; // para testar a separação por dia
  return entrada;
}

test('um dia de pedidos vira o relatório por Brogueira', () => {
  limpar();
  // Ana: contas (7 + 8) e um montante de 520
  receber('Ana', 'https://670win.me/?id=357497224\n7 contas variadas');
  receber('Ana', 'https://boispin.bet/?id=763865456\n8 contas variadas 10 e 11');
  receber('Ana', 'https://www.okokathena.win/?id=393339299\n520 em 4');
  // Bia: dois montantes
  receber('Bia', 'https://www.lasanhapg.co/?id=534739675\n1000 7 contas');
  receber('Bia', 'https://okokathena.com/?id=920808049\nQuero 400');
  // Um Operador (admin) pediu também — não entra no relatório das Brogueiras
  receber('Chefe', 'https://a.com/?id=9\n5 contas', { papel: 'operador' });

  const r = relatorioBrogueiras('today');

  assert.equal(r.resumo.brogueirasAtivas, 2, 'o operador não vira Brogueira');
  assert.equal(r.resumo.pedidos, 5);
  assert.equal(r.resumo.montanteTotal, 1920); // 520 + 1000 + 400
  assert.equal(r.resumo.contasTotal, 15); // 7 + 8 (o "7 contas" do montante não entra)

  const [primeira, segunda] = r.brogueiras; // ordenado por montante
  assert.equal(primeira.nome, 'Bia');
  assert.equal(primeira.montanteTotal, 1400);
  assert.equal(primeira.contasTotal, 0);
  assert.equal(primeira.montantePedidos, 2);

  assert.equal(segunda.nome, 'Ana');
  assert.equal(segunda.montanteTotal, 520);
  assert.equal(segunda.contasTotal, 15);
  assert.equal(segunda.pedidos, 3);
});

test('cada Brogueira leva a lista dos links que mandou', () => {
  limpar();
  receber('Ana', 'https://670win.me/?id=1\n7 contas');
  receber('Ana', 'https://boispin.bet/?id=2\n300 2 contas');
  receber('Ana', 'https://670win.me/?id=1\n5 contas'); // link repetido não duplica

  const [ana] = relatorioBrogueiras('today').brogueiras;
  assert.deepEqual(ana.links, ['https://670win.me/?id=1', 'https://boispin.bet/?id=2']);
  assert.equal(ana.pedidos, 3);
  assert.equal(ana.contasTotal, 12); // 7 + 5
  assert.equal(ana.montanteTotal, 300);
});

test('os links ficam agrupados por dia', () => {
  limpar();
  receber('Ana', 'https://a.com/?id=1\n7 contas', { dia: '2026-08-01' });
  receber('Ana', 'https://b.com/?id=2\n8 contas', { dia: '2026-08-02' });
  receber('Ana', 'https://c.com/?id=3\n9 contas', { dia: '2026-08-02' });

  const [ana] = relatorioBrogueiras('all').brogueiras;
  assert.equal(ana.dias.length, 2);
  assert.equal(ana.dias[0].day, '2026-08-02'); // mais recente primeiro
  assert.equal(ana.dias[0].pedidos.length, 2);
  assert.equal(ana.dias[1].day, '2026-08-01');
  assert.deepEqual(ana.dias[1].pedidos[0].links, ['https://a.com/?id=1']);
});

test('plataformas mais pedidas saem agregadas', () => {
  limpar();
  receber('Ana', 'https://www.lasanhapg.co/?id=1\n300 2 contas');
  receber('Bia', 'https://lasanhapg.co/?id=2\n400 2 contas');
  receber('Ana', 'https://670win.me/?id=3\n7 contas');

  const { plataformas } = relatorioBrogueiras('today');
  assert.equal(plataformas[0].dominio, 'lasanhapg.co');
  assert.equal(plataformas[0].qtd, 2);
});

test('filtro por período separa hoje do histórico', () => {
  limpar();
  receber('Ana', 'https://a.com/?id=1\n7 contas', { dia: '2020-01-01' });
  receber('Bia', 'https://b.com/?id=2\n8 contas');
  assert.equal(filtrarPedidos('today').length, 1);
  assert.equal(filtrarPedidos('all').length, 2);
  assert.equal(filtrarPedidos({ day: '2020-01-01' }).length, 1);
  assert.equal(relatorioBrogueiras('today').brogueiras[0].nome, 'Bia');
});

test('operadores só aparecem quando pedidos explicitamente', () => {
  limpar();
  receber('Chefe', 'https://a.com/?id=1\n5 contas', { papel: 'operador' });
  assert.equal(relatorioBrogueiras('today').brogueiras.length, 0);
  const comOps = relatorioBrogueiras('today', { incluirOperadores: true });
  assert.equal(comOps.brogueiras.length, 1);
  assert.equal(comOps.brogueiras[0].papel, 'operador');
});

test('pedido registrado guarda o dia e o texto original', () => {
  limpar();
  const e = receber('Ana', 'https://670win.me/?id=357497224\n7 contas variadas');
  assert.equal(e.day, HOJE);
  assert.equal(e.tipo, 'conta');
  assert.equal(e.contas, 7);
  assert.match(e.text, /670win/);
  assert.deepEqual(e.dominios, ['670win.me']);
});

/* ── classificação Operador x Brogueira ── */

const MEMBROS = [
  { id: '111@lid', lid: '111@lid', pn: '5511111111111@s.whatsapp.net', admin: 'superadmin' },
  { id: '222@lid', lid: '222@lid', pn: '5522222222222@s.whatsapp.net', admin: 'admin' },
  { id: '333@lid', lid: '333@lid', pn: '5533333333333@s.whatsapp.net', admin: null },
];

test('admin do grupo é Operador; o resto é Brogueira', async () => {
  invalidarGrupo('g@g.us');
  const buscar = async () => MEMBROS;
  const papel = (id, pn) => papelDoRemetente('g@g.us', { id, lid: id, pn, digitos: [] }, buscar);

  assert.equal(await papel('111@lid'), OPERADOR);
  assert.equal(await papel('222@lid'), OPERADOR);
  assert.equal(await papel('333@lid'), BROGUEIRA);
  assert.equal(await papel('999@lid'), BROGUEIRA); // saiu do grupo: segue Brogueira
});

test('casa também pelo telefone quando o LID não bate', async () => {
  invalidarGrupo('g2@g.us');
  const buscar = async () => MEMBROS;
  const remetente = { id: 'outro@lid', lid: 'outro@lid', pn: null, digitos: ['5522222222222'] };
  assert.equal(await papelDoRemetente('g2@g.us', remetente, buscar), OPERADOR);
});

test('a lista é buscada uma vez e reaproveitada até invalidar', async () => {
  invalidarGrupo('g3@g.us');
  let chamadas = 0;
  const buscar = async () => { chamadas++; return MEMBROS; };
  const r = { id: '333@lid', lid: '333@lid', digitos: [] };
  await papelDoRemetente('g3@g.us', r, buscar);
  await papelDoRemetente('g3@g.us', r, buscar);
  await papelDoRemetente('g3@g.us', r, buscar);
  assert.equal(chamadas, 1, 'cache evita uma consulta por mensagem');

  invalidarGrupo('g3@g.us'); // alguém entrou/virou admin
  await papelDoRemetente('g3@g.us', r, buscar);
  assert.equal(chamadas, 2);
});

test('falha ao buscar membros não classifica ninguém errado', async () => {
  invalidarGrupo('g4@g.us');
  const buscar = async () => { throw new Error('sem conexão'); };
  const papel = await papelDoRemetente('g4@g.us', { id: 'x@lid', digitos: [] }, buscar);
  assert.equal(papel, DESCONHECIDO, 'sem a lista, não afirma que é Brogueira');
});
