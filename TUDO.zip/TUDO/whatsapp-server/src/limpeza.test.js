// Limpeza de dados coletados.
//
// DATA_DIR é apontado para um diretório temporário ANTES de importar db.js:
// limparDados() persiste em disco, e o db.json de produção não pode ser tocado
// por um teste. O node:test roda cada arquivo em seu próprio processo, então
// esse override não vaza para as outras suítes.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-limpeza-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb, saveDb, backupDb, listarBackups, getConfigSessao } = await import('./db.js');
const { limparDados } = await import('./store.js');

loadDb(); // cria um db.json vazio no diretório temporário

// Popula o histórico com entradas em dias distintos e totais coerentes.
function semear() {
  const db = getDb();
  db.messages = [
    { id: '1', day: '2026-07-01', ts: '2026-07-01T10:00:00Z', montante: 100, contasTotal: 10, contasQtd: 1, operatorId: 'a' },
    { id: '2', day: '2026-07-15', ts: '2026-07-15T10:00:00Z', montante: 200, contasTotal: 20, contasQtd: 2, operatorId: 'b' },
    { id: '3', day: '2026-08-01', ts: '2026-08-01T10:00:00Z', montante: 300, contasTotal: 30, contasQtd: 3, operatorId: 'c' },
  ];
  Object.assign(db.stats, {
    totalMessages: 999, // maior que o histórico: acumulado de antes da janela de 5000
    totalMontante: 9999,
    totalContasValor: 999,
    totalContasQtd: 99,
  });
  saveDb({ immediate: true });
  return db;
}

test('escopo "tudo" apaga histórico e zera os totais', () => {
  const db = semear();
  const r = limparDados({ escopo: 'tudo' });

  assert.equal(r.removidas, 3);
  assert.equal(r.restantes, 0);
  assert.equal(db.messages.length, 0);
  assert.equal(db.stats.totalMessages, 0);
  assert.equal(db.stats.totalMontante, 0);
  assert.equal(db.stats.totalContasValor, 0);
  assert.equal(db.stats.totalContasQtd, 0);
});

test('escopo "historico" apaga lançamentos e recalcula os totais do que sobrou', () => {
  const db = semear();
  const r = limparDados({ escopo: 'historico', antesDe: '2026-07-15' });

  assert.equal(r.removidas, 1); // só a de 01/07
  assert.deepEqual(db.messages.map((m) => m.id), ['2', '3']);
  // Totais passam a refletir o que restou, não o acumulado antigo.
  assert.equal(db.stats.totalMessages, 2);
  assert.equal(db.stats.totalMontante, 500);
  assert.equal(db.stats.totalContasValor, 50);
  assert.equal(db.stats.totalContasQtd, 5);
});

test('escopo "estatisticas" zera os totais e preserva o histórico', () => {
  const db = semear();
  const r = limparDados({ escopo: 'estatisticas' });

  assert.equal(r.removidas, 0);
  assert.equal(db.messages.length, 3);
  assert.equal(db.stats.totalMessages, 0);
  assert.equal(db.stats.totalMontante, 0);
});

test('antesDe é exclusivo: a entrada exatamente na data de corte é mantida', () => {
  const db = semear();
  limparDados({ escopo: 'historico', antesDe: '2026-07-15' });
  assert.ok(db.messages.some((m) => m.day === '2026-07-15'));
});

test('limpeza preserva config e agendamentos', () => {
  const db = semear();
  getConfigSessao().welcomeMessage = 'não me apague';
  db.schedules = [{ id: 's1', cron: '0 9 * * *' }];

  limparDados({ escopo: 'tudo' });

  assert.equal(getConfigSessao().welcomeMessage, 'não me apague');
  assert.equal(db.schedules.length, 1);
});

test('escopo inválido e antesDe malformado são rejeitados', () => {
  semear();
  assert.throws(() => limparDados({ escopo: 'geral' }), /escopo inválido/);
  assert.throws(() => limparDados({ escopo: 'tudo', antesDe: '01/07/2026' }), /YYYY-MM-DD/);
  // Nada foi apagado pelas chamadas inválidas.
  assert.equal(getDb().messages.length, 3);
});

test('backupDb grava uma cópia restaurável e listarBackups a enxerga', () => {
  const db = semear();
  const caminho = backupDb();

  assert.ok(fs.existsSync(caminho));
  const copia = JSON.parse(fs.readFileSync(caminho, 'utf8'));
  assert.equal(copia.messages.length, 3);

  limparDados({ escopo: 'tudo' });
  assert.equal(db.messages.length, 0);
  // O backup continua com os dados de antes da limpeza.
  assert.equal(JSON.parse(fs.readFileSync(caminho, 'utf8')).messages.length, 3);

  assert.ok(listarBackups().some((b) => b.nome === path.basename(caminho)));
});

test('backups antigos são podados em 10', () => {
  semear();
  for (let i = 0; i < 14; i++) backupDb();
  const nomes = fs.readdirSync(DIR_TEMP).filter((n) => /^backup-.*\.json$/.test(n));
  assert.ok(nomes.length <= 10, `esperava no máximo 10 backups, achei ${nomes.length}`);
});

test.after(() => fs.rmSync(DIR_TEMP, { recursive: true, force: true }));
