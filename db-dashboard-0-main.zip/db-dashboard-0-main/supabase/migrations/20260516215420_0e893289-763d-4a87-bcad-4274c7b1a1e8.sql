ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS commission_contas_percent numeric;

ALTER TABLE public.operations
  ADD COLUMN IF NOT EXISTS deposito_contas numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS saque_contas numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS comissao_contas numeric NOT NULL DEFAULT 0;