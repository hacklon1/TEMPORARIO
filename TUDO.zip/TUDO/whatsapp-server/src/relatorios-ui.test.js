// A aba Relatórios num DOM real (jsdom).
//
// É a tela que mexe com dinheiro: aqui se protege o que o usuário VÊ (os
// totais, o rótulo do lucro, o que cada filtro manda para o servidor) e o que
// ela DISPARA — nenhum "zerar" pode sair sem confirmação e sem o período certo.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const PUBLIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

const USUARIOS = [
  { id: 'u1', nome: 'Ana', email: 'ana@x.com', papel: 'user' },
  { id: 'u2', nome: 'Bia', email: null, papel: 'user' },
  { id: 'u3', nome: 'Chefe', email: null, papel: 'admin' },
];

const RELATORIO = {
  ok: true,
  filtros: { de: null, ate: null, userId: null, modo: 'liquido' },
  usuarios: USUARIOS,
  metas: { metaDiariaBlogueira: 200, metaSemanalBlogueira: 1000 },
  totais: {
    pedidos: 7, lucro: 1500, lucroLiquido: 1500, lucroBruto: 1200,
    deposito: 900, saque: 2400, blogueira: 300,
    blogueiraHoje: 100, blogueiraSemana: 250,
    metaDiaria: 200, metaSemanal: 1000, pctDiaria: 50, pctSemanal: 25,
    dia: '2026-08-29', semanaDe: '2026-08-24',
  },
  porUsuario: [
    { user_id: 'u1', nome: 'Ana', email: 'ana@x.com', papel: 'user', chefia: false, pedidos: 4,
      deposito: 600, saque: 1600, blogueira: 200, comissao: 40, comissao_contas: 10,
      lucro: 1000, lucroLiquido: 1000, lucroBruto: 800, blogueiraHoje: 60, blogueiraSemana: 150,
      total_comissao: 50 },
    { user_id: 'u2', nome: 'Bia', email: null, papel: 'user', chefia: false, pedidos: 2,
      deposito: 300, saque: 800, blogueira: 100, comissao: 20, comissao_contas: 0,
      lucro: 400, lucroLiquido: 400, lucroBruto: 300, blogueiraHoje: 40, blogueiraSemana: 100,
      total_comissao: 20 },
    { user_id: 'u3', nome: 'Chefe', email: null, papel: 'admin', chefia: true, pedidos: 1,
      deposito: 0, saque: 0, blogueira: 0, comissao: 500, comissao_contas: 0,
      lucro: 100, lucroLiquido: 100, lucroBruto: 100, blogueiraHoje: 0, blogueiraSemana: 0,
      total_comissao: 500 },
  ],
  comissoes: {
    usuarios: [
      { user_id: 'u1', nome: 'Ana', email: 'ana@x.com', comissao: 40, comissao_contas: 10, total: 50 },
      { user_id: 'u2', nome: 'Bia', email: null, comissao: 20, comissao_contas: 0, total: 20 },
    ],
    comissao: 60, comissao_contas: 10, total: 70,
  },
  backups: [
    { id: 'r1', user_id: 'u1', usuarioNome: 'Ana', reset_by: 'admin', operacoes: 3,
      total_comissao: 90, total_comissao_contas: 10, total: 100, undone: false,
      created_at: '2026-08-28T12:00:00.000Z', operations: [] },
    { id: 'r2', user_id: 'u2', usuarioNome: 'Bia', reset_by: 'admin', operacoes: 1,
      total_comissao: 15, total_comissao_contas: 0, total: 15, undone: true,
      created_at: '2026-08-27T12:00:00.000Z', undone_at: '2026-08-27T13:00:00.000Z', operations: [] },
  ],
  operadores: {
    periodo: { de: null, ate: null },
    padraoPct: 10,
    operadores: [
      { operadorId: 'op1', operadorPn: '5573900000001@s.whatsapp.net', nome: 'Chefe da noite',
        nomeOriginal: '🥷🏻', apelido: 'Chefe da noite', isento: false,
        servicos: 4, salario: 400, servicoIds: ['s1', 's2', 's3', 's4'], pct: 15, pctPropria: true,
        comissao: 60, servicosCobrados: 1, salarioCobrado: 100, comissaoCobrada: 15,
        porDia: { '2026-08-24': { servicos: 2, salario: 250, comissao: 37.5 }, '2026-08-26': { servicos: 2, salario: 150, comissao: 22.5 } } },
      { operadorId: 'op2', operadorPn: null, nome: 'Murilo', nomeOriginal: 'Murilo', apelido: null, isento: false,
        servicos: 2, salario: 200, servicoIds: ['s5', 's6'], pct: 10, pctPropria: false,
        comissao: 20, servicosCobrados: 0, salarioCobrado: 0, comissaoCobrada: 0,
        porDia: { '2026-08-26': { servicos: 2, salario: 200, comissao: 20 } } },
    ],
    resumo: { operadores: 2, servicos: 6, salario: 600, comissao: 80,
      servicosTotal: 7, salarioTotal: 700, comissaoTotal: 95, comissaoCobrada: 15 },
  },
  validado: {
    hoje: { dia: '2026-08-26', servicos: 4, montante: 3200, meta: 4000, pct: 80 },
    semana: { de: '2026-08-29', ate: '2026-09-04', rotulo: 'sáb 29/08 05h → sáb 05/09 05h',
      servicos: 9, montantes: 9, salario: 640, operadores: 3, montante: 7400, meta: 0, pct: null },
  },
  semana: {
    semana: { de: '2026-08-24', ate: '2026-08-30', rotulo: '24/08 a 30/08' },
    anterior: '2026-08-17', proxima: null, atual: true,
    dias: [
      { day: '2026-08-24', rotulo: 'seg', dataCurta: '24/08', futuro: false, hoje: false, servicos: 2, salario: 250, comissao: 37.5, comissaoAberta: 37.5 },
      { day: '2026-08-25', rotulo: 'ter', dataCurta: '25/08', futuro: false, hoje: false, servicos: 0, salario: 0, comissao: 0 },
      { day: '2026-08-26', rotulo: 'qua', dataCurta: '26/08', futuro: false, hoje: true, servicos: 4, salario: 350, comissao: 42.5, comissaoAberta: 0 },
      { day: '2026-08-27', rotulo: 'qui', dataCurta: '27/08', futuro: true, hoje: false, servicos: 0, salario: 0, comissao: 0 },
      { day: '2026-08-28', rotulo: 'sex', dataCurta: '28/08', futuro: true, hoje: false, servicos: 0, salario: 0, comissao: 0 },
      { day: '2026-08-29', rotulo: 'sáb', dataCurta: '29/08', futuro: true, hoje: false, servicos: 0, salario: 0, comissao: 0 },
      { day: '2026-08-30', rotulo: 'dom', dataCurta: '30/08', futuro: true, hoje: false, servicos: 0, salario: 0, comissao: 0 },
    ],
    resumo: { operadores: 2, servicos: 6, salario: 600, comissao: 80,
      servicosTotal: 7, salarioTotal: 700, comissaoTotal: 95, comissaoCobrada: 15 },
    padraoPct: 10,
  },
  cobrancas: [
    { id: 'cob1', operadorId: 'op1', operadorNome: 'Adrian', periodo: { de: '2026-08-01', ate: '2026-08-28' },
      pct: 15, servicoIds: ['s0'], servicos: 1, salario: 100, valor: 15, por: 'admin',
      criadaEm: '2026-08-28T12:00:00.000Z', desfeita: false, desfeitaEm: null },
    { id: 'cob2', operadorId: 'op2', operadorNome: 'Murilo', periodo: { de: null, ate: null },
      pct: 10, servicoIds: ['sx'], servicos: 1, salario: 50, valor: 5, por: 'admin',
      criadaEm: '2026-08-27T12:00:00.000Z', desfeita: true, desfeitaEm: '2026-08-27T13:00:00.000Z' },
  ],
  auditoria: [
    { id: 'a1', operation_id: 'o1', user_id: 'u1', usuarioNome: 'Ana', acao: 'EDITADA',
      changed_by: 'admin', changed_at: '2026-08-28T10:00:00.000Z',
      snapshot: { lucro: 100, deposito: 50, saque: 150 } },
  ],
};

// O "Ver mais" da comissão: tudo o que o Operador pegou, validado ou não.
const SERVICOS_OP = {
  ok: true, operadorId: 'op1', nome: 'Chefe da noite', periodo: { de: '2026-08-24', ate: '2026-08-30' },
  pct: 15, isento: false,
  resumo: { pegos: 3, validados: 2, taxa: 67, salarioPego: 300, salarioValidado: 250, montanteValidado: 1200, comissao: 37.5 },
  servicos: [
    { id: 's1', day: '2026-08-26', ts: '2026-08-26T18:10:00.000Z', pedidoTs: '2026-08-26T18:00:00.000Z',
      validadoEm: '2026-08-26T18:20:00.000Z', tipo: 'montante', status: 'validado', statusRotulo: 'validado',
      validado: true, brogueira: 'Looh', grupo: 'DB', contasPedidas: 0, montante: 800, salario: 150,
      casamento: 'citacao', comprovante: { tipo: 'pdf', ts: '2026-08-26T18:20:00.000Z' }, cobrado: false, comissao: 22.5 },
    { id: 's2', day: '2026-08-26', ts: '2026-08-26T17:00:00.000Z', pedidoTs: '2026-08-26T16:55:00.000Z',
      validadoEm: '2026-08-26T17:10:00.000Z', tipo: 'conta', status: 'validado', statusRotulo: 'validado',
      validado: true, brogueira: 'Ariane', grupo: 'DB', contasPedidas: 4, montante: 400, salario: 100,
      casamento: 'valor', comprovante: { tipo: 'imagem', ts: '2026-08-26T17:10:00.000Z' }, cobrado: true, comissao: 15 },
    { id: 's3', day: '2026-08-24', ts: '2026-08-24T20:00:00.000Z', pedidoTs: '2026-08-24T19:50:00.000Z',
      validadoEm: null, tipo: 'montante', status: 'expirado_sem_comprovante', statusRotulo: 'sem comprovante',
      validado: false, brogueira: 'Bia', grupo: 'DB', contasPedidas: 0, montante: 300, salario: 50,
      casamento: 'tempo', comprovante: null, cobrado: false, comissao: 0 },
  ],
};

const OPERACOES = {
  ok: true,
  operacoes: [
    { id: 'o1', user_id: 'u1', data_operacao: '2026-08-28', nome_conta: 'Conta A',
      deposito: 100, saque: 400, blogueira: 50, comissao: 20, comissao_contas: 5,
      lucro: 300, deposito_contas: 10, saque_contas: 30, salario_contas: 5 },
  ],
};

async function montar({ papel = 'admin' } = {}) {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;
  // O papel é lido do localStorage no boot do app.js (ROLE é `let`, não vira
  // propriedade de window) — por isso ele é escolhido ANTES de injetar o script.
  window.localStorage.setItem('ws_role', papel);
  window.Element.prototype.getBoundingClientRect = () => ({ left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0 });
  window.Element.prototype.scrollIntoView = () => {};
  window.confirm = () => true;                    // as confirmações são testadas à parte
  const pedidos = [];
  window.fetch = async (url, opts = {}) => {
    const u = String(url);
    pedidos.push({ url: u, method: opts.method || 'GET', body: opts.body ? JSON.parse(opts.body) : null });
    const corpo = () => {
      if (u.includes('/api/relatorios/backups/')) return { ok: true, restauradas: 3, sumiram: 0, total: 100 };
      if (u.includes('/api/relatorios/cobrancas/')) return { ok: true, servicos: 1, valor: 15, operador: 'Adrian' };
      if (u.includes('/api/relatorios/operadores/cobrar')) return { ok: true, servicos: 6, total: 80, cobrancas: [{ id: 'x' }, { id: 'y' }] };
      if (u.includes('/api/relatorios/operadores/pct')) return { ok: true, config: { padraoPct: 12, porOperador: {} } };
      if (u.includes('/api/relatorios/operadores/apelido')) return { ok: true, config: {} };
      if (u.includes('/cobranca')) return { ok: true, operadorId: 'op1', nome: 'Chefe da noite',
        para: '5573900000001@s.whatsapp.net', servicos: 4, salario: 400, pct: 15,
        comissao: 60, comissaoAberta: 60, comissaoApurada: 0,
        periodo: 'sáb 29/08 05h → sáb 05/09 05h',
        mensagem: 'Olá Chefe da noite, comissão de R$ 60,00 (15%).' };
      if (u.includes('/cobrar-whatsapp')) return { ok: true, nome: 'Chefe da noite', nomeSessao: 'Número 1',
        para: '5573900000001@s.whatsapp.net', comissao: 60 };
      if (u.includes('/api/relatorios/operadores/isento')) return { ok: true, config: {} };
      if (u.includes('/servicos')) return SERVICOS_OP;
      if (u.includes('/api/relatorios/operadores')) return { ...RELATORIO.operadores, ok: true, semana: RELATORIO.semana, conhecidos: [
        { operadorId: 'op1', nomeOriginal: '🥷🏻', nome: 'Chefe da noite', apelido: 'Chefe da noite', isento: false, validados: 9, salarioTotal: 900, pct: 15, pctPropria: true },
        { operadorId: 'op3', nomeOriginal: 'Sócio', nome: 'Sócio', apelido: null, isento: true, validados: 4, salarioTotal: 500, pct: 10, pctPropria: false },
      ] };
      if (u.includes('/api/relatorios/comissoes/zerar')) return { ok: true, operacoes: 4, total: 70, backups: [{ id: 'rX' }] };
      if (u.includes('/api/relatorios/metas')) return { ok: true, metas: RELATORIO.metas };
      if (u.includes('/api/relatorios')) return RELATORIO;
      if (u.includes('/api/operations')) return OPERACOES;
      if (u.includes('/api/sessoes')) return { ok: true, recursos: [], sessoes: [], conflitos: [] };
      if (u.includes('/api/dias')) return { ok: true, hoje: '2026-08-29', primeiro: '2026-08-01', dias: [] };
      return { ok: true };
    };
    return { ok: true, status: 200, json: async () => corpo(), headers: { get: () => null }, blob: async () => ({}) };
  };
  for (const arquivo of ['app.js', 'relatorios.js']) {
    const tag = window.document.createElement('script');
    tag.textContent = fs.readFileSync(path.join(PUBLIC, arquivo), 'utf8');
    window.document.body.appendChild(tag);
  }
  const espera = (ms = 25) => new Promise((r) => setTimeout(r, ms));
  return { window, doc: window.document, pedidos, espera, fechar: async () => { await espera(30); dom.window.close(); } };
}

/* ═══════════ Navegação e papel ═══════════ */

test('a aba Relatórios fica logo abaixo do Painel', async () => {
  const { doc, fechar } = await montar();
  try {
    const itens = [...doc.querySelectorAll('.nav-item')].map((b) => b.dataset.tab);
    assert.equal(itens[0], 'painel');
    assert.equal(itens[1], 'relatorios', 'a ordem do menu é o que o usuário pediu');
  } finally { await fechar(); }
});

test('o viewer não enxerga a aba (a tela é financeira e é adminOnly)', async () => {
  const { window, doc, espera, fechar } = await montar({ papel: 'viewer' });
  try {
    window.aplicarRole();
    await espera();
    assert.equal(doc.querySelector('.nav-item[data-tab="relatorios"]').classList.contains('hidden'), true);
    assert.equal(doc.getElementById('tab-relatorios').classList.contains('hidden'), true);
  } finally { await fechar(); }
});

/* ═══════════ Render ═══════════ */

test('a aba desenha totais, comissões, backups, tabela e log', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);

    assert.equal(doc.getElementById('page-title').textContent, 'Relatórios por usuário');
    // Quadro 1: quantidade de montantes validados na semana da casa.
    assert.equal(doc.getElementById('rel-k-pedidos').textContent, '9');
    assert.match(doc.getElementById('rel-k-pedidos-sub').textContent, /sáb 29\/08 05h/);
    // Quadro 2: o salário que as Brogueiras pagaram na mesma semana.
    assert.match(doc.getElementById('rel-k-lucro').textContent, /640,00/);
    assert.match(doc.getElementById('rel-k-lucro-sub').textContent, /3 operador\(es\)/);
    assert.equal(doc.getElementById('rel-k-lucro').className, 'value pos');

    // os dois quadros mostram o montante VALIDADO, não o lançado à mão
    assert.match(doc.getElementById('rel-k-hoje').textContent, /3\.200,00/);
    assert.match(doc.getElementById('rel-k-semana').textContent, /7\.400,00/);
    assert.equal(doc.getElementById('rel-barra-hoje').style.width, '80%');
    assert.match(doc.getElementById('rel-k-hoje-sub').textContent, /4 serviço\(s\) validado\(s\)/);
    assert.match(doc.getElementById('rel-k-hoje-sub').textContent, /80% da meta diária/);
    // sem meta, o rodapé conta os serviços (e diz a janela) em vez de um "0%"
    assert.match(doc.getElementById('rel-k-semana-sub').textContent,
      /^9 serviço\(s\) validado\(s\) · sáb 29\/08 05h/);

    // comissões: só quem não é chefia
    const comissoes = [...doc.querySelectorAll('#rel-tbl-comissao tbody tr')];
    assert.equal(comissoes.length, 2);
    assert.match(doc.getElementById('rel-com-total').textContent, /70,00/);
    assert.ok(!doc.querySelector('#rel-tbl-comissao tbody').textContent.includes('Chefe'),
      'a chefia não pode aparecer na conta de comissão');

    // backups: um ativo (com botão) e um desfeito (sem)
    const backups = [...doc.querySelectorAll('#rel-tbl-backups tbody tr')];
    assert.equal(backups.length, 2);
    assert.equal(backups[0].querySelector('.badge').textContent, 'ATIVO');
    assert.ok(backups[0].querySelector('[data-desfazer]'));
    assert.equal(backups[1].querySelector('.badge').textContent, 'DESFEITO');
    assert.equal(backups[1].querySelector('[data-desfazer]'), null);

    // tabela por usuário (a chefia aparece aqui — o dinheiro passou por ela)
    const linhas = [...doc.querySelectorAll('#rel-tbl-usuarios tbody tr.rel-linha')];
    assert.deepEqual(linhas.map((l) => l.dataset.user), ['u1', 'u2', 'u3']);
    assert.ok(linhas[2].textContent.includes('chefia'));

    // log de alterações
    assert.match(doc.querySelector('#rel-tbl-log tbody').textContent, /EDITADA/);
  } finally { await fechar(); }
});

test('a aba não oferece mais lucro bruto, nova operação nem cadastro de usuários', async () => {
  // Os três foram tirados a pedido do dono: o lucro do relatório é sempre o
  // líquido, e operação/usuário entram pela API, não à mão na tela.
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);

    assert.equal(doc.getElementById('rel-modo'), null, 'o alternador líquido/bruto saiu');
    assert.equal(doc.getElementById('rel-nova-op'), null, '"Nova operação" saiu');
    assert.equal(doc.getElementById('rel-gerir-usuarios'), null, '"Usuários" saiu');
    assert.equal(doc.getElementById('rel-k-lucro-label').textContent, 'Salário pago na semana');
    assert.equal(doc.getElementById('rel-th-lucro').textContent, 'Lucro');

    // E a busca não pede mais um modo — o servidor já responde em líquido.
    assert.ok(pedidos.filter((p) => p.url.includes('/api/relatorios?')).every((p) => !p.url.includes('modo=')),
      pedidos.map((p) => p.url).join(' | '));
    // O quadro passou a mostrar o salário da semana, não o lucro do livro-caixa.
    assert.match(doc.getElementById('rel-k-lucro').textContent, /640,00/);
  } finally { await fechar(); }
});

/* ═══════════ Filtros ═══════════ */

test('os atalhos de período mexem nos filtros de cima', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelector('#rel-atalhos button[data-atalho="hoje"]').onclick();
    await espera(40);

    const ultima = pedidos.filter((p) => p.url.includes('/api/relatorios?')).at(-1).url;
    const hoje = new Date();
    const iso = `${hoje.getFullYear()}-${String(hoje.getMonth() + 1).padStart(2, '0')}-${String(hoje.getDate()).padStart(2, '0')}`;
    assert.ok(ultima.includes('de=' + iso) && ultima.includes('ate=' + iso), ultima);
    assert.equal(doc.getElementById('rel-de').value, iso, 'o filtro de cima tem que refletir o atalho');
    assert.equal(doc.getElementById('rel-limpar').classList.contains('hidden'), false);
  } finally { await fechar(); }
});

test('limpar tira o recorte e volta a buscar tudo', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelector('#rel-atalhos button[data-atalho="mes"]').onclick();
    await espera(40);
    doc.getElementById('rel-limpar').onclick();
    await espera(40);

    const ultima = pedidos.filter((p) => p.url.includes('/api/relatorios?')).at(-1).url;
    assert.ok(!ultima.includes('de=') && !ultima.includes('ate='), ultima);
    assert.equal(doc.getElementById('rel-limpar').classList.contains('hidden'), true);
  } finally { await fechar(); }
});

/* ═══════════ Linha expansível ═══════════ */

test('expandir um usuário busca as operações do período', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelector('#rel-tbl-usuarios tbody tr.rel-linha').onclick();
    await espera(60);

    assert.ok(pedidos.some((p) => p.url.includes('/api/operations?') && p.url.includes('user=u1')),
      pedidos.map((p) => p.url).join(' | '));
    const detalhe = doc.querySelector('#rel-tbl-usuarios .rel-detalhe');
    assert.ok(detalhe, 'a linha deveria abrir');
    assert.match(detalhe.textContent, /Conta A/);
    // depósito na linha = deposito + deposito_contas (100 + 10)
    assert.match(detalhe.textContent, /110,00/);
  } finally { await fechar(); }
});

/* ═══════════ Ações destrutivas ═══════════ */

test('zerar por usuário manda o período e o usuário, e nada sai sem confirmação', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelector('#rel-atalhos button[data-atalho="hoje"]').onclick();
    await espera(40);

    // Recusar a confirmação não pode disparar nada.
    window.confirm = () => false;
    doc.querySelector('#rel-tbl-comissao [data-zerar]').onclick();
    await espera(30);
    assert.equal(pedidos.some((p) => p.url.includes('/comissoes/zerar')), false, 'cancelou = não zera');

    window.confirm = () => true;
    doc.querySelector('#rel-tbl-comissao [data-zerar]').onclick();
    await espera(40);
    const chamada = pedidos.find((p) => p.url.includes('/comissoes/zerar'));
    assert.ok(chamada, 'deveria ter chamado o servidor');
    assert.equal(chamada.method, 'POST');
    assert.equal(chamada.body.user_id, 'u1');
    assert.ok(chamada.body.de && chamada.body.ate, 'o período filtrado tem que ir junto');
  } finally { await fechar(); }
});

test('"Zerar todas" não manda usuário, e fica travado quando não há o que zerar', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.getElementById('rel-zerar-todas').onclick();
    await espera(40);
    const chamada = pedidos.find((p) => p.url.includes('/comissoes/zerar'));
    assert.equal(chamada.body.user_id, undefined);

    // Sem comissão no período, o botão nasce desabilitado.
    window.renderRelatorios({ ...RELATORIO, comissoes: { usuarios: [], comissao: 0, comissao_contas: 0, total: 0 } });
    assert.equal(doc.getElementById('rel-zerar-todas').disabled, true);
    assert.match(doc.querySelector('#rel-tbl-comissao tbody').textContent, /Nenhuma comissão/);
  } finally { await fechar(); }
});

test('desfazer um backup chama a rota do backup escolhido', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelector('#rel-tbl-backups [data-desfazer]').onclick();
    await espera(40);
    assert.ok(pedidos.some((p) => p.url.includes('/api/relatorios/backups/r1/desfazer') && p.method === 'POST'),
      pedidos.map((p) => p.url).join(' | '));
  } finally { await fechar(); }
});

/* ═══════════ Metas e cadastro ═══════════ */

test('salvar metas manda os dois valores', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.getElementById('rel-meta-dia').value = '350';
    doc.getElementById('rel-meta-semana').value = '2100';
    doc.getElementById('rel-meta-salvar').onclick();
    await espera(40);
    const chamada = pedidos.find((p) => p.url.includes('/relatorios/metas'));
    assert.deepEqual(chamada.body, { metaDiariaBlogueira: 350, metaSemanalBlogueira: 2100 });
  } finally { await fechar(); }
});

test('editar uma operação existente continua funcionando (pela linha do histórico)', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelector('#rel-tbl-usuarios tbody tr.rel-linha').onclick();   // abre o histórico
    await espera(60);

    doc.querySelector('#rel-tbl-usuarios [data-editar]').onclick({ stopPropagation() {} });
    await espera(20);
    const modal = doc.querySelector('.rel-modal-fundo');
    assert.ok(modal, 'o modal de edição deveria abrir');
    assert.match(modal.querySelector('h3').textContent, /Editar operação/);
    assert.equal(modal.querySelector('[name=deposito]').value, '100', 'vem preenchido com o valor atual');

    modal.querySelector('[name=lucro]').value = '999';
    modal.querySelector('[data-ok]').onclick();
    await espera(50);

    const chamada = pedidos.find((p) => p.url.includes('/api/operations/o1') && p.method === 'PATCH');
    assert.ok(chamada, 'deveria ter salvo a edição');
    assert.equal(chamada.body.lucro, 999);
    assert.equal(chamada.body.comissao, 20, 'os outros campos vão como estavam');
  } finally { await fechar(); }
});

/* ═══════════ Comissão cobrada dos Operadores ═══════════ */

test('a tabela dos Operadores mostra salário, % e a comissão devida', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);

    assert.match(doc.getElementById('rel-op-salario').textContent, /700,00/, 'o tile mostra tudo o que foi pego');
    assert.match(doc.getElementById('rel-op-comissao').textContent, /80,00/);
    assert.match(doc.getElementById('rel-op-cobrado').textContent, /15,00/);
    assert.equal(doc.getElementById('rel-pct-padrao').value, '10');

    const linhas = [...doc.querySelectorAll('#rel-tbl-operadores tbody tr')];
    assert.equal(linhas.length, 2);
    assert.match(linhas[0].textContent, /Chefe da noite/);
    assert.equal(linhas[0].querySelector('input.rel-pct').value, '15');
    assert.match(linhas[0].textContent, /60,00/, '15% de 400');
    // quem não tem regra própria é marcado como "padrão"
    assert.match(linhas[1].textContent, /padrão/);
  } finally { await fechar(); }
});

test('mudar a % de um Operador salva só a dele', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    const input = doc.querySelector('#rel-tbl-operadores input.rel-pct');
    input.value = '20';
    input.onchange();
    await espera(40);

    const chamada = pedidos.find((p) => p.url.includes('/operadores/pct'));
    assert.deepEqual(chamada.body, { operadorId: 'op1', pct: 20 });
  } finally { await fechar(); }
});

test('a % padrão da casa é salva sem operador', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    const campo = doc.getElementById('rel-pct-padrao');
    campo.value = '12';
    campo.onchange({ target: campo });
    await espera(40);
    const chamada = pedidos.find((p) => p.url.includes('/operadores/pct'));
    assert.equal(chamada.body.operadorId, null);
    assert.equal(chamada.body.pct, 12);
  } finally { await fechar(); }
});

test('"Zerar comissão" na linha dá baixa, e não sai sem confirmação', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);

    window.confirm = () => false;
    doc.querySelector('#rel-tbl-operadores [data-zerar-comissao]').onclick();
    await espera(30);
    assert.equal(pedidos.some((p) => p.url.includes('/operadores/cobrar')), false, 'cancelou = não dá baixa');

    window.confirm = () => true;
    doc.querySelector('#rel-tbl-operadores [data-zerar-comissao]').onclick();
    await espera(40);
    const chamada = pedidos.find((p) => p.url.includes('/operadores/cobrar'));
    assert.equal(chamada.body.operadorId, 'op1');
    // Sem dia aberto, o recorte é a semana em exibição.
    assert.equal(chamada.body.dia, null);
    assert.ok(chamada.body.semana, 'a semana tem que ir junto');
  } finally { await fechar(); }
});

test('"Cobrar" abre a mensagem pronta e manda pelo WhatsApp', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelector('#rel-tbl-operadores [data-cobrar]').onclick();
    await espera(60);

    // Primeiro busca a prévia — quanto é, para quem vai e o texto do modelo.
    assert.ok(pedidos.some((p) => p.url.includes('/relatorios/operadores/op1/cobranca')),
      pedidos.map((p) => p.url).join(' | '));
    const modal = doc.querySelector('.rel-modal-fundo');
    assert.ok(modal, 'o modal da cobrança deveria abrir');
    assert.match(modal.querySelector('h3').textContent, /Cobrar Chefe da noite no WhatsApp/);
    assert.match(modal.querySelector('[name=mensagem]').value, /comissão de R\$ 60,00/);
    assert.match(modal.textContent, /5573900000001/, 'diz para quem vai');

    // O texto pode ser ajustado só para este envio.
    modal.querySelector('[name=mensagem]').value = 'Fala! Passa a comissão hoje?';
    modal.querySelector('[data-ok]').onclick();
    await espera(60);

    const envio = pedidos.find((p) => p.url.includes('/cobrar-whatsapp'));
    assert.ok(envio, 'deveria ter mandado');
    assert.equal(envio.method, 'POST');
    assert.equal(envio.body.mensagem, 'Fala! Passa a comissão hoje?');
    assert.ok(envio.body.semana, 'manda o recorte junto');
    // Mandar mensagem NÃO pode dar baixa na comissão.
    assert.equal(pedidos.some((p) => p.url.endsWith('/operadores/cobrar')), false);
  } finally { await fechar(); }
});

test('sem número do Operador, a cobrança avisa em vez de mandar', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    // O servidor devolve a prévia sem `para` quando só existe o @lid.
    const original = window.fetch;
    window.fetch = async (url, cfg) => (String(url).includes('/cobranca')
      ? { ok: true, status: 200, json: async () => ({ ok: true, operadorId: 'op1', nome: 'Chefe da noite',
          para: null, servicos: 4, salario: 400, pct: 15, comissao: 60, periodo: 'x', mensagem: 'oi' }) }
      : original(url, cfg));

    doc.querySelector('#rel-tbl-operadores [data-cobrar]').onclick();
    await espera(60);
    const modal = doc.querySelector('.rel-modal-fundo');
    assert.match(modal.textContent, /não expôs o telefone/);
    assert.match(modal.querySelector('[data-ok]').textContent, /Fechar/, 'sem número, nem oferece enviar');
  } finally { await fechar(); }
});

test('"Cobrar todas" vai sem operador e trava quando não há nada a cobrar', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.getElementById('rel-cobrar-todas').onclick();
    await espera(40);
    assert.equal(pedidos.find((p) => p.url.includes('/operadores/cobrar')).body.operadorId, undefined);

    window.renderRelatorios({
      ...RELATORIO,
      operadores: { ...RELATORIO.operadores, operadores: [], resumo: { operadores: 0, servicos: 0, salario: 0, comissao: 0, comissaoCobrada: 0 } },
    });
    assert.equal(doc.getElementById('rel-cobrar-todas').disabled, true);
    assert.match(doc.querySelector('#rel-tbl-operadores tbody').textContent, /Nenhum serviço validado/);
  } finally { await fechar(); }
});

test('o histórico de cobranças mostra a % do dia e permite desfazer a ativa', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    const linhas = [...doc.querySelectorAll('#rel-tbl-cobrancas tbody tr')];
    assert.equal(linhas.length, 2);
    assert.match(linhas[0].textContent, /15%/);
    assert.equal(linhas[0].querySelector('.badge').textContent, 'COBRADA');
    assert.equal(linhas[1].querySelector('.badge').textContent, 'DESFEITA');
    assert.equal(linhas[1].querySelector('[data-desfazer-cobranca]'), null, 'desfeita não desfaz de novo');

    linhas[0].querySelector('[data-desfazer-cobranca]').onclick();
    await espera(40);
    assert.ok(pedidos.some((p) => p.url.includes('/api/relatorios/cobrancas/cob1/desfazer')),
      pedidos.map((p) => p.url).join(' | '));
  } finally { await fechar(); }
});

/* ═══════════ Semana, dias, apelido e isentos ═══════════ */

test('a faixa mostra os 7 dias da semana com o que foi pego em cada um', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);

    assert.match(doc.getElementById('rel-semana-rotulo').textContent, /24\/08 a 30\/08/);
    const dias = [...doc.querySelectorAll('#rel-dias .rel-dia')];
    assert.equal(dias.length, 7);
    assert.match(dias[0].textContent, /seg 24\/08/);
    assert.match(dias[0].textContent, /250,00/, 'a segunda soma o que foi pego nela');
    assert.match(dias[0].textContent, /a cobrar/);
    assert.match(dias[2].textContent, /tudo cobrado/, 'dia sem saldo aberto avisa que já foi cobrado');
    assert.match(dias[1].textContent, /sem serviço/);
    assert.equal(dias[3].disabled, true, 'dia futuro não é clicável');
    assert.ok(dias[2].classList.contains('hoje'));
    // o total do card é a SEMANA inteira
    assert.match(doc.getElementById('rel-op-comissao').textContent, /80,00/);
    assert.equal(doc.getElementById('rel-op-periodo').textContent, 'semana inteira');
  } finally { await fechar(); }
});

test('clicar num dia abre só aquele dia — e clicar de novo volta para a semana', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelectorAll('#rel-dias .rel-dia')[0].onclick();
    await espera(50);

    assert.ok(pedidos.some((p) => p.url.includes('/api/relatorios?') && p.url.includes('dia=2026-08-24')),
      pedidos.map((p) => p.url).join(' | '));
    assert.equal(doc.getElementById('rel-op-periodo').textContent, 'dia 24/08/2026');
    assert.equal(doc.querySelectorAll('#rel-dias .rel-dia')[0].getAttribute('aria-pressed'), 'true');

    doc.querySelectorAll('#rel-dias .rel-dia')[0].onclick();
    await espera(50);
    assert.equal(doc.getElementById('rel-op-periodo').textContent, 'semana inteira');
    assert.ok(!pedidos.at(-1).url.includes('dia='), pedidos.at(-1).url);
  } finally { await fechar(); }
});

test('as setas andam de semana em semana e a seguinte trava no presente', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    assert.equal(doc.getElementById('rel-semana-prox').disabled, true, 'não há semana futura');

    doc.getElementById('rel-semana-ant').onclick();
    await espera(50);
    assert.ok(pedidos.some((p) => p.url.includes('semana=2026-08-17')), pedidos.map((p) => p.url).join(' | '));
  } finally { await fechar(); }
});

test('o nome na tabela é o apelido, com o nome do WhatsApp embaixo', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    const linha = doc.querySelector('#rel-tbl-operadores tbody tr');
    assert.match(linha.textContent, /Chefe da noite/);
    assert.match(linha.textContent, /🥷🏻/, 'o original fica visível para conferência');

    linha.querySelector('[data-apelido]').onclick();
    await espera(20);
    const modal = doc.querySelector('.rel-modal-fundo');
    assert.ok(modal, 'o modal de apelido deveria abrir');
    modal.querySelector('[name=apelido]').value = 'Noturno';
    modal.querySelector('[data-ok]').onclick();
    await espera(50);
    const chamada = pedidos.find((p) => p.url.includes('/operadores/apelido'));
    assert.deepEqual(chamada.body, { operadorId: 'op1', apelido: 'Noturno' });
  } finally { await fechar(); }
});

test('isentar sai pela linha, com confirmação', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);

    window.confirm = () => false;
    doc.querySelector('#rel-tbl-operadores [data-isentar]').onclick();
    await espera(30);
    assert.equal(pedidos.some((p) => p.url.includes('/operadores/isento')), false, 'cancelou = não isenta');

    window.confirm = () => true;
    doc.querySelector('#rel-tbl-operadores [data-isentar]').onclick();
    await espera(40);
    assert.deepEqual(pedidos.find((p) => p.url.includes('/operadores/isento')).body,
      { operadorId: 'op1', isento: true });
  } finally { await fechar(); }
});

test('a tela de ajuste lista todos, inclusive o isento que sumiu do quadro', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.getElementById('rel-operadores-ajuste').onclick();
    await espera(60);

    const linhas = [...doc.querySelectorAll('.rel-isento-linha')];
    assert.equal(linhas.length, 2);
    assert.match(linhas[1].textContent, /Sócio/);
    assert.equal(linhas[1].querySelector('.ajuste-isento').checked, true);
    assert.equal(linhas[0].querySelector('.ajuste-apelido').value, 'Chefe da noite');
  } finally { await fechar(); }
});

test('a cobrança usa o recorte da tela (semana, ou o dia aberto)', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelectorAll('#rel-dias .rel-dia')[0].onclick();   // abre a segunda
    await espera(50);
    doc.getElementById('rel-cobrar-todas').onclick();
    await espera(50);

    const chamada = pedidos.find((p) => p.url.includes('/operadores/cobrar'));
    assert.equal(chamada.body.dia, '2026-08-24', 'cobra só o dia que está na tela');
  } finally { await fechar(); }
});

test('o histórico de cobranças fica escondido até alguém pedir', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);

    const card = doc.getElementById('rel-card-cobrancas');
    const botao = doc.getElementById('rel-ver-historico');
    assert.equal(card.classList.contains('hidden'), true, 'nasce fechado');
    assert.equal(botao.getAttribute('aria-expanded'), 'false');
    // O botão já diz quantas cobranças existem, para não abrir à toa.
    assert.match(botao.textContent, /Ver histórico de comissões \(2\)/);

    botao.onclick();
    assert.equal(card.classList.contains('hidden'), false, 'o clique revela');
    assert.equal(botao.getAttribute('aria-expanded'), 'true');
    assert.match(botao.textContent, /Ocultar histórico/);
    // E o conteúdo está lá, montado.
    assert.equal(doc.querySelectorAll('#rel-tbl-cobrancas tbody tr').length, 2);

    doc.getElementById('rel-fechar-historico').onclick();
    assert.equal(card.classList.contains('hidden'), true, 'o "Ocultar" fecha de novo');
    assert.match(botao.textContent, /Ver histórico de comissões/);
  } finally { await fechar(); }
});

test('recarregar os dados não abre o histórico sozinho', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    await window.carregarRelatorios();
    await espera(40);
    assert.equal(doc.getElementById('rel-card-cobrancas').classList.contains('hidden'), true);
  } finally { await fechar(); }
});

test('o botão Cobrar continua ativo com a comissão zerada no painel', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    // Operador sem nada em aberto (tudo já apurado no "Zerar comissão").
    window.renderRelatorios({
      ...RELATORIO,
      operadores: {
        ...RELATORIO.operadores,
        operadores: [{ ...RELATORIO.operadores.operadores[0], comissao: 0, servicos: 0, salario: 0 }],
      },
    });

    const linha = doc.querySelector('#rel-tbl-operadores tbody tr');
    assert.equal(linha.querySelector('[data-cobrar]').disabled, false, 'ainda dá para cobrar');
    assert.equal(linha.querySelector('[data-zerar-comissao]').disabled, true, 'mas não há o que zerar');
  } finally { await fechar(); }
});

test('a prévia explica quando o valor já foi apurado', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    const original = window.fetch;
    window.fetch = async (url, cfg) => (String(url).includes('/cobranca')
      ? { ok: true, status: 200, json: async () => ({ ok: true, operadorId: 'op1', nome: 'Chefe da noite',
          para: '5573900000001@s.whatsapp.net', servicos: 0, salario: 0, pct: 15,
          comissao: 60, comissaoAberta: 0, comissaoApurada: 60, periodo: 'semana', mensagem: 'oi' }) }
      : original(url, cfg));

    doc.querySelector('#rel-tbl-operadores [data-cobrar]').onclick();
    await espera(60);
    const modal = doc.querySelector('.rel-modal-fundo');
    assert.match(modal.textContent, /já foi\s+apurado/);
    assert.match(modal.textContent, /continua valendo até ele pagar/);
    assert.match(modal.querySelector('[data-ok]').textContent, /Enviar cobrança/);
  } finally { await fechar(); }
});

/* ═══════════ "Ver mais": o dia inteiro do Operador ═══════════ */

test('Ver mais abre os serviços pegos e pinta de verde os validados', async () => {
  const { window, doc, pedidos, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    const botao = doc.querySelector('[data-ver="op1"]');
    assert.ok(botao, 'o botão Ver mais existe na linha do Operador');
    // Fica à ESQUERDA do Cobrar.
    const acoes = [...botao.parentElement.querySelectorAll('button')].map((b) => b.textContent.trim());
    assert.deepEqual(acoes.slice(0, 2), ['Ver mais', 'Cobrar']);

    botao.onclick();
    await espera();

    assert.ok(pedidos.some((p) => p.url.includes('/api/relatorios/operadores/op1/servicos')),
      pedidos.map((p) => p.url).join(' | '));
    const linhas = [...doc.querySelectorAll('.rel-servicos tbody tr')];
    assert.equal(linhas.length, 3, 'lista os 3 serviços pegos, não só os validados');
    // Verde só nos validados.
    assert.deepEqual(linhas.map((l) => l.classList.contains('sv-linha-ok')), [true, true, false]);
    const texto = doc.querySelector('.rel-servicos').textContent;
    assert.match(texto, /Looh/);
    assert.match(texto, /sem comprovante/);   // o que não fechou continua visível
    assert.match(texto, /já cobrado/);        // e o que já saiu numa cobrança é dito
  } finally { await fechar(); }
});

test('Ver mais fecha ao clicar de novo e some ao trocar de semana', async () => {
  const { window, doc, espera, fechar } = await montar();
  try {
    window.abrirAba('relatorios');
    await espera(60);
    doc.querySelector('[data-ver="op1"]').onclick();
    await espera();
    assert.ok(doc.querySelector('.rel-servicos'));

    doc.querySelector('[data-ver="op1"]').onclick();   // agora diz "Ocultar"
    await espera();
    assert.equal(doc.querySelector('.rel-servicos'), null);

    // Reabre e troca a semana: a lista era do recorte antigo, não pode ficar.
    doc.querySelector('[data-ver="op1"]').onclick();
    await espera();
    assert.ok(doc.querySelector('.rel-servicos'));
    doc.getElementById('rel-semana-ant').onclick();
    await espera();
    assert.equal(doc.querySelector('.rel-servicos'), null,
      'trocar de semana fecha o detalhe em vez de mostrar a lista velha');
  } finally { await fechar(); }
});
