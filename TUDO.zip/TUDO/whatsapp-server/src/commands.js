// Comandos administrativos recebidos via WhatsApp.
// Autorização por número + senha opcional. Comandos começam com '!'.
import { getDb, getConfig } from './db.js';
import { relatorioGeral, relatorioOperadores, relatorioIndicacoesTexto } from './reports.js';
import { periodoDoTexto, montantesValidados } from './store.js';
import { soDigitos } from './jid.js';

export { soDigitos };

// Normaliza a identidade recebida: aceita string (JID) ou o objeto de jid.js.
function digitosDoRemetente(remetente) {
  if (remetente && Array.isArray(remetente.digitos)) return remetente.digitos;
  const d = soDigitos(remetente);
  return d ? [d] : [];
}

// Compara ignorando o código do país quando um dos lados o omite, e o nono
// dígito dos celulares brasileiros (55 DD 9XXXXXXXX vs 55 DD XXXXXXXX).
function variacoes(num) {
  const set = new Set();
  const add = (v) => { if (v && v.length >= 8) set.add(v); };
  add(num);
  if (num.startsWith('55') && num.length >= 12) {
    const semPais = num.slice(2);
    add(semPais);
    const ddd = semPais.slice(0, 2);
    const resto = semPais.slice(2);
    if (resto.length === 9 && resto.startsWith('9')) add(`55${ddd}${resto.slice(1)}`);
    if (resto.length === 8) add(`55${ddd}9${resto}`);
  }
  return set;
}

function autorizado(remetente, lista) {
  if (!Array.isArray(lista) || lista.length === 0) return false;
  const permitidos = new Set();
  for (const item of lista) {
    for (const v of variacoes(soDigitos(item))) permitidos.add(v);
  }
  for (const d of digitosDoRemetente(remetente)) {
    for (const v of variacoes(d)) {
      if (permitidos.has(v)) return true;
    }
  }
  return false;
}

// Verifica se o texto é um comando. Retorna { cmd, args, senha } ou null.
export function parseComando(text) {
  const t = String(text ?? '').trim();
  if (!t.startsWith('!')) return null;
  const partes = t.slice(1).split(/\s+/);
  const cmd = (partes.shift() ?? '').toUpperCase();
  if (!cmd) return null;
  // senha pode vir como último token no formato senha=XXXX
  let senha = null;
  const rest = [];
  for (const p of partes) {
    const m = /^senha=(.+)$/i.exec(p);
    if (m) senha = m[1];
    else rest.push(p);
  }
  return { cmd, args: rest, senha };
}

// Processa um comando. Retorna { reply } ou null.
// null = não responder (não é comando, ou remetente sem qualquer autorização).
// `remetente` = identidade de jid.js ({ lid, pn, digitos }) ou um JID em string.
// `config` é a do NÚMERO que recebeu o comando: cada um tem sua própria lista de
// autorizados e sua própria senha. Sem ela, cai na do Número 1.
export function executarComando(text, remetente, config = getConfig()) {
  const parsed = parseComando(text);
  if (!parsed) return null;

  const db = getDb();
  const { cmd, senha } = parsed;

  const podeComando = autorizado(remetente, config.commandAuthorizedNumbers);
  const listaRelatorio =
    Array.isArray(config.reportAuthorizedNumbers) && config.reportAuthorizedNumbers.length > 0
      ? config.reportAuthorizedNumbers
      : config.commandAuthorizedNumbers;
  const podeRelatorio = autorizado(remetente, listaRelatorio);

  // Sem NENHUMA autorização o bot fica em silêncio: em grupos movimentados,
  // responder a todo "!algo" transformaria o bot numa fonte de spam.
  if (!podeComando && !podeRelatorio) return null;

  // Senha (se configurada) é exigida para qualquer comando.
  if (config.commandPassword && senha !== config.commandPassword) {
    return { reply: '🔒 Senha incorreta ou ausente. Use: !COMANDO senha=SUA_SENHA' };
  }

  // Todo relatório aceita o período no primeiro argumento: sem nada é hoje,
  // e "ontem", "28/08", "semana", "mes" ou "geral" olham para trás. O rótulo
  // do próprio relatório já diz qual recorte saiu — ninguém lê um número do
  // dia 28 achando que é de hoje.
  const periodo = periodoDoTexto(parsed.args[0]);

  switch (cmd) {
    case 'RELATORIO':
    case 'RELATÓRIO':
      if (!podeRelatorio) return { reply: '⛔ Você não tem permissão para relatórios.' };
      return { reply: relatorioGeral(periodo) };

    case 'OPERADORES':
      if (!podeRelatorio) return { reply: '⛔ Você não tem permissão para relatórios.' };
      return { reply: relatorioOperadores(periodo) };

    case 'INDICACOES':
    case 'INDICAÇÕES':
    case 'INDICACAO':
      if (!podeRelatorio) return { reply: '⛔ Você não tem permissão para relatórios.' };
      return { reply: relatorioIndicacoesTexto(periodo) };

    case 'AJUDA':
    case 'HELP':
      return {
        reply: [
          '*Comandos disponíveis:*',
          '!RELATORIO — resumo de hoje (montante validado)',
          '!OPERADORES — desempenho por operador (montante validado)',
          '!INDICACOES — ranking de quem mais indicou',
          '',
          'Os três aceitam o período no fim:',
          '  ontem · 28/08 · semana · mes · ano · geral',
          '  ex.: !RELATORIO ontem   ·   !OPERADORES 28/08',
          '!STATUS — estado do bot',
          '!AJUDA — esta mensagem',
        ].join('\n'),
      };

    case 'STATUS': {
      if (!podeComando) return { reply: '⛔ Sem permissão.' };
      const fmt = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
      // Acumulado = o validado de todo o histórico. db.stats.totalMontante é a
      // soma dos lançamentos e continua gravada, mas mostrar ela aqui daria um
      // número maior que o do relatório do mesmo período.
      const acumulado = montantesValidados('all');
      return {
        reply: [
          '🤖 *Status*',
          `Mensagens processadas: ${db.stats.totalMessages}`,
          `Montante validado (acumulado): ${fmt(acumulado.total)}`,
          `Serviços validados: ${acumulado.servicos}`,
          `Contas: ${db.stats.totalContasQtd} (${fmt(db.stats.totalContasValor)})`,
        ].join('\n'),
      };
    }

    default:
      return { reply: `Comando desconhecido: !${cmd}. Use !AJUDA.` };
  }
}
