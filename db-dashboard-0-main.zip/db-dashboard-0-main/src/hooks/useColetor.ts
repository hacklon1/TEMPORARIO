import { useSyncExternalStore } from "react";

import { assinarColetor, lerColetor, type EstadoColetor } from "@/lib/coletorStore";

/** Log e últimas respostas do coletor, ao vivo. O store é externo ao React de
 *  propósito: quem escreve nele é a camada de rede, não um componente. */
export function useColetor(): EstadoColetor {
  return useSyncExternalStore(assinarColetor, lerColetor, lerColetor);
}
