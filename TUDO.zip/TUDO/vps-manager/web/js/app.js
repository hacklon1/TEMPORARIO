/* VPS Manager — painel */
'use strict';

const $  = (s, r = document) => r.querySelector(s);
const $$ = (s, r = document) => Array.from(r.querySelectorAll(s));
const icon = (n, cls = 'i') => `<svg class="${cls}" aria-hidden="true"><use href="#i-${n}"></use></svg>`;

/* ---------- formatação ---------- */
function bytes(n) {
  if (n === null || n === undefined) return '—';
  const u = ['B', 'KB', 'MB', 'GB', 'TB'];
  let v = Number(n), i = 0;
  while (v >= 1024 && i < u.length - 1) { v /= 1024; i++; }
  return `${v.toFixed(i === 0 || v >= 100 ? 0 : 1)}<small> ${u[i]}</small>`;
}
function bytesPlain(n) { return String(bytes(n)).replace(/<[^>]+>/g, ''); }
function when(ts) {
  if (!ts) return '—';
  const d = new Date(ts * 1000), now = Date.now() / 1000;
  const opts = now - ts < 86400 * 300
    ? {day: '2-digit', month: 'short', hour: '2-digit', minute: '2-digit'}
    : {day: '2-digit', month: 'short', year: 'numeric'};
  return d.toLocaleString('pt-BR', opts).replace('.', '');
}
function uptime(s) {
  const d = Math.floor(s / 86400), h = Math.floor(s % 86400 / 3600), m = Math.floor(s % 3600 / 60);
  if (d) return `${d} ${d === 1 ? 'dia' : 'dias'} e ${h}h`;
  return h ? `${h}h ${m}min` : `${m} min`;
}
function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
}
function level(p) { return p >= 90 ? 'fail' : p >= 75 ? 'warn' : ''; }

/* ---------- avisos ---------- */
function note(text, kind = '') {
  const el = document.createElement('div');
  el.className = `note ${kind}`;
  el.innerHTML = `${icon(kind === 'fail' ? 'alert' : kind === 'run' ? 'check' : 'info')}<span>${esc(text)}</span>`;
  $('#notes').appendChild(el);
  setTimeout(() => { el.style.opacity = '0'; el.style.transition = 'opacity .3s'; setTimeout(() => el.remove(), 320); }, 4500);
}

/* ---------- rede ---------- */
async function api(path, opts = {}) {
  const r = await fetch(path, {
    headers: opts.body && !(opts.body instanceof FormData) ? {'Content-Type': 'application/json'} : {},
    ...opts
  });
  if (r.status === 401) { location.href = '/login'; throw new Error('sessão encerrada'); }
  const json = (r.headers.get('content-type') || '').includes('json');
  const data = json ? await r.json() : await r.text();
  if (!r.ok) throw new Error((data && data.detail) || `o servidor respondeu ${r.status}`);
  return data;
}

/* ---------- folha sobreposta ---------- */
function sheet(title, html, narrow = false) {
  $('#sheet-title').textContent = title;
  $('#sheet-in').innerHTML = html;
  $('#sheet-box').classList.toggle('narrow', narrow);
  $('#sheet').classList.add('on');
  const first = $('#sheet-in input, #sheet-in button');
  if (first) first.focus();
}
function closeSheet() { $('#sheet').classList.remove('on'); }
$('#sheet-x').onclick = closeSheet;
$('#sheet').onclick = e => { if (e.target.id === 'sheet') closeSheet(); };
document.addEventListener('keydown', e => { if (e.key === 'Escape') closeSheet(); });

/* ---------- navegação ---------- */
const load = {};
function go(view) {
  $$('#nav button').forEach(b => {
    const on = b.dataset.view === view;
    on ? b.setAttribute('aria-current', 'page') : b.removeAttribute('aria-current');
  });
  $$('.view').forEach(s => s.classList.toggle('on', s.id === `v-${view}`));
  history.replaceState(null, '', `#${view}`);
  if (load[view]) load[view]();
}
$$('#nav button').forEach(b => b.onclick = () => go(b.dataset.view));
window.addEventListener('hashchange', () => {
  const v = location.hash.slice(1);
  if (load[v] && !$(`#v-${v}`).classList.contains('on')) go(v);
});

/* ---------- régua de vitais ---------- */
function vitals(s) {
  const cell = (k, v, foot, pct) => `
    <div class="vital">
      <div class="k">${k}</div>
      <div class="v">${v}${foot ? ` <small>${foot}</small>` : ''}</div>
      ${pct === undefined ? '' : `<div class="meter"><i class="${level(pct)}" style="width:${Math.min(pct, 100)}%"></i></div>`}
    </div>`;
  $('#vitals').innerHTML = [
    cell('CPU', `${s.cpu.percent.toFixed(0)}%`, `${s.cpu.cores} núcleos`, s.cpu.percent),
    cell('Memória', `${s.memory.percent.toFixed(0)}%`, `de ${s.memory.total_gb} GB`, s.memory.percent),
    cell('Disco', `${s.disk.percent}%`, `${s.disk.free_gb} GB livres`, s.disk.percent),
    cell('Carga 1/5/15 min', s.cpu.load.map(n => n.toFixed(2)).join(' ')),
    cell('No ar há', uptime(s.uptime_seconds), ''),
    cell('Processos', s.processes, '')
  ].join('');
}

/* ---------- visão geral ---------- */
async function overview() {
  try {
    const [s, procs, ports] = await Promise.all([
      api('/api/system'), api('/api/system/processes?limit=10'), api('/api/system/ports')
    ]);
    $('#machine').textContent = s.hostname;
    vitals(s);
    $('#ov-lede').innerHTML =
      `${esc(s.distro)}, kernel <span class="code">${esc(s.kernel)}</span> em ${esc(s.arch)}. ` +
      `Recebeu ${s.network.recv_gb} GB e enviou ${s.network.sent_gb} GB desde que ligou.`;

    $('#proc-n').textContent = `${procs.length} de ${s.processes}`;
    $('#procs').innerHTML = procs.map(p => `
      <tr${p.cpu >= 60 ? ' data-state="warn"' : ''}>
        <td><span title="${esc(p.cmd)}">${esc(p.name)}</span>
            <span class="code muted"> ${p.pid}</span></td>
        <td class="muted">${esc(p.user || '—')}</td>
        <td class="num">${p.cpu.toFixed(1)}%</td>
        <td class="num">${p.mem.toFixed(1)}%</td>
      </tr>`).join('');

    $('#port-n').textContent = `${ports.length} abertas`;
    $('#ports').innerHTML = ports.map(p => `
      <tr>
        <td class="code" style="font-weight:600">${p.port}</td>
        <td>${esc(p.process || '—')}</td>
        <td class="code muted">${esc(p.addr)}</td>
        <td class="num muted">${p.pid || '—'}</td>
      </tr>`).join('');
  } catch (e) { note(e.message, 'fail'); }
}
load.overview = overview;
$('#ov-again').onclick = overview;

let beat = null;
function heartbeat() {
  clearInterval(beat);
  if ($('#live').checked) {
    beat = setInterval(async () => {
      try { vitals(await api('/api/system')); } catch (e) { clearInterval(beat); }
      if ($('#v-overview').classList.contains('on')) overview();
    }, 5000);
  }
}
$('#live').onchange = heartbeat;

/* ---------- projetos ---------- */
async function projects() {
  const box = $('#projects');
  box.innerHTML = '<div class="blank"><span class="load"></span> Pesando as pastas…</div>';
  try {
    const d = await api('/api/projects');
    $('#skips').textContent = d.excludes.join('  ');
    if (!d.projects.length) {
      box.innerHTML = '<div class="blank"><strong>Nenhum projeto em /opt</strong>Crie uma pasta lá e ela aparece aqui.</div>';
      return;
    }
    const q = p => `root=${encodeURIComponent(p.root)}&fmt=${$('#fmt').value}`;
    box.innerHTML = d.projects.map(p => `
      <article class="proj">
        <div class="proj-top">
          <h4>${icon('box')} ${esc(p.name)}</h4>
          <div class="loc">${esc(p.path)}</div>
        </div>
        <div class="weigh">
          <div>
            <div class="k">Enxuto</div>
            <div class="v">${bytes(p.slim_bytes)}</div>
          </div>
          <div>
            <div class="k">Integral</div>
            <div class="v full">${bytes(p.total_bytes)}</div>
          </div>
          <div style="margin-left:auto;text-align:right">
            <div class="k">Alterado</div>
            <div class="v full" style="font-size:12.5px">${when(p.modified)}</div>
          </div>
        </div>
        <div class="proj-acts">
          <a class="btn btn-sm btn-primary" href="/api/projects/${encodeURIComponent(p.name)}/download?${q(p)}&full=false">
            ${icon('download')} Baixar</a>
          <a class="btn btn-sm" href="/api/projects/${encodeURIComponent(p.name)}/download?${q(p)}&full=true">Cópia integral</a>
          <button class="btn btn-sm btn-quiet" data-open="${esc(p.path)}">${icon('folder')} Abrir</button>
        </div>
      </article>`).join('');
    $$('#projects [data-open]').forEach(b => b.onclick = () => { go('files'); files(b.dataset.open); });
  } catch (e) {
    box.innerHTML = `<div class="blank"><strong>Não deu para listar</strong>${esc(e.message)}</div>`;
  }
}
load.projects = projects;
$('#proj-again').onclick = projects;
$('#fmt').onchange = () => { if ($('#v-projects').classList.contains('on')) projects(); };
$('#dl-all').onclick = () => {
  note('Empacotando todos os projetos. O download começa em instantes.');
  location.href = `/api/projects/download-all?root=/opt&fmt=${$('#fmt').value}&full=false`;
};

/* ---------- arquivos ---------- */
let here = '/opt';
async function files(path = here) {
  try {
    const d = await api(`/api/files/list?path=${encodeURIComponent(path)}&hidden=${$('#hidden').checked}`);
    here = d.path;
    const parts = d.path.split('/').filter(Boolean);
    let acc = '';
    $('#path').innerHTML = `<button data-p="/">/</button>` + parts.map((p, i) => {
      acc += '/' + p;
      return `${i ? '<span class="sep">/</span>' : ''}<button data-p="${esc(acc)}">${esc(p)}</button>`;
    }).join('');
    $$('#path button').forEach(b => b.onclick = () => files(b.dataset.p));

    $('#files').innerHTML = d.entries.map(e => {
      const name = e.is_dir
        ? `<button class="fitem dir" data-dir="${esc(e.path)}">${icon('folder')} ${esc(e.name)}</button>`
        : `<button class="fitem" ${e.viewable ? `data-view="${esc(e.path)}"` : 'disabled'}>${icon(e.is_link ? 'link' : 'file')} ${esc(e.name)}</button>`;
      const link = e.is_link ? `<span class="code muted"> → ${esc(e.link_target)}</span>` : '';
      return `<tr>
        <td>${name}${link}</td>
        <td class="num">${e.is_dir ? '<span class="muted">pasta</span>' : bytes(e.size)}</td>
        <td class="code muted">${esc(e.mode)}</td>
        <td class="muted">${esc(e.owner)}<span class="muted">:${esc(e.group)}</span></td>
        <td class="muted nowrap">${when(e.modified)}</td>
        <td class="right nowrap">
          <a class="btn btn-sm btn-quiet" href="/api/files/download?path=${encodeURIComponent(e.path)}&fmt=tar.gz&full=true"
             aria-label="Baixar ${esc(e.name)}">${icon('download')}</a>
        </td></tr>`;
    }).join('') || '<tr><td colspan="6"><div class="blank"><strong>Pasta vazia</strong>Nada aqui dentro.</div></td></tr>';

    $$('#files [data-dir]').forEach(b => b.onclick = () => files(b.dataset.dir));
    $$('#files [data-view]').forEach(b => b.onclick = async () => {
      try {
        const f = await api(`/api/files/view?path=${encodeURIComponent(b.dataset.view)}`);
        sheet(f.path, `<pre>${esc(f.content)}</pre>`);
      } catch (err) { note(err.message, 'fail'); }
    });
  } catch (e) { note(e.message, 'fail'); }
}
load.files = () => files(here);
$('#hidden').onchange = () => files(here);
$('#dl-here').onclick = () => { location.href = `/api/files/download?path=${encodeURIComponent(here)}&fmt=tar.gz&full=true`; };
$('#act-up').onclick = () => $('#upfile').click();
$('#upfile').onchange = async () => {
  const f = $('#upfile').files[0];
  if (!f) return;
  const body = new FormData();
  body.append('dest', here);
  body.append('file', f);
  note(`Enviando ${f.name}…`);
  try {
    const r = await api('/api/files/upload', {method: 'POST', body});
    note(`${f.name} chegou em ${here} (${bytesPlain(r.size)})`, 'run');
    files(here);
  } catch (e) { note(e.message, 'fail'); }
  $('#upfile').value = '';
};

/* ---------- terminal ---------- */
let term = null, fit = null, ws = null;
const KEYS = ['ls -la /opt', 'df -h', 'free -h', 'systemctl status vps-manager', 'journalctl -n 40 --no-pager', 'top -b -n1 | head -20', 'clear'];

function bootTerm() {
  if (term) return;
  term = new Terminal({
    fontFamily: "'Fira Code', ui-monospace, Menlo, Consolas, monospace",
    fontSize: 13, lineHeight: 1.25, cursorBlink: true, scrollback: 8000,
    theme: {
      background: '#070c15', foreground: '#dce6f4', cursor: '#38bdf8',
      cursorAccent: '#070c15', selectionBackground: 'rgba(56,189,248,.28)',
      black: '#0b111b', red: '#f2555a', green: '#22c55e', yellow: '#f0b429',
      blue: '#38bdf8', magenta: '#a78bfa', cyan: '#4dd6e0', white: '#dce6f4',
      brightBlack: '#5a7796', brightRed: '#ff8b8f', brightGreen: '#5ee08b',
      brightYellow: '#ffd166', brightBlue: '#7dd3fc', brightMagenta: '#c4b5fd',
      brightCyan: '#8ee7ef', brightWhite: '#ffffff'
    }
  });
  fit = new FitAddon.FitAddon();
  term.loadAddon(fit);
  try { term.loadAddon(new WebLinksAddon.WebLinksAddon()); } catch (e) {}
  term.open($('#term'));
  fit.fit();
  term.onData(d => ws && ws.readyState === 1 && ws.send(JSON.stringify({type: 'input', data: d})));
  new ResizeObserver(() => {
    if (!$('#v-terminal').classList.contains('on')) return;
    try { fit.fit(); } catch (e) { return; }
    if (ws && ws.readyState === 1) ws.send(JSON.stringify({type: 'resize', cols: term.cols, rows: term.rows}));
  }).observe($('#term'));

  $('#keys').innerHTML = KEYS.map(c => `<button data-c="${esc(c)}">${esc(c)}</button>`).join('');
  $$('#keys button').forEach(b => b.onclick = () => {
    if (!ws || ws.readyState !== 1) { note('Conecte o terminal antes.', 'fail'); return; }
    ws.send(JSON.stringify({type: 'input', data: b.dataset.c + '\r'}));
    term.focus();
  });
}

function termState(msg, cls) {
  $('#term-state').className = `state ${cls}`;
  $('#term-msg').textContent = msg;
}

function connect() {
  bootTerm();
  if (ws) { try { ws.close(); } catch (e) {} }
  fit.fit();
  const id = $('#term-host').value;
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  termState('conectando', 'warn');
  ws = new WebSocket(`${proto}://${location.host}/ws/terminal?cols=${term.cols}&rows=${term.rows}${id ? `&host_id=${id}` : ''}`);
  ws.onmessage = ev => {
    const m = JSON.parse(ev.data);
    if (m.type === 'data') term.write(m.data);
    else if (m.type === 'ready') {
      termState('conectado', 'run');
      $('#term-who').textContent = m.host;
      term.focus();
    } else if (m.type === 'error') {
      term.write(`\r\n\x1b[31m${m.message}\x1b[0m\r\n`);
      termState('não conectou', 'fail');
    } else if (m.type === 'closed') termState('sessão encerrada', '');
  };
  ws.onclose = () => { termState('desconectado', ''); $('#term-who').textContent = ''; };
  ws.onerror = () => termState('falha de conexão', 'fail');
}
$('#term-go').onclick = connect;
$('#term-end').onclick = () => { if (ws) ws.close(); ws = null; };
load.terminal = () => { bootTerm(); setTimeout(() => { try { fit.fit(); } catch (e) {} }, 60); };

/* ---------- serviços ---------- */
async function services() {
  try {
    const list = await api('/api/system/services');
    $('#services').innerHTML = list.map(s => {
      const st = s.active === 'active' ? 'run' : s.active === 'failed' ? 'fail' : 'warn';
      const word = s.active === 'active' ? 'rodando' : s.active === 'failed' ? 'falhou' : s.active;
      return `<tr data-state="${st}">
        <td><b>${esc(s.name)}</b><div class="muted" style="font-size:12px">${esc(s.description)}</div></td>
        <td><span class="state ${st}"><span class="led"></span>${esc(word)}</span></td>
        <td class="muted">${s.enabled === 'enabled' ? 'inicia sozinho' : esc(s.enabled || '—')}</td>
        <td class="num muted">${s.pid !== '0' ? esc(s.pid) : '—'}</td>
        <td class="right nowrap">
          <button class="btn btn-sm btn-quiet" data-svc="${esc(s.name)}" data-act="restart" title="Reiniciar" aria-label="Reiniciar ${esc(s.name)}">${icon('refresh')}</button>
          <button class="btn btn-sm btn-quiet" data-svc="${esc(s.name)}" data-act="start" title="Iniciar" aria-label="Iniciar ${esc(s.name)}">${icon('play')}</button>
          <button class="btn btn-sm btn-danger" data-svc="${esc(s.name)}" data-act="stop" title="Parar" aria-label="Parar ${esc(s.name)}">${icon('stop')}</button>
          <button class="btn btn-sm btn-quiet" data-log="${esc(s.name)}" title="Ver registro" aria-label="Ver registro de ${esc(s.name)}">${icon('logs')}</button>
        </td></tr>`;
    }).join('');

    $$('#services [data-act]').forEach(b => b.onclick = async () => {
      const {svc, act} = b.dataset;
      const verb = {start: 'Iniciar', stop: 'Parar', restart: 'Reiniciar'}[act];
      if (act === 'stop' && !confirm(`Parar ${svc}? Quem depende dele para de responder até você iniciar de novo.`)) return;
      b.disabled = true;
      try {
        const r = await api(`/api/system/services/${encodeURIComponent(svc)}`, {
          method: 'POST', body: JSON.stringify({action: act})
        });
        note(r.ok ? `${svc}: ${verb.toLowerCase()} deu certo` : `${svc} não respondeu: ${r.stderr || 'código ' + r.rc}`,
             r.ok ? 'run' : 'fail');
      } catch (e) { note(e.message, 'fail'); }
      services();
    });
    $$('#services [data-log]').forEach(b => b.onclick = async () => {
      try {
        const r = await api(`/api/system/services/${encodeURIComponent(b.dataset.log)}/logs?lines=300`);
        sheet(`journalctl -u ${b.dataset.log}`, `<pre>${esc(r.log)}</pre>`);
      } catch (e) { note(e.message, 'fail'); }
    });
  } catch (e) { note(e.message, 'fail'); }
}
load.services = services;
$('#svc-again').onclick = services;

/* ---------- hosts ---------- */
async function hosts() {
  try {
    const d = await api('/api/hosts');
    $('#term-host').innerHTML =
      `<option value="">esta VPS (${esc(d.fallback.username)}@${esc(d.fallback.hostname)})</option>` +
      d.hosts.map(h => `<option value="${h.id}">${esc(h.name)} — ${esc(h.username)}@${esc(h.hostname)}</option>`).join('');

    $('#hosts').innerHTML = `
      <tr data-state="${d.fallback.key_present ? 'run' : 'fail'}">
        <td><b>esta VPS</b><div class="muted" style="font-size:12px">${d.fallback.key_present ? 'chave no lugar' : 'chave ausente'}</div></td>
        <td class="code">${esc(d.fallback.username)}@${esc(d.fallback.hostname)}:${d.fallback.port}</td>
        <td class="code muted">${esc(d.fallback.key_path)}</td>
        <td class="right"><button class="btn btn-sm btn-quiet" id="try-def">Testar</button></td>
      </tr>` + d.hosts.map(h => `
      <tr>
        <td><b>${esc(h.name)}</b>${h.is_default ? '<div class="muted" style="font-size:12px">host padrão</div>' : ''}</td>
        <td class="code">${esc(h.username)}@${esc(h.hostname)}:${h.port}</td>
        <td class="code muted">${esc(h.key_path)}</td>
        <td class="right nowrap">
          <button class="btn btn-sm btn-quiet" data-try="${h.id}">Testar</button>
          <button class="btn btn-sm btn-danger" data-drop="${h.id}" aria-label="Remover ${esc(h.name)}">${icon('trash')}</button>
        </td></tr>`).join('');

    const test = async id => {
      note('Testando a conexão…');
      try {
        const r = id ? await api(`/api/hosts/${id}/check`, {method: 'POST'})
                     : await api('/api/hosts/check', {method: 'POST'});
        note(r.ok ? `Respondeu: ${r.output.replace(/\n/g, ' · ')}` : `Não conectou: ${r.output}`, r.ok ? 'run' : 'fail');
      } catch (e) { note(e.message, 'fail'); }
    };
    const dflt = $('#try-def'); if (dflt) dflt.onclick = () => test(null);
    $$('#hosts [data-try]').forEach(b => b.onclick = () => test(b.dataset.try));
    $$('#hosts [data-drop]').forEach(b => b.onclick = async () => {
      if (!confirm('Remover este host da lista?')) return;
      try { await api(`/api/hosts/${b.dataset.drop}`, {method: 'DELETE'}); note('Host removido', 'run'); hosts(); }
      catch (e) { note(e.message, 'fail'); }
    });
  } catch (e) { note(e.message, 'fail'); }
}
load.hosts = hosts;
$('#host-form').onsubmit = async e => {
  e.preventDefault();
  try {
    await api('/api/hosts', {method: 'POST', body: JSON.stringify({
      name: $('#h-name').value, hostname: $('#h-host').value,
      port: Number($('#h-port').value) || 22, username: $('#h-user').value || 'root',
      key_path: $('#h-key').value, is_default: $('#h-def').checked
    })});
    note('Host adicionado', 'run');
    e.target.reset(); $('#h-port').value = 22; $('#h-user').value = 'root';
    hosts();
  } catch (err) { note(err.message, 'fail'); }
};

/* ---------- auditoria ---------- */
const VERB = {
  'login': 'entrou', 'logout': 'saiu', 'password_change': 'trocou a senha',
  'project.download': 'baixou projeto', 'project.download_all': 'baixou tudo',
  'file.download': 'baixou arquivo', 'file.upload': 'enviou arquivo',
  'ssh.terminal': 'terminal', 'ssh.exec': 'rodou comando',
  'host.create': 'criou host', 'host.delete': 'removeu host'
};
async function audit() {
  try {
    const rows = await api('/api/auth/audit?limit=200');
    $('#audit').innerHTML = rows.map(r => {
      const label = VERB[r.action] || (r.action.startsWith('service.') ? `serviço: ${r.action.slice(8)}` : r.action);
      return `<tr data-state="${r.ok ? 'run' : 'fail'}">
        <td class="code nowrap">${esc(r.ts)}</td>
        <td>${esc(r.username || '—')}</td>
        <td class="code muted">${esc(r.ip || '—')}</td>
        <td>${esc(label)}</td>
        <td class="code muted">${esc(r.target || '—')}</td>
        <td class="muted">${esc(r.detail || '')}</td></tr>`;
    }).join('') || '<tr><td colspan="6"><div class="blank"><strong>Sem registros ainda</strong>Cada ação no painel aparece aqui.</div></td></tr>';
  } catch (e) { note(e.message, 'fail'); }
}
load.audit = audit;
$('#audit-again').onclick = audit;

/* ---------- conta ---------- */
$('#act-out').onclick = async () => {
  try { await api('/api/auth/logout', {method: 'POST'}); } catch (e) {}
  location.href = '/login';
};
$('#act-pw').onclick = () => {
  sheet('Trocar senha', `
    <label for="pw-old">Senha atual</label>
    <input type="password" id="pw-old" autocomplete="current-password">
    <label for="pw-new">Nova senha</label>
    <input type="password" id="pw-new" autocomplete="new-password">
    <p class="lede" style="margin-top:8px;font-size:12.5px">
      No mínimo 10 caracteres. Ela vale como a senha de root desta VPS — escolha uma longa.
    </p>
    <button class="btn btn-primary btn-block" id="pw-go">Salvar nova senha</button>`, true);
  $('#pw-go').onclick = async () => {
    try {
      await api('/api/auth/password', {method: 'POST', body: JSON.stringify({
        current_password: $('#pw-old').value, new_password: $('#pw-new').value
      })});
      note('Senha trocada', 'run');
      closeSheet();
    } catch (e) { note(e.message, 'fail'); }
  };
};

/* ---------- início ---------- */
(async () => {
  try {
    const me = await api('/api/auth/me');
    $('#who').textContent = me.username;
  } catch (e) { return; }
  try {
    const s = await api('/api/system');
    $('#machine').textContent = s.hostname;
    vitals(s);
  } catch (e) {}
  await hosts();
  const view = (location.hash || '#overview').slice(1);
  go(load[view] ? view : 'overview');
  heartbeat();
})();
