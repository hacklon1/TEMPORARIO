// Períodos de calendário (hoje / semana / mês / ano) e o ranking dos Operadores.
//
// O vocabulário de período é o mesmo em TODOS os relatórios; um erro aqui
// vazaria para o Painel, para as Brogueiras e para os comandos do WhatsApp.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-periodos-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb } = await import('./db.js');
const {
  intervaloPeriodo, noIntervalo, rotuloPeriodo, filtrarEntradas, filtrarServicos,
  rankingOperadores, dayKey,
} = await import('./store.js');
const { STATUS } = await import('./servicos.js');

loadDb();

test('intervalo: hoje é um dia só; semana começa na SEGUNDA', () => {
  const hoje = dayKey();
  assert.deepEqual(intervaloPeriodo('today'), { de: hoje, ate: hoje });

  const semana = intervaloPeriodo('week');
  assert.equal(semana.ate, hoje);
  // O primeiro dia da janela tem que ser uma segunda-feira.
  const [a, m, d] = semana.de.split('-').map(Number);
  assert.equal(new Date(Date.UTC(a, m - 1, d)).getUTCDay(), 1, `${semana.de} deveria ser segunda`);
  assert.ok(semana.de <= hoje);
});

test('intervalo: mês e ano começam no dia 1º; geral não recorta nada', () => {
  const hoje = dayKey();
  assert.equal(intervaloPeriodo('month').de, hoje.slice(0, 8) + '01');
  assert.equal(intervaloPeriodo('year').de, hoje.slice(0, 4) + '-01-01');
  assert.equal(intervaloPeriodo('all'), null);
  assert.equal(noIntervalo('1999-01-01', null), true);
});

test('intervalo: dia exato, intervalo aberto e período desconhecido', () => {
  assert.deepEqual(intervaloPeriodo({ day: '2026-03-04' }), { de: '2026-03-04', ate: '2026-03-04' });
  assert.deepEqual(intervaloPeriodo({ de: '2026-01-01' }), { de: '2026-01-01', ate: '9999-12-31' });
  // Um period inventado NÃO pode virar "tudo" — exageraria todo número do painel.
  assert.deepEqual(intervaloPeriodo('decada'), intervaloPeriodo('today'));
});

test('rótulo do período sai em português e com as datas', () => {
  assert.equal(rotuloPeriodo('all'), 'Geral');
  assert.match(rotuloPeriodo('today'), /^Hoje \(\d{4}-\d{2}-\d{2}\)$/);
  assert.match(rotuloPeriodo('month'), /^Este mês \(\d{2}\/\d{2}\/\d{4} a \d{2}\/\d{2}\/\d{4}\)$/);
  assert.equal(rotuloPeriodo({ day: '2026-03-04' }), '04/03/2026');
});

/* ═══════════ Filtro e ranking sobre dados plantados ═══════════ */

const hoje = dayKey();
const ontem = (() => {
  const d = new Date(`${hoje}T12:00:00Z`);
  d.setUTCDate(d.getUTCDate() - 1);
  return d.toISOString().slice(0, 10);
})();
const anoPassado = `${Number(hoje.slice(0, 4)) - 1}-06-15`;

function plantar() {
  const db = getDb();
  db.messages = [
    { id: 'm1', ts: `${hoje}T12:00:00.000Z`, day: hoje, sessaoId: 'n1', groupId: 'G', operatorId: 'OP1', operatorPn: '5573999999999@s.whatsapp.net', operatorName: 'Carlos', montante: 400, contasQtd: 2, contasTotal: 16 },
    { id: 'm2', ts: `${hoje}T13:00:00.000Z`, day: hoje, sessaoId: 'n1', groupId: 'G', operatorId: 'OP2', operatorName: 'Ana', montante: 100, contasQtd: 0, contasTotal: 0 },
    { id: 'm3', ts: `${ontem}T12:00:00.000Z`, day: ontem, sessaoId: 'n1', groupId: 'G', operatorId: 'OP1', operatorName: 'Carlos', montante: 300, contasQtd: 1, contasTotal: 8 },
    { id: 'm4', ts: `${anoPassado}T12:00:00.000Z`, day: anoPassado, sessaoId: 'n1', groupId: 'G', operatorId: 'OP3', operatorName: 'Antigo', montante: 999, contasQtd: 0, contasTotal: 0 },
    // Resposta a um pedido de CONTA: sem montante, só o preço ("Valor: R$ 30").
    { id: 'm5', ts: `${hoje}T14:00:00.000Z`, day: hoje, sessaoId: 'n1', groupId: 'G', operatorId: 'OP1', operatorName: 'Carlos', montante: 0, contasQtd: 1, contasTotal: 30, contasOferecidas: 12 },
  ];
  db.servicos = [
    {
      id: 's1', day: hoje, ts: `${hoje}T11:58:00.000Z`, sessaoId: 'n1', groupId: 'G',
      status: STATUS.VALIDADO, pedidoTs: `${hoje}T11:58:00.000Z`, brogueiraChave: 'B1',
      brogueiraNome: 'Bia', tipo: 'montante', montantePedido: 400, contasPedidas: 2, links: [],
      atendimento: { entradaId: 'm1', msgId: 'x1', ts: `${hoje}T12:00:00.000Z`, operatorId: 'OP1', operatorName: 'Carlos', montante: 400, contasQtd: 2, contasTotal: 16, casamento: 'valor' },
      comprovante: { msgId: 'c1', ts: `${hoje}T12:30:00.000Z`, tipo: 'imagem', casamento: 'tempo' },
    },
    {
      id: 's2', day: hoje, ts: `${hoje}T12:58:00.000Z`, sessaoId: 'n1', groupId: 'G',
      status: STATUS.SEM_COMPROVANTE, pedidoTs: `${hoje}T12:58:00.000Z`, brogueiraChave: 'B2',
      brogueiraNome: 'Duda', tipo: 'montante', montantePedido: 100, contasPedidas: 0, links: [],
      atendimento: { entradaId: 'm2', msgId: 'x2', ts: `${hoje}T13:00:00.000Z`, operatorId: 'OP2', operatorName: 'Ana', montante: 100, contasQtd: 0, contasTotal: 0, casamento: 'tempo' },
      comprovante: null,
    },
    {
      id: 's3', day: ontem, ts: `${ontem}T11:58:00.000Z`, sessaoId: 'n1', groupId: 'G',
      status: STATUS.VALIDADO, pedidoTs: `${ontem}T11:58:00.000Z`, brogueiraChave: 'B1',
      brogueiraNome: 'Bia', tipo: 'montante', montantePedido: 300, contasPedidas: 1, links: [],
      atendimento: { entradaId: 'm3', msgId: 'x3', ts: `${ontem}T12:00:00.000Z`, operatorId: 'OP1', operatorName: 'Carlos', montante: 300, contasQtd: 1, contasTotal: 8, casamento: 'citacao' },
      comprovante: { msgId: 'c3', ts: `${ontem}T12:20:00.000Z`, tipo: 'pdf', casamento: 'citacao' },
    },
    // Serviço de CONTA: as 12 contas do pedido é que são as contas do serviço —
    // o `contasQtd: 1` do atendimento é só o rótulo "Valor:" da resposta.
    {
      id: 's4', day: hoje, ts: `${hoje}T13:58:00.000Z`, sessaoId: 'n1', groupId: 'G',
      status: STATUS.VALIDADO, pedidoTs: `${hoje}T13:58:00.000Z`, brogueiraChave: 'B3',
      brogueiraNome: 'Lia', tipo: 'conta', montantePedido: 0, contasPedidas: 12, links: [],
      atendimento: { entradaId: 'm5', msgId: 'x5', ts: `${hoje}T14:00:00.000Z`, operatorId: 'OP1', operatorName: 'Carlos', montante: 0, contasQtd: 1, contasTotal: 30, casamento: 'valor' },
      comprovante: { msgId: 'c4', ts: `${hoje}T14:20:00.000Z`, tipo: 'imagem', casamento: 'tempo' },
    },
  ];
  return db;
}

test('o filtro corta pelo dia certo em cada período', () => {
  plantar();
  assert.equal(filtrarEntradas('today').length, 3);
  assert.equal(filtrarEntradas('all').length, 5);
  assert.equal(filtrarEntradas('year').length, 4); // o do ano passado fica de fora
  assert.equal(filtrarServicos('today').length, 3);
  assert.equal(filtrarServicos({ day: ontem }).length, 1);
});

test('ranking: soma o que cada Operador pegou e o que lançou', () => {
  plantar();
  const { resumo, operadores } = rankingOperadores('today');

  assert.equal(resumo.operadores, 2);
  assert.equal(resumo.servicos, 3);
  assert.equal(resumo.validados, 2);
  assert.equal(resumo.montanteValidado, 400);
  assert.equal(resumo.montanteLancado, 500);
  assert.equal(resumo.taxa, 2 / 3);

  const carlos = operadores[0];
  assert.equal(carlos.nome, 'Carlos'); // 1º: pegou mais serviço
  assert.equal(carlos.servicos, 2);
  assert.equal(carlos.validados, 2);
  assert.equal(carlos.taxa, 1);
  assert.equal(carlos.montanteValidado, 400);
  assert.equal(carlos.montanteLancado, 400);
  // As contas do serviço saem do PEDIDO: 12 do pedido de conta. O serviço de
  // montante não entra — o "2 contas" dele é em quantas partes o montante foi
  // dividido, não um pedido de 2 contas.
  assert.equal(carlos.contasValidadasQtd, 12);
  // Contas em três recortes: as que ele pegou, as que fecharam e as lançadas.
  assert.equal(carlos.contasPegasQtd, 12);
  assert.equal(carlos.contasPegasValor, 30);
  assert.equal(carlos.contasQtd, 3); // do lançamento (rótulos "Valor:")
  assert.equal(carlos.brogueiras, 2);
  assert.equal(carlos.casamento.valor, 2);
  // O telefone acompanha o operador — é por ele que a busca do painel acha.
  assert.equal(carlos.pn, '5573999999999@s.whatsapp.net');

  const ana = operadores[1];
  assert.equal(ana.validados, 0);
  assert.equal(ana.semComprovante, 1);
  assert.equal(ana.taxa, 0);

  // No resumo, contas pegas contam o serviço que não fechou; validadas, não.
  // (aqui o único serviço de conta fechou, então os dois batem em 12)
  assert.equal(resumo.contasPegasQtd, 12);
  assert.equal(resumo.contasValidadasQtd, 12);
  assert.equal(resumo.contasQtd, 3);
});

test('ranking: no período maior, o mesmo Operador soma os dois dias', () => {
  plantar();
  const { operadores, resumo } = rankingOperadores('year');
  const carlos = operadores.find((o) => o.nome === 'Carlos');
  assert.equal(carlos.servicos, 3);
  assert.equal(carlos.validados, 3);
  assert.equal(carlos.montanteValidado, 700);
  assert.equal(carlos.lancamentos, 3);
  assert.equal(carlos.contasPegasQtd, 12); // só o pedido de conta traz contas
  assert.equal(carlos.dias.length, 2);
  assert.equal(carlos.dias[0].contasPegasQtd, 12);
  assert.equal(carlos.dias[0].day, hoje); // mais recente primeiro
  assert.equal(carlos.ultimosServicos.length, 3);
  assert.equal(carlos.ultimosServicos[0].atendimentoTs > carlos.ultimosServicos[1].atendimentoTs, true);
  assert.match(resumo.periodo, /^Este ano/);
});

test('ranking: quem só lançou (sem pedido casado) continua no ranking', () => {
  plantar();
  const { operadores } = rankingOperadores('all');
  const antigo = operadores.find((o) => o.nome === 'Antigo');
  assert.ok(antigo, 'o operador sem serviço casado sumiu do ranking');
  assert.equal(antigo.servicos, 0);
  assert.equal(antigo.montanteLancado, 999);
  assert.equal(antigo.taxa, 0);
});

/* ═══════════ "Montante" = montante VALIDADO ═══════════
   Regra do usuário: tanto o KPI do Painel quanto tudo o que o bot responde no
   PV mostram o montante que fechou os 3 passos. m2 (R$ 100 de Ana) foi lançado
   e nunca comprovou — não pode aparecer em número nenhum. */

test('montantesValidados soma só o que fechou os 3 passos', async () => {
  plantar();
  const { montantesValidados } = await import('./store.js');

  const hj = montantesValidados('today');
  assert.equal(hj.total, 400, 'os 100 de Ana ficaram sem comprovante');
  assert.equal(hj.servicos, 2, 's1 (400) e s4 (conta, montante 0)');
  assert.equal(hj.grupos.get('G'), 400);
  assert.equal(hj.operadores.get('OP1'), 400);
  assert.equal(hj.operadores.has('OP2'), false, 'Ana não fechou nada hoje');
  assert.equal(hj.qtdOperadores, 1);

  assert.equal(montantesValidados({ day: ontem }).total, 300);
  assert.equal(montantesValidados('all').total, 700);
});

test('o Painel e o bot mostram o validado; o lançado vai junto como referência', async () => {
  plantar();
  const { dadosRelatorio, relatorioGeral, relatorioOperadores } = await import('./reports.js');

  const { totais, operadores } = dadosRelatorio('today');
  assert.equal(totais.montante, 400, 'é o campo que o KPI "Montante" lê');
  assert.equal(totais.montanteLancado, 500, 'o bruto continua disponível');
  assert.equal(totais.servicosValidados, 2);
  // As contas não mudaram de definição — só o montante.
  assert.equal(totais.contasValor, 46);

  const grupo = totais.grupos.find((g) => g.id === 'G');
  assert.equal(grupo.montante, 400);
  assert.equal(grupo.montanteLancado, 500);

  const carlos = operadores.find((o) => o.nome === 'Carlos');
  const ana = operadores.find((o) => o.nome === 'Ana');
  assert.equal(carlos.montante, 400);
  assert.equal(ana.montante, 0, 'lançou 100 e não comprovou: zero validado');
  assert.equal(ana.montanteLancado, 100);
  // Ordenado pelo validado — quem entregou fica em cima.
  assert.equal(operadores[0].nome, 'Carlos');

  // O texto que sai no PV.
  const txt = relatorioGeral('today');
  assert.match(txt, /Montante validado: \*R\$\s?400,00\* \(2 serviço\(s\)\)/);
  assert.doesNotMatch(txt, /500,00/, 'o lançamento bruto não aparece no texto');
  assert.match(relatorioOperadores('today'), /montante validado/);
});

test('o resumo conta os montantes pegos e os validados', async () => {
  plantar();
  const { relatorioServicos } = await import('./store.js');
  const { resumo } = relatorioServicos('today');

  // Hoje: s1 (montante 400, validado), s2 (montante 100, sem comprovante) e
  // s4 (pedido de CONTA, montante 0 — não é um montante pego).
  assert.equal(resumo.atendidos, 3);
  assert.equal(resumo.montantesPegos, 2, 's4 não trouxe montante');
  assert.equal(resumo.montantesValidados, 1, 'só s1 chegou ao comprovante');
  // A contagem e o R$ do mesmo quadro falam do mesmo conjunto.
  assert.equal(resumo.montanteValidado + resumo.montanteNaoValidado, 500);
  assert.equal(resumo.montanteValidado, 400);
});
