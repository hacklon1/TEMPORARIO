
-- Tabela para "Tabelas" gerenciadas por admins
CREATE TABLE public.admin_tables (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  titulo text NOT NULL,
  descricao text,
  file_url text NOT NULL,
  ordem integer NOT NULL DEFAULT 0,
  created_by uuid,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.admin_tables ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Authenticated view admin_tables"
ON public.admin_tables FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins insert admin_tables"
ON public.admin_tables FOR INSERT TO authenticated
WITH CHECK (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins update admin_tables"
ON public.admin_tables FOR UPDATE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins delete admin_tables"
ON public.admin_tables FOR DELETE TO authenticated
USING (has_role(auth.uid(), 'admin'::app_role));

CREATE TRIGGER set_admin_tables_updated_at
BEFORE UPDATE ON public.admin_tables
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();

-- Bucket público para arquivos de tabelas
INSERT INTO storage.buckets (id, name, public)
VALUES ('tables-files', 'tables-files', true)
ON CONFLICT (id) DO NOTHING;

CREATE POLICY "Public view tables-files"
ON storage.objects FOR SELECT
USING (bucket_id = 'tables-files');

CREATE POLICY "Admins upload tables-files"
ON storage.objects FOR INSERT TO authenticated
WITH CHECK (bucket_id = 'tables-files' AND has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins update tables-files"
ON storage.objects FOR UPDATE TO authenticated
USING (bucket_id = 'tables-files' AND has_role(auth.uid(), 'admin'::app_role));

CREATE POLICY "Admins delete tables-files"
ON storage.objects FOR DELETE TO authenticated
USING (bucket_id = 'tables-files' AND has_role(auth.uid(), 'admin'::app_role));
