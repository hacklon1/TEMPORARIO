REVOKE EXECUTE ON FUNCTION public.is_dono(uuid) FROM authenticated;
REVOKE EXECUTE ON FUNCTION public.dono_exists() FROM authenticated;