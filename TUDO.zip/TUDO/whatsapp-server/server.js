// Whatsap Server / BOT-ULTIMATE — ponto central da aplicação.
// Express (painel + API) + Socket.IO (tempo real) + Baileys (WhatsApp) + node-cron.
import 'dotenv/config';
import http from 'node:http';
import https from 'node:https';
import path from 'node:path';
import fs from 'node:fs';
import { fileURLToPath } from 'node:url';
import express from 'express';
import multer from 'multer';
import { Server as SocketServer } from 'socket.io';

import { logger } from './src/logger.js';
import {
  loadDb, getDb, saveDb, defaultConfig, defaultConfigGlobal, CHAVES_CONFIG_GLOBAL, getSessao, getSessoes,
  getConfig, getConfigSessao, backupDb, listarBackups,
} from './src/db.js';
import {
  IDS_SESSOES, SESSAO_PADRAO, RECURSOS, CHAVES_RECURSOS, CHAVES_CONFIG_SESSAO, existeSessao, conflitos,
} from './src/sessoes.js';
import {
  limparDados, validarLimpeza, relatorioBrogueiras, relatorioIndicacoes, relatorioServicos,
  rankingOperadores, diasComDados, periodoDoTexto,
} from './src/store.js';
import { MODOS_CASAMENTO } from './src/servicos.js';
import * as operacoes from './src/operacoes.js';
import * as comissoes from './src/comissoes.js';
import {
  setIo, setEstadoProvider, snapshot, emitUpdate, emitAdmin, sanitizeConfigGlobal,
} from './src/realtime.js';
import {
  configurarAuth, sincronizarSessoes, pararTudo, reconectarAgora, desvincularSessao, estado, estados,
  conexaoGeral, qrDataUrl, sendText, listGroups, groupMembers, groupParticipants, nomesDeGruposConhecidos,
} from './src/whatsapp.js';
import { configAlertas, montarTexto, enviarAlerta } from './src/alertas.js';
import {
  sincronizarExport, testarExport, statusExport, iniciarExportador,
} from './src/exportador.js';
import {
  iniciarAgendamentos, adicionarAgendamento, atualizarAgendamento, removerAgendamento, alternarAgendamento,
} from './src/scheduler.js';
import { relatorioGeral, relatorioOperadores, dadosRelatorio } from './src/reports.js';
import * as relatoriosExternos from './src/relatorios-externos.js';
import { login, resolveToken, logout } from './src/auth.js';
import { UPLOAD_DIR, MAX_IMAGEM, ehImagemSuportada, caminhoMidia, midiaExiste } from './src/midia.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const PORT = Number(process.env.PORT ?? 8480);
const HOST = process.env.HOST ?? '127.0.0.1';
const API_TOKEN = process.env.API_TOKEN ?? '';
// Token do Dash (dashboard externo que puxa os relatórios do dia). Precisa ser
// DIFERENTE do API_TOKEN: é ele que separa a rota /api/relatorios/operadores do
// Dash da rota de mesmo nome que o painel usa.
const RELATORIOS_TOKEN = process.env.RELATORIOS_TOKEN ?? '';
const RELATORIOS_CORS_ORIGIN = process.env.RELATORIOS_CORS_ORIGIN ?? '';
const AUTH_DIR = path.resolve(__dirname, process.env.AUTH_DIR ?? './auth');
const TLS_CERT = process.env.TLS_CERT || '';
const TLS_KEY = process.env.TLS_KEY || '';

if (!API_TOKEN || API_TOKEN === 'troque-me') {
  logger.error('API_TOKEN não configurado no .env — abortando');
  process.exit(1);
}

// ── Bootstrap de estado ────────────────────────────────────────────
loadDb();
if (!getDb().stats.startedAt) {
  getDb().stats.startedAt = new Date().toISOString();
  saveDb();
}
// Cada número tem sua sessão em auth/<id>. Migra a instalação de número único.
configurarAuth(AUTH_DIR);
// O realtime não importa o whatsapp.js (seria import circular): recebe daqui a
// função que sabe o estado das conexões.
setEstadoProvider(() => ({
  sessoes: estados(),
  conflitos: conflitos(getDb(), nomesDeGruposConhecidos()),
  connection: conexaoGeral(),
}));

const app = express();

// TLS opcional: se TLS_CERT/TLS_KEY existirem, sobe em HTTPS; senão HTTP.
const tlsAtivo = TLS_CERT && TLS_KEY && fs.existsSync(TLS_CERT) && fs.existsSync(TLS_KEY);
const server = tlsAtivo
  ? https.createServer({
      cert: fs.readFileSync(TLS_CERT),
      key: fs.readFileSync(TLS_KEY),
      minVersion: 'TLSv1.2', // recusa protocolos antigos/inseguros
      honorCipherOrder: true,
    }, app)
  : http.createServer(app);
if (tlsAtivo) logger.info('TLS habilitado (HTTPS)');
else if (TLS_CERT || TLS_KEY) logger.warn('TLS_CERT/TLS_KEY definidos mas arquivo(s) ausente(s) — subindo em HTTP');

const io = new SocketServer(server, { cors: { origin: false } });
setIo(io);

app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Upload (multer) ────────────────────────────────────────────────
// Definido aqui em cima porque as rotas de agendamento também recebem
// multipart (imagem + texto), não só a rota /api/upload lá embaixo.
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
const upload = multer({ dest: UPLOAD_DIR, limits: { fileSize: 25 * 1024 * 1024 } });
// Uploader restrito a imagens — o WhatsApp só renderiza como foto estes formatos.
const uploadImagem = multer({
  dest: UPLOAD_DIR,
  limits: { fileSize: MAX_IMAGEM },
  fileFilter: (_req, file, cb) =>
    ehImagemSuportada(file.mimetype)
      ? cb(null, true)
      : cb(new Error(`formato não suportado: ${file.mimetype} (use JPG, PNG ou WebP)`)),
});

// Erro do multer (arquivo grande / formato recusado) precisa virar 400 com a
// mensagem — o handler padrão do Express devolveria um HTML de erro 500.
function comUpload(mw) {
  return (req, res, next) =>
    mw(req, res, (err) => {
      if (!err) return next();
      const grande = err.code === 'LIMIT_FILE_SIZE';
      res.status(400).json({
        ok: false,
        error: grande ? `imagem acima do limite de ${Math.round(MAX_IMAGEM / 1024 / 1024)} MB` : err.message,
      });
    });
}

// Extrai o token da requisição (Bearer ou ?token= para o <img> do QR).
function getToken(req) {
  const auth = req.get('authorization') ?? '';
  const bearer = auth.startsWith('Bearer ') ? auth.slice(7) : null;
  return bearer ?? req.query.token;
}

// Painel estático (a página em si não expõe dados; a API exige autenticação).
// `no-cache` = o navegador ainda guarda, mas SEMPRE revalida (304 é barato).
// Sem isso um app.js velho em cache ao lado de um index.html novo abre o painel
// quebrado — e o usuário não tem como saber que precisa limpar o cache.
app.use(express.static(path.join(__dirname, 'public'), {
  setHeaders: (res) => res.setHeader('Cache-Control', 'no-cache'),
}));

// Liveness sem auth.
app.get('/health', (_req, res) => res.json({ ok: true }));

// ── Login / Logout (públicos) ──────────────────────────────────────
// Limite simples de tentativas por IP: sem isso a senha do viewer (curta) é
// atacável por força bruta contra um endpoint público.
const LOGIN_MAX_TENTATIVAS = 10;
const LOGIN_JANELA_MS = 10 * 60 * 1000;
const tentativasLogin = new Map(); // ip -> { n, exp }

function registrarFalha(ip) {
  const agora = Date.now();
  const e = tentativasLogin.get(ip);
  if (!e || e.exp < agora) tentativasLogin.set(ip, { n: 1, exp: agora + LOGIN_JANELA_MS });
  else e.n += 1;
}
function bloqueado(ip) {
  const e = tentativasLogin.get(ip);
  if (!e) return false;
  if (e.exp < Date.now()) {
    tentativasLogin.delete(ip);
    return false;
  }
  return e.n >= LOGIN_MAX_TENTATIVAS;
}
// Evita crescimento indefinido do Map.
setInterval(() => {
  const agora = Date.now();
  for (const [ip, e] of tentativasLogin) if (e.exp < agora) tentativasLogin.delete(ip);
}, LOGIN_JANELA_MS).unref();

app.post('/api/login', (req, res) => {
  const ip = req.ip ?? req.socket.remoteAddress ?? 'desconhecido';
  if (bloqueado(ip)) {
    logger.warn({ ip }, 'login bloqueado por excesso de tentativas');
    return res.status(429).json({ ok: false, error: 'muitas tentativas — tente novamente mais tarde' });
  }
  const { username, password } = req.body ?? {};
  const r = login(String(username ?? ''), String(password ?? ''));
  if (!r) {
    registrarFalha(ip);
    return res.status(401).json({ ok: false, error: 'usuário ou senha inválidos' });
  }
  tentativasLogin.delete(ip);
  res.json({ ok: true, token: r.token, role: r.role, user: r.user });
});
app.post('/api/logout', (req, res) => {
  logout(getToken(req));
  res.json({ ok: true });
});

/* ── Relatórios do coletor (Dash externo) ──────────────────────────
   Ficam ANTES da autenticação do painel porque usam outra chave: o Dash manda
   `Authorization: Bearer <RELATORIOS_TOKEN>` e nada mais (sem cookie, sem
   sessão). O contrato é fixo — o Dash rejeita a resposta inteira se um campo
   mudar de nome —, então o formato vive em src/relatorios-externos.js.

   /operadores é o único caminho que colide com o painel. O desempate é pelo
   token, nesta ordem: token do Dash → contrato do Dash; token do painel → rota
   antiga do painel; qualquer outra coisa → 401 do contrato. Antes um token
   errado caía no painel e recebia o 401 DELE, num formato diferente.

   /api/v1/relatorios/... é um apelido das mesmas três rotas, fora do namespace
   do painel — ali não há colisão possível, nem hoje nem numa rota futura. */
const ehDoDash = (req) =>
  Boolean(RELATORIOS_TOKEN) && getToken(req) === RELATORIOS_TOKEN;

if (!RELATORIOS_TOKEN) {
  logger.warn('RELATORIOS_TOKEN ausente — as rotas do Dash em /api/relatorios/* ficam desligadas');
}

// CORS só serve ao Dash rodando em modo de desenvolvimento (o navegador
// chamando direto). Em produção a chamada é servidor-a-servidor e não passa
// por aqui — por isso a origem é explícita no .env, nunca '*'.
function corsDoDash(req, res) {
  if (!RELATORIOS_CORS_ORIGIN) return;
  res.set('Access-Control-Allow-Origin', RELATORIOS_CORS_ORIGIN);
  res.set('Vary', 'Origin');
  res.set('Access-Control-Allow-Headers', 'authorization, content-type, x-dash-client');
  res.set('Access-Control-Allow-Methods', 'GET, OPTIONS');
}

const CAMINHOS_DASH = [
  '/api/relatorios/:relatorio(montante|contas|operadores)',
  '/api/v1/relatorios/:relatorio(montante|contas|operadores)',
];

app.options(CAMINHOS_DASH, (req, res) => {
  corsDoDash(req, res);
  res.sendStatus(204);
});

app.get(CAMINHOS_DASH, (req, res, next) => {
  const nome = req.params.relatorio;
  corsDoDash(req, res);
  // Rastro mínimo de quem chama: sem ele não dá para distinguir "o Dash pediu e
  // deu 401" de "a chamada nem chegou aqui" (TLS/firewall/função não publicada).
  logger.info({
    relatorio: nome, ip: req.ip, dia: req.query?.dia ?? null,
    origem: req.get('origin') || req.get('user-agent') || null,
    comToken: Boolean(getToken(req)),
  }, 'consulta do Dash');
  if (!ehDoDash(req)) {
    // Token do painel em /api/relatorios/operadores: é o painel chamando a
    // rota dele, deixa seguir. Token nenhum ou token errado é o Dash mal
    // configurado — e aí a resposta tem de ser a do contrato do Dash, não a
    // do painel, senão o erro chega no formato errado do outro lado.
    if (nome === 'operadores' && !req.path.startsWith('/api/v1/') && resolveToken(getToken(req))) return next();
    return res.status(401).json({ error: 'unauthorized' });
  }
  const dia = relatoriosExternos.diaDaConsulta(req.query);
  // Data ilegível não pode virar "hoje" em silêncio: o Dash mostraria o dia
  // errado achando que pediu outro. E 2026-13-45 não é um dia.
  if (!dia) return res.status(400).json({ error: 'data inválida (use YYYY-MM-DD)' });
  try {
    res.type('application/json; charset=utf-8');
    res.json(relatoriosExternos.RELATORIOS[nome](dia));
  } catch (e) {
    logger.error({ err: e, relatorio: nome }, 'relatório do Dash falhou');
    res.status(500).json({ error: String(e?.message ?? e).slice(0, 200) });
  }
});

// ── Autenticação (todas as demais rotas /api) ──────────────────────
app.use('/api', (req, res, next) => {
  const auth = resolveToken(getToken(req));
  if (!auth) return res.status(401).json({ ok: false, error: 'não autorizado' });
  req.auth = auth;
  next();
});

// Guard: só admin. O 'viewer' fica restrito ao monitoramento.
const adminOnly = (req, res, next) =>
  req.auth.role === 'admin' ? next() : res.status(403).json({ ok: false, error: 'acesso restrito ao monitoramento' });

// ── Socket.IO (tempo real) ─────────────────────────────────────────
io.use((socket, next) => {
  const auth = resolveToken(socket.handshake.auth?.token);
  if (!auth) return next(new Error('não autorizado'));
  socket.data.role = auth.role === 'viewer' ? 'viewer' : 'admin';
  next();
});
io.on('connection', (socket) => {
  const role = socket.data.role;
  socket.join(role);
  socket.emit('update', snapshot(conexaoGeral(), role));
  socket.emit('connection', { sessaoId: null, connection: conexaoGeral(), geral: conexaoGeral() });
  // QR pendente de cada número (quem acabou de abrir o painel não esperou o evento).
  if (role === 'admin') {
    for (const id of IDS_SESSOES) {
      const qr = estado(id).qr;
      if (qr) socket.emit('qr', { sessaoId: id, qr });
    }
  }
});

// ── API REST ───────────────────────────────────────────────────────
// Número pedido na query/corpo. Sem parâmetro devolve o Número 1 — é o que
// mantém funcionando quem chama a API sem saber de múltiplos números.
function sessaoDaReq(req, campo = 'sessao') {
  const bruto = String(req.query?.[campo] ?? req.body?.[campo] ?? '').trim();
  if (!bruto) return SESSAO_PADRAO;
  if (!existeSessao(bruto)) return null;
  return bruto;
}

// Filtro de número para relatórios: aceita vazio/'todas' = os três somados.
function filtroSessao(req) {
  const bruto = String(req.query?.sessao ?? '').trim();
  if (!bruto || bruto === 'todas') return null;
  return existeSessao(bruto) ? bruto : undefined; // undefined = inválido
}

app.get('/api/status', (req, res) => {
  const st = estado(SESSAO_PADRAO);
  res.json({
    ok: true,
    role: req.auth.role,
    // Campos "de topo" mantidos por compatibilidade: são do Número 1.
    connection: conexaoGeral(),
    me: st.me,
    hasQr: Boolean(st.qr),
    lastError: st.lastError,
    tentativasReconexao: st.tentativasReconexao,
    proximaTentativaEm: st.proximaTentativaEm,
    ultimoLogout: st.ultimoLogout,
    sessoes: estados(),
  });
});

/* ── Números (sessões) ───────────────────────────────────────────── */

app.get('/api/sessoes', adminOnly, (_req, res) => {
  res.json({
    ok: true,
    recursos: RECURSOS,
    sessoes: estados(),
    conflitos: conflitos(getDb(), nomesDeGruposConhecidos()),
  });
});

// Liga/desliga um número, renomeia e escolhe os recursos dele.
app.patch('/api/sessoes/:id', adminOnly, (req, res) => {
  const id = req.params.id;
  if (!existeSessao(id)) return res.status(404).json({ ok: false, error: 'número inexistente' });
  const sessao = getSessao(id);
  const { nome, ativa, recursos } = req.body ?? {};

  if (nome !== undefined) {
    const limpo = String(nome).trim().slice(0, 40);
    if (!limpo) return res.status(400).json({ ok: false, error: 'nome vazio' });
    sessao.nome = limpo;
  }
  if (recursos !== undefined) {
    if (!recursos || typeof recursos !== 'object') {
      return res.status(400).json({ ok: false, error: 'recursos inválidos' });
    }
    const desconhecidos = Object.keys(recursos).filter((k) => !CHAVES_RECURSOS.includes(k));
    if (desconhecidos.length) {
      return res.status(400).json({ ok: false, error: `recurso desconhecido: ${desconhecidos.join(', ')}` });
    }
    for (const [k, v] of Object.entries(recursos)) sessao.recursos[k] = Boolean(v);
  }
  if (ativa !== undefined) sessao.ativa = Boolean(ativa);

  saveDb({ immediate: true });
  // Ligar/desligar reflete na conexão na hora; mudança de recurso vale para a
  // próxima mensagem (o handler lê o db a cada uma).
  sincronizarSessoes();
  emitUpdate();
  res.json({ ok: true, sessao: estados().find((s) => s.id === id), conflitos: conflitos(getDb(), nomesDeGruposConhecidos()) });
});

// Força uma tentativa de reconexão imediata (sem esperar o backoff).
app.post('/api/sessoes/:id/reconnect', adminOnly, (req, res) => {
  if (!existeSessao(req.params.id)) return res.status(404).json({ ok: false, error: 'número inexistente' });
  res.json({ ok: reconectarAgora(req.params.id) });
});

// Desvincula: apaga a sessão salva e volta a pedir QR (troca de número).
app.post('/api/sessoes/:id/desvincular', adminOnly, async (req, res) => {
  if (!existeSessao(req.params.id)) return res.status(404).json({ ok: false, error: 'número inexistente' });
  try {
    await desvincularSessao(req.params.id);
    emitUpdate();
    res.json({ ok: true });
  } catch (err) {
    res.status(500).json({ ok: false, error: err.message });
  }
});

app.get('/api/sessoes/:id/qr', adminOnly, async (req, res) => {
  if (!existeSessao(req.params.id)) return res.status(404).json({ ok: false, error: 'número inexistente' });
  const dataUrl = await qrDataUrl(req.params.id);
  if (!dataUrl) return res.status(409).json({ ok: false, error: 'sem QR (conectado, desligado ou iniciando)' });
  const base64 = dataUrl.split(',')[1];
  res.set('Content-Type', 'image/png').send(Buffer.from(base64, 'base64'));
});

// Compat: reconexão/QR do Número 1 sem informar a sessão.
app.post('/api/reconnect', adminOnly, (req, res) => {
  const id = sessaoDaReq(req);
  if (!id) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({ ok: reconectarAgora(id) });
});

/* Painel de um dia do passado: mesmo snapshot, outro recorte.
   `?period=` aceita 'hoje' (padrão, o que o socket empurra) ou uma data
   'YYYY-MM-DD' — é como o painel entra em modo histórico. O socket continua
   mandando só o dia corrente; quem está olhando ontem ignora o que chega. */
app.get('/api/snapshot', (req, res) => {
  const filtro = filtroSessao(req);
  if (filtro === undefined) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({ ok: true, ...snapshot(conexaoGeral(), req.auth.role, filtro, periodoDaReq(req)) });
});

/* Calendário do histórico: primeiro dia gravado, último, e o que cada dia tem.
   O navegador de dias do painel usa para saber até onde pode voltar e para
   marcar os dias com movimento. Vale para o viewer — é dado de monitoramento. */
app.get('/api/dias', (req, res) => {
  const filtro = filtroSessao(req);
  if (filtro === undefined) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({ ok: true, sessao: filtro, ...diasComDados(filtro) });
});

app.get('/api/qr', adminOnly, async (req, res) => {
  const id = sessaoDaReq(req);
  if (!id) return res.status(400).json({ ok: false, error: 'número inválido' });
  const dataUrl = await qrDataUrl(id);
  if (!dataUrl) return res.status(409).json({ ok: false, error: 'sem QR (conectado ou iniciando)' });
  const base64 = dataUrl.split(',')[1];
  res.set('Content-Type', 'image/png').send(Buffer.from(base64, 'base64'));
});

// Config — leitura (sem senha) e atualização (merge de campos permitidos).
// Cada número tem a SUA configuração; o que é do servidor (fuso, janela dos
// repetidos) fica em `global` e vale para os três.
function configVisivel(id) {
  const c = { ...getConfig(id) };
  c.commandPasswordSet = Boolean(c.commandPassword);
  delete c.commandPassword;
  return c;
}

app.get('/api/config', adminOnly, (req, res) => {
  const id = sessaoDaReq(req);
  if (!id) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({
    ok: true,
    sessao: id,
    config: configVisivel(id),
    global: sanitizeConfigGlobal(getDb().config),
    configs: Object.fromEntries(getSessoes().map((s) => [s.id, configVisivel(s.id)])),
  });
});

// Prazo da validação em 3 passos: minutos, de 1 a 7 dias.
function janelaMinutos(v) {
  const n = Number(v);
  return Number.isFinite(n) && n >= 1 && n <= 10080 ? Math.round(n) : undefined;
}

// Limite de alerta: inteiro ≥ 0 (0 = contagem desligada).
function limiteAlerta(v, teto) {
  const n = Number(v);
  return Number.isFinite(n) && n >= 0 && n <= teto ? Math.round(n) : undefined;
}

// Valida/normaliza cada campo. Sem isso o painel podia gravar tipos errados
// (ex.: monitoredGroups como string) e quebrar o processamento de mensagens.
const validadores = {
  autoReplyEnabled: (v) => Boolean(v),
  autoReplyGroups: (v) => Boolean(v),
  monitorPrivate: (v) => Boolean(v),
  autoReplyMessage: (v) => String(v ?? '').slice(0, 4096),
  commandPassword: (v) => String(v ?? '').slice(0, 200),
  monitorMode: (v) => (['none', 'all', 'specific'].includes(v) ? v : undefined),
  // Janela dos links repetidos: horas ≥ 0 (0 = histórico inteiro). Teto de um
  // ano — acima disso dá no mesmo que 0 e só confunde quem lê o campo.
  repetidosJanelaHoras: (v) => {
    const n = Number(v);
    return Number.isFinite(n) && n >= 0 && n <= 8784 ? Math.round(n) : undefined;
  },
  // Validação de serviço em 3 passos (pedido → Operador → comprovante PIX).
  servicosEnabled: (v) => Boolean(v),
  servicosModoCasamento: (v) => (MODOS_CASAMENTO.includes(v) ? v : undefined),
  // Prazos em minutos: 1 min a 7 dias. Zero não faria sentido (nada casaria) e
  // um prazo gigante casaria o comprovante de hoje com o pedido da semana passada.
  servicosJanelaAtendimentoMin: (v) => janelaMinutos(v),
  servicosJanelaComprovanteMin: (v) => janelaMinutos(v),
  // Alerta de link repetido
  alertaRepetidosEnabled: (v) => Boolean(v),
  alertaRepetidosMarcarTodos: (v) => Boolean(v),
  alertaRepetidosMensagem: (v) => String(v ?? '').slice(0, 1000),
  // Vazio = sem destino (o alerta fica parado). Grupo ou número; o painel
  // oferece só grupos, que é onde "marcar todos" faz sentido.
  alertaRepetidosGrupo: (v) => {
    const s = String(v ?? '').trim();
    if (!s) return '';
    if (/@(g\.us|s\.whatsapp\.net)$/.test(s)) return s;
    const digitos = s.replace(/\D/g, '');
    return digitos ? `${digitos}@s.whatsapp.net` : undefined;
  },
  // 0 desliga a contagem. Teto para não gravar um limite que nunca dispara.
  alertaRepetidosPorLink: (v) => limiteAlerta(v, 1000),
  alertaRepetidosPorDia: (v) => limiteAlerta(v, 100000),
  // Exportação para o DB Dashboard. A URL só é aceita em HTTPS: o segredo vai
  // no cabeçalho, e em HTTP ele viajaria em claro.
  exportEnabled: (v) => Boolean(v),
  exportUrl: (v) => {
    const s = String(v ?? '').trim();
    if (!s) return '';
    try {
      const u = new URL(s);
      return u.protocol === 'https:' ? u.toString() : undefined;
    } catch {
      return undefined;
    }
  },
  exportSegredo: (v) => String(v ?? '').slice(0, 200),
  exportApiKey: (v) => String(v ?? '').slice(0, 500),
  exportIntervaloMin: (v) => {
    const n = Number(v);
    return Number.isFinite(n) && n >= 1 && n <= 1440 ? Math.round(n) : undefined;
  },
  welcomeEnabled: (v) => Boolean(v),
  welcomeMessage: (v) => String(v ?? '').slice(0, 4096),
  welcomeMode: (v) => (['all', 'specific'].includes(v) ? v : undefined),
  welcomeGroups: (v) => (Array.isArray(v) ? v.map(String).filter(Boolean) : undefined),
  timezone: (v) => {
    const s = String(v ?? '');
    try {
      new Intl.DateTimeFormat('pt-BR', { timeZone: s });
      return s;
    } catch {
      return undefined;
    }
  },
  monitoredGroups: (v) => (Array.isArray(v) ? v.map(String).filter(Boolean) : undefined),
  commandAuthorizedNumbers: (v) => (Array.isArray(v) ? v.map(String).filter(Boolean) : undefined),
  reportAuthorizedNumbers: (v) => (Array.isArray(v) ? v.map(String).filter(Boolean) : undefined),
};

app.post('/api/config', adminOnly, (req, res) => {
  const db = getDb();
  const id = sessaoDaReq(req);
  if (!id) return res.status(400).json({ ok: false, error: 'número inválido' });
  const configSessao = getConfigSessao(id);
  const permitidos = Object.keys(defaultConfig);
  const invalidos = [];
  // Valida TUDO antes de gravar: um pedido com um campo ruim não pode deixar a
  // configuração pela metade.
  const aplicar = [];
  for (const [k, v] of Object.entries(req.body ?? {})) {
    if (k === 'sessao') continue;
    if (!permitidos.includes(k)) continue;
    const limpo = validadores[k] ? validadores[k](v) : v;
    if (limpo === undefined) invalidos.push(k);
    else aplicar.push([k, limpo]);
  }
  if (invalidos.length) {
    return res.status(400).json({ ok: false, error: `valor inválido para: ${invalidos.join(', ')}` });
  }
  for (const [k, limpo] of aplicar) {
    // Fuso e janela dos repetidos são do servidor; o resto é do número.
    if (CHAVES_CONFIG_GLOBAL.includes(k)) db.config[k] = limpo;
    else configSessao[k] = limpo;
  }
  saveDb({ immediate: true });
  emitUpdate();
  res.json({ ok: true, sessao: id, config: configVisivel(id), global: sanitizeConfigGlobal(db.config) });
});

// Grupos de UM número (cada conta participa dos seus).
app.get('/api/groups', adminOnly, async (req, res) => {
  const id = sessaoDaReq(req);
  if (!id) return res.status(400).json({ ok: false, error: 'número inválido' });
  try {
    res.json({ ok: true, sessao: id, groups: await listGroups(id) });
  } catch (err) {
    res.status(502).json({ ok: false, error: err.message });
  }
});

// Membros de um grupo já classificados: administradores = Operadores,
// o resto = Brogueiras.
app.get('/api/groups/:id/membros', adminOnly, async (req, res) => {
  const sessaoId = sessaoDaReq(req);
  if (!sessaoId) return res.status(400).json({ ok: false, error: 'número inválido' });
  try {
    const membros = await groupMembers(sessaoId, req.params.id);
    res.json({
      ok: true,
      total: membros.length,
      operadores: membros.filter((m) => m.admin),
      brogueiras: membros.filter((m) => !m.admin),
    });
  } catch (err) {
    res.status(502).json({ ok: false, error: err.message });
  }
});

/* Período de qualquer relatório: `?period=` aceita hoje | ontem | semana | mes |
   ano | geral (e os nomes em inglês), ou uma data ('2026-08-28', '28/08') para
   um dia exato — é assim que o painel pede os dias anteriores. O vocabulário é
   o mesmo dos comandos do WhatsApp (periodoDoTexto no store); semana/mês/ano
   são de CALENDÁRIO — ver intervaloPeriodo(). Desconhecido cai em hoje, nunca
   em "tudo", que exageraria os números de quem só errou a digitação. */
function periodoDaReq(req) {
  return periodoDoTexto(req.query.period);
}

app.get('/api/report', (req, res) => {
  const period = periodoDaReq(req);
  const sessao = filtroSessao(req);
  if (sessao === undefined) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({ ok: true, sessao, texto: relatorioGeral(period, { sessao }), ...dadosRelatorio(period, { sessao }) });
});

// Relatório das Brogueiras: pedidos de link do dia (ou geral), já separados
// em contas x montante, somados por pessoa.
app.get('/api/brogueiras', adminOnly, (req, res) => {
  const period = periodoDaReq(req);
  const incluirOperadores = req.query.operadores === '1';
  const sessao = filtroSessao(req);
  if (sessao === undefined) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({ ok: true, period, sessao, ...relatorioBrogueiras(period, { incluirOperadores, sessao }) });
});

// Indicações: ranking de quem trouxe mais Brogueiras + a lista das indicadas.
app.get('/api/indicacoes', adminOnly, (req, res) => {
  const period = periodoDaReq(req);
  const sessao = filtroSessao(req);
  if (sessao === undefined) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({ ok: true, period, sessao, ...relatorioIndicacoes(period, { sessao }) });
});

// DESEMPENHO DOS OPERADORES: só os serviços que fecharam os 3 passos
// (pedido da Brogueira → resposta do Operador → comprovante PIX dela).
app.get('/api/servicos', adminOnly, (req, res) => {
  const period = periodoDaReq(req);
  const sessao = filtroSessao(req);
  if (sessao === undefined) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({ ok: true, period, sessao, ...relatorioServicos(period, { sessao }) });
});

// Ranking dos Operadores: quantos serviços cada um pegou no período e quanto
// isso deu — em serviço validado e em lançamento bruto.
app.get('/api/operadores/ranking', adminOnly, (req, res) => {
  const period = periodoDaReq(req);
  const sessao = filtroSessao(req);
  if (sessao === undefined) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({ ok: true, period, sessao, ...rankingOperadores(period, { sessao }) });
});

app.get('/api/operadores', (req, res) => {
  const period = periodoDaReq(req);
  const sessao = filtroSessao(req);
  if (sessao === undefined) return res.status(400).json({ ok: false, error: 'número inválido' });
  res.json({ ok: true, sessao, texto: relatorioOperadores(period, { sessao }) });
});

app.post('/api/send', adminOnly, async (req, res) => {
  const { to, message } = req.body ?? {};
  if (!to || !message) return res.status(400).json({ ok: false, error: 'campos "to" e "message" obrigatórios' });
  const id = sessaoDaReq(req);
  if (!id) return res.status(400).json({ ok: false, error: 'número inválido' });
  const sessao = getSessao(id);
  // Sem o recurso ligado o número não envia: é o mesmo contrato do painel.
  if (!sessao.ativa) return res.status(409).json({ ok: false, error: `${sessao.nome} está desligado` });
  if (!sessao.recursos?.envios) {
    return res.status(409).json({ ok: false, error: `${sessao.nome} está sem o recurso "Envio manual" ligado` });
  }
  try {
    res.json({ ok: true, ...(await sendText(id, String(to), String(message))) });
  } catch (err) {
    res.status(502).json({ ok: false, error: err.message });
  }
});

/* ── Exportação para o DB Dashboard ──────────────────────────────────────
   O bot empurra ranking + serviços para o site. Aqui ficam só o status e os
   dois gatilhos manuais do painel; o ciclo automático é do exportador. */
app.get('/api/export', adminOnly, (_req, res) => res.json({ ok: true, ...statusExport() }));

// Teste de conexão: um lote marcado como `teste`, que o site responde sem
// gravar nada. Confere URL e segredo sem sujar o banco de lá.
app.post('/api/export/testar', adminOnly, async (_req, res) => {
  const r = await testarExport();
  res.status(r.ok ? 200 : 502).json({ ...r, status_export: statusExport() });
});

// "Sincronizar agora": ignora o intervalo, mas nada além dele — o que já foi
// enviado continua não indo de novo.
app.post('/api/export/sincronizar', adminOnly, async (_req, res) => {
  const r = await sincronizarExport({ forcar: true });
  emitUpdate();
  res.status(r.ok ? 200 : 502).json({ ...r, status_export: statusExport() });
});

// Alerta de link repetido: dispara um exemplo AGORA, com a configuração salva.
// Serve para conferir o destino e o "marcar todos" sem esperar um caso real —
// e não marca nada como já alertado, porque não houve caso nenhum.
app.post('/api/alertas/testar', adminOnly, async (req, res) => {
  const id = sessaoDaReq(req);
  if (!id) return res.status(400).json({ ok: false, error: 'número inválido' });
  const configDaSessao = getConfig(id);
  const cfg = configAlertas(configDaSessao);
  if (!cfg.grupo) return res.status(400).json({ ok: false, error: 'escolha o grupo que recebe o alerta' });

  const exemplo = {
    autorNome: 'Fulana (exemplo)',
    groupName: 'teste do painel',
    day: null,
  };
  const texto = `${montarTexto({
    cfg,
    entry: exemplo,
    repeticao: {
      link: 'https://exemplo.com/?id=123456', chave: 'exemplo.com/?id=123456',
      vezes: Math.max(2, cfg.porLink || 3), deOutra: true, primeiroPor: 'Ciclana (exemplo)',
      primeiroEm: new Date(Date.now() - 3600 * 1000).toISOString(),
    },
    totalDia: null,
    config: configDaSessao,
  })}\n\n_(mensagem de teste enviada pelo painel)_`;

  try {
    // Sai pelo mesmo número que dispararia o alerta de verdade.
    await enviarAlerta({ grupo: cfg.grupo, marcarTodos: cfg.marcarTodos, texto }, {
      reply: (to, msg, opts) => sendText(id, to, msg, opts),
      getGroupParticipants: (jid) => groupParticipants(id, jid),
    });
    res.json({ ok: true, sessao: id, grupo: cfg.grupo, marcouTodos: cfg.marcarTodos, texto });
  } catch (err) {
    res.status(502).json({ ok: false, error: err.message });
  }
});

// Agendamentos (admin)
app.get('/api/schedules', adminOnly, (_req, res) => res.json({ ok: true, schedules: getDb().schedules }));
// Aceita JSON (só texto) ou multipart/form-data com o campo "image".
app.post('/api/schedules', adminOnly, comUpload(uploadImagem.single('image')), (req, res) => {
  const arquivo = req.file;
  try {
    const media = arquivo
      ? { file: arquivo.filename, mime: arquivo.mimetype, nome: arquivo.originalname }
      : null;
    res.json({ ok: true, schedule: adicionarAgendamento({ ...(req.body ?? {}), media }) });
  } catch (err) {
    // Agendamento recusado: o arquivo já subiu e ficaria órfão em uploads/.
    if (arquivo) fs.rmSync(arquivo.path, { force: true });
    res.status(400).json({ ok: false, error: err.message });
  }
});

// Imagem de um agendamento (para a miniatura no painel).
app.get('/api/schedules/:id/media', adminOnly, (req, res) => {
  const s = getDb().schedules.find((x) => x.id === req.params.id);
  if (!s?.media || !midiaExiste(s.media)) return res.status(404).json({ ok: false, error: 'sem imagem' });
  res.type(s.media.mime).sendFile(caminhoMidia(s.media.file));
});
app.patch('/api/schedules/:id', adminOnly, (req, res) => {
  const ok = alternarAgendamento(req.params.id, Boolean(req.body?.enabled));
  res.status(ok ? 200 : 404).json({ ok });
});

// Edição completa. Aceita JSON ou multipart (campo "image" troca a imagem;
// removerImagem=true tira a que já existe).
app.put('/api/schedules/:id', adminOnly, comUpload(uploadImagem.single('image')), (req, res) => {
  const arquivo = req.file;
  try {
    const dados = { ...(req.body ?? {}) };
    if (arquivo) dados.media = { file: arquivo.filename, mime: arquivo.mimetype, nome: arquivo.originalname };
    const schedule = atualizarAgendamento(req.params.id, dados);
    if (!schedule) {
      if (arquivo) fs.rmSync(arquivo.path, { force: true });
      return res.status(404).json({ ok: false, error: 'agendamento não encontrado' });
    }
    res.json({ ok: true, schedule });
  } catch (err) {
    if (arquivo) fs.rmSync(arquivo.path, { force: true }); // edição recusada: não deixa o upload órfão
    res.status(400).json({ ok: false, error: err.message });
  }
});
app.delete('/api/schedules/:id', adminOnly, (req, res) => {
  const ok = removerAgendamento(req.params.id);
  res.status(ok ? 200 : 404).json({ ok });
});

// ── Limpeza de dados coletados (admin, destrutivo) ─────────────────
// Sempre grava um backup antes de tocar no db: é a única forma de desfazer.
app.post('/api/dados/limpar', adminOnly, (req, res) => {
  const { escopo = 'tudo', antesDe = null, confirmar } = req.body ?? {};
  if (confirmar !== true) {
    return res.status(400).json({ ok: false, error: 'operação destrutiva: envie confirmar:true' });
  }
  // Valida antes de gastar um backup com um pedido que vai ser recusado.
  try {
    validarLimpeza({ escopo, antesDe });
  } catch (err) {
    return res.status(400).json({ ok: false, error: err.message });
  }
  let backup = null;
  try {
    backup = path.basename(backupDb());
  } catch (err) {
    // Sem backup não seguimos: o histórico seria perdido sem volta.
    logger.error(err, 'falha ao criar backup — limpeza abortada');
    return res.status(500).json({ ok: false, error: 'falha ao criar backup — nada foi apagado' });
  }
  try {
    const r = limparDados({ escopo, antesDe });
    logger.warn({ ...r, backup, por: req.auth.user }, 'dados coletados apagados');
    emitUpdate();
    res.json({ ok: true, ...r, backup });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* ═══════════ Relatórios por usuário (aba Relatórios) ═══════════
   Livro-caixa dos operadores: operações, comissões, metas e o rastro de tudo.
   TUDO aqui é `adminOnly` — o viewer nem vê a aba, e o guard é a garantia de
   que não vê pela API também. As regras de negócio (corte das 5h, líquido x
   bruto, quem entra na comissão) moram em src/operacoes.js. */

// Filtros comuns: ?de=&ate=&user=&modo=liquido|bruto
function filtrosRelatorio(req) {
  const dia = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v ?? '')) ? String(v) : null);
  return {
    de: dia(req.query.de),
    ate: dia(req.query.ate),
    userId: req.query.user ? String(req.query.user) : null,
    modo: req.query.modo === 'bruto' ? 'bruto' : 'liquido',
  };
}

// Quem está mexendo — vai para o log de alterações e para o backup da comissão.
const quem = (req) => req.auth?.user || req.auth?.role || 'admin';

// "Mudou alguma coisa nas operações": o painel aberto recarrega a aba sozinho.
// Vai sem carga útil — os números vêm pela API, que confere o papel de novo.
const emitOperacoes = () => emitAdmin('operacoes', { em: new Date().toISOString() });

// Uma chamada só desenha a aba inteira (totais, comissões, backups, log).
app.get('/api/relatorios', adminOnly, (req, res) => {
  const f = filtrosRelatorio(req);
  res.json({
    ok: true,
    ...operacoes.painelRelatorios(f),
    // Comissão COBRADA dos Operadores: % sobre o salário (o `Valor` da
    // mensagem deles) dos serviços que fecharam os 3 passos. O fechamento é
    // por SEMANA (`?semana=` escolhe qual, `?dia=` abre um dia dela).
    operadores: comissoes.comissoesOperadores(recorteComissao(req)),
    semana: comissoes.resumoSemana({ referencia: req.query.semana ?? req.query.dia ?? null }),
    // Os dois quadros do topo: montante que os Operadores pegaram e foi validado.
    validado: comissoes.montanteValidado({}),
    cobrancas: comissoes.listarCobrancas(100),
  });
});

/* ── Comissão dos Operadores: semana, porcentagem, cobrança e desfazer ──
   O recorte padrão é a SEMANA (segunda a domingo) — é o ciclo em que a casa
   acerta com o Operador. `?dia=` abre um dia dessa semana; `?de=&ate=` ainda
   funciona para quem quiser um intervalo qualquer. */
function recorteComissao(req) {
  const dia = (v) => (/^\d{4}-\d{2}-\d{2}$/.test(String(v ?? '')) ? String(v) : null);
  const umDia = dia(req.query.dia);
  if (umDia) return { de: umDia, ate: umDia };
  const semana = dia(req.query.semana);
  if (semana) return comissoes.semanaDe(semana);
  const f = filtrosRelatorio(req);
  if (f.de || f.ate) return { de: f.de, ate: f.ate };
  return comissoes.semanaDe();   // sem nada: a semana corrente
}

app.get('/api/relatorios/operadores', adminOnly, (req, res) => {
  res.json({
    ok: true,
    ...comissoes.comissoesOperadores(recorteComissao(req)),
    semana: comissoes.resumoSemana({ referencia: req.query.semana ?? req.query.dia ?? null }),
    conhecidos: comissoes.operadoresConhecidos(),
  });
});

app.get('/api/relatorios/semana', adminOnly, (req, res) =>
  res.json({ ok: true, ...comissoes.resumoSemana({ referencia: req.query.ref ?? null }) }));

/* Apelido: só muda o nome na tela — o histórico guarda o pushName do WhatsApp. */
app.post('/api/relatorios/operadores/apelido', adminOnly, (req, res) => {
  try {
    const { operadorId, apelido } = req.body ?? {};
    res.json({ ok: true, config: comissoes.definirApelido({ operadorId, apelido }) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* Isento: não é cobrado e não aparece no quadro (continua na tela de ajuste). */
app.post('/api/relatorios/operadores/isento', adminOnly, (req, res) => {
  try {
    const { operadorId, isento } = req.body ?? {};
    res.json({ ok: true, config: comissoes.definirIsento({ operadorId, isento: Boolean(isento) }) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/relatorios/operadores/pct', adminOnly, (req, res) => {
  try {
    const { operadorId = null, pct } = req.body ?? {};
    if (pct === undefined || pct === null || Number.isNaN(Number(pct))) {
      return res.status(400).json({ ok: false, error: 'informe a porcentagem' });
    }
    res.json({ ok: true, config: comissoes.definirPct({ operadorId, pct }) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/relatorios/operadores/:id/pct', adminOnly, (req, res) =>
  res.json({ ok: true, config: comissoes.limparPct(req.params.id) }));

/* Prévia da cobrança: para quem vai, quanto é e o texto pronto (com a
   mensagem que o dono escreveu em Configurações). Não manda nada. */
app.get('/api/relatorios/operadores/:id/cobranca', adminOnly, (req, res) => {
  try {
    // Mesmo recorte da tabela de comissão — a prévia não pode falar de outra
    // janela que a da tela.
    res.json({ ok: true, ...comissoes.cobrancaDoOperador(req.params.id, recorteComissao(req)) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* "Ver mais": tudo o que o Operador pegou no recorte da tela, validado ou não.
   A tabela de comissão só mostra o cobrável; aqui aparece o dia inteiro dele. */
app.get('/api/relatorios/operadores/:id/servicos', adminOnly, (req, res) => {
  try {
    res.json({ ok: true, ...comissoes.servicosDoOperador(req.params.id, recorteComissao(req)) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* Manda a cobrança pelo WhatsApp, do bot para o Operador.
   Mandar a mensagem NÃO dá baixa na comissão — a baixa é o "Zerar comissão",
   que grava a cobrança com a lista de serviços. São dois botões porque são
   duas coisas: uma fala com a pessoa, a outra mexe no dinheiro. */
app.post('/api/relatorios/operadores/:id/cobrar-whatsapp', adminOnly, async (req, res) => {
  try {
    const corpo = req.body ?? {};
    const recorte = corpo.dia
      ? { de: corpo.dia, ate: corpo.dia }
      : (corpo.semana ? comissoes.semanaDe(corpo.semana) : comissoes.semanaDe());
    const cobranca = comissoes.cobrancaDoOperador(req.params.id, recorte);
    if (!cobranca.para) {
      return res.status(409).json({
        ok: false,
        error: 'o WhatsApp não expôs o número deste Operador — não há para onde mandar',
      });
    }
    // O texto pode vir editado da tela; sem ele, vale o modelo das Configurações.
    const texto = String(corpo.mensagem ?? '').trim() || cobranca.mensagem;

    // Manda pelo número que está ligado e com "Envio manual" liberado. Sem
    // nenhum, avisa em vez de falhar silenciosamente.
    const emissor = (corpo.sessao && existeSessao(corpo.sessao) ? [getSessao(corpo.sessao)] : getSessoes())
      .find((x) => x.ativa && x.recursos?.envios && estado(x.id)?.connection === 'open');
    if (!emissor) {
      return res.status(409).json({
        ok: false,
        error: 'nenhum número conectado com o recurso "Envio manual" ligado',
      });
    }

    const envio = await sendText(emissor.id, cobranca.para, texto);
    logger.warn({ por: quem(req), operador: cobranca.nome, valor: cobranca.comissao, sessao: emissor.id },
      'cobrança de comissão enviada no WhatsApp');
    res.json({ ok: true, ...cobranca, mensagem: texto, sessao: emissor.id, nomeSessao: emissor.nome, envio });
  } catch (err) {
    res.status(err.message?.includes('não tem serviço') ? 400 : 502).json({ ok: false, error: err.message });
  }
});

app.post('/api/relatorios/operadores/cobrar', adminOnly, (req, res) => {
  try {
    const corpo = req.body ?? {};
    const recorte = corpo.dia
      ? { de: corpo.dia, ate: corpo.dia }
      : (corpo.semana ? comissoes.semanaDe(corpo.semana) : { de: corpo.de ?? null, ate: corpo.ate ?? null });
    const r = comissoes.cobrar({
      operadorId: corpo.operadorId ?? null,
      ...recorte,
      por: quem(req),
    });
    logger.warn({ por: quem(req), servicos: r.servicos, total: r.total }, 'comissão de operadores cobrada');
    emitOperacoes();
    res.json({ ok: true, ...r });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.post('/api/relatorios/cobrancas/:id/desfazer', adminOnly, (req, res) => {
  try {
    const r = comissoes.desfazerCobranca(req.params.id);
    logger.warn({ por: quem(req), ...r }, 'cobrança de comissão desfeita');
    emitOperacoes();
    res.json({ ok: true, ...r });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.get('/api/relatorios/export.csv', adminOnly, (req, res) => {
  const csv = operacoes.csvPorUsuario(filtrosRelatorio(req));
  res.setHeader('Content-Type', 'text/csv; charset=utf-8');
  res.setHeader('Content-Disposition', `attachment; filename="${operacoes.nomeArquivoCsv()}"`);
  res.send(csv);
});

app.post('/api/relatorios/metas', adminOnly, (req, res) => {
  try {
    const metas = operacoes.salvarMetas(req.body ?? {});
    emitUpdate();
    res.json({ ok: true, metas });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

/* ── Usuários do relatório (perfil + papel) ── */
app.get('/api/relatorios/usuarios', adminOnly, (_req, res) =>
  res.json({ ok: true, usuarios: operacoes.listarUsuarios() }));

app.post('/api/relatorios/usuarios', adminOnly, (req, res) => {
  try {
    res.json({ ok: true, usuario: operacoes.salvarUsuario(req.body ?? {}) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.patch('/api/relatorios/usuarios/:id', adminOnly, (req, res) => {
  try {
    res.json({ ok: true, usuario: operacoes.salvarUsuario({ ...req.body, id: req.params.id }) });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/relatorios/usuarios/:id', adminOnly, (req, res) =>
  res.json({ ok: true, removidos: operacoes.apagarUsuario(req.params.id) }));

/* ── Operações ── */
app.get('/api/operations', adminOnly, (req, res) => {
  const f = filtrosRelatorio(req);
  res.json({ ok: true, operacoes: operacoes.filtrarOperacoes(f) });
});

app.post('/api/operations', adminOnly, (req, res) => {
  try {
    const op = operacoes.registrarOperacao(req.body ?? {});
    emitOperacoes();
    res.status(201).json({ ok: true, operacao: op });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.patch('/api/operations/:id', adminOnly, (req, res) => {
  try {
    const op = operacoes.atualizarOperacao(req.params.id, req.body ?? {}, { por: quem(req) });
    emitOperacoes();
    res.json({ ok: true, operacao: op });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.delete('/api/operations/:id', adminOnly, (req, res) => {
  const removidos = operacoes.apagarOperacao(req.params.id, { por: quem(req) });
  if (removidos) emitOperacoes();
  res.json({ ok: true, removidos });
});

/* ── Comissões: zerar (com backup) e desfazer ── */
app.post('/api/relatorios/comissoes/zerar', adminOnly, (req, res) => {
  try {
    const corpo = req.body ?? {};
    const r = operacoes.zerarComissoes({
      de: corpo.de ?? null,
      ate: corpo.ate ?? null,
      userId: corpo.user_id ?? null,
      por: quem(req),
    });
    logger.warn({ por: quem(req), operacoes: r.operacoes, total: r.total }, 'comissões zeradas');
    emitOperacoes();
    res.json({ ok: true, ...r });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.get('/api/relatorios/backups', adminOnly, (_req, res) =>
  res.json({ ok: true, backups: operacoes.listarBackupsComissao(100) }));

app.post('/api/relatorios/backups/:id/desfazer', adminOnly, (req, res) => {
  try {
    const r = operacoes.desfazerReset(req.params.id);
    logger.warn({ por: quem(req), ...r }, 'reset de comissão desfeito');
    emitOperacoes();
    res.json({ ok: true, ...r });
  } catch (err) {
    res.status(400).json({ ok: false, error: err.message });
  }
});

app.get('/api/relatorios/auditoria', adminOnly, (req, res) =>
  res.json({ ok: true, log: operacoes.logAlteracoes(Number(req.query.limite) || 200) }));

app.get('/api/dados/backups', adminOnly, (_req, res) => res.json({ ok: true, backups: listarBackups() }));

// Upload de arquivos (multer, admin)
app.post('/api/upload', adminOnly, comUpload(upload.single('file')), (req, res) => {
  if (!req.file) return res.status(400).json({ ok: false, error: 'arquivo ausente (campo "file")' });
  res.json({ ok: true, file: { nome: req.file.originalname, salvo: req.file.filename, tamanho: req.file.size } });
});

// ── Sobe ───────────────────────────────────────────────────────────
server.listen(PORT, HOST, () => logger.info(`Whatsap Server (bot) em ${tlsAtivo ? 'https' : 'http'}://${HOST}:${PORT}`));

// Sobe os números marcados como ativos no painel (na primeira instalação, só o 1).
sincronizarSessoes();
iniciarAgendamentos();
// Exportação para o site: o tique pergunta de minuto em minuto se já é hora.
// Ligar/desligar é pela configuração, não por reiniciar o processo.
iniciarExportador();

// Um erro assíncrono solto (ex.: uma promise rejeitada no Baileys) derruba o
// processo por padrão no Node 22. Preferimos registrar e seguir vivo — o
// systemd reinicia de qualquer forma, mas sem perder o estado em memória.
process.on('unhandledRejection', (reason) => {
  logger.error({ err: reason }, 'unhandledRejection — processo mantido vivo');
});
process.on('uncaughtException', (err) => {
  logger.error(err, 'uncaughtException — tentando salvar estado');
  try {
    saveDb({ immediate: true });
  } catch {
    /* já logado dentro de saveDb */
  }
});

let encerrando = false;
for (const sig of ['SIGINT', 'SIGTERM']) {
  process.on(sig, () => {
    if (encerrando) return;
    encerrando = true;
    logger.info(`${sig} — encerrando`);
    saveDb({ immediate: true });
    pararTudo(); // cancela os timers de reconexão e fecha os sockets dos 3 números
    io.close();
    server.close(() => process.exit(0));
    // rede aberta (WhatsApp/sockets) pode segurar o event loop — força saída
    setTimeout(() => process.exit(0), 3000).unref();
  });
}
