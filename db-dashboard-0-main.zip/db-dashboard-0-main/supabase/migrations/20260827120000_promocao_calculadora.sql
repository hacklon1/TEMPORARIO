-- Promoção da Calculadora de % (Montante).
--
-- Quando ativa, todo montante a partir de um valor definido passa a usar
-- automaticamente um percentual fixo, no lugar do que o usuário escolheu.
--
-- Fica em app_settings porque vale para todo mundo — Donos, Admins e
-- Operadores. As políticas dessa tabela já dão leitura a qualquer usuário
-- autenticado e escrita só a admin (e, por herança, ao DONO).

ALTER TABLE public.app_settings
  ADD COLUMN IF NOT EXISTS promo_ativa BOOLEAN NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS promo_valor_minimo NUMERIC(14,2) NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS promo_percentual NUMERIC(5,2) NOT NULL DEFAULT 0;

COMMENT ON COLUMN public.app_settings.promo_ativa IS
  'Liga a promoção da Calculadora de % (Montante).';
COMMENT ON COLUMN public.app_settings.promo_valor_minimo IS
  'A partir deste montante (inclusive) a promoção passa a valer.';
COMMENT ON COLUMN public.app_settings.promo_percentual IS
  'Percentual aplicado quando a promoção vale.';

-- A calculadora precisa reagir na hora em que o admin muda a promoção.
DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.app_settings;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;
