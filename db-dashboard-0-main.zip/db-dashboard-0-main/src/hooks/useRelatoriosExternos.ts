import { useQuery } from "@tanstack/react-query";

import {
  buscarRelatoriosDoDia,
  diaOperacional,
  type RelatoriosDoDia,
} from "@/lib/relatoriosExternos";

/** Relatórios do coletor externo para um dia operacional.
 *  Revalida sozinho a cada 5 min — o coletor fecha os números ao longo do dia. */
export function useRelatoriosExternos(data: string = diaOperacional(), enabled = true) {
  return useQuery<RelatoriosDoDia>({
    queryKey: ["relatorios-externos", data],
    queryFn: ({ signal }) => buscarRelatoriosDoDia(data, signal),
    enabled,
    staleTime: 60_000,
    refetchInterval: 5 * 60_000,
    retry: 1,
  });
}
