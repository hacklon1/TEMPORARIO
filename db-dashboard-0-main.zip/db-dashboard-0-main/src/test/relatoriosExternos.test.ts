import { describe, expect, it } from "vitest";

import { contasSchema, diaOperacional, montanteSchema, operadoresSchema } from "@/lib/relatoriosExternos";

// Amostras reduzidas do coletor em 2026-08-31 (nomes e telefones trocados).
// O que elas guardam: os campos novos da fonte atual, os campos zerados que
// sobraram do contrato antigo (`deposito`/`saque`) e chaves que o Dash não
// conhece — nada disso pode derrubar a validação.

const montanteBruto = {
  data: "2026-08-31",
  gerado_em: "2026-09-01T08:42:45-03:00",
  moeda: "BRL",
  totais: {
    pedidos: 94,
    deposito: 0,
    saque: 0,
    blogueira: 2485.04,
    comissao: 148.9,
    lucro: 148.9,
    montante: 11446,
    validados: 62,
  },
  por_hora: [
    { hora: "05:00", deposito: 0, saque: 0, lucro: 0, montante: 0, blogueira: 0 },
    { hora: "08:00", deposito: 0, saque: 0, lucro: 23.7, montante: 813, blogueira: 207 },
  ],
};

const contasBruto = {
  data: "2026-08-31",
  gerado_em: "2026-09-01T08:42:47-03:00",
  moeda: "BRL",
  totais: {
    contas_solicitadas: 132,
    deposito: 0,
    saque: 0,
    salario: 484,
    comissao: 9.7,
    lucro: 9.7,
    zerou: 10,
    sacou: 14,
    aberta: 0,
    pedidos: 24,
    montante: 903,
  },
  itens: [
    {
      nome_conta: "Blogueira A",
      deposito: 0,
      saque: 0,
      salario: 60,
      lucro: 0,
      status: "sacou",
      atualizado_em: "2026-08-31T23:49:01-03:00",
      contas: 1,
      montante: 300,
      operador: "Operador 1",
    },
    {
      nome_conta: "Blogueira A",
      deposito: 0,
      saque: 0,
      salario: 25,
      lucro: 0,
      status: "zerou",
      atualizado_em: "2026-08-31T20:18:10-03:00",
      contas: 5,
      montante: 0,
      operador: "Operador 2",
    },
  ],
};

const operadoresBruto = {
  data: "2026-08-31",
  gerado_em: "2026-09-01T08:42:58-03:00",
  moeda: "BRL",
  operadores: [
    {
      id: "1111@lid",
      nome: "Operador 1",
      usuario: "550000000001",
      categoria: "montante",
      pedidos: 21,
      deposito: 0,
      saque: 0,
      blogueira: 634,
      comissao: 63.4,
      lucro: 570.6,
      meta_dia: 20000,
      online: false,
      ultima_operacao: "2026-08-31T21:58:23-03:00",
      validados: 19,
      montante: 3318,
      pct: 10,
      isento: false,
    },
    {
      id: "2222@lid",
      nome: "usuario_removido",
      usuario: null,
      categoria: "contas",
      pedidos: 0,
      deposito: 0,
      saque: 0,
      blogueira: 0,
      comissao: 0,
      lucro: 0,
      meta_diaria: 20000,
      online: false,
      ultima_operacao: null,
      validados: 0,
      montante: 0,
      pct: 0,
      isento: true,
    },
  ],
};

describe("contrato dos relatórios do coletor", () => {
  it("aceita o montante com os campos novos e ignora os desconhecidos", () => {
    const r = montanteSchema.parse(montanteBruto);
    expect(r.totais.montante).toBe(11446);
    expect(r.totais.validados).toBe(62);
    expect(r.por_hora[1]).toMatchObject({ hora: "08:00", montante: 813, blogueira: 207 });
  });

  it("aceita contas com uma linha por pedido e a mesma blogueira repetida", () => {
    const r = contasSchema.parse(contasBruto);
    // contas_solicitadas conta CONTAS; pedidos conta LINHAS. Grandezas distintas.
    expect(r.totais.contas_solicitadas).toBe(132);
    expect(r.totais.pedidos).toBe(24);
    expect(r.totais.aberta).toBe(0);
    expect(r.itens.map((i) => i.nome_conta)).toEqual(["Blogueira A", "Blogueira A"]);
    expect(r.itens[0]).toMatchObject({ contas: 1, montante: 300, operador: "Operador 1" });
  });

  it("aceita operadores com pct/isento e preserva o cadastro removido", () => {
    const r = operadoresSchema.parse(operadoresBruto);
    expect(r.operadores).toHaveLength(2);
    expect(r.operadores[0]).toMatchObject({ validados: 19, montante: 3318, pct: 10, isento: false });
    expect(r.operadores[1]).toMatchObject({ nome: "usuario_removido", isento: true, ultima_operacao: null });
  });

  it("aceita a meta como `meta_dia` (servidor) ou `meta_diaria` (spec antiga)", () => {
    const r = operadoresSchema.parse(operadoresBruto);
    expect(r.operadores[0].meta_dia).toBe(20000); // veio como meta_dia
    expect(r.operadores[1].meta_dia).toBe(20000); // veio como meta_diaria
  });

  it("mantém por_hora na ordem operacional (05:00 primeiro), sem reordenar", () => {
    const r = montanteSchema.parse({
      ...montanteBruto,
      por_hora: [
        { hora: "05:00", montante: 1, blogueira: 0, lucro: 0 },
        { hora: "23:00", montante: 2, blogueira: 0, lucro: 0 },
        { hora: "00:00", montante: 3, blogueira: 0, lucro: 0 },
        { hora: "04:00", montante: 4, blogueira: 0, lucro: 0 },
      ],
    });
    expect(r.por_hora.map((h) => h.hora)).toEqual(["05:00", "23:00", "00:00", "04:00"]);
  });
});

describe("dia operacional (05:00 → 04:59, America/Sao_Paulo)", () => {
  // Instantes em UTC; São Paulo é UTC-3 nessas datas.
  it("2h da madrugada em São Paulo pertence ao dia anterior", () => {
    // 2026-09-02T02:00-03:00 = 05:00Z
    expect(diaOperacional(new Date("2026-09-02T05:00:00Z"))).toBe("2026-09-01");
  });

  it("04:59 ainda é o dia anterior; 05:00 já é o dia corrente", () => {
    expect(diaOperacional(new Date("2026-09-02T07:59:59Z"))).toBe("2026-09-01");
    expect(diaOperacional(new Date("2026-09-02T08:00:00Z"))).toBe("2026-09-02");
  });

  it("não depende do fuso do navegador: 23h em São Paulo é o mesmo dia mesmo já sendo amanhã em UTC", () => {
    // 2026-09-01T23:30-03:00 = 2026-09-02T02:30Z
    expect(diaOperacional(new Date("2026-09-02T02:30:00Z"))).toBe("2026-09-01");
  });

  it("vira o mês e o ano corretamente na madrugada", () => {
    // 2027-01-01T01:00-03:00 = 04:00Z
    expect(diaOperacional(new Date("2027-01-01T04:00:00Z"))).toBe("2026-12-31");
  });
});

describe("tolerância do contrato", () => {
  it("não rejeita a resposta por causa de um campo que o Dash não conhece", () => {
    const comExtras = {
      ...montanteBruto,
      campo_do_futuro: "qualquer coisa",
      totais: { ...montanteBruto.totais, outro_extra: 42 },
    };
    expect(() => montanteSchema.parse(comExtras)).not.toThrow();
  });
});
