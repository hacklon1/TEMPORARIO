// Edge function `ingest-whatsapp` — o endereço que o Whatsap Server chama.
//
// Contrato (POST, application/json):
//   cabeçalho  x-db-secret: <segredo combinado>
//   corpo      { origem, versao, enviado_em, teste?, operadores: [...], servicos: [...] }
//   resposta   { ok, operadores: <n>, servicos: <n> }
//
// Idempotente: upsert por (dia, operador_id) e por id de serviço. O bot reenvia
// o lote inteiro quando uma resposta se perde — e reenviar não pode duplicar.
//
// Deploy no Supabase:
//   supabase functions deploy ingest-whatsapp --no-verify-jwt
//   supabase secrets set WHATSAPP_INGEST_SECRET=<o mesmo segredo do painel do bot>
//
// `--no-verify-jwt` porque quem chama é um servidor, não um usuário logado: a
// autorização aqui é o segredo compartilhado, conferido abaixo.
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.45.4';

const SEGREDO = Deno.env.get('WHATSAPP_INGEST_SECRET') ?? '';
const SUPABASE_URL = Deno.env.get('SUPABASE_URL')!;
const SERVICE_KEY = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;

// Comparação de tamanho fixo: um `===` vaza, pelo tempo de resposta, quantos
// caracteres do segredo estão certos.
function segredoConfere(recebido: string): boolean {
  if (!SEGREDO || recebido.length !== SEGREDO.length) return false;
  let diferenca = 0;
  for (let i = 0; i < SEGREDO.length; i++) diferenca |= SEGREDO.charCodeAt(i) ^ recebido.charCodeAt(i);
  return diferenca === 0;
}

const json = (corpo: unknown, status = 200) =>
  new Response(JSON.stringify(corpo), { status, headers: { 'content-type': 'application/json' } });

Deno.serve(async (req) => {
  if (req.method !== 'POST') return json({ ok: false, erro: 'use POST' }, 405);
  if (!segredoConfere(req.headers.get('x-db-secret') ?? '')) {
    return json({ ok: false, erro: 'segredo inválido' }, 401);
  }

  let corpo: any;
  try {
    corpo = await req.json();
  } catch {
    return json({ ok: false, erro: 'corpo não é JSON' }, 400);
  }

  // Teste de conexão do painel do bot: confirma segredo e URL sem gravar nada.
  if (corpo?.teste === true) return json({ ok: true, teste: true, recebido_em: new Date().toISOString() });

  const operadores = Array.isArray(corpo?.operadores) ? corpo.operadores : [];
  const servicos = Array.isArray(corpo?.servicos) ? corpo.servicos : [];
  if (operadores.length > 5000 || servicos.length > 5000) {
    return json({ ok: false, erro: 'lote grande demais' }, 413);
  }

  const db = createClient(SUPABASE_URL, SERVICE_KEY, { auth: { persistSession: false } });
  const agora = new Date().toISOString();

  if (operadores.length) {
    const { error } = await db
      .from('wa_operadores_dia')
      .upsert(operadores.map((o: any) => ({ ...o, atualizado_em: agora })), { onConflict: 'dia,operador_id' });
    if (error) return json({ ok: false, erro: `operadores: ${error.message}` }, 500);
  }

  if (servicos.length) {
    const { error } = await db
      .from('wa_servicos')
      .upsert(servicos.map((s: any) => ({ ...s, atualizado_em: agora })), { onConflict: 'id' });
    if (error) return json({ ok: false, erro: `servicos: ${error.message}` }, 500);
  }

  return json({ ok: true, operadores: operadores.length, servicos: servicos.length, recebido_em: agora });
});
