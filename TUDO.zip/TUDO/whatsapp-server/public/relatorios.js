/* ═══════════════ Aba Relatórios (admin) ═══════════════
   O livro-caixa dos operadores: quanto cada um movimentou, quanto há a pagar
   de comissão e o rastro de tudo que foi editado, apagado ou zerado.

   Mora num arquivo próprio porque o app.js já passou de 2.700 linhas — e esta
   aba não é monitoramento, é dinheiro: misturar as duas coisas no mesmo
   arquivo só aumentaria a chance de um erro aqui derrubar o Painel.

   Depende de app.js (carregado antes): $, api, esc, brl, num, dataDia. */

const relEstado = {
  de: '', ate: '', usuario: '',
  // A comissão dos Operadores tem o seu próprio recorte: ela fecha por semana
  // (segunda a domingo), e um dia pode ser aberto dentro dela. Não segue os
  // filtros de data do topo de propósito — o acerto com o Operador é semanal.
  semana: '',   // qualquer dia da semana em exibição ('' = semana corrente)
  dia: '',      // dia aberto dentro da semana ('' = a semana inteira)
  dados: null,
  expandido: null,      // user_id com o histórico aberto
  // "Ver mais" da tabela de comissão: qual Operador está aberto e o que ele
  // pegou no recorte. A chave guarda de QUAL recorte a lista é — trocar de
  // semana ou de dia sem isso deixaria a lista velha aberta embaixo dos
  // números novos.
  servicosAberto: null,
  servicosChave: null,   // null = nada aberto; '' é um recorte legítimo (sem filtro)
  servicos: new Map(),  // operadorId -> { resumo, servicos }
  operacoes: new Map(), // user_id -> operações do período (carregadas ao expandir)
};

/* ── Avisos (o "toast" do painel já existe no Painel; aqui é o mesmo estilo) ── */
function relAviso(texto, tipo = 'ok') {
  const caixa = $('avisos');
  if (!caixa) return;
  const el = document.createElement('div');
  el.className = 'aviso-toast ' + (tipo === 'erro' ? 'erro' : 'validado');
  el.innerHTML = `<b>${esc(texto)}</b>`;
  el.onclick = () => el.remove();
  caixa.prepend(el);
  while (caixa.children.length > 4) caixa.lastElementChild.remove();
  setTimeout(() => el.remove(), tipo === 'erro' ? 12000 : 7000);
}

const relQs = () => {
  const p = new URLSearchParams();
  if (relEstado.de) p.set('de', relEstado.de);
  if (relEstado.ate) p.set('ate', relEstado.ate);
  if (relEstado.usuario) p.set('user', relEstado.usuario);
  if (relEstado.semana) p.set('semana', relEstado.semana);
  if (relEstado.dia) p.set('dia', relEstado.dia);
  return p.toString();
};

const relTemFiltro = () => Boolean(relEstado.de || relEstado.ate || relEstado.usuario);

/* ═══════════ Carga ═══════════ */

async function carregarRelatorios() {
  // Mudou o recorte (semana, dia, filtro)? O "Ver mais" aberto falava do
  // recorte antigo — fecha, em vez de deixar uma lista velha embaixo dos
  // números novos.
  if (relEstado.servicosChave !== null && relEstado.servicosChave !== relQs()) {
    relEstado.servicos.clear();
    relEstado.servicosAberto = null;
    relEstado.servicosChave = null;
  }
  try {
    const r = await api('/relatorios?' + relQs());
    if (!r.ok) return;
    relEstado.dados = r;
    renderRelatorios(r);
  } catch (err) {
    relAviso('não foi possível carregar os relatórios: ' + err.message, 'erro');
  }
}

/* ═══════════ Render ═══════════ */

function renderRelatorios(d) {
  // filtros
  $('rel-de').value = relEstado.de;
  $('rel-ate').value = relEstado.ate;
  const sel = $('rel-usuario');
  const escolhido = relEstado.usuario;
  sel.innerHTML = '<option value="">Todos os usuários</option>' + d.usuarios.map((u) =>
    `<option value="${esc(u.id)}">${esc(u.nome)}${u.papel !== 'user' ? ' · ' + esc(u.papel) : ''}</option>`).join('');
  sel.value = escolhido;
  $('rel-limpar').classList.toggle('hidden', !relTemFiltro());
  $('rel-filtro-info').textContent = relTemFiltro()
    ? `${relEstado.de ? 'de ' + dataDia(relEstado.de) : ''} ${relEstado.ate ? 'até ' + dataDia(relEstado.ate) : ''}`.trim()
    : 'todo o histórico';

  // metas
  if (document.activeElement !== $('rel-meta-dia')) $('rel-meta-dia').value = d.metas.metaDiariaBlogueira || '';
  if (document.activeElement !== $('rel-meta-semana')) $('rel-meta-semana').value = d.metas.metaSemanalBlogueira || '';

  // Os quadros do topo falam da SEMANA DA CASA (sábado 05h → sábado 05h) e não
  // seguem o filtro de datas: são o ciclo corrente, o que zera todo sábado.
  const semana = d.validado?.semana ?? { montantes: 0, salario: 0, rotulo: '', operadores: 0 };
  $('rel-k-pedidos').textContent = num(semana.montantes);
  $('rel-k-pedidos-sub').textContent = semana.rotulo || 'na semana';
  $('rel-k-lucro').textContent = brl(semana.salario);
  $('rel-k-lucro').className = 'value ' + (semana.salario < 0 ? 'neg' : 'pos');
  $('rel-k-lucro-sub').textContent = semana.operadores
    ? `${num(semana.operadores)} operador(es) · o "Valor" das mensagens deles`
    : 'nada pago nesta semana ainda';

  // Montante validado: o que os Operadores pegaram e fechou os 3 passos.
  // A barra só aparece quando existe meta; sem meta, o rodapé conta quantos
  // serviços entraram — que é a informação útil no lugar de um "0%".
  const quadroValidado = (dados, elValor, elBarra, elSub, rotulo) => {
    const d = dados || { montante: 0, servicos: 0, meta: 0, pct: null };
    $(elValor).textContent = brl(d.montante);
    const largura = d.pct === null ? 0 : Math.min(100, d.pct);
    $(elBarra).style.width = largura + '%';
    $(elBarra).className = d.pct !== null && d.pct >= 100 ? 'cheio' : '';
    const validados = `${num(d.servicos)} serviço(s) validado(s)`;
    const janela = d.rotulo ? ` · ${d.rotulo}` : '';
    $(elSub).textContent = d.pct === null
      ? (d.servicos ? validados + janela : `sem serviço validado ${rotulo === 'diária' ? 'hoje' : 'na semana'}`)
      : `${validados} · ${num(d.pct)}% da meta ${rotulo} (${brl(d.meta)})`;
  };
  quadroValidado(d.validado?.hoje, 'rel-k-hoje', 'rel-barra-hoje', 'rel-k-hoje-sub', 'diária');
  quadroValidado(d.validado?.semana, 'rel-k-semana', 'rel-barra-semana', 'rel-k-semana-sub', 'semanal');

  renderComissaoOperadores(d.operadores, d.semana);
  renderCobrancas(d.cobrancas || []);
  renderComissoes(d.comissoes);
  renderBackups(d.backups);
  renderTabelaUsuarios(d.porUsuario);
  renderLogAlteracoes(d.auditoria);
}

/* ═══════════ Comissão COBRADA dos Operadores ═══════════
   A base é o salário que o Operador recebeu da Brogueira — o `💸 Valor` da
   mensagem dele — e só entra serviço validado. A porcentagem é escolhida por
   Operador; quem não tem a sua segue o padrão da casa. */

function renderComissaoOperadores(d, semana) {
  if (!d) return;
  const r = d.resumo || {};
  // Salário = tudo o que foi pego no recorte (cobrado ou não) — é o que a soma
  // dos dias mostra. Comissão = só o que ainda não foi cobrado.
  $('rel-op-salario').textContent = brl(r.salarioTotal ?? r.salario);
  $('rel-op-comissao').textContent = brl(r.comissao);
  $('rel-op-cobrado').textContent = brl(r.comissaoCobrada);
  $('rel-op-periodo').textContent = relEstado.dia
    ? `dia ${dataDia(relEstado.dia)}`
    : 'semana inteira';
  $('rel-cobrar-todas').disabled = !r.comissao;
  if (document.activeElement !== $('rel-pct-padrao')) $('rel-pct-padrao').value = d.padraoPct ?? 0;
  renderSemana(semana);

  const corpo = document.querySelector('#rel-tbl-operadores tbody');
  corpo.innerHTML = (d.operadores || []).map((o) => `
    <tr>
      <td><span class="rel-op-nome"><b>${esc(o.nome)}</b>
        <button class="btn-ghost sm apelido-btn" data-apelido="${esc(o.operadorId)}"
          title="Trocar o nome que aparece aqui">✎</button></span>
        ${o.pctPropria ? '' : ' <span class="badge">padrão</span>'}
        ${o.apelido ? `<div class="sub">${esc(o.nomeOriginal)}</div>` : ''}</td>
      <td class="num">${num(o.servicos)}</td>
      <td class="num">${esc(brl(o.salario))}</td>
      <td class="num"><input type="number" class="rel-pct" min="0" max="100" step="0.5"
        value="${o.pct}" data-pct="${esc(o.operadorId)}" aria-label="Porcentagem de ${esc(o.nome)}" /></td>
      <td class="num"><b>${esc(brl(o.comissao))}</b></td>
      <td class="num sub">${esc(brl(o.comissaoCobrada))}</td>
      <td class="acoes">
        <button class="btn-ghost sm" data-ver="${esc(o.operadorId)}"
          title="Todos os serviços que ele pegou no recorte — validados em verde"
          aria-expanded="${relEstado.servicosAberto === o.operadorId}">${relEstado.servicosAberto === o.operadorId ? 'Ocultar' : 'Ver mais'}</button>
        <button class="btn-ghost sm" data-cobrar="${esc(o.operadorId)}"
          title="Manda a cobrança no WhatsApp do Operador — vale também depois de zerar">Cobrar</button>
        <button class="btn-ghost sm" data-isentar="${esc(o.operadorId)}"
          title="Isentar: some do quadro e não é cobrado">Isentar</button>
        <button class="btn sm" data-zerar-comissao="${esc(o.operadorId)}" ${o.comissao ? '' : 'disabled'}
          title="Dá baixa: registra a cobrança e zera o que está em aberto">Zerar comissão</button>
      </td>
    </tr>
    ${relEstado.servicosAberto === o.operadorId
      ? `<tr class="rel-detalhe"><td colspan="7">${htmlServicosOperador(o.operadorId)}</td></tr>` : ''}`).join('')
    || `<tr><td colspan="7" class="vazio">Nenhum serviço validado ${relEstado.dia ? 'neste dia' : 'nesta semana'}.</td></tr>`;

  corpo.querySelectorAll('[data-pct]').forEach((input) => {
    input.onchange = () => salvarPct(input.dataset.pct, input.value);
  });
  corpo.querySelectorAll('[data-ver]').forEach((b) => {
    b.onclick = () => alternarServicosOperador(b.dataset.ver);
  });
  corpo.querySelectorAll('[data-cobrar]').forEach((b) => {
    b.onclick = () => cobrarNoWhatsApp(b.dataset.cobrar);
  });
  corpo.querySelectorAll('[data-zerar-comissao]').forEach((b) => {
    b.onclick = () => cobrarOperador(b.dataset.zerarComissao);
  });
  corpo.querySelectorAll('[data-apelido]').forEach((b) => {
    b.onclick = () => renomearOperador(b.dataset.apelido);
  });
  corpo.querySelectorAll('[data-isentar]').forEach((b) => {
    b.onclick = () => isentarOperador(b.dataset.isentar);
  });
}

/* ── "Ver mais": o dia inteiro do Operador ─────────────────────────────
   A tabela acima só fala do que é cobrável (serviço validado). Quem cobra
   precisa ver também o que ele pegou e não fechou — é a pergunta que o
   Operador faz de volta ("peguei 20, por que só 19 contam?"). Os validados
   ficam em VERDE: são os que entraram na conta da comissão. */

async function alternarServicosOperador(operadorId) {
  if (relEstado.servicosAberto === operadorId) {
    relEstado.servicosAberto = null;
    return renderComissaoOperadores(relEstado.dados?.operadores, relEstado.dados?.semana);
  }
  relEstado.servicosAberto = operadorId;
  // A lista é do recorte que está na tela: trocou a semana ou o dia, ela morre.
  const chave = relQs();
  if (relEstado.servicosChave !== chave) {
    relEstado.servicos.clear();
    relEstado.servicosChave = chave;
  }
  renderComissaoOperadores(relEstado.dados?.operadores, relEstado.dados?.semana); // mostra "carregando…"
  if (relEstado.servicos.has(operadorId)) return;
  try {
    const r = await api(`/relatorios/operadores/${encodeURIComponent(operadorId)}/servicos?` + chave);
    if (!r.ok) throw new Error(r.error || 'não deu para ler os serviços');
    relEstado.servicos.set(operadorId, r);
  } catch (err) {
    relEstado.servicos.set(operadorId, { erro: err.message });
  }
  // Só redesenha se ainda for este o aberto (o usuário pode ter fechado).
  if (relEstado.servicosAberto === operadorId) {
    renderComissaoOperadores(relEstado.dados?.operadores, relEstado.dados?.semana);
  }
}

const horaDoDia = (ts) => (ts
  ? new Date(ts).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' })
  : '—');

function htmlServicosOperador(operadorId) {
  const d = relEstado.servicos.get(operadorId);
  if (!d) return '<div class="vazio">carregando…</div>';
  if (d.erro) return `<div class="vazio">${esc(d.erro)}</div>`;
  if (!d.servicos.length) {
    return `<div class="vazio">Nenhum serviço pego por ele ${relEstado.dia ? 'neste dia' : 'nesta semana'}.</div>`;
  }
  const r = d.resumo;
  return `<div class="rel-servicos">
    <div class="mini-list">
      <div class="mini"><span class="l">Serviços pegos</span><span class="v">${num(r.pegos)}</span></div>
      <div class="mini"><span class="l">Validados</span><span class="v sv-ok">${num(r.validados)} · ${num(r.taxa)}%</span></div>
      <div class="mini"><span class="l">Valor dos validados</span><span class="v">${esc(brl(r.salarioValidado))}</span></div>
      <div class="mini"><span class="l">Comissão (${num(d.pct)}%)</span><span class="v">${esc(brl(r.comissao))}</span></div>
    </div>
    <p class="hint">Em <b class="sv-ok">verde</b>, os serviços validados — os únicos que entram na
      comissão. Os demais ele pegou, mas não fecharam com comprovante${r.pegos > r.validados
        ? ` (${num(r.pegos - r.validados)} no recorte, ${esc(brl(r.salarioPego - r.salarioValidado))} que não são cobrados)` : ''}.</p>
    <div class="tbl-wrap rel-historico">
      <table class="tbl">
        <thead><tr>
          <th>Dia</th><th>Atendeu</th><th>Brogueira</th><th>Pedido</th>
          <th class="num">Montante</th><th class="num">Valor</th><th class="num">Comissão</th><th>Situação</th>
        </tr></thead>
        <tbody>${d.servicos.map((sv) => `
          <tr class="${sv.validado ? 'sv-linha-ok' : ''}">
            <td>${esc(dataDia(sv.day))}</td>
            <td>${esc(horaDoDia(sv.ts))}</td>
            <td>${esc(sv.brogueira)}</td>
            <td>${sv.tipo === 'conta'
              ? `${num(sv.contasPedidas)} conta(s)` : 'montante'}</td>
            <td class="num">${esc(brl(sv.montante))}</td>
            <td class="num">${esc(brl(sv.salario))}</td>
            <td class="num">${sv.validado ? esc(brl(sv.comissao)) : '—'}</td>
            <td>${sv.validado
              ? `<span class="selo-sv ok">validado ${esc(horaDoDia(sv.validadoEm))}</span>${sv.cobrado ? ' <span class="badge">já cobrado</span>' : ''}`
              : `<span class="selo-sv">${esc(sv.statusRotulo)}</span>`}</td>
          </tr>`).join('')}</tbody>
      </table>
    </div>
  </div>`;
}

/* ── A semana e os seus dias ──────────────────────────────────────────
   A comissão fecha por semana; a faixa mostra o que foi pego em cada dia e
   clicar num deles abre só aquele dia (clicar de novo volta para a semana). */
function renderSemana(semana) {
  if (!semana) return;
  relEstado.dadosSemana = semana;
  $('rel-semana-rotulo').textContent = semana.atual ? `esta semana · ${semana.semana.rotulo}` : semana.semana.rotulo;
  $('rel-semana-prox').disabled = !semana.proxima;

  $('rel-dias').innerHTML = semana.dias.map((d) => `
    <button type="button" class="rel-dia ${d.hoje ? 'hoje' : ''}" data-dia="${d.day}"
      aria-pressed="${relEstado.dia === d.day}" ${d.futuro ? 'disabled' : ''}
      title="${d.servicos} serviço(s) validado(s) em ${dataDia(d.day)}">
      <span class="d">${d.rotulo} ${d.dataCurta}</span>
      <span class="v">${d.salario ? brl(d.salario) : '—'}</span>
      <span class="n">${d.servicos
        ? (d.comissaoAberta ? brl(d.comissaoAberta) + ' a cobrar' : 'tudo cobrado')
        : 'sem serviço'}</span>
    </button>`).join('');

  $('rel-dias').querySelectorAll('[data-dia]').forEach((b) => {
    b.onclick = () => {
      relEstado.dia = relEstado.dia === b.dataset.dia ? '' : b.dataset.dia;
      carregarRelatorios();
    };
  });
}

function irParaSemana(referencia) {
  relEstado.semana = referencia || '';
  relEstado.dia = '';
  carregarRelatorios();
}

function renderCobrancas(lista) {
  // O botão carrega a contagem: dá para saber que existe histórico sem abrir.
  const botao = $('rel-ver-historico');
  if (botao && !historicoAberto) {
    botao.textContent = lista.length
      ? `Ver histórico de comissões (${lista.length})`
      : 'Ver histórico de comissões';
  }
  const corpo = document.querySelector('#rel-tbl-cobrancas tbody');
  corpo.innerHTML = lista.map((c) => `
    <tr class="${c.desfeita ? 'desfeito' : ''}">
      <td>${esc(new Date(c.criadaEm).toLocaleString('pt-BR'))}</td>
      <td>${esc(c.operadorNome)}</td>
      <td>${c.periodo?.de || c.periodo?.ate
        ? esc(`${c.periodo.de ? dataDia(c.periodo.de) : '…'} a ${c.periodo.ate ? dataDia(c.periodo.ate) : '…'}`)
        : 'tudo'}</td>
      <td class="num">${num(c.servicos)}</td>
      <td class="num">${esc(brl(c.salario))}</td>
      <td class="num">${num(c.pct)}%</td>
      <td class="num"><b>${esc(brl(c.valor))}</b></td>
      <td><span class="badge ${c.desfeita ? 'ok' : 'aviso'}">${c.desfeita ? 'DESFEITA' : 'COBRADA'}</span></td>
      <td>${c.desfeita ? '' : `<button class="btn-ghost sm" data-desfazer-cobranca="${esc(c.id)}">Desfazer</button>`}</td>
    </tr>`).join('') || '<tr><td colspan="9" class="vazio">Nenhuma comissão cobrada ainda.</td></tr>';

  corpo.querySelectorAll('[data-desfazer-cobranca]').forEach((b) => {
    b.onclick = () => desfazerCobranca(b.dataset.desfazerCobranca);
  });
}

function renomearOperador(operadorId) {
  const alvo = (relEstado.dados?.operadores?.operadores ?? []).find((o) => o.operadorId === operadorId);
  if (!alvo) return;
  abrirModal('Nome do Operador no relatório', `
    <p class="hint">O WhatsApp entrega o nome que a própria pessoa escolheu
      (<b>${esc(alvo.nomeOriginal)}</b>). O apelido vale só aqui — o histórico não é reescrito,
      e deixar em branco volta ao original.</p>
    <div class="campo"><label>Apelido</label>
      <input name="apelido" value="${esc(alvo.apelido || '')}" placeholder="${esc(alvo.nomeOriginal)}" maxlength="40" /></div>`,
  async (raiz) => {
    const r = await api('/relatorios/operadores/apelido', {
      method: 'POST',
      body: JSON.stringify({ operadorId, apelido: raiz.querySelector('[name=apelido]').value }),
    });
    if (!r.ok) throw new Error(r.error || 'falha ao salvar');
    relAviso('nome atualizado');
    await carregarRelatorios();
  });
}

async function isentarOperador(operadorId, isento = true) {
  const alvo = (relEstado.dados?.operadores?.operadores ?? []).find((o) => o.operadorId === operadorId);
  const nome = alvo?.nome || 'este Operador';
  if (isento && !confirm(`Isentar ${nome}?\n\n`
    + 'Ele deixa de ser cobrado e some do quadro de comissões. '
    + 'As cobranças já feitas continuam no histórico.')) return;
  try {
    const r = await api('/relatorios/operadores/isento', {
      method: 'POST', body: JSON.stringify({ operadorId, isento }),
    });
    if (!r.ok) throw new Error(r.error || 'falha ao salvar');
    relAviso(isento ? `${nome} agora é isento` : `${nome} voltou a ser cobrado`);
    await carregarRelatorios();
  } catch (err) {
    relAviso('não foi possível salvar: ' + err.message, 'erro');
  }
}

/* Tela de ajuste: apelido, porcentagem e isenção de TODOS os Operadores
   conhecidos — inclusive os isentos, que não aparecem no quadro. */
async function modalOperadoresAjuste() {
  const r = await api('/relatorios/operadores?' + relQs());
  const lista = r.conhecidos || [];
  const modal = abrirModal('Operadores — nome, comissão e isenção', `
    <p class="hint">O apelido vale só no relatório. Isento não é cobrado e não aparece no quadro.</p>
    <div class="rel-isento-lista">${lista.map((o) => `
      <div class="rel-isento-linha" data-op="${esc(o.operadorId)}">
        <input type="text" class="ajuste-apelido" value="${esc(o.apelido || '')}" placeholder="${esc(o.nomeOriginal)}" maxlength="40" />
        <span class="orig">${esc(o.nomeOriginal)}</span>
        <span class="sub">${o.validados} val · ${esc(brl(o.salarioTotal))}</span>
        <label class="sub">% <input type="number" class="ajuste-pct" min="0" max="100" step="0.5" value="${o.pct}" style="width:4.2rem" /></label>
        <label class="sub"><input type="checkbox" class="ajuste-isento" ${o.isento ? 'checked' : ''} /> isento</label>
      </div>`).join('') || '<div class="vazio">Nenhum Operador conhecido ainda.</div>'}
    </div>`, async (raiz) => {
    // Salva de uma vez o que mudou — três chamadas por linha só quando muda.
    for (const linha of raiz.querySelectorAll('.rel-isento-linha')) {
      const operadorId = linha.dataset.op;
      const original = lista.find((o) => o.operadorId === operadorId);
      const apelido = linha.querySelector('.ajuste-apelido').value.trim();
      const pct = Number(linha.querySelector('.ajuste-pct').value || 0);
      const isentoAgora = linha.querySelector('.ajuste-isento').checked;
      if (apelido !== (original.apelido || '')) {
        await api('/relatorios/operadores/apelido', { method: 'POST', body: JSON.stringify({ operadorId, apelido }) });
      }
      if (pct !== original.pct) {
        await api('/relatorios/operadores/pct', { method: 'POST', body: JSON.stringify({ operadorId, pct }) });
      }
      if (isentoAgora !== original.isento) {
        await api('/relatorios/operadores/isento', { method: 'POST', body: JSON.stringify({ operadorId, isento: isentoAgora }) });
      }
    }
    relAviso('operadores atualizados');
    await carregarRelatorios();
  }, 'Salvar');
  return modal;
}

/* O histórico de cobranças é consulta, não operação do dia: fica fechado até
   alguém pedir. Sem persistir a escolha — a tela sempre abre limpa. */
let historicoAberto = false;

function mostrarHistorico(abrir) {
  historicoAberto = abrir;
  const card = $('rel-card-cobrancas');
  const botao = $('rel-ver-historico');
  if (!card || !botao) return;
  card.classList.toggle('hidden', !abrir);
  botao.setAttribute('aria-expanded', String(abrir));
  botao.textContent = abrir
    ? 'Ocultar histórico'
    : `Ver histórico de comissões${relEstado.dados?.cobrancas?.length ? ` (${relEstado.dados.cobrancas.length})` : ''}`;
  // `?.` porque nem todo navegador embutido tem scrollIntoView — e ficar sem
  // a rolagem suave é bem melhor do que a tela quebrar ao abrir o histórico.
  if (abrir) card.scrollIntoView?.({ behavior: 'smooth', block: 'nearest' });
}

async function salvarPct(operadorId, valor) {
  try {
    const r = await api('/relatorios/operadores/pct', {
      method: 'POST',
      body: JSON.stringify({ operadorId, pct: Number(valor || 0) }),
    });
    if (!r.ok) throw new Error(r.error || 'falha ao salvar');
    await carregarRelatorios();
  } catch (err) {
    relAviso('não foi possível salvar a porcentagem: ' + err.message, 'erro');
  }
}

/* "Cobrar" fala com a pessoa: abre a mensagem que o dono escreveu em
   Configurações, já preenchida com os números daquele Operador, e manda pelo
   WhatsApp. Não mexe no dinheiro — quem dá baixa é o "Zerar comissão". */
async function cobrarNoWhatsApp(operadorId) {
  let c;
  try {
    const qs = new URLSearchParams();
    if (relEstado.dia) qs.set('dia', relEstado.dia);
    else if (relEstado.semana) qs.set('semana', relEstado.semana);
    c = await api(`/relatorios/operadores/${encodeURIComponent(operadorId)}/cobranca?` + qs.toString());
    if (!c.ok) throw new Error(c.error || 'não foi possível montar a cobrança');
  } catch (err) {
    relAviso(err.message, 'erro');
    return;
  }

  abrirModal(`Cobrar ${c.nome} no WhatsApp`, `
    <div class="rel-form-grid" style="grid-template-columns:repeat(4,1fr)">
      <div class="mini"><span class="l">Serviços</span><span class="v">${num(c.servicos)}</span></div>
      <div class="mini"><span class="l">Salário</span><span class="v">${esc(brl(c.salario))}</span></div>
      <div class="mini"><span class="l">Comissão</span><span class="v">${esc(brl(c.comissao))}</span></div>
      <div class="mini"><span class="l">Período</span><span class="v" style="font-size:.8rem">${esc(c.periodo)}</span></div>
    </div>
    ${c.comissaoApurada
      ? `<p class="hint" style="margin-top:.6rem">Do total, <b>${esc(brl(c.comissaoApurada))}</b> já foi
          apurado no "Zerar comissão"${c.comissaoAberta ? ` e ${esc(brl(c.comissaoAberta))} segue em aberto` : ''} —
          a cobrança continua valendo até ele pagar.</p>`
      : (c.comissao ? '' : '<p class="hint" style="margin-top:.6rem">Nada apurado neste recorte: a mensagem sai zerada, mas você pode ajustar o texto antes de mandar.</p>')}
    <label style="margin-top:.8rem">Mensagem</label>
    <textarea name="mensagem" rows="9">${esc(c.mensagem)}</textarea>
    <p class="hint">${c.para
      ? `Vai para <b>${esc(String(c.para).split('@')[0])}</b>. O modelo é o de Configurações › Cobrança de comissão — dá para ajustar aqui só para este envio.`
      : '<b>Sem número:</b> o WhatsApp não expôs o telefone deste Operador, então não há para onde mandar.'}</p>`,
  async (raiz) => {
    if (!c.para) return false;
    const r = await api(`/relatorios/operadores/${encodeURIComponent(operadorId)}/cobrar-whatsapp`, {
      method: 'POST',
      body: JSON.stringify({
        mensagem: raiz.querySelector('[name=mensagem]').value,
        dia: relEstado.dia || null,
        semana: relEstado.dia ? null : (relEstado.semana || hojeSemana()),
      }),
    });
    if (!r.ok) throw new Error(r.error || 'falha ao enviar');
    relAviso(`cobrança enviada para ${r.nome} por ${r.nomeSessao}`);
  }, c.para ? 'Enviar cobrança' : 'Fechar');
}

// Qualquer dia da semana em exibição serve de referência para o servidor.
function hojeSemana() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

async function cobrarOperador(operadorId) {
  const alvo = relEstado.dados?.operadores?.operadores?.find((o) => o.operadorId === operadorId);
  if (!alvo) return;
  const periodo = relEstado.dia ? `no dia ${dataDia(relEstado.dia)}` : `na semana ${$('rel-semana-rotulo').textContent}`;
  if (!confirm(`Zerar a comissão de ${alvo.nome} ${periodo}?\n\n`
    + `${alvo.servicos} serviço(s) validado(s) · salário ${brl(alvo.salario)} · ${alvo.pct}%\n`
    + `Valor: ${brl(alvo.comissao)}\n\n`
    + 'Dá baixa: fica registrado com a lista de serviços — e dá para desfazer.')) return;
  await executarCobranca({ operadorId });
}

async function cobrarTodas() {
  const r = relEstado.dados?.operadores?.resumo;
  if (!r?.comissao) return;
  const periodo = relEstado.dia ? `no dia ${dataDia(relEstado.dia)}` : `na semana ${$('rel-semana-rotulo').textContent}`;
  if (!confirm(`Zerar a comissão de ${r.operadores} Operador(es) ${periodo}?\n\n`
    + `${r.servicos} serviço(s) validado(s) · salário ${brl(r.salario)}\n`
    + `Total: ${brl(r.comissao)}\n\n`
    + 'Sai um registro por Operador — dá para desfazer um a um.')) return;
  await executarCobranca({});
}

async function executarCobranca(corpo) {
  try {
    const r = await api('/relatorios/operadores/cobrar', {
      method: 'POST',
      // O recorte é o mesmo que está na tela: o dia aberto, ou a semana.
      body: JSON.stringify({ ...corpo, dia: relEstado.dia || null, semana: relEstado.semana || hojeSemana() }),
    });
    if (!r.ok) throw new Error(r.error || 'falha ao cobrar');
    relAviso(`${r.servicos} serviço(s) baixados · ${brl(r.total)} em ${r.cobrancas.length} registro(s)`);
    await carregarRelatorios();
  } catch (err) {
    relAviso('não foi possível cobrar: ' + err.message, 'erro');
  }
}

async function desfazerCobranca(id) {
  const c = relEstado.dados?.cobrancas?.find((x) => x.id === id);
  if (!c) return;
  if (!confirm(`Desfazer a cobrança de ${c.operadorNome}?\n\n`
    + `${c.servicos} serviço(s) · ${brl(c.valor)}\n\n`
    + 'Eles voltam a contar como comissão em aberto.')) return;
  try {
    const r = await api(`/relatorios/cobrancas/${encodeURIComponent(id)}/desfazer`, { method: 'POST' });
    if (!r.ok) throw new Error(r.error || 'falha ao desfazer');
    relAviso(`cobrança desfeita · ${brl(r.valor)} de volta em aberto`);
    await carregarRelatorios();
  } catch (err) {
    relAviso('não foi possível desfazer: ' + err.message, 'erro');
  }
}

function renderComissoes(c) {
  $('rel-com-blog').textContent = brl(c.comissao);
  $('rel-com-contas').textContent = brl(c.comissao_contas);
  $('rel-com-total').textContent = brl(c.total);
  $('rel-com-periodo').textContent = relTemFiltro()
    ? `${relEstado.de ? dataDia(relEstado.de) : '…'} a ${relEstado.ate ? dataDia(relEstado.ate) : 'hoje'}`
    : 'todo o histórico';
  $('rel-zerar-todas').disabled = c.total === 0;

  const corpo = document.querySelector('#rel-tbl-comissao tbody');
  corpo.innerHTML = c.usuarios.map((u) => `
    <tr>
      <td><b>${esc(u.nome)}</b>${u.email ? `<div class="sub">${esc(u.email)}</div>` : ''}</td>
      <td class="num">${esc(brl(u.comissao))}</td>
      <td class="num">${esc(brl(u.comissao_contas))}</td>
      <td class="num"><b>${esc(brl(u.total))}</b></td>
      <td><button class="btn-ghost sm" data-zerar="${esc(u.user_id)}" ${u.total === 0 ? 'disabled' : ''}>Zerar</button></td>
    </tr>`).join('') || '<tr><td colspan="5" class="vazio">Nenhuma comissão a pagar no período.</td></tr>';

  corpo.querySelectorAll('[data-zerar]').forEach((b) => {
    b.onclick = () => zerarComissao(b.dataset.zerar);
  });
}

function renderBackups(lista) {
  const corpo = document.querySelector('#rel-tbl-backups tbody');
  corpo.innerHTML = lista.map((b) => `
    <tr class="${b.undone ? 'desfeito' : ''}">
      <td>${esc(new Date(b.created_at).toLocaleString('pt-BR'))}</td>
      <td>${esc(b.usuarioNome)}<div class="sub">${b.operacoes} operação(ões)</div></td>
      <td>${esc(b.reset_by)}</td>
      <td class="num">${esc(brl(b.total_comissao))}</td>
      <td class="num">${esc(brl(b.total_comissao_contas))}</td>
      <td><span class="badge ${b.undone ? 'ok' : 'aviso'}">${b.undone ? 'DESFEITO' : 'ATIVO'}</span></td>
      <td>${b.undone ? '' : `<button class="btn-ghost sm" data-desfazer="${esc(b.id)}">Desfazer</button>`}</td>
    </tr>`).join('') || '<tr><td colspan="7" class="vazio">Nenhuma comissão foi zerada ainda.</td></tr>';

  corpo.querySelectorAll('[data-desfazer]').forEach((b) => {
    b.onclick = () => desfazerBackup(b.dataset.desfazer);
  });
}

function renderTabelaUsuarios(linhas) {
  const corpo = document.querySelector('#rel-tbl-usuarios tbody');
  if (!linhas.length) {
    corpo.innerHTML = '<tr><td colspan="9" class="vazio">Nenhuma operação registrada no período.</td></tr>';
    return;
  }
  corpo.innerHTML = linhas.map((l) => {
    const aberto = relEstado.expandido === l.user_id;
    const detalhe = aberto
      ? `<tr class="rel-detalhe"><td colspan="9">${htmlOperacoes(l.user_id)}</td></tr>`
      : '';
    return `
      <tr class="rel-linha ${aberto ? 'aberta' : ''}" data-user="${esc(l.user_id)}">
        <td class="chevron">${aberto ? '▾' : '▸'}</td>
        <td><b>${esc(l.nome)}</b>${l.chefia ? ' <span class="badge">chefia</span>' : ''}
          ${l.email ? `<div class="sub">${esc(l.email)}</div>` : ''}</td>
        <td class="num">${num(l.pedidos)}</td>
        <td class="num">${esc(brl(l.deposito))}</td>
        <td class="num">${esc(brl(l.saque))}</td>
        <td class="num">${esc(brl(l.blogueira))}</td>
        <td class="num ${l.lucro < 0 ? 'neg' : 'pos'}"><b>${esc(brl(l.lucro))}</b></td>
        <td class="num">${esc(brl(l.blogueiraHoje))}</td>
        <td class="num">${esc(brl(l.blogueiraSemana))}</td>
      </tr>${detalhe}`;
  }).join('');

  corpo.querySelectorAll('.rel-linha').forEach((tr) => {
    tr.onclick = () => alternarUsuario(tr.dataset.user);
  });
  corpo.querySelectorAll('[data-editar]').forEach((b) => {
    b.onclick = (ev) => { ev.stopPropagation(); modalOperacao(b.dataset.editar); };
  });
  corpo.querySelectorAll('[data-apagar]').forEach((b) => {
    b.onclick = (ev) => { ev.stopPropagation(); apagarOperacao(b.dataset.apagar); };
  });
}

function htmlOperacoes(userId) {
  const ops = relEstado.operacoes.get(userId);
  if (!ops) return '<div class="vazio">carregando…</div>';
  if (!ops.length) return '<div class="vazio">Nenhuma operação deste usuário no período.</div>';
  return `<div class="tbl-wrap rel-historico">
    <table class="tbl">
      <thead><tr><th>Data</th><th>Conta</th><th class="num">Depósito</th><th class="num">Saque</th>
        <th class="num">Blogueira</th><th class="num">Comissão</th><th class="num">Lucro</th><th></th></tr></thead>
      <tbody>${ops.map((o) => `
        <tr>
          <td>${esc(dataDia(o.data_operacao || o.dia))}</td>
          <td>${esc(o.nome_conta || '—')}</td>
          <td class="num">${esc(brl(Number(o.deposito) + Number(o.deposito_contas)))}</td>
          <td class="num">${esc(brl(Number(o.saque) + Number(o.saque_contas)))}</td>
          <td class="num">${esc(brl(Number(o.blogueira) + Number(o.salario_contas)))}</td>
          <td class="num">${esc(brl(Number(o.comissao) + Number(o.comissao_contas)))}</td>
          <td class="num">${esc(brl(Number(o.lucro)
            + (Number(o.saque_contas) - Number(o.deposito_contas) + Number(o.salario_contas))))}</td>
          <td class="acoes">
            <button class="btn-ghost sm" data-editar="${esc(o.id)}">Editar</button>
            <button class="btn-ghost sm" data-apagar="${esc(o.id)}">Apagar</button>
          </td>
        </tr>`).join('')}</tbody>
    </table>
  </div>`;
}

function renderLogAlteracoes(log) {
  const corpo = document.querySelector('#rel-tbl-log tbody');
  corpo.innerHTML = log.map((l) => `
    <tr>
      <td>${esc(new Date(l.changed_at).toLocaleString('pt-BR'))}</td>
      <td><span class="badge ${l.acao === 'APAGADA' ? 'perigo' : 'aviso'}">${esc(l.acao)}</span></td>
      <td>${esc(l.usuarioNome)}</td>
      <td>${esc(l.changed_by)}</td>
      <td class="num">${esc(brl(l.snapshot?.lucro))}</td>
      <td class="num">${esc(brl(l.snapshot?.deposito))}</td>
      <td class="num">${esc(brl(l.snapshot?.saque))}</td>
    </tr>`).join('') || '<tr><td colspan="7" class="vazio">Nada foi editado ou apagado ainda.</td></tr>';
}

/* ═══════════ Expandir o histórico de um usuário ═══════════ */

async function alternarUsuario(userId) {
  if (relEstado.expandido === userId) {
    relEstado.expandido = null;
    renderTabelaUsuarios(relEstado.dados.porUsuario);
    return;
  }
  relEstado.expandido = userId;
  renderTabelaUsuarios(relEstado.dados.porUsuario);   // mostra "carregando…"
  try {
    const p = new URLSearchParams();
    if (relEstado.de) p.set('de', relEstado.de);
    if (relEstado.ate) p.set('ate', relEstado.ate);
    p.set('user', userId);
    const r = await api('/operations?' + p.toString());
    relEstado.operacoes.set(userId, r.operacoes || []);
  } catch {
    relEstado.operacoes.set(userId, []);
  }
  if (relEstado.expandido === userId) renderTabelaUsuarios(relEstado.dados.porUsuario);
}

/* ═══════════ Ações destrutivas ═══════════
   Nunca zerar sem backup: o servidor grava o snapshot primeiro e só então
   zera; aqui a confirmação diz exatamente quantas operações e quanto. */

async function zerarComissao(userId) {
  const alvo = relEstado.dados.comissoes.usuarios.find((u) => u.user_id === userId);
  if (!alvo) return;
  const periodo = relTemFiltro() ? ` no período ${$('rel-com-periodo').textContent}` : ' em TODO o histórico';
  if (!confirm(`Zerar a comissão de ${alvo.nome}${periodo}?\n\n`
    + `Total: ${brl(alvo.total)}\n\n`
    + 'Um backup é gravado antes — dá para desfazer no card de backups.')) return;
  await executarZerar({ user_id: userId });
}

async function zerarTodas() {
  const c = relEstado.dados.comissoes;
  if (!c.total) return;
  const periodo = relTemFiltro() ? `no período ${$('rel-com-periodo').textContent}` : 'em TODO o histórico';
  if (!confirm(`Zerar a comissão de ${c.usuarios.length} usuário(s) ${periodo}?\n\n`
    + `Total: ${brl(c.total)}\n\n`
    + 'É gravado um backup por usuário — dá para desfazer um a um.')) return;
  await executarZerar({});
}

async function executarZerar(corpo) {
  try {
    const r = await api('/relatorios/comissoes/zerar', {
      method: 'POST',
      body: JSON.stringify({ ...corpo, de: relEstado.de || null, ate: relEstado.ate || null }),
    });
    if (!r.ok) throw new Error(r.error || 'falha ao zerar');
    relAviso(`${r.operacoes} operação(ões) zeradas · ${brl(r.total)} · ${r.backups.length} backup(s) gravado(s)`);
    await carregarRelatorios();
  } catch (err) {
    relAviso('não foi possível zerar: ' + err.message, 'erro');
  }
}

async function desfazerBackup(id) {
  const b = relEstado.dados.backups.find((x) => x.id === id);
  if (!b) return;
  if (!confirm(`Devolver a comissão zerada de ${b.usuarioNome}?\n\n`
    + `${b.operacoes} operação(ões) · ${brl(b.total)}\n\n`
    + 'Cada operação volta ao valor exato de antes.')) return;
  try {
    const r = await api(`/relatorios/backups/${encodeURIComponent(id)}/desfazer`, { method: 'POST' });
    if (!r.ok) throw new Error(r.error || 'falha ao desfazer');
    relAviso(`${r.restauradas} operação(ões) restauradas`
      + (r.sumiram ? ` · ${r.sumiram} não existe(m) mais` : ''));
    await carregarRelatorios();
  } catch (err) {
    relAviso('não foi possível desfazer: ' + err.message, 'erro');
  }
}

async function apagarOperacao(id) {
  if (!confirm('Apagar esta operação?\n\nEla sai dos totais, mas fica registrada no log de alterações.')) return;
  try {
    const r = await api('/operations/' + encodeURIComponent(id), { method: 'DELETE' });
    if (!r.ok) throw new Error(r.error || 'falha ao apagar');
    relEstado.operacoes.delete(relEstado.expandido);
    relAviso('operação apagada');
    await carregarRelatorios();
    if (relEstado.expandido) alternarUsuario(relEstado.expandido);
  } catch (err) {
    relAviso('não foi possível apagar: ' + err.message, 'erro');
  }
}

/* ═══════════ Modais (operação e usuários) ═══════════ */

function abrirModal(titulo, corpoHtml, aoConfirmar, textoBotao = 'Salvar') {
  const fundo = document.createElement('div');
  fundo.className = 'rel-modal-fundo';
  fundo.innerHTML = `
    <div class="rel-modal card" role="dialog" aria-modal="true">
      <div class="card-head"><h3>${esc(titulo)}</h3>
        <button class="btn-ghost sm" data-fechar>✕</button></div>
      <div class="rel-modal-corpo">${corpoHtml}</div>
      <div class="rel-modal-pe">
        <button class="btn-ghost" data-fechar>Cancelar</button>
        <button class="btn" data-ok>${esc(textoBotao)}</button>
      </div>
    </div>`;
  const fechar = () => fundo.remove();
  fundo.querySelectorAll('[data-fechar]').forEach((b) => { b.onclick = fechar; });
  fundo.onclick = (ev) => { if (ev.target === fundo) fechar(); };
  fundo.querySelector('[data-ok]').onclick = async () => {
    try {
      const seguir = await aoConfirmar(fundo);
      if (seguir !== false) fechar();
    } catch (err) {
      relAviso(err.message, 'erro');
    }
  };
  document.body.appendChild(fundo);
  const primeiro = fundo.querySelector('input,select');
  if (primeiro) primeiro.focus();
  return fundo;
}

const CAMPOS_OP = [
  ['deposito', 'Depósito'], ['saque', 'Saque'], ['blogueira', 'Blogueira'],
  ['comissao', 'Comissão'], ['comissao_contas', 'Comissão contas'], ['lucro', 'Lucro'],
  ['deposito_contas', 'Depósito contas'], ['saque_contas', 'Saque contas'], ['salario_contas', 'Salário contas'],
];

/* Edição de uma operação que já existe. A CRIAÇÃO saiu da tela a pedido do
   dono: operação nova entra pela API (`POST /api/operations`), não à mão. */
function modalOperacao(id) {
  const op = [...relEstado.operacoes.values()].flat().find((o) => o.id === id);
  if (!op) return;
  const usuarios = relEstado.dados?.usuarios ?? [];
  const corpo = `
    <div class="rel-form-grid">
      <label>Usuário<select name="user_id">${usuarios.map((u) =>
        `<option value="${esc(u.id)}" ${op?.user_id === u.id ? 'selected' : ''}>${esc(u.nome)}</option>`).join('')}</select></label>
      <label>Data da operação<input type="date" name="data_operacao" value="${esc(op?.data_operacao || '')}" /></label>
      <label>Nome da conta<input name="nome_conta" value="${esc(op?.nome_conta || '')}" placeholder="opcional" /></label>
      ${CAMPOS_OP.map(([campo, rotulo]) =>
        `<label>${rotulo} (R$)<input type="number" step="0.01" name="${campo}" value="${Number(op[campo] || 0)}" /></label>`).join('')}
    </div>
    <p class="hint">Sem data, a operação entra no dia operacional de agora — que só vira às 05:00.</p>`;

  abrirModal('Editar operação', corpo, async (raiz) => {
    const dados = {};
    raiz.querySelectorAll('[name]').forEach((el) => {
      dados[el.name] = el.type === 'number' ? Number(el.value || 0) : el.value;
    });
    const r = await api('/operations/' + encodeURIComponent(id), { method: 'PATCH', body: JSON.stringify(dados) });
    if (!r.ok) throw new Error(r.error || 'falha ao salvar');
    relAviso('operação atualizada');
    relEstado.operacoes.clear();
    await carregarRelatorios();
    if (relEstado.expandido) alternarUsuario(relEstado.expandido);
  }, 'Salvar');
}

/* ═══════════ CSV ═══════════ */

async function baixarCsvRelatorio() {
  try {
    const res = await fetch('/api/relatorios/export.csv?' + relQs(), {
      headers: { Authorization: 'Bearer ' + TOKEN },
    });
    if (!res.ok) throw new Error('falha ao gerar o CSV');
    const blob = await res.blob();
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = (res.headers.get('content-disposition') || '').match(/filename="([^"]+)"/)?.[1]
      || 'relatorio-usuarios.csv';
    document.body.appendChild(a);
    a.click();
    a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  } catch (err) {
    relAviso(err.message, 'erro');
  }
}

/* ═══════════ Controles ═══════════ */

function relAplicarFiltros() {
  relEstado.de = $('rel-de').value || '';
  relEstado.ate = $('rel-ate').value || '';
  relEstado.usuario = $('rel-usuario').value || '';
  relEstado.expandido = null;
  relEstado.operacoes.clear();
  carregarRelatorios();
}

// Atalhos de período do card de comissão — mexem nos MESMOS filtros de cima,
// para não existir dois recortes disputando a mesma tela.
function relAtalho(qual) {
  const hoje = new Date();
  const iso = (d) => `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
  if (qual === 'hoje') { relEstado.de = iso(hoje); relEstado.ate = iso(hoje); }
  if (qual === '7') {
    const de = new Date(hoje); de.setDate(de.getDate() - 6);
    relEstado.de = iso(de); relEstado.ate = iso(hoje);
  }
  if (qual === 'mes') {
    relEstado.de = iso(new Date(hoje.getFullYear(), hoje.getMonth(), 1));
    relEstado.ate = iso(hoje);
  }
  document.querySelectorAll('#rel-atalhos button').forEach((b) =>
    b.classList.toggle('active', b.dataset.atalho === qual));
  relEstado.expandido = null;
  carregarRelatorios();
}

if ($('tab-relatorios')) {
  $('rel-de').onchange = relAplicarFiltros;
  $('rel-ate').onchange = relAplicarFiltros;
  $('rel-usuario').onchange = relAplicarFiltros;
  $('rel-limpar').onclick = () => {
    // Limpar os CAMPOS, não só o estado: relAplicarFiltros() lê os inputs, e
    // zerar apenas as variáveis deixaria o filtro voltar no próximo render.
    $('rel-de').value = '';
    $('rel-ate').value = '';
    $('rel-usuario').value = '';
    document.querySelectorAll('#rel-atalhos button').forEach((b) => b.classList.remove('active'));
    relAplicarFiltros();
  };
  document.querySelectorAll('#rel-atalhos button').forEach((b) => {
    b.onclick = () => relAtalho(b.dataset.atalho);
  });
  $('rel-zerar-todas').onclick = zerarTodas;
  $('rel-cobrar-todas').onclick = cobrarTodas;
  $('rel-semana-ant').onclick = () => irParaSemana(relEstado.dadosSemana?.anterior);
  $('rel-semana-prox').onclick = () => irParaSemana(relEstado.dadosSemana?.proxima);
  $('rel-semana-rotulo').onclick = () => irParaSemana('');   // volta para a semana corrente
  $('rel-operadores-ajuste').onclick = modalOperadoresAjuste;
  $('rel-ver-historico').onclick = () => mostrarHistorico(!historicoAberto);
  $('rel-fechar-historico').onclick = () => mostrarHistorico(false);
  $('rel-pct-padrao').onchange = (ev) => salvarPct(null, ev.target.value);
  $('rel-csv').onclick = baixarCsvRelatorio;
  $('rel-meta-salvar').onclick = async () => {
    try {
      const r = await api('/relatorios/metas', {
        method: 'POST',
        body: JSON.stringify({
          metaDiariaBlogueira: Number($('rel-meta-dia').value || 0),
          metaSemanalBlogueira: Number($('rel-meta-semana').value || 0),
        }),
      });
      if (!r.ok) throw new Error(r.error || 'falha ao salvar');
      relAviso('metas salvas');
      await carregarRelatorios();
    } catch (err) {
      relAviso('não foi possível salvar as metas: ' + err.message, 'erro');
    }
  };
}
