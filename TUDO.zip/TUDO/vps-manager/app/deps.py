"""Dependencias FastAPI: sessao do usuario e utilitarios de request."""
from __future__ import annotations

from fastapi import Depends, HTTPException, Request, status

from .security import COOKIE_NAME, decode_token


def client_ip(request: Request) -> str:
    fwd = request.headers.get("x-forwarded-for") or request.headers.get("x-real-ip")
    if fwd:
        return fwd.split(",")[0].strip()
    return request.client.host if request.client else "?"


def _token_from(request: Request) -> str | None:
    tok = request.cookies.get(COOKIE_NAME)
    if tok:
        return tok
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return None


async def current_user(request: Request) -> dict:
    tok = _token_from(request)
    claims = decode_token(tok) if tok else None
    if not claims:
        raise HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail="sessao invalida ou expirada")
    return {"username": claims["sub"], "role": claims.get("role", "admin")}


async def admin_user(user: dict = Depends(current_user)) -> dict:
    if user.get("role") not in ("admin", "superadmin"):
        raise HTTPException(status_code=403, detail="acesso negado")
    return user


def ws_user(cookies: dict, query_token: str | None = None) -> dict | None:
    tok = cookies.get(COOKIE_NAME) or query_token
    claims = decode_token(tok) if tok else None
    if not claims:
        return None
    return {"username": claims["sub"], "role": claims.get("role", "admin")}
