CREATE TABLE IF NOT EXISTS public.user_passwords (
  user_id UUID NOT NULL PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  password TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  updated_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

GRANT ALL ON public.user_passwords TO service_role;

ALTER TABLE public.user_passwords ENABLE ROW LEVEL SECURITY;

CREATE POLICY "No client access to user_passwords"
ON public.user_passwords
AS RESTRICTIVE
FOR ALL
TO authenticated, anon
USING (false)
WITH CHECK (false);

CREATE TRIGGER user_passwords_set_updated_at
BEFORE UPDATE ON public.user_passwords
FOR EACH ROW EXECUTE FUNCTION public.set_updated_at();