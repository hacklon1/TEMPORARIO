import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  ArrowDownToLine,
  ArrowUpFromLine,
  TrendingUp,
  Activity,
  Heart,
  Calculator as CalculatorIcon,
  X,
  Pencil,
  Save,
  Megaphone,
  History,
} from "lucide-react";

import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import {
  BarChart,
  Bar,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
  CartesianGrid,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { StatCard } from "@/components/StatCard";
import { SideCalculator } from "@/components/SideCalculator";
import { AccountsCalculator } from "@/components/AccountsCalculator";
import { DepositSplitter } from "@/components/DepositSplitter";
import { ChangePasswordButton } from "@/components/ChangePasswordButton";
import { ConexaoColetor } from "@/components/ConexaoColetor";
import { formatBRL, formatDate } from "@/lib/format";
import { cn } from "@/lib/utils";

type Op = {
  id: string;
  user_id: string;
  deposito: number;
  saque: number;
  blogueira: number;
  lucro: number;
  lucro_contas: number;
  deposito_contas: number;
  saque_contas: number;
  salario_contas: number;
  data_operacao: string | null;
  created_at: string;
};

type ProfileMin = { id: string; nome: string; email: string; operator_type: "bi" | "montante" | "contas" | null };

export default function Dashboard() {
  const { isAdmin, user, operatorType } = useAuth();
  const qc = useQueryClient();
  // Categoria do Operador: "montante" e "contas" travam o dashboard no
  // respectivo escopo. "bi" mantém tudo livre, como sempre foi.
  const scopeMontante = operatorType !== "contas";
  const scopeContas = operatorType !== "montante";
  const lockedMode = operatorType === "bi" ? null : operatorType;

  const [calcModePref, setCalcModePref] = useState<"montante" | "contas">(
    () => ((localStorage.getItem("dash:calcMode") as "montante" | "contas") ?? "montante"),
  );
  const calcMode = lockedMode ?? calcModePref;
  const setCalcMode = setCalcModePref;
  useEffect(() => { localStorage.setItem("dash:calcMode", calcModePref); }, [calcModePref]);
  const [showCalc, setShowCalc] = useState<boolean>(() => {
    if (typeof window === "undefined") return true;
    return localStorage.getItem("db:showCalc") !== "0";
  });

  const toggleCalc = (next: boolean) => {
    setShowCalc(next);
    try {
      localStorage.setItem("db:showCalc", next ? "1" : "0");
    } catch {}
  };

  const [selectedUser, setSelectedUser] = useState<string>("all");
  const [profitModePref, setProfitMode] = useState<"montante" | "contas" | "ambos">(() => {
    if (typeof window === "undefined") return "ambos";
    return (localStorage.getItem("db:profitMode") as any) || "ambos";
  });
  // Operador de Montante/Contas não escolhe: o modo é o da sua categoria.
  const profitMode = lockedMode ?? profitModePref;
  useEffect(() => {
    try { localStorage.setItem("db:profitMode", profitModePref); } catch {}
  }, [profitModePref]);

  const [lucroKind, setLucroKind] = useState<"liquido" | "bruto">(() => {
    if (typeof window === "undefined") return "liquido";
    return (localStorage.getItem("db:lucroKind") as any) || "liquido";
  });
  useEffect(() => {
    try { localStorage.setItem("db:lucroKind", lucroKind); } catch {}
  }, [lucroKind]);

  const { data: aviso } = useQuery({
    queryKey: ["aviso-dashboard"],
    queryFn: async () => {
      const { data } = await supabase.from("app_settings").select("aviso_dashboard").eq("id", 1).maybeSingle();
      return (data?.aviso_dashboard ?? "") as string;
    },
  });
  const [avisoDismissed, setAvisoDismissed] = useState<boolean>(() => {
    if (typeof window === "undefined") return false;
    return localStorage.getItem("db:avisoDismissed") === (aviso || "");
  });
  useEffect(() => {
    if (typeof window !== "undefined") {
      setAvisoDismissed(localStorage.getItem("db:avisoDismissed") === (aviso || ""));
    }
  }, [aviso]);

  const { data: ops = [], isLoading: loading } = useQuery({
    queryKey: ["ops", "dashboard", isAdmin ? "all" : user?.id],
    queryFn: async () => {
      const pageSize = 1000;
      const rows: any[] = [];
      let from = 0;

      while (true) {
        let q = supabase
          .from("operations")
          .select("id, user_id, deposito, saque, blogueira, lucro, lucro_contas, deposito_contas, saque_contas, salario_contas, data_operacao, created_at")
          .order("created_at", { ascending: true })
          .range(from, from + pageSize - 1);

        if (!isAdmin && user?.id) q = q.eq("user_id", user.id);

        const { data, error } = await q;
        if (error) throw error;

        const batch = data ?? [];
        rows.push(...batch);

        if (batch.length < pageSize) break;
        from += pageSize;
      }

      return rows.map((o: any) => ({
        ...o,
        deposito: Number(o.deposito),
        saque: Number(o.saque),
        blogueira: Number(o.blogueira),
        lucro: Number(o.lucro),
        lucro_contas: Number(o.lucro_contas ?? 0),
        deposito_contas: Number(o.deposito_contas ?? 0),
        saque_contas: Number(o.saque_contas ?? 0),
        salario_contas: Number(o.salario_contas ?? 0),
      })) as Op[];
    },
  });

  const filteredOps = useMemo(
    () => (isAdmin && selectedUser !== "all" ? ops.filter((o) => o.user_id === selectedUser) : ops),
    [ops, isAdmin, selectedUser],
  );

  const { data: ranking = [] } = useQuery({
    queryKey: ["ranking"],
    queryFn: async () => {
      const { data } = await supabase.rpc("get_user_ranking");
      return (data ?? []).map((r: any) => ({
        user_id: r.user_id as string,
        nome: r.nome as string,
        lucro: Number(r.lucro),
        deposito: Number(r.deposito),
        saque: Number(r.saque),
        pedidos: Number(r.pedidos),
      }));
    },
  });

  const { data: profiles = [] } = useQuery({
    queryKey: ["dashboard-profiles", isAdmin],
    enabled: isAdmin,
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("id, nome, email, operator_type")
        .order("nome", { ascending: true });
      return (data ?? []) as ProfileMin[];
    },
  });

  const { data: myProfile } = useQuery({
    queryKey: ["my-profile", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("daily_goal, commission_percent")
        .eq("id", user!.id)
        .maybeSingle();
      return data as { daily_goal: number | null; commission_percent: number | null } | null;
    },
  });

  const dailyGoal = Number(myProfile?.daily_goal ?? 0);

  // Inline edit da meta diária
  const [editingGoal, setEditingGoal] = useState(false);
  const [goalInput, setGoalInput] = useState("");
  useEffect(() => { setGoalInput(String(dailyGoal || "")); }, [dailyGoal]);
  const saveGoal = async () => {
    if (!user?.id) return;
    const v = Number(goalInput) || 0;
    const { error } = await supabase.from("profiles").update({ daily_goal: v }).eq("id", user.id);
    if (error) return toast.error("Erro ao salvar meta");
    toast.success("Meta atualizada");
    setEditingGoal(false);
    qc.invalidateQueries({ queryKey: ["my-profile"] });
  };

  // Aviso editor (admin)
  const [avisoDraft, setAvisoDraft] = useState("");
  const [avisoEditing, setAvisoEditing] = useState(false);
  useEffect(() => { setAvisoDraft(aviso ?? ""); }, [aviso]);
  const saveAviso = async () => {
    const { error } = await supabase.from("app_settings").update({ aviso_dashboard: avisoDraft }).eq("id", 1);
    if (error) return toast.error("Erro ao salvar aviso", { description: error.message });
    toast.success("Aviso publicado");
    setAvisoEditing(false);
    qc.invalidateQueries({ queryKey: ["aviso-dashboard"] });
  };

  useEffect(() => {
    const channel = supabase
      .channel("ops-dash")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "operations" },
        () => {
          qc.invalidateQueries({ queryKey: ["ops"] });
          qc.invalidateQueries({ queryKey: ["ranking"] });
          // Traz operadores recém-criados e mudanças de categoria, que o
          // cartão diário usa para decidir o que exibir.
          qc.invalidateQueries({ queryKey: ["dashboard-profiles"] });
        },
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  const effLucro = (o: { lucro: number; lucro_contas: number; saque: number; deposito: number; saque_contas: number; deposito_contas: number }) => {
    const m = lucroKind === "bruto" ? (o.saque - o.deposito) : o.lucro;
    const c = lucroKind === "bruto" ? (o.saque_contas - o.deposito_contas) : o.lucro_contas;
    return profitMode === "montante" ? m
      : profitMode === "contas" ? c
      : m + c;
  };

  const totals = useMemo(() => {
    const t = filteredOps.reduce(
      (acc, o) => {
        // Depositado/Sacado/Blogueiras somam o que a categoria enxerga.
        // Para o Operador BI isso continua sendo Montante + Contas.
        acc.dep += (scopeMontante ? o.deposito : 0) + (scopeContas ? o.deposito_contas : 0);
        acc.saq += (scopeMontante ? o.saque : 0) + (scopeContas ? o.saque_contas : 0);
        acc.blog += (scopeMontante ? o.blogueira : 0) + (scopeContas ? o.salario_contas : 0);
        // Lucro continua respeitando o seletor (Montantes / Contas / Ambos)
        acc.lucro += effLucro(o);
        acc.lucroMontante += o.lucro;
        acc.lucroContas += o.lucro_contas;
        return acc;
      },
      { dep: 0, saq: 0, blog: 0, lucro: 0, lucroMontante: 0, lucroContas: 0 },
    );
    return { ...t, count: filteredOps.length };
  }, [filteredOps, profitMode, lucroKind, scopeMontante, scopeContas]);

  // === Lucro do Dia (Hoje) — dia operacional inicia às 05:00 (fuso BRT, independente do navegador) ===
  // BRT = UTC-3 sem horário de verão. Calculamos a janela em UTC para não depender do fuso do browser.
  const businessDayRange = () => {
    const BRT_OFFSET_MS = 3 * 60 * 60 * 1000; // BRT = UTC-3
    const nowUtcMs = Date.now();
    const brtMs = nowUtcMs - BRT_OFFSET_MS; // "agora" como se estivesse em UTC equivalente ao BRT
    const brt = new Date(brtMs);
    // Início do dia operacional em BRT às 05:00
    let y = brt.getUTCFullYear();
    let m = brt.getUTCMonth();
    let d = brt.getUTCDate();
    if (brt.getUTCHours() < 5) {
      const prev = new Date(Date.UTC(y, m, d - 1));
      y = prev.getUTCFullYear(); m = prev.getUTCMonth(); d = prev.getUTCDate();
    }
    // 05:00 BRT = 08:00 UTC
    const start = new Date(Date.UTC(y, m, d, 5 + 3, 0, 0, 0));
    const end = new Date(start.getTime() + 24 * 60 * 60 * 1000);
    return { start, end };
  };

  const getOperationDate = (o: Pick<Op, "data_operacao" | "created_at">) => o.data_operacao || o.created_at;

  const getOperationTime = (o: Pick<Op, "data_operacao" | "created_at">) =>
    new Date(getOperationDate(o)).getTime();

  const todayOpsSource = isAdmin ? ops : filteredOps;

  const todayOps = useMemo(() => {
    const { start, end } = businessDayRange();
    return todayOpsSource
      .filter((o) => {
        const t = getOperationTime(o);
        return t >= start.getTime() && t < end.getTime();
      })
      .sort((a, b) => getOperationTime(b) - getOperationTime(a));
  }, [todayOpsSource]);

  const todayTotal = useMemo(
    () => todayOps.reduce((s, o) => s + effLucro(o), 0),
    [todayOps, profitMode, lucroKind],
  );

  const todayByUser = useMemo(() => {
    const map = new Map<string, { user_id: string; nome: string; categoria: "bi" | "montante" | "contas"; lucro: number; dep: number; sal: number; ops: number; last: string | null }>();

    // Cada cartão mostra o que a categoria daquele operador comporta.
    const categoriaDe = (uid: string) =>
      (profiles.find((p) => p.id === uid)?.operator_type ?? "bi") as "bi" | "montante" | "contas";

    const baseUsers = profiles.length > 0
      ? profiles.map((p) => ({ user_id: p.id, nome: p.nome }))
      : ranking.map((r) => ({ user_id: r.user_id, nome: r.nome }));

    for (const p of baseUsers) {
      map.set(p.user_id, { user_id: p.user_id, nome: p.nome, categoria: categoriaDe(p.user_id), lucro: 0, dep: 0, sal: 0, ops: 0, last: null });
    }

    for (const o of todayOps) {
      const nome = ranking.find((r) => r.user_id === o.user_id)?.nome ?? "—";
      const cur = map.get(o.user_id) ?? { user_id: o.user_id, nome, categoria: categoriaDe(o.user_id), lucro: 0, dep: 0, sal: 0, ops: 0, last: null };
      cur.nome = cur.nome === "—" ? nome : cur.nome;
      cur.lucro += effLucro(o);
      // Depositado conta só Montante — deposito_contas fica de fora de propósito,
      // independentemente do modo de lucro selecionado.
      cur.dep += o.deposito;
      // Contas conta só o salário — depósito e saque de contas ficam de fora.
      cur.sal += o.salario_contas;
      cur.ops += 1;
      const opDate = getOperationDate(o);
      if (!cur.last || new Date(opDate) > new Date(cur.last)) cur.last = opDate;
      map.set(o.user_id, cur);
    }
    return Array.from(map.values())
      .filter((u) => u.ops > 0)
      .sort((a, b) => (b.lucro - a.lucro) || a.nome.localeCompare(b.nome, "pt-BR"));
  }, [todayOps, ranking, profiles, profitMode, lucroKind]);

  // Lucro TOTAL por usuário (todo o período) — visível apenas para admin
  const allByUser = useMemo(() => {
    const map = new Map<string, { user_id: string; nome: string; lucro: number; ops: number; dep: number; saq: number }>();
    for (const o of ops) {
      const nome = ranking.find((r) => r.user_id === o.user_id)?.nome ?? "—";
      const cur = map.get(o.user_id) ?? { user_id: o.user_id, nome, lucro: 0, ops: 0, dep: 0, saq: 0 };
      cur.lucro += effLucro(o);
      cur.dep += o.deposito + o.deposito_contas;
      cur.saq += o.saque + o.saque_contas;
      cur.ops += 1;
      map.set(o.user_id, cur);
    }
    return Array.from(map.values()).sort((a, b) => b.lucro - a.lucro);
  }, [ops, ranking, profitMode, lucroKind]);

  // Lucro do PRÓPRIO usuário hoje (independente do filtro de admin)
  const myTodayProfit = useMemo(() => {
    if (!user?.id) return 0;
    const { start, end } = businessDayRange();
    return ops
      .filter((o) => o.user_id === user.id)
      .filter((o) => {
        const t = getOperationTime(o);
        return t >= start.getTime() && t < end.getTime();
      })
      .reduce((s, o) => s + effLucro(o), 0);
  }, [ops, user?.id, profitMode, lucroKind]);

  const formatTime = (iso: string) =>
    new Date(iso).toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

  const [dailyRange, setDailyRange] = useState<7 | 14 | 30>(14);
  const [dailyMode, setDailyMode] = useState<"grouped" | "stacked">("grouped");

  // Per-user daily profit chart data
  const { dailyData, userKeys, dailyTotal, bestDay } = useMemo(() => {
    const source = filteredOps;
    const profitByUser = new Map<string, number>();
    for (const o of source) profitByUser.set(o.user_id, (profitByUser.get(o.user_id) ?? 0) + effLucro(o));
    const topUsers = Array.from(profitByUser.entries())
      .sort((a, b) => Math.abs(b[1]) - Math.abs(a[1]))
      .slice(0, 5)
      .map(([uid]) => uid);
    const nameOf = (uid: string) => ranking.find((r) => r.user_id === uid)?.nome ?? "—";
    const keys = topUsers.map((uid) => ({ uid, name: nameOf(uid) }));

    const dayMap = new Map<string, { ts: number; date: string; total: number } & Record<string, number | string>>();
    for (const o of source) {
      if (!topUsers.includes(o.user_id)) continue;
      const d = new Date(new Date(o.created_at).getTime() - 5 * 3600 * 1000);
      d.setHours(0, 0, 0, 0);
      const ts = d.getTime();
      const label = d.toLocaleDateString("pt-BR", { day: "2-digit", month: "2-digit" });
      const cur = dayMap.get(label) ?? { ts, date: label, total: 0 };
      const k = nameOf(o.user_id);
      cur[k] = ((cur[k] as number) ?? 0) + effLucro(o);
      cur.total += effLucro(o);
      dayMap.set(label, cur);
    }
    const sorted = Array.from(dayMap.values()).sort((a, b) => a.ts - b.ts).slice(-dailyRange);
    const total = sorted.reduce((s, d) => s + d.total, 0);
    const best = sorted.reduce<{ date: string; total: number } | null>(
      (acc, d) => (!acc || d.total > acc.total ? { date: d.date, total: d.total } : acc),
      null,
    );
    return { dailyData: sorted, userKeys: keys, dailyTotal: total, bestDay: best };
  }, [filteredOps, ranking, dailyRange, lucroKind, profitMode]);

  const barColors = [
    "#1e2a4a", // navy
    "#f5a524", // amber
    "#3b82f6", // blue
    "#ef4444", // red
    "#94a3b8", // slate
  ];

  return (
    <div
      className={
        showCalc
          ? "grid gap-6 lg:grid-cols-[1fr_320px]"
          : "grid gap-6 grid-cols-1"
      }
    >
      <div className="space-y-6 animate-fade-in">
        {isAdmin && (
          <div className="glass-strong space-y-2 rounded-2xl border border-accent/30 bg-accent/5 p-4">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <Megaphone className="h-4 w-4 text-accent" />
                <h3 className="text-xs font-bold uppercase tracking-wider text-accent">Aviso da Dashboard (ADM)</h3>
              </div>
              {!avisoEditing ? (
                <Button size="sm" variant="ghost" onClick={() => setAvisoEditing(true)}>
                  <Pencil className="h-3 w-3" /> Editar
                </Button>
              ) : (
                <div className="flex gap-1">
                  <Button size="sm" variant="ghost" onClick={() => { setAvisoDraft(aviso ?? ""); setAvisoEditing(false); }}>
                    <X className="h-3 w-3" /> Cancelar
                  </Button>
                  <Button size="sm" onClick={saveAviso} className="bg-gradient-primary">
                    <Save className="h-3 w-3" /> Publicar
                  </Button>
                </div>
              )}
            </div>
            {avisoEditing ? (
              <Textarea value={avisoDraft} onChange={(e) => setAvisoDraft(e.target.value)} rows={3} placeholder="Escreva o aviso que será exibido a todos os usuários..." />
            ) : (
              <p className="whitespace-pre-wrap text-sm text-muted-foreground">
                {aviso?.trim() ? aviso : <span className="italic">Nenhum aviso publicado.</span>}
              </p>
            )}
          </div>
        )}
        {aviso && aviso.trim() && !avisoDismissed && (
          <div className="glass-strong flex items-start gap-3 rounded-2xl border border-accent/40 bg-accent/10 p-4">
            <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-lg bg-accent/20 text-accent">!</div>
            <div className="flex-1">
              <p className="text-xs font-bold uppercase tracking-wider text-accent">Aviso</p>
              <p className="mt-1 whitespace-pre-wrap text-sm text-foreground">{aviso}</p>
            </div>
            <Button
              size="icon"
              variant="ghost"
              onClick={() => {
                try { localStorage.setItem("db:avisoDismissed", aviso); } catch {}
                setAvisoDismissed(true);
              }}
              className="h-7 w-7"
              aria-label="Dispensar aviso"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
        )}
        <div className="flex items-start justify-between gap-4">
          <div>
            <h1 className="text-2xl font-bold md:text-3xl">Dashboard</h1>
            <p className="text-sm text-muted-foreground">
              {isAdmin
                ? "Visão geral de todas as operações da plataforma."
                : "Sua visão financeira em tempo real."}
            </p>
          </div>
          <div className="flex shrink-0 flex-wrap items-center gap-2">
            <select
              value={lucroKind}
              onChange={(e) => setLucroKind(e.target.value as any)}
              className="h-9 rounded-md border border-border bg-background px-2 text-sm"
              title="Tipo de lucro"
            >
              <option value="liquido">Líquido</option>
              <option value="bruto">Bruto</option>
            </select>
            {lockedMode ? (
              <span className="flex h-9 items-center rounded-md border border-border bg-muted/40 px-3 text-sm font-medium">
                {lockedMode === "montante" ? "Operador de Montante" : "Operador de Contas"}
              </span>
            ) : (
              <select
                value={profitMode}
                onChange={(e) => setProfitMode(e.target.value as any)}
                className="h-9 rounded-md border border-border bg-background px-2 text-sm"
                title="Modo de lucro"
              >
                <option value="montante">Lucro: Montantes</option>
                <option value="contas">Lucro: Contas</option>
                <option value="ambos">Lucro: Ambos</option>
              </select>
            )}
            {isAdmin && ranking.length > 0 && (
              <select
                value={selectedUser}
                onChange={(e) => setSelectedUser(e.target.value)}
                className="h-9 rounded-md border border-border bg-background px-2 text-sm"
              >
                <option value="all">Todos os usuários</option>
                {ranking.map((r) => (
                  <option key={r.user_id} value={r.user_id}>
                    {r.nome}
                  </option>
                ))}
              </select>
            )}
            {!showCalc && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => toggleCalc(true)}
              >
                <CalculatorIcon className="h-4 w-4" />
                Calculadora
              </Button>
            )}
          </div>
        </div>
        {profitMode === "ambos" && (
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="glass-strong rounded-2xl p-4">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Lucro Montantes</p>
              <p className={`number-tabular text-2xl font-bold ${totals.lucroMontante >= 0 ? "text-success" : "text-destructive"}`}>{formatBRL(totals.lucroMontante)}</p>
            </div>
            <div className="glass-strong rounded-2xl p-4">
              <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Lucro Contas</p>
              <p className={`number-tabular text-2xl font-bold ${totals.lucroContas >= 0 ? "text-success" : "text-destructive"}`}>{formatBRL(totals.lucroContas)}</p>
            </div>
          </div>
        )}


        <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-3">
          {isAdmin && (
            <StatCard
              title="Lucro do Dia (Todos)"
              value={formatBRL(todayTotal)}
              icon={TrendingUp}
              tone={todayTotal >= 0 ? "success" : "destructive"}
              hint="Soma do lucro de todos os usuários hoje"
            />
          )}
          <StatCard
            title="Total Depositado"
            value={formatBRL(totals.dep)}
            icon={ArrowDownToLine}
            tone="warning"
          />
          <StatCard
            title="Total Sacado"
            value={formatBRL(totals.saq)}
            icon={ArrowUpFromLine}
            tone="primary"
          />
          <StatCard
            title="Ganho Blogueiras"
            value={formatBRL(totals.blog)}
            icon={Heart}
            tone="destructive"
          />
          <StatCard
            title="Lucro Líquido Total"
            value={formatBRL(totals.lucro)}
            icon={TrendingUp}
            tone={totals.lucro >= 0 ? "success" : "destructive"}
            hint="(Saque − Depósito) + Blogueira"
          />
          <StatCard
            title="Operações"
            value={String(totals.count)}
            icon={Activity}
            tone="muted"
          />
        </div>





        {/* === LUCRO DO DIA (Tempo Real) === */}
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="glass-strong relative overflow-hidden rounded-2xl p-5 lg:col-span-1">
            <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-primary/10 blur-2xl" />
            <div className="relative">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs font-medium uppercase tracking-wider text-muted-foreground">
                    Lucro do Dia
                  </p>
                  {editingGoal ? (
                    <div className="mt-1 flex items-center gap-1">
                      <Input
                        type="number" step="0.01" value={goalInput}
                        onChange={(e) => setGoalInput(e.target.value)}
                        className="h-7 w-28 text-xs"
                        autoFocus
                      />
                      <button onClick={saveGoal} className="rounded p-1 text-success hover:bg-success/10" title="Salvar">
                        <Save className="h-3 w-3" />
                      </button>
                      <button onClick={() => setEditingGoal(false)} className="rounded p-1 text-muted-foreground hover:bg-muted" title="Cancelar">
                        <X className="h-3 w-3" />
                      </button>
                    </div>
                  ) : (
                    <p className="mt-0.5 flex items-center gap-1 text-[11px] text-muted-foreground">
                      Meta: <span className="font-semibold text-foreground">{formatBRL(dailyGoal)}</span>
                      <button onClick={() => setEditingGoal(true)} className="rounded p-0.5 hover:bg-muted" title="Editar meta">
                        <Pencil className="h-3 w-3" />
                      </button>
                    </p>
                  )}
                </div>
                <span className="relative flex h-3 w-3">
                  <span className="absolute inline-flex h-full w-full animate-ping rounded-full bg-success opacity-60" />
                  <span className="relative inline-flex h-3 w-3 rounded-full bg-success" />
                </span>
              </div>

              {(() => {
                const lucroHoje = Math.max(0, myTodayProfit);
                const meta = dailyGoal > 0 ? dailyGoal : 0;
                const pct = meta > 0 ? Math.min(100, (lucroHoje / meta) * 100) : 0;
                const restante = Math.max(0, meta - lucroHoje);
                const data = meta > 0
                  ? [
                      { name: "Lucro", value: Math.min(lucroHoje, meta) },
                      { name: "Faltam", value: restante },
                    ]
                  : [{ name: "Lucro", value: lucroHoje || 1 }];
                return (
                  <div className="mt-3">
                    <div className="relative mx-auto h-48 w-48">
                      <ResponsiveContainer width="100%" height="100%">
                        <PieChart>
                          <Pie
                            data={data}
                            innerRadius={62}
                            outerRadius={88}
                            startAngle={90}
                            endAngle={-270}
                            paddingAngle={meta > 0 && restante > 0 && lucroHoje > 0 ? 2 : 0}
                            dataKey="value"
                            stroke="none"
                          >
                            <Cell fill={pct >= 100 ? "#e0b34a" : "hsl(var(--primary))"} />
                            <Cell fill="hsl(var(--muted) / 0.4)" />
                          </Pie>
                        </PieChart>
                      </ResponsiveContainer>
                      <div className="pointer-events-none absolute inset-0 flex flex-col items-center justify-center">
                        <span className={`number-tabular text-2xl font-bold ${myTodayProfit >= 0 ? "text-success" : "text-destructive"}`}>
                          {formatBRL(myTodayProfit)}
                        </span>
                        {meta > 0 && (
                          <span className="text-[11px] text-muted-foreground">
                            {pct.toFixed(0)}% da meta
                          </span>
                        )}
                      </div>
                    </div>
                    {meta > 0 ? (
                      <p className="mt-3 text-center text-xs text-muted-foreground">
                        {restante > 0
                          ? <>Faltam <span className="font-semibold text-foreground">{formatBRL(restante)}</span> para bater a meta</>
                          : <span className="font-semibold text-success">🎉 Meta diária atingida!</span>}
                      </p>
                    ) : (
                      <p className="mt-3 text-center text-[11px] text-muted-foreground">
                        Defina sua meta diária com o administrador
                      </p>
                    )}
                  </div>
                );
              })()}

              {isAdmin && selectedUser === "all" && todayByUser.length > 0 && (
                <div className="mt-4 space-y-1.5 border-t border-border/40 pt-3">
                  <div className="flex items-center justify-between">
                    <div className="text-[10px] font-semibold uppercase tracking-wide text-muted-foreground">
                      Total sistema (hoje)
                    </div>
                    <div className={`number-tabular text-xs font-bold ${todayTotal >= 0 ? "text-success" : "text-destructive"}`}>
                      {formatBRL(todayTotal)}
                    </div>
                  </div>
                  {todayByUser.slice(0, 5).map((u) => (
                    <div key={u.user_id} className="flex items-center justify-between rounded-lg border border-border/40 bg-background/40 px-2.5 py-1.5">
                      <div className="min-w-0">
                        <div className="truncate text-xs font-semibold">{u.nome}</div>
                        <div className="text-[10px] text-muted-foreground">
                          {u.ops > 0 && u.last ? `${u.ops} op • últ. ${formatTime(u.last)}` : "Sem registro hoje"}
                        </div>
                      </div>
                      <div className="text-right">
                        <div className={`number-tabular text-xs font-bold ${u.lucro >= 0 ? "text-success" : "text-destructive"}`}>
                          {formatBRL(u.lucro)}
                        </div>
                        <div className="number-tabular text-[10px] text-muted-foreground">
                          {u.categoria === "montante"
                            ? `dep ${formatBRL(u.dep)}`
                            : u.categoria === "contas"
                              ? `contas ${formatBRL(u.sal)}`
                              : `dep ${formatBRL(u.dep)} · contas ${formatBRL(u.sal)}`}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          </div>

          <div className="glass-strong rounded-2xl p-5 lg:col-span-2">
            <div className="mb-3 flex items-center justify-between">
              <div>
                <h2 className="text-lg font-semibold">Histórico de ganhos — Hoje</h2>
                <p className="text-xs text-muted-foreground">
                  {isAdmin
                    ? "Todas as transações do dia, em tempo real."
                    : "Suas transações do dia, atualizadas automaticamente."}
                </p>
              </div>
            </div>
            <div className="max-h-72 overflow-auto rounded-xl border border-border/40">
              <table className="w-full text-sm">
                <thead className="sticky top-0 bg-background/80 backdrop-blur">
                  <tr className="text-left text-[11px] uppercase tracking-wide text-muted-foreground">
                    <th className="px-3 py-2 font-medium">Hora</th>
                    {isAdmin && <th className="px-3 py-2 font-medium">Usuário</th>}
                    <th className="px-3 py-2 text-right font-medium">Depósito</th>
                    <th className="px-3 py-2 text-right font-medium">Saque</th>
                    <th className="px-3 py-2 text-right font-medium">Lucro</th>
                  </tr>
                </thead>
                <tbody>
                  {todayOps.length === 0 ? (
                    <tr>
                      <td colSpan={isAdmin ? 5 : 4} className="px-3 py-8 text-center text-muted-foreground">
                        Nenhuma transação registrada hoje ainda.
                      </td>
                    </tr>
                  ) : (
                    todayOps.map((o) => {
                      const nome = ranking.find((r) => r.user_id === o.user_id)?.nome ?? "—";
                      const positive = o.lucro >= 0;
                      return (
                        <tr key={o.id} className="border-t border-border/40 hover:bg-muted/30">
                          <td className="px-3 py-2 text-xs text-muted-foreground">{formatTime(getOperationDate(o))}</td>
                          {isAdmin && <td className="px-3 py-2 text-xs">{nome}</td>}
                          <td className="number-tabular px-3 py-2 text-right text-xs text-warning">{formatBRL(o.deposito)}</td>
                          <td className="number-tabular px-3 py-2 text-right text-xs text-primary">{formatBRL(o.saque)}</td>
                          <td className={`number-tabular px-3 py-2 text-right text-xs font-bold ${positive ? "text-success" : "text-destructive"}`}>
                            {formatBRL(o.lucro)}
                          </td>
                        </tr>
                      );
                    })
                  )}
                </tbody>
              </table>
            </div>
          </div>
        </div>




        <div className="grid gap-6 lg:grid-cols-2">
          <div className="glass-strong rounded-2xl p-5">
            <div className="mb-4 flex items-end justify-between">
              <div>
                <h2 className="text-lg font-semibold">Lucro diário por usuário</h2>
                <p className="text-xs text-muted-foreground">
                  Lucro líquido de hoje · atualização em tempo real
                </p>
              </div>
              <span className="text-[11px] text-muted-foreground">{todayByUser.length} usuário(s)</span>
            </div>
            {todayByUser.length === 0 ? (
              <div className="flex h-60 items-center justify-center text-sm text-muted-foreground">
                Nenhum usuário registrou operações hoje ainda.
              </div>
            ) : (
              <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3">
                {todayByUser.map((u) => {
                  const positive = u.lucro >= 0;
                  return (
                    <div
                      key={u.user_id}
                      className="relative overflow-hidden rounded-2xl border border-border/40 bg-background/40 p-4 transition hover:-translate-y-0.5 hover:border-primary/40 hover:shadow-elegant"
                    >
                      <div className={`pointer-events-none absolute -right-10 -top-10 h-32 w-32 rounded-full blur-2xl ${positive ? "bg-success/10" : "bg-destructive/10"}`} />
                      <div className="relative">
                        <div className="flex items-center gap-2">
                          <div className={`flex h-7 w-7 items-center justify-center rounded-lg ring-1 ${positive ? "bg-success/10 text-success ring-success/30" : "bg-destructive/10 text-destructive ring-destructive/30"}`}>
                            <TrendingUp className="h-4 w-4" />
                          </div>
                          <p className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
                            Lucro do dia
                          </p>
                        </div>
                        <p className="mt-2 truncate text-sm font-semibold">{u.nome}</p>
                        <p className={`number-tabular mt-0.5 text-2xl font-bold ${positive ? "text-success" : "text-destructive"}`}>
                          {formatBRL(u.lucro)}
                        </p>
                        {/* Quanto o operador movimentou hoje — só para Admin e DONO.
                            Operador de Montante mostra só Montante, o de Contas só
                            Contas, e o BI mostra os dois lado a lado. */}
                        {isAdmin && (
                          <div
                            className={cn(
                              "mt-2 grid gap-2 border-t border-border/40 pt-2",
                              u.categoria === "bi" ? "grid-cols-2" : "grid-cols-1",
                            )}
                          >
                            {u.categoria !== "contas" && (
                              <div>
                                <p className="text-[9px] uppercase tracking-wider text-muted-foreground">
                                  Depositado <span className="text-muted-foreground/70">(Montante)</span>
                                </p>
                                <p className="number-tabular text-sm font-bold text-warning">{formatBRL(u.dep)}</p>
                              </div>
                            )}
                            {u.categoria !== "montante" && (
                              <div>
                                <p className="text-[9px] uppercase tracking-wider text-muted-foreground">
                                  Contas <span className="text-muted-foreground/70">(Salário)</span>
                                </p>
                                <p className="number-tabular text-sm font-bold text-accent">{formatBRL(u.sal)}</p>
                              </div>
                            )}
                          </div>
                        )}
                        <p className="mt-1 text-[10px] text-muted-foreground">
                          {u.ops > 0 && u.last ? `${u.ops} op • últ. ${formatTime(u.last)}` : "Sem registro hoje"}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>


          <div className="glass-strong rounded-2xl p-5">
            <div className="mb-4">
              <h2 className="text-lg font-semibold">Ranking de usuários</h2>
              <p className="text-xs text-muted-foreground">
                Quem está gerando mais lucro e movimento na plataforma
              </p>
            </div>
            {(() => {
              const me = ranking.find((r) => r.user_id === user?.id);
              if (!me) return null;
              const positive = me.lucro >= 0;
              return (
                <div className="mb-3 rounded-xl border border-primary/30 bg-primary/5 p-3">
                  <div className="mb-2 flex items-center justify-between">
                    <div className="text-xs font-semibold uppercase tracking-wide text-primary">Seu desempenho</div>
                    <div className="text-[11px] text-muted-foreground">{me.pedidos} operações</div>
                  </div>
                  <div className="grid grid-cols-3 gap-2">
                    <div>
                      <div className="text-[10px] uppercase text-muted-foreground">Lucro</div>
                      <div className={`number-tabular text-sm font-bold ${positive ? "text-success" : "text-destructive"}`}>
                        {formatBRL(me.lucro)}
                      </div>
                    </div>
                    <div>
                      <div className="text-[10px] uppercase text-muted-foreground">Depositou</div>
                      <div className="number-tabular text-sm font-bold text-warning">{formatBRL(me.deposito)}</div>
                    </div>
                    <div>
                      <div className="text-[10px] uppercase text-muted-foreground">Sacou</div>
                      <div className="number-tabular text-sm font-bold text-primary">{formatBRL(me.saque)}</div>
                    </div>
                  </div>
                </div>
              );
            })()}
            {ranking.length === 0 ? (
              <div className="flex h-60 items-center justify-center text-sm text-muted-foreground">
                Sem dados ainda.
              </div>
            ) : (
              <div className="space-y-2">
                {ranking.slice(0, 10).map((r, i) => {
                  const top = ranking[0]?.lucro || 1;
                  const pct = Math.max(2, Math.min(100, (Math.abs(r.lucro) / Math.abs(top)) * 100));
                  const positive = r.lucro >= 0;
                  const medal = i === 0 ? "🥇" : i === 1 ? "🥈" : i === 2 ? "🥉" : null;
                  const isSelf = r.user_id === user?.id;
                  const canSeeValues = isAdmin || isSelf;
                  return (
                    <div
                      key={r.user_id}
                      className="group relative overflow-hidden rounded-xl border border-border/40 bg-background/40 p-3 transition hover:border-primary/40"
                    >
                      <div
                        className={`absolute inset-y-0 left-0 ${positive ? "bg-success/10" : "bg-destructive/10"}`}
                        style={{ width: `${pct}%` }}
                      />
                      <div className="relative flex items-center justify-between gap-3">
                        <div className="flex min-w-0 items-center gap-3">
                          <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-background/80 text-sm font-bold text-muted-foreground">
                            {medal ?? `#${i + 1}`}
                          </div>
                          <div className="min-w-0">
                            <div className="truncate text-sm font-semibold">
                              {r.nome}
                              {isSelf && <span className="ml-1 text-[10px] text-primary">(você)</span>}
                            </div>
                            <div className="truncate text-[11px] text-muted-foreground">
                              {canSeeValues
                                ? `${r.pedidos} op • Dep ${formatBRL(r.deposito)} • Saq ${formatBRL(r.saque)}`
                                : `${r.pedidos} operações`}
                            </div>
                          </div>
                        </div>
                        <div
                          className={`number-tabular shrink-0 text-right text-sm font-bold ${
                            canSeeValues
                              ? positive ? "text-success" : "text-destructive"
                              : "text-muted-foreground"
                          }`}
                        >
                          {canSeeValues ? formatBRL(r.lucro) : "•••••"}
                        </div>
                      </div>
                    </div>
                  );
                })}
              </div>
            )}
          </div>
        </div>

        {isAdmin && <AdminAuditFeed />}

        {/* Diagnóstico da ponte com o coletor externo: teste, log e o JSON cru
            recebido. Só admin — expõe endereço, rotas e payload da integração. */}
        {isAdmin && <ConexaoColetor />}
      </div>


      {showCalc && (
        <aside className="relative space-y-4 lg:sticky lg:top-20 lg:self-start lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto lg:pr-1">
          <div className="flex items-center justify-end gap-2">
            <ChangePasswordButton />
            <Button
              variant="outline"
              size="icon"
              onClick={() => toggleCalc(false)}
              aria-label="Esconder calculadora"
              className="h-8 w-8 rounded-full border-destructive/50 bg-destructive/10 text-destructive hover:bg-destructive hover:text-destructive-foreground"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>
          {/* Operador travado numa categoria não escolhe a calculadora. */}
          {!lockedMode && (
            <div className="grid grid-cols-2 gap-2 rounded-xl bg-background/40 p-1 ring-1 ring-border">
              <button
                type="button"
                onClick={() => setCalcMode("montante")}
                className={`rounded-lg px-3 py-2 text-xs font-semibold transition-all ${calcMode === "montante" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"}`}
              >
                Montante
              </button>
              <button
                type="button"
                onClick={() => setCalcMode("contas")}
                className={`rounded-lg px-3 py-2 text-xs font-semibold transition-all ${calcMode === "contas" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"}`}
              >
                Contas
              </button>
            </div>
          )}
          {calcMode === "montante" ? <SideCalculator /> : <AccountsCalculator />}
          {/* O divisor alimenta o campo de Depósito (Montante). */}
          {scopeMontante && <DepositSplitter />}
        </aside>
      )}

    </div>
  );
}

function AdminAuditFeed() {
  const { data: audits = [], isLoading } = useQuery({
    queryKey: ["dashboard-audit"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("operation_audit")
        .select("id, operation_id, user_id, acao, snapshot, changed_by, changed_at")
        .order("changed_at", { ascending: false })
        .limit(20);
      if (error) throw error;
      return data ?? [];
    },
  });

  const { data: profilesList = [] } = useQuery({
    queryKey: ["profiles-min"],
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("id, nome, email");
      return (data ?? []) as { id: string; nome: string; email: string }[];
    },
  });

  const nameOf = (id: string | null) => {
    if (!id) return "—";
    const p = profilesList.find((x) => x.id === id);
    return p ? p.nome : id.slice(0, 8);
  };

  if (!isLoading && audits.length === 0) return null;

  return (
    <div className="glass-strong space-y-3 rounded-2xl p-4">
      <div className="flex items-center gap-2">
        <History className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-bold uppercase tracking-wider">Alterações recentes dos usuários</h2>
        <span className="ml-auto text-[11px] text-muted-foreground">últimas 20</span>
      </div>
      {isLoading ? (
        <p className="text-xs text-muted-foreground">Carregando...</p>
      ) : (
        <ul className="divide-y divide-border/40 text-xs">
          {audits.map((a: any) => {
            const s = a.snapshot ?? {};
            return (
              <li key={a.id} className="flex flex-wrap items-center gap-2 py-2">
                <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${a.acao === "APAGADA" ? "bg-destructive/15 text-destructive" : "bg-warning/15 text-warning"}`}>
                  {a.acao}
                </span>
                <span className="text-muted-foreground">{formatDate(a.changed_at)}</span>
                <span>•</span>
                <span className="font-medium">{nameOf(a.changed_by)}</span>
                <span className="text-muted-foreground">alterou operação de</span>
                <span className="font-medium">{nameOf(a.user_id)}</span>
                <span className="ml-auto text-muted-foreground">
                  Lucro {formatBRL(Number(s.lucro ?? 0))}
                </span>
              </li>
            );
          })}
        </ul>
      )}
    </div>
  );
}

