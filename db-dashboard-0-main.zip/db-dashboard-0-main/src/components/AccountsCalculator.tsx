import { memo, useEffect, useMemo, useState } from "react";
import { Calculator, Copy, Pencil, Check, Table as TableIcon } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { formatBRL } from "@/lib/format";
import { cn } from "@/lib/utils";
import { toast } from "sonner";
import { supabase } from "@/integrations/supabase/client";
import { useQuery } from "@tanstack/react-query";
import { DEFAULT_CONTAS_TEMPLATE, renderTemplate } from "@/lib/pixTemplates";

type Tier = { min: number; max: number; price: number };


const TABELA_1: Tier[] = [
  { min: 10, max: 10, price: 5 },
  { min: 10, max: 12, price: 6 },
  { min: 10, max: 13, price: 7 },
  { min: 10, max: 13, price: 8 },
  { min: 10, max: 14, price: 9 },
  { min: 10, max: 15, price: 10 },
  { min: 10, max: 16, price: 11 },
  { min: 10, max: 17, price: 11 },
];

const TABELA_2: Tier[] = [
  { min: 10, max: 10, price: 6 },
  { min: 10, max: 11, price: 7 },
  { min: 10, max: 12, price: 8 },
  { min: 10, max: 13, price: 9 },
  { min: 10, max: 14, price: 10 },
  { min: 10, max: 15, price: 11 },
  { min: 10, max: 16, price: 11 },
  { min: 10, max: 17, price: 12 },
];

const SEPARADOR = "━━━━━━━━━━━━━";

const DEFAULT_HEADER = `📌 PIX CELULAR

💠 EXEMPLO

🏷️ EXEMPLO

🏦 MERCADO PAGO`;

const DEFAULT_FOOTER = `⚠️ MARCAR E ENVIAR O COMPROVANTE`;

function findPrice(tabela: Tier[], min: number, max: number): number | null {
  // exact match first
  const exact = tabela.find((t) => t.min === min && t.max === max);
  if (exact) return exact.price;
  // fallback: smallest tier that contains [min,max]
  const contains = tabela
    .filter((t) => t.min <= min && t.max >= max)
    .sort((a, b) => a.price - b.price);
  if (contains.length) return contains[0].price;
  return null;
}

function AccountsCalculatorImpl() {
  const [qtd, setQtd] = useState<string>(() => localStorage.getItem("calcContas:qtd") ?? "5");
  const [minStr, setMinStr] = useState<string>(() => localStorage.getItem("calcContas:min") ?? "10");
  const [maxStr, setMaxStr] = useState<string>(() => localStorage.getItem("calcContas:max") ?? "10");
  const [tabela, setTabela] = useState<"1" | "2">(
    () => ((localStorage.getItem("calcContas:tabela") as "1" | "2") ?? "1"),
  );

  const [header, setHeader] = useState<string>(
    () => localStorage.getItem("calcContas:header") ?? DEFAULT_HEADER,
  );
  const [editing, setEditing] = useState(false);
  const [copied, setCopied] = useState(false);

  useEffect(() => {
    localStorage.setItem("calcContas:qtd", qtd);
  }, [qtd]);
  useEffect(() => {
    localStorage.setItem("calcContas:min", minStr);
  }, [minStr]);
  useEffect(() => {
    localStorage.setItem("calcContas:max", maxStr);
  }, [maxStr]);
  useEffect(() => {
    localStorage.setItem("calcContas:tabela", tabela);
  }, [tabela]);
  useEffect(() => {
    localStorage.setItem("calcContas:header", header);
  }, [header]);

  const qtdNum = Math.max(1, Number(qtd) || 1);
  const minNum = Number(minStr) || 0;
  const maxNum = Number(maxStr) || 0;

  const precoUnit = useMemo(() => {
    if (minNum <= 0 || maxNum <= 0 || maxNum < minNum) return null;
    return findPrice(tabela === "1" ? TABELA_1 : TABELA_2, minNum, maxNum);
  }, [minNum, maxNum, tabela]);

  const total = useMemo(() => (precoUnit ?? 0) * qtdNum, [precoUnit, qtdNum]);

  const { data: globalTemplate } = useQuery({
    queryKey: ["pix-template-contas-global"],
    queryFn: async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("pix_template_contas_global")
        .eq("id", 1)
        .maybeSingle();
      return ((data as any)?.pix_template_contas_global as string | null) ?? null;
    },
  });

  const pixMessage = useMemo(() => {
    const template = globalTemplate ?? DEFAULT_CONTAS_TEMPLATE;
    return renderTemplate(template, {
      header: header.trim(),
      qtd: String(qtdNum),
      min: String(minNum),
      max: String(maxNum),
      preco_unit: precoUnit !== null ? formatBRL(precoUnit) : "—",
      total: formatBRL(total),
    });
  }, [globalTemplate, header, total, qtdNum, minNum, maxNum, precoUnit]);


  const copiar = async () => {
    try {
      await navigator.clipboard.writeText(pixMessage);
      setCopied(true);
      toast.success("Mensagem copiada");
      setTimeout(() => setCopied(false), 1500);
    } catch {
      toast.error("Não foi possível copiar");
    }
  };

  return (
    <div className="glass-strong space-y-5 rounded-2xl p-5">
      <div className="flex items-center gap-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/30">
          <Calculator className="h-4 w-4" />
        </div>
        <div>
          <h3 className="font-semibold leading-tight">Calculadora de Contas</h3>
          <p className="text-xs text-muted-foreground">Cálculo por faixa de depósito</p>
        </div>
      </div>

      <div className="space-y-1.5">
        <Label className="text-xs">Quantidade de Contas</Label>
        <Input
          type="number"
          inputMode="numeric"
          min={1}
          value={qtd}
          onChange={(e) => setQtd(e.target.value)}
        />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="space-y-1.5">
          <Label className="text-xs">Mínimo</Label>
          <Input
            type="number"
            inputMode="numeric"
            value={minStr}
            onChange={(e) => setMinStr(e.target.value)}
          />
        </div>
        <div className="space-y-1.5">
          <Label className="text-xs">Máximo</Label>
          <Input
            type="number"
            inputMode="numeric"
            value={maxStr}
            onChange={(e) => setMaxStr(e.target.value)}
          />
        </div>
      </div>

      <div className="space-y-2">
        <Label className="text-xs">Selecione a tabela de cálculo</Label>
        <div className="grid grid-cols-2 gap-2">
          {(["1", "2"] as const).map((t) => (
            <button
              key={t}
              type="button"
              onClick={() => setTabela(t)}
              className={cn(
                "flex items-center justify-center gap-2 rounded-xl border px-3 py-3 text-sm font-semibold transition-all",
                tabela === t
                  ? "border-primary bg-primary/10 text-primary ring-1 ring-primary/40"
                  : "border-border bg-background/40 text-muted-foreground hover:text-foreground",
              )}
            >
              <TableIcon className="h-4 w-4" />
              TABELA {t}
            </button>
          ))}
        </div>
      </div>

      <div className="space-y-2 rounded-xl border border-border bg-background/40 p-3 text-sm">
        <div className="flex items-center justify-between text-muted-foreground">
          <span>Preço por conta</span>
          <span className="font-semibold text-foreground">
            {precoUnit !== null ? formatBRL(precoUnit) : "—"}
          </span>
        </div>
        <div className="flex items-center justify-between">
          <span className="text-muted-foreground">Total ({qtdNum}× contas)</span>
          <span className="number-tabular text-base font-bold text-accent">
            {formatBRL(total)}
          </span>
        </div>
        {precoUnit === null && minNum > 0 && maxNum > 0 && (
          <p className="text-[11px] text-warning">
            Faixa fora das tabelas. Ajuste mínimo/máximo.
          </p>
        )}
      </div>

      <div className="space-y-2 rounded-xl border border-primary/30 bg-gradient-to-br from-primary/5 to-transparent p-3">
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold uppercase tracking-wider text-primary">
            Mensagem PIX
          </p>
          <div className="flex gap-1">
            <Button
              type="button"
              size="sm"
              variant="ghost"
              className="h-7 px-2"
              onClick={() => setEditing((v) => !v)}
              title="Editar chave PIX"
            >
              <Pencil className="h-3 w-3" />
            </Button>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              className="h-7 px-2"
              onClick={copiar}
              title="Copiar mensagem"
            >
              {copied ? <Check className="h-3 w-3 text-success" /> : <Copy className="h-3 w-3" />}
            </Button>
          </div>
        </div>

        {editing && (
          <div className="space-y-1.5">
            <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">
              Sua chave PIX (texto livre — fica acima do separador)
            </Label>
            <Textarea
              value={header}
              onChange={(e) => setHeader(e.target.value)}
              rows={6}
              className="text-xs"
            />
            <div className="flex justify-end">
              <Button
                type="button"
                size="sm"
                variant="ghost"
                className="h-7 text-[10px]"
                onClick={() => setHeader(DEFAULT_HEADER)}
              >
                Restaurar padrão
              </Button>
            </div>
          </div>
        )}

        <pre className="max-h-72 overflow-auto whitespace-pre-wrap rounded-lg bg-background/60 p-3 text-[11px] leading-relaxed text-foreground">
{pixMessage}
        </pre>
      </div>
    </div>
  );
}

export const AccountsCalculator = memo(AccountsCalculatorImpl);
