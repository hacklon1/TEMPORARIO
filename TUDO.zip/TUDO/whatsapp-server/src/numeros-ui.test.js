// Aba "Números" do painel, num DOM real (jsdom): os cartões dos 3 números, o
// QR de cada um, os interruptores de recurso e o aviso de sobreposição.
//
// Sem isto, um erro de sintaxe no app.js quebraria o painel INTEIRO e só
// apareceria no navegador do usuário (foi o que já aconteceu uma vez, com uma
// função redeclarada).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const PUBLIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

const RECURSOS = [
  { chave: 'monitorar', nome: 'Monitoramento (montante e contas)', descricao: 'x' },
  { chave: 'pedidos', nome: 'Pedidos das Brogueiras', descricao: 'y' },
  { chave: 'agendamentos', nome: 'Agendamentos', descricao: 'z' },
];

const SESSOES = [
  { id: 'n1', nome: 'Operação', ativa: true, connection: 'open', hasQr: false, me: { id: '5573981810457:12@s.whatsapp.net' }, recursos: { monitorar: true, pedidos: true, agendamentos: true } },
  { id: 'n2', nome: 'Divulgação', ativa: true, connection: 'connecting', hasQr: true, me: null, recursos: { monitorar: false, pedidos: false, agendamentos: true } },
  { id: 'n3', nome: 'Número 3', ativa: false, connection: 'desligado', hasQr: false, me: null, recursos: { monitorar: false, pedidos: false, agendamentos: false } },
];

// Sobe o painel com um servidor de mentira: nenhuma chamada sai para a rede.
async function montarPainel({ conflitos = [] } = {}) {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;
  window.Element.prototype.getBoundingClientRect = () => ({
    left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0,
  });
  window.Element.prototype.setPointerCapture = () => {};
  window.Element.prototype.releasePointerCapture = () => {};

  const chamadas = [];
  window.fetch = async (url, opts = {}) => {
    chamadas.push({ url: String(url), method: opts.method || 'GET', body: opts.body ? JSON.parse(opts.body) : null });
    const corpo = String(url).includes('/api/sessoes')
      ? { ok: true, recursos: RECURSOS, sessoes: SESSOES, conflitos }
      : { ok: true };
    return { ok: true, status: 200, json: async () => corpo };
  };
  window.confirm = () => true;

  const tag = window.document.createElement('script');
  tag.textContent = fs.readFileSync(path.join(PUBLIC, 'app.js'), 'utf8');
  window.document.body.appendChild(tag);

  // Estado que o painel receberia pelo Socket.IO. O catálogo de recursos é
  // buscado no servidor (fetch de mentira acima), então esperamos o microtask.
  window.atualizarSessoes(JSON.parse(JSON.stringify(SESSOES)));
  await new Promise((r) => setTimeout(r, 20));
  return { window, doc: window.document, chamadas };
}

test('a aba Números desenha um cartão por número, com nome e estado', async () => {
  const { doc } = await montarPainel();
  const cartoes = doc.querySelectorAll('.num-card');
  assert.equal(cartoes.length, 3);

  const n1 = doc.querySelector('.num-card[data-sessao="n1"]');
  assert.equal(n1.querySelector('.num-nome').value, 'Operação');
  assert.ok(n1.querySelector('.num-dot').classList.contains('open'), 'conectado = bolinha verde');
  assert.match(n1.querySelector('.num-status').textContent, /Conectado/);

  const n3 = doc.querySelector('.num-card[data-sessao="n3"]');
  assert.ok(n3.classList.contains('off'), 'número desligado fica esmaecido');
  assert.match(n3.querySelector('.num-status').textContent, /Desligado/);
  assert.equal(n3.querySelector('.num-ativa').checked, false);
});

test('o QR aparece só no número que está esperando pareamento', async () => {
  const { doc } = await montarPainel();
  const qrN2 = doc.querySelector('.num-card[data-sessao="n2"] .num-qr');
  const qrN1 = doc.querySelector('.num-card[data-sessao="n1"] .num-qr');
  assert.equal(qrN2.classList.contains('hidden'), false);
  assert.equal(qrN1.classList.contains('hidden'), true);
  const img = doc.querySelector('.num-card[data-sessao="n2"] .num-qr-img');
  assert.match(img.getAttribute('src') || '', /\/api\/sessoes\/n2\/qr/, 'cada número tem o seu endereço de QR');
});

test('os recursos de cada número aparecem marcados como estão no servidor', async () => {
  const { doc } = await montarPainel();
  const marcados = (id) => [...doc.querySelectorAll(`.num-card[data-sessao="${id}"] .num-recurso input`)]
    .filter((c) => c.checked).map((c) => c.dataset.recurso);
  assert.deepEqual(marcados('n1'), ['monitorar', 'pedidos', 'agendamentos']);
  assert.deepEqual(marcados('n2'), ['agendamentos'], 'o número 2 só dispara agendamentos');
  assert.deepEqual(marcados('n3'), []);
});

test('mexer num recurso salva só aquele número', async () => {
  const { doc, chamadas } = await montarPainel();
  const chk = doc.querySelector('.num-card[data-sessao="n2"] .num-recurso input[data-recurso="pedidos"]');
  chk.checked = true;
  chk.dispatchEvent(new (doc.defaultView.Event)('change', { bubbles: true }));
  await new Promise((r) => setTimeout(r, 10));

  const patch = chamadas.find((c) => c.method === 'PATCH');
  assert.ok(patch, 'salvou');
  assert.match(patch.url, /\/api\/sessoes\/n2$/);
  assert.deepEqual(patch.body, { recursos: { pedidos: true } });
});

test('ligar/desligar um número vai como ativa', async () => {
  const { doc, chamadas } = await montarPainel();
  const chk = doc.querySelector('.num-card[data-sessao="n3"] .num-ativa');
  chk.checked = true;
  chk.dispatchEvent(new (doc.defaultView.Event)('change', { bubbles: true }));
  await new Promise((r) => setTimeout(r, 10));
  const patch = chamadas.find((c) => c.method === 'PATCH');
  assert.match(patch.url, /\/api\/sessoes\/n3$/);
  assert.deepEqual(patch.body, { ativa: true });
});

test('sobreposição entre números aparece como aviso; sem sobreposição, some', async () => {
  const semConflito = await montarPainel();
  assert.equal(semConflito.doc.getElementById('num-conflitos').classList.contains('hidden'), true);

  const comConflito = await montarPainel({
    conflitos: [{ recurso: 'monitorar', alvo: 'A@g.us', nome: 'DB OPERAÇÕES', sessoes: ['n1', 'n2'], certeza: 'confirmado' }],
  });
  const box = comConflito.doc.getElementById('num-conflitos');
  assert.equal(box.classList.contains('hidden'), false);
  const texto = comConflito.doc.getElementById('num-conflitos-lista').textContent;
  assert.match(texto, /Monitoramento/);
  assert.match(texto, /Operação e Divulgação/, 'diz QUAIS números');
  assert.match(texto, /DB OPERAÇÕES/, 'e em qual grupo');
});

test('os seletores de número das abas são preenchidos (com "Todos" só no filtro)', async () => {
  const { doc } = await montarPainel();
  const valores = (id) => [...doc.getElementById(id).options].map((o) => o.value);
  assert.deepEqual(valores('filtro-sessao'), ['todas', 'n1', 'n2', 'n3']);
  assert.deepEqual(valores('cfg-sessao'), ['n1', 'n2', 'n3']);
  assert.deepEqual(valores('grp-sessao'), ['n1', 'n2', 'n3']);
  assert.deepEqual(valores('send-sessao'), ['n1', 'n2', 'n3']);
  assert.deepEqual(valores('sch-sessao'), ['n1', 'n2', 'n3']);
  assert.match(doc.getElementById('cfg-sessao').options[0].textContent, /Operação/);
});

test('o cabeçalho conta quantos números estão conectados', async () => {
  const { doc, window } = await montarPainel();
  window.renderConexao({ sessaoId: 'n1', connection: 'open', geral: 'open' });
  assert.equal(doc.getElementById('conn-text').textContent, '1/2 conectados');
});

test('o Painel avisa que há número esperando QR e leva para a aba certa', async () => {
  const { doc } = await montarPainel();
  const aviso = doc.getElementById('qr-box');
  assert.equal(aviso.classList.contains('hidden'), false);
  assert.match(doc.getElementById('qr-aviso-quais').textContent, /Divulgação/);

  doc.querySelector('[data-goto="numeros"]').click();
  assert.equal(doc.getElementById('tab-numeros').classList.contains('hidden'), false);
  assert.equal(doc.getElementById('page-title').textContent, 'Números');
});
