// Conexões WhatsApp via Baileys — ATÉ 3 NÚMEROS ao mesmo tempo.
//
// Cada número é uma "instância" independente: socket, sessão em disco
// (auth/<id>), QR, backoff de reconexão e cache de nomes de grupo próprios.
// Nada é compartilhado entre elas — é o que impede que a queda (ou o
// re-pareamento) de um número mexa nos outros.
//
// Toda função pública recebe o id da sessão ('n1' | 'n2' | 'n3').
import fs from 'node:fs/promises';
import fsSync from 'node:fs';
import path from 'node:path';
import { Boom } from '@hapi/boom';
import makeWASocket, {
  DisconnectReason,
  fetchLatestBaileysVersion,
  useMultiFileAuthState,
} from '@whiskeysockets/baileys';
import qrcodeTerminal from 'qrcode-terminal';
import QRCode from 'qrcode';
import { logger } from './logger.js';
import { getSessao, getSessoes } from './db.js';
import { IDS_SESSOES, SESSAO_PADRAO } from './sessoes.js';
import { processMessage } from './handler.js';
import { processarEntradaGrupo } from './welcome.js';
import { soDigitos } from './jid.js';
import { invalidarGrupo } from './membros.js';
import { emitQr, emitConnection, emitUpdate } from './realtime.js';

const BACKOFF_BASE_MS = 2000;
const BACKOFF_MAX_MS = 60_000;
// Limite de re-pareamentos automáticos por processo: evita apagar a sessão em
// loop caso o servidor devolva 401 repetidamente.
const MAX_RELOGINS = 3;
// Se o número for desvinculado no celular, a sessão em auth/ vira lixo e aquele
// número fica morto. Por padrão limpamos e emitimos um QR novo.
const AUTO_RELOGIN = (process.env.AUTO_RELOGIN ?? 'true') !== 'false';

let baseAuthDir = null;
let encerrandoTudo = false;

// id -> instância. Criada sob demanda; sobrevive à desconexão (guarda o
// diagnóstico do que aconteceu com aquele número).
const instancias = new Map();

function novoEstado() {
  return {
    connection: 'close',
    qr: null,
    me: null,
    lastError: null,
    // Diagnóstico de reconexão (exposto em /api/status e no painel).
    tentativasReconexao: 0,
    proximaTentativaEm: null,
    ultimoLogout: null,
    relogins: 0,
  };
}

function instancia(id = SESSAO_PADRAO) {
  const chave = IDS_SESSOES.includes(id) ? id : SESSAO_PADRAO;
  if (!instancias.has(chave)) {
    instancias.set(chave, {
      id: chave,
      sock: null,
      starting: false,
      reconnectTimer: null,
      parada: true, // não deve reconectar sozinha (número desligado no painel)
      groupNameCache: new Map(),
      state: novoEstado(),
    });
  }
  return instancias.get(chave);
}

const authDirDe = (id) => path.join(baseAuthDir, id);

/**
 * Define a pasta-base das sessões e migra a instalação de um número só:
 * antes as credenciais ficavam soltas em auth/, agora cada número tem a sua em
 * auth/<id>. Sem isto o Número 1 pediria pareamento de novo depois do deploy.
 */
export function configurarAuth(base) {
  baseAuthDir = path.resolve(base);
  fsSync.mkdirSync(baseAuthDir, { recursive: true });

  const destino = authDirDe(SESSAO_PADRAO);
  const credsSoltas = fsSync.existsSync(path.join(baseAuthDir, 'creds.json'));
  const jaMigrado = fsSync.existsSync(path.join(destino, 'creds.json'));
  if (credsSoltas && !jaMigrado) {
    fsSync.mkdirSync(destino, { recursive: true });
    let movidos = 0;
    for (const nome of fsSync.readdirSync(baseAuthDir)) {
      if (IDS_SESSOES.includes(nome)) continue; // as pastas das sessões
      try {
        fsSync.renameSync(path.join(baseAuthDir, nome), path.join(destino, nome));
        movidos += 1;
      } catch (err) {
        logger.error({ err, arquivo: nome }, 'falha ao migrar arquivo de sessão para auth/n1');
      }
    }
    logger.warn({ movidos, destino }, 'sessão do número único migrada para auth/n1');
  }
  for (const id of IDS_SESSOES) fsSync.mkdirSync(authDirDe(id), { recursive: true });
}

// Derruba o socket atual de UMA instância sem disparar reconexão.
function destruirSocket(inst) {
  if (!inst.sock) return;
  const antigo = inst.sock;
  inst.sock = null;
  try {
    antigo.ev.removeAllListeners();
  } catch (err) {
    logger.debug({ err, sessao: inst.id }, 'falha ao remover listeners do socket antigo');
  }
  try {
    antigo.ws?.close();
  } catch (err) {
    logger.debug({ err, sessao: inst.id }, 'falha ao fechar websocket antigo');
  }
}

function agendarReconexao(inst, motivo) {
  if (encerrandoTudo || inst.parada) return;
  if (inst.reconnectTimer) return; // já há uma tentativa na fila — não empilha sockets
  const espera = Math.min(BACKOFF_BASE_MS * 2 ** inst.state.tentativasReconexao, BACKOFF_MAX_MS);
  inst.state.tentativasReconexao += 1;
  inst.state.proximaTentativaEm = new Date(Date.now() + espera).toISOString();
  logger.warn({ sessao: inst.id, motivo, espera, tentativa: inst.state.tentativasReconexao }, 'reconexão agendada');
  inst.reconnectTimer = setTimeout(() => {
    inst.reconnectTimer = null;
    inst.state.proximaTentativaEm = null;
    iniciarSessao(inst.id).catch((err) => {
      logger.error({ err, sessao: inst.id }, 'falha ao reconectar');
      agendarReconexao(inst, 'erro ao iniciar socket');
    });
  }, espera);
  inst.reconnectTimer.unref?.();
}

// Apaga a sessão salva de UM número para forçar novo pareamento (novo QR).
// Esvazia o CONTEÚDO do diretório em vez de removê-lo: sob ProtectSystem=strict
// o systemd expõe auth/ como ReadWritePath, então os arquivos são graváveis mas
// o próprio diretório não pode sofrer rmdir.
async function limparAuth(authDir) {
  const alvo = path.resolve(authDir);
  // Trava de segurança: nunca esvaziar a raiz nem um caminho raso inesperado.
  if (alvo.split(path.sep).filter(Boolean).length < 2) {
    throw new Error(`recusando limpar AUTH_DIR suspeito: ${alvo}`);
  }
  await fs.mkdir(alvo, { recursive: true });
  const entradas = await fs.readdir(alvo);
  let removidos = 0;
  for (const nome of entradas) {
    try {
      await fs.rm(path.join(alvo, nome), { recursive: true, force: true });
      removidos += 1;
    } catch (err) {
      logger.error({ err, arquivo: nome }, 'falha ao remover arquivo de sessão');
    }
  }
  logger.warn({ authDir: alvo, removidos }, 'sessão removida — aguardando novo pareamento');
}

// Contexto que o handler recebe: quem é este número e o que ele pode fazer.
// Lido do db a cada mensagem — mudar um recurso no painel vale na hora, sem
// reiniciar nem reconectar.
function contextoSessao(id) {
  const s = getSessao(id);
  return { id: s.id, nome: s.nome, ativa: s.ativa, recursos: s.recursos, config: s.config };
}

// Helpers de envio/consulta já amarrados a ESTA sessão — é o que garante que
// uma resposta saia pelo mesmo número que recebeu a mensagem.
function depsDaSessao(id) {
  return {
    sessao: contextoSessao(id),
    reply: (to, text, opts) => sendText(id, to, text, opts),
    getGroupName: (jid) => getGroupName(id, jid),
    getGroupInfo: (jid) => getGroupInfo(id, jid),
    getGroupMembers: (jid) => groupMembers(id, jid),
    getGroupParticipants: (jid) => groupParticipants(id, jid),
    souEu: (jid) => souEu(id, jid),
  };
}

/**
 * Sobe (ou ressobe) o socket de UM número.
 */
export async function iniciarSessao(id) {
  if (!baseAuthDir) throw new Error('configurarAuth() não foi chamado');
  const inst = instancia(id);
  inst.parada = false;
  if (encerrandoTudo) return;
  if (inst.starting) {
    logger.debug({ sessao: inst.id }, 'início ignorado — já há uma inicialização em andamento');
    return;
  }
  inst.starting = true;

  const authDir = authDirDe(inst.id);
  let saveCreds;
  try {
    destruirSocket(inst);
    await fs.mkdir(authDir, { recursive: true });

    const { state: authState, saveCreds: persistirCreds } = await useMultiFileAuthState(authDir);
    saveCreds = persistirCreds;
    const { version } = await fetchLatestBaileysVersion();
    logger.info({ sessao: inst.id, version }, 'iniciando socket WhatsApp');

    inst.sock = makeWASocket({
      version,
      auth: authState,
      logger,
      printQRInTerminal: false,
      // O nome aparece em "Aparelhos conectados" no celular — com 3 números,
      // saber qual é qual pelo próprio WhatsApp evita desvincular o errado.
      browser: [`Whatsap Server ${inst.id.toUpperCase()}`, 'Chrome', '1.0.0'],
    });
  } catch (err) {
    inst.starting = false;
    throw err;
  }

  const meuSock = inst.sock;
  // Ignora eventos de um socket já substituído.
  const atual = () => inst.sock === meuSock;

  // creds.update é assíncrono: sem try/catch uma falha de escrita viraria
  // unhandledRejection e derrubaria o processo.
  meuSock.ev.on('creds.update', async () => {
    try {
      await saveCreds();
    } catch (err) {
      logger.error({ err, sessao: inst.id }, 'falha ao salvar credenciais');
    }
  });

  meuSock.ev.on('connection.update', (update) => {
    if (!atual()) return;
    const { connection, lastDisconnect, qr } = update;

    if (qr) {
      inst.state.qr = qr;
      // Receber QR significa que o socket está saudável e só falta o
      // pareamento: zera o backoff para que a expiração do QR não empurre as
      // regenerações para intervalos de 60s enquanto o usuário não escaneia.
      inst.state.tentativasReconexao = 0;
      qrcodeTerminal.generate(qr, { small: true });
      emitQr(inst.id, qr);
      logger.warn({ sessao: inst.id }, 'escaneie o QR (painel → aba Números) para autenticar');
    }

    if (connection) {
      inst.state.connection = connection;
      emitConnection(inst.id, connection);
    }

    if (connection === 'open') {
      inst.state.qr = null;
      inst.state.lastError = null;
      inst.state.tentativasReconexao = 0;
      inst.state.proximaTentativaEm = null;
      // Guardamos também o LID: sob endereçamento @lid o participante que
      // chega num grupo vem como LID, e comparar só com o telefone nunca casa.
      inst.state.me = meuSock.user
        ? { id: meuSock.user.id, name: meuSock.user.name, lid: meuSock.user.lid ?? null }
        : null;
      emitQr(inst.id, null);
      emitUpdate();
      logger.info({ sessao: inst.id, me: inst.state.me }, 'WhatsApp conectado');
    }

    if (connection === 'close') {
      const statusCode = new Boom(lastDisconnect?.error)?.output?.statusCode;
      const loggedOut = statusCode === DisconnectReason.loggedOut;
      inst.state.lastError = lastDisconnect?.error?.message ?? null;
      // O QR morre junto com o socket — não deixar o painel exibir um código
      // expirado que nunca vai parear.
      inst.state.qr = null;
      emitQr(inst.id, null);
      logger.warn({ sessao: inst.id, statusCode, loggedOut }, 'conexão encerrada');

      if (!loggedOut) {
        agendarReconexao(inst, `statusCode ${statusCode}`);
        return;
      }

      // Deslogado: a sessão em auth/<id> não serve mais para nada.
      inst.state.me = null;
      inst.state.ultimoLogout = new Date().toISOString();
      if (!AUTO_RELOGIN) {
        logger.error({ sessao: inst.id }, 'deslogado — AUTO_RELOGIN desativado; limpe a sessão pelo painel');
        return;
      }
      if (inst.state.relogins >= MAX_RELOGINS) {
        logger.error({ sessao: inst.id, relogins: inst.state.relogins }, 'deslogado — limite de re-pareamentos atingido');
        return;
      }
      inst.state.relogins += 1;
      logger.error({ sessao: inst.id, tentativa: inst.state.relogins }, 'deslogado — limpando sessão e gerando novo QR');
      destruirSocket(inst);
      limparAuth(authDir)
        .then(() => {
          inst.state.tentativasReconexao = 0;
          agendarReconexao(inst, 'novo pareamento após logout');
        })
        .catch((err) => logger.error({ err, sessao: inst.id }, 'falha ao limpar sessão após logout'));
    }
  });

  // Novas mensagens
  meuSock.ev.on('messages.upsert', async ({ messages, type }) => {
    if (!atual()) return;
    if (type !== 'notify') return;
    // Um número desligado no painel não processa nada, mesmo que o socket
    // ainda esteja de pé por um instante.
    const deps = depsDaSessao(inst.id);
    if (!deps.sessao.ativa) return;
    for (const msg of messages) {
      // Uma mensagem problemática não pode abortar o lote nem virar
      // unhandledRejection (que derrubaria o processo no Node 22).
      try {
        await processMessage(msg, deps);
      } catch (err) {
        logger.error({ err, sessao: inst.id }, 'erro não tratado ao processar mensagem');
      }
    }
  });

  // Entrada/saída de participantes — dispara as boas-vindas.
  meuSock.ev.on('group-participants.update', async (update) => {
    if (!atual()) return;
    // Entrou/saiu/virou admin: o cache de papéis do grupo está velho e
    // classificaria a próxima mensagem pelo cargo antigo.
    if (update?.id) invalidarGrupo(update.id);
    const deps = depsDaSessao(inst.id);
    if (!deps.sessao.ativa || !deps.sessao.recursos.boasVindas) return;
    try {
      await processarEntradaGrupo(update, deps);
    } catch (err) {
      logger.error({ err, sessao: inst.id }, 'erro ao processar entrada em grupo');
    }
  });

  // Mantém o cache de nomes de grupos atualizado
  meuSock.ev.on('groups.update', (updates) => {
    if (!atual()) return;
    for (const u of updates) {
      if (u.id && u.subject) inst.groupNameCache.set(u.id, u.subject);
    }
  });

  inst.starting = false;
}

/**
 * Para UM número: cancela reconexão e fecha o socket, mantendo a sessão em
 * disco (religar não pede QR de novo).
 */
export function pararSessao(id) {
  const inst = instancia(id);
  inst.parada = true;
  if (inst.reconnectTimer) {
    clearTimeout(inst.reconnectTimer);
    inst.reconnectTimer = null;
  }
  destruirSocket(inst);
  inst.state.connection = 'close';
  inst.state.qr = null;
  inst.state.proximaTentativaEm = null;
  emitConnection(inst.id, 'close');
  emitQr(inst.id, null);
}

/**
 * Põe as conexões de acordo com o db: sobe quem está `ativa`, derruba o resto.
 * Chamado no boot e a cada mudança de sessão no painel.
 */
export function sincronizarSessoes() {
  for (const s of getSessoes()) {
    const inst = instancia(s.id);
    const rodando = Boolean(inst.sock) || inst.starting || Boolean(inst.reconnectTimer);
    if (s.ativa && !rodando) {
      iniciarSessao(s.id).catch((err) => logger.error({ err, sessao: s.id }, 'falha ao iniciar sessão'));
    } else if (!s.ativa && (rodando || !inst.parada)) {
      pararSessao(s.id);
      logger.info({ sessao: s.id }, 'número desligado no painel — socket encerrado');
    }
  }
}

// Encerra tudo de forma limpa (shutdown do processo).
export function pararTudo() {
  encerrandoTudo = true;
  for (const id of IDS_SESSOES) {
    const inst = instancia(id);
    inst.parada = true;
    if (inst.reconnectTimer) {
      clearTimeout(inst.reconnectTimer);
      inst.reconnectTimer = null;
    }
    destruirSocket(inst);
  }
}

// Força uma nova tentativa imediata para um número (botão no painel).
export function reconectarAgora(id = SESSAO_PADRAO) {
  if (!baseAuthDir) return false;
  const sessao = getSessao(id);
  if (!sessao?.ativa) return false;
  const inst = instancia(id);
  inst.parada = false;
  if (inst.reconnectTimer) {
    clearTimeout(inst.reconnectTimer);
    inst.reconnectTimer = null;
  }
  inst.state.tentativasReconexao = 0;
  agendarReconexao(inst, 'reconexão manual');
  return true;
}

/**
 * Desvincula um número: apaga a sessão em disco e volta a pedir QR. Usado
 * quando se quer trocar o número que ocupa aquele lugar.
 */
export async function desvincularSessao(id) {
  const inst = instancia(id);
  const authDir = authDirDe(inst.id);
  destruirSocket(inst);
  if (inst.reconnectTimer) {
    clearTimeout(inst.reconnectTimer);
    inst.reconnectTimer = null;
  }
  await limparAuth(authDir);
  inst.state = novoEstado();
  inst.state.ultimoLogout = new Date().toISOString();
  inst.groupNameCache.clear();
  emitQr(inst.id, null);
  emitConnection(inst.id, 'close');
  // Se o número segue ligado no painel, ele volta e mostra um QR novo.
  if (getSessao(id)?.ativa) {
    inst.parada = false;
    await iniciarSessao(id);
  }
  return true;
}

/* ═══════════ Estado ═══════════ */

export function estado(id = SESSAO_PADRAO) {
  return instancia(id).state;
}

// Estado de cada número + o que ele é no db, do jeito que o painel mostra.
export function estados() {
  return getSessoes().map((s) => {
    const st = instancia(s.id).state;
    return {
      id: s.id,
      nome: s.nome,
      ativa: s.ativa,
      recursos: s.recursos,
      connection: s.ativa ? st.connection : 'desligado',
      me: st.me,
      hasQr: Boolean(st.qr),
      lastError: st.lastError,
      tentativasReconexao: st.tentativasReconexao,
      proximaTentativaEm: st.proximaTentativaEm,
      ultimoLogout: st.ultimoLogout,
    };
  });
}

/**
 * Estado "de topo" mostrado no cabeçalho do painel: aberto se ao menos um
 * número ligado está conectado; senão, o estado mais avançado entre eles.
 */
export function conexaoGeral() {
  const ativos = getSessoes().filter((s) => s.ativa).map((s) => instancia(s.id).state.connection);
  if (!ativos.length) return 'close';
  if (ativos.includes('open')) return 'open';
  if (ativos.includes('connecting')) return 'connecting';
  return 'close';
}

export function sessaoConectada(id) {
  return instancia(id).state.connection === 'open';
}

/* ═══════════ Envio e consultas (sempre por sessão) ═══════════ */

export function toJid(raw) {
  if (typeof raw !== 'string') throw new Error('número inválido');
  if (raw.includes('@')) return raw;
  const digits = raw.replace(/\D/g, '');
  if (!digits) throw new Error('número inválido');
  return `${digits}@s.whatsapp.net`;
}

// Socket pronto para uso — a mensagem de erro diz QUAL número está fora.
function socketPronto(id) {
  const inst = instancia(id);
  if (!inst.sock || inst.state.connection !== 'open') {
    const nome = getSessao(id)?.nome ?? id;
    throw new Error(`${nome} não está conectado`);
  }
  return inst.sock;
}

// `mentions` recebe JIDs; o WhatsApp só renderiza o "@" como menção real
// quando o JID vem nessa lista, além de aparecer como @numero no texto.
export async function sendText(sessaoId, to, text, { mentions } = {}) {
  const sock = socketPronto(sessaoId);
  const corpo = String(text ?? '').trim();
  if (!corpo) throw new Error('mensagem vazia');
  const jid = toJid(to);
  const conteudo = { text: corpo };
  if (Array.isArray(mentions) && mentions.length) conteudo.mentions = mentions;
  const result = await sock.sendMessage(jid, conteudo);
  return { jid, id: result?.key?.id ?? null, sessaoId };
}

// Envia uma imagem com legenda opcional (texto da mensagem vai na legenda,
// que é como o WhatsApp mostra "imagem + texto" numa mensagem só).
export async function sendImage(sessaoId, to, arquivo, { caption, mimetype, mentions } = {}) {
  const sock = socketPronto(sessaoId);
  const jid = toJid(to);
  const conteudo = { image: Buffer.isBuffer(arquivo) ? arquivo : { url: String(arquivo) } };
  const legenda = String(caption ?? '').trim();
  if (legenda) conteudo.caption = legenda;
  if (mimetype) conteudo.mimetype = mimetype;
  if (Array.isArray(mentions) && mentions.length) conteudo.mentions = mentions;
  const result = await sock.sendMessage(jid, conteudo);
  return { jid, id: result?.key?.id ?? null, sessaoId };
}

// Participantes de um grupo com o papel de cada um, como o WhatsApp entrega.
// `admin` vem 'admin' | 'superadmin' | null/undefined.
export async function groupMembers(sessaoId, jid) {
  const sock = socketPronto(sessaoId);
  if (!String(jid).endsWith('@g.us')) throw new Error('não é um grupo');
  const meta = await sock.groupMetadata(jid);
  return (meta?.participants ?? []).map((p) => ({
    id: p.id,
    lid: p.lid ?? null,
    pn: p.jid ?? p.phoneNumber ?? null,
    admin: p.admin ?? null,
  }));
}

// JIDs de todos os participantes de um grupo — usado para "marcar todos".
// O WhatsApp notifica quem está em `mentions` mesmo sem "@fulano" no texto,
// que é como os bots de "marcar todos" evitam poluir a mensagem com números.
export async function groupParticipants(sessaoId, jid) {
  const sock = socketPronto(sessaoId);
  if (!String(jid).endsWith('@g.us')) return [];
  const meta = await sock.groupMetadata(jid);
  return (meta?.participants ?? []).map((p) => p.id).filter(Boolean);
}

// Resolve o nome (subject) de um grupo, com cache por sessão.
export async function getGroupName(sessaoId, jid) {
  const inst = instancia(sessaoId);
  if (inst.groupNameCache.has(jid)) return inst.groupNameCache.get(jid);
  if (!inst.sock || inst.state.connection !== 'open') return jid;
  try {
    const meta = await inst.sock.groupMetadata(jid);
    if (meta?.subject) {
      inst.groupNameCache.set(jid, meta.subject);
      return meta.subject;
    }
  } catch {
    // sem permissão / grupo desconhecido
  }
  return jid;
}

// Nome + total de participantes de um grupo (usado pelas boas-vindas, que
// precisam do {total}; o nome reaproveita/alimenta o mesmo cache).
export async function getGroupInfo(sessaoId, jid) {
  const inst = instancia(sessaoId);
  const cacheado = inst.groupNameCache.get(jid);
  if (!inst.sock || inst.state.connection !== 'open') return { nome: cacheado ?? jid, total: null };
  try {
    const meta = await inst.sock.groupMetadata(jid);
    if (meta?.subject) inst.groupNameCache.set(jid, meta.subject);
    return { nome: meta?.subject ?? cacheado ?? jid, total: meta?.participants?.length ?? null };
  } catch {
    return { nome: cacheado ?? jid, total: null };
  }
}

// O bot não deve saudar a si mesmo quando é adicionado a um grupo.
export function souEu(sessaoId, jid) {
  if (!jid) return false;
  const alvo = soDigitos(jid);
  if (!alvo) return false;
  const me = instancia(sessaoId).state.me;
  return [me?.id, me?.lid].some((meu) => meu && soDigitos(meu) === alvo);
}

// Lista os grupos que a conta participa (para o painel escolher quais monitorar).
export async function listGroups(sessaoId = SESSAO_PADRAO) {
  const inst = instancia(sessaoId);
  if (!inst.sock || inst.state.connection !== 'open') return [];
  const all = await inst.sock.groupFetchAllParticipating();
  return Object.values(all).map((g) => ({ id: g.id, nome: g.subject, participantes: g.participants?.length ?? 0 }));
}

// Nome de todos os grupos conhecidos por qualquer número — usado só para o
// aviso de conflito sair com nome de grupo em vez de JID.
export function nomesDeGruposConhecidos() {
  const out = {};
  for (const id of IDS_SESSOES) {
    for (const [jid, nome] of instancia(id).groupNameCache) out[jid] = nome;
  }
  return out;
}

export async function qrDataUrl(sessaoId = SESSAO_PADRAO) {
  const qr = instancia(sessaoId).state.qr;
  if (!qr) return null;
  return QRCode.toDataURL(qr);
}

// Exposto só para os testes: zera as instâncias entre casos.
export function _resetInstancias() {
  instancias.clear();
  encerrandoTudo = false;
}
