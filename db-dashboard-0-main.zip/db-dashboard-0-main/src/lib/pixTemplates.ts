// Default PIX templates and placeholder renderer.
// Admins can edit these templates in /tabelas.

export const DEFAULT_MONTANTE_TEMPLATE = `{header}

━━━━━━━━━━━━━━━

🔸 Montante: {montante}
💸 Valor: {valor}

📊 Até {contas} {contas_label}{aviso_alto}

━━━━━━━━━━━━━━━

⚡ Envio após confirmação do pagamento

📩 Envie o comprovante para dar continuidade`;

export const DEFAULT_CONTAS_TEMPLATE = `{header}

━━━━━━━━━━━━━━━

💸 {total}

⚠️ MARCAR E ENVIAR O COMPROVANTE

━━━━━━━━━━━━━━━`;

export const MONTANTE_PLACEHOLDERS = [
  "{header}", "{montante}", "{valor}", "{contas}", "{contas_label}", "{aviso_alto}",
];

export const CONTAS_PLACEHOLDERS = [
  "{header}", "{qtd}", "{min}", "{max}", "{preco_unit}", "{total}",
];

export function renderTemplate(
  template: string,
  vars: Record<string, string>,
): string {
  let out = template;
  for (const [k, v] of Object.entries(vars)) {
    out = out.split(`{${k}}`).join(v);
  }
  return out.trim();
}
