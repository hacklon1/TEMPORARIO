-- O "Nome" deixa de existir como informação própria: ele passa a ser sempre
-- igual ao usuário de login.
--
-- A coluna profiles.nome continua existindo porque várias partes do sistema
-- leem dela (get_user_ranking, relatórios, tabela de operações). Ela vira um
-- espelho do username, em vez de um campo editável à parte.

UPDATE public.profiles
   SET nome = username
 WHERE nome IS DISTINCT FROM username;

-- Mantém os dois em sincronia mesmo se algo gravar só o username.
CREATE OR REPLACE FUNCTION public.sync_nome_com_username()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  NEW.nome := NEW.username;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sync_nome_com_username ON public.profiles;
CREATE TRIGGER sync_nome_com_username
  BEFORE INSERT OR UPDATE OF username, nome ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.sync_nome_com_username();
