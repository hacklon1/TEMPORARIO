"""Metricas da VPS, processos, portas e servicos systemd."""
from __future__ import annotations

import asyncio

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel

from .. import db
from ..deps import admin_user, client_ip
from ..services import systemd, sysinfo

router = APIRouter(prefix="/api/system", tags=["system"])


@router.get("")
async def stats(user: dict = Depends(admin_user)):
    return sysinfo.snapshot()


@router.get("/processes")
async def processes(limit: int = 15, sort: str = "cpu", user: dict = Depends(admin_user)):
    # a amostragem de CPU dorme 0,25s — fora do laco de eventos, senao trava
    # os WebSockets do terminal que estiverem neste worker
    return await asyncio.to_thread(sysinfo.top_processes, max(1, min(limit, 100)), sort)


@router.get("/ports")
async def ports(user: dict = Depends(admin_user)):
    return await asyncio.to_thread(sysinfo.listening_ports)


@router.get("/services")
async def services(user: dict = Depends(admin_user)):
    return await systemd.list_units()


class ServiceAction(BaseModel):
    action: str


@router.post("/services/{name}")
async def service_action(name: str, body: ServiceAction, request: Request, user: dict = Depends(admin_user)):
    res = await systemd.control(name, body.action)
    await db.audit(f"service.{body.action}", username=user["username"], ip=client_ip(request),
                   target=name, ok=res.get("ok", False), detail=(res.get("stderr") or "")[:300])
    if not res.get("ok") and res.get("error"):
        raise HTTPException(status_code=400, detail=res["error"])
    return res


@router.get("/services/{name}/logs")
async def service_logs(name: str, lines: int = 200, user: dict = Depends(admin_user)):
    return {"unit": name, "log": await systemd.journal(name, lines)}
