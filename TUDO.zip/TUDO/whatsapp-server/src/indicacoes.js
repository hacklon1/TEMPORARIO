// Indicações: quem trouxe quem para o grupo.
//
// A Brogueira nova se apresenta dizendo de quem veio. As duas formas que
// aparecem no grupo são estruturalmente opostas:
//
//   INDICADORA DEPOIS DO GATILHO        INDICADORA ANTES DO VERBO
//   "Vim por @5511999999999"            "@5511999999999 me indicou"
//   "Vim pela indicação da @fulana"     "foi a @fulana que me trouxe"
//   "Fui indicada pela @fulana"         "@fulana me chamou pro grupo"
//
// Por isso não há um regex só: há uma lista de padrões e cada um sabe de que
// lado do texto está a indicadora. Vence o que casar MAIS CEDO na mensagem —
// numa frase com duas leituras possíveis, a primeira é a que a pessoa disse.
//
// Quem envia a mensagem é a INDICADA; a mencionada é a INDICADORA. Esta parte
// é só texto (sem db e sem Baileys), como pedidos.js — o registro fica no
// store.js e a resolução de identidade acontece no handler.
import { desestilizar } from './parser.js';
import { soDigitos } from './jid.js';

/* ── Dobra de caixa e acento PRESERVANDO o tamanho ──────────────────
   normalizeText() do parser colapsa espaços e remove diacríticos com NFD, o
   que muda os índices — e aqui precisamos recortar o texto ORIGINAL na
   posição que o regex casou (para devolver "Ana", não "ana"). Por isso a
   dobra é feita caractere a caractere e só quando o tamanho não muda. */
function dobrarChar(c) {
  const min = c.toLowerCase();
  const base = min.normalize('NFD').replace(/[̀-ͯ]/g, '');
  if (base.length === c.length) return base;
  if (min.length === c.length) return min; // ex.: 'İ' minúsculo tem 2 unidades
  return c; // emoji e pares substitutos ficam intactos
}

export function dobrar(str) {
  let out = '';
  for (const c of String(str ?? '')) out += dobrarChar(c);
  return out;
}

/* ── Peças dos padrões ─────────────────────────────────────────────── */

// Menção real do WhatsApp: sempre "@<dígitos>". Digitada à mão pode ser "@ana".
const MENCAO = "@([\\p{L}\\p{N}][\\p{L}\\p{N}._'-]*)";
// Nome escrito sem "@" ("Vim pela Ana"). Validado depois por maiúscula/registro.
const NOME = "([\\p{L}][\\p{L}.'-]+)";

// Verbos de chegada: "vim", "cheguei", "entrei", "fui indicada"...
// "foi" fica de fora de propósito: "o pagamento foi pela @fulana" não é uma
// indicação, e "foi a @fulana que me trouxe" já cai no padrão do outro lado.
const CHEGADA = '(?:vim|venho|vinha|cheguei|entrei|entramos|to|tou|estou|fui)';
// O que liga a chegada à pessoa: "por", "pela", "através da", "por causa da".
const CONECTOR =
  '(?:por|pel[oa]s?|atraves|causa|mao|indicacao|indicacoes|indicada|indicado|convidada|convidado|convite|recomendacao|recomendada|trazida|trazido)';
// Substantivos que sozinhos já dizem "indicação" ("Indicação da @fulana").
const INDICACAO_FORTE =
  '(?:indicacao|indicacoes|indicada|indicado|convidada|convidado|convite|recomendacao|recomendada|recomendado|trazida|trazido)';
// Verbos de "me trouxe": só no passado, para "pode me chamar" não virar
// indicação. "passou" ficou de fora — "me passou o link" é outra coisa.
const VERBOS = '(?:indicou|indicaram|trouxe|trouxeram|convidou|chamou|adicionou|add|apresentou)';
// Verbos que dispensam o "me" ("@fulana indicou").
const VERBOS_DIRETOS = '(?:indicou|indicaram|recomendou|convidou|trouxe)';
// Palavras de ligação entre o conector e um nome sem "@" ("pela amiga Ana").
// O \b no fim é essencial: sem ele o "a" da alternância comeria o "A" de "Ana".
const LIGACAO =
  "(?:\\s+(?:d[aeo]s?|pel[oa]s?|por|a|o|as|os|minha|meu|nossa|nosso|amiga|amigo|foi|era|indicacao|indicacoes|convite|recomendacao)\\b)*";

// Sem "@" o nome não pode ser recortado no escuro: entre "vim pela Ana" e
// "vim pelo grupo" a diferença é justamente ser um nome próprio.
const PALAVRAS_COMUNS = new Set([
  'grupo', 'grupos', 'link', 'links', 'lista', 'indicacao', 'indicacoes', 'convite', 'divulgacao',
  'amiga', 'amigas', 'amigo', 'colega', 'prima', 'irma', 'mae', 'tia', 'vizinha', 'sobrinha',
  'menina', 'meninas', 'mulher', 'moca', 'pessoa', 'gente', 'todas', 'todos', 'voce', 'voces',
  'dela', 'dele', 'ela', 'ele', 'minha', 'meu', 'nossa', 'nosso', 'aqui', 'hoje', 'ontem', 'agora',
  'causa', 'favor', 'deus', 'insta', 'instagram', 'whatsapp', 'zap', 'face', 'facebook', 'tiktok',
  'telegram', 'anuncio', 'propaganda', 'publicidade', 'status', 'video', 'chamada', 'bot',
]);

const criar = (fonte) => new RegExp(fonte, 'du'); // 'd' = índices dos grupos

// Com "@" o que estiver entre o gatilho e a pessoa pode ser qualquer coisa: o
// próprio "@" delimita onde o nome começa. Sem ele, o recorte é cego — daí as
// duas listas, com folgas diferentes.
//
//   `onde: 'depois'` → a indicadora vem depois do gatilho ("vim por @fulana")
//   `onde: 'antes'`  → a indicadora vem antes do verbo  ("@fulana me indicou")

const PADROES_MENCAO = [
  // "quem me indicou foi a @fulana"
  { id: 'quem-me-indicou', onde: 'depois', re: criar(`\\bquem\\s+(?:me|nos)\\s+${VERBOS}\\b[^@\\n]{0,20}?${MENCAO}`) },
  // "vim por @fulana", "cheguei pela indicação da @fulana", "fui indicada pela @fulana"
  { id: 'chegada', onde: 'depois', re: criar(`\\b${CHEGADA}\\b[^@\\n]{0,40}?\\b${CONECTOR}\\b[^@\\n]{0,25}?${MENCAO}`) },
  // "indicação da @fulana", "convite da @fulana"
  { id: 'indicacao', onde: 'depois', re: criar(`\\b${INDICACAO_FORTE}\\b[^@\\n]{0,25}?${MENCAO}`) },
  // "me indicou: @fulana"
  { id: 'me-indicou', onde: 'depois', re: criar(`\\b(?:me|nos)\\s+${VERBOS}\\b[^@\\n]{0,20}?${MENCAO}`) },
  // "@fulana me indicou", "foi a @fulana que me trouxe"
  { id: 'mencao-me-verbo', onde: 'antes', re: criar(`${MENCAO}[^@\\n]{0,25}?\\b(?:me|nos|mim)\\b[^@\\n]{0,12}?${VERBOS}\\b`) },
  // "@fulana indicou"
  { id: 'mencao-verbo', onde: 'antes', re: criar(`${MENCAO}\\s*(?:que\\s+)?\\b${VERBOS_DIRETOS}\\b`) },
];

// Sem "@" o nome tem de estar colado no gatilho, só com palavras de ligação
// no meio: com a mesma folga da lista acima, "vim por causa do meu Marido"
// viraria indicação e "minha amiga me indicou" apontaria para "minha".
const PADROES_NOME = [
  { id: 'quem-me-indicou', onde: 'depois', re: criar(`\\bquem\\s+(?:me|nos)\\s+${VERBOS}\\b${LIGACAO}\\s+${NOME}`) },
  { id: 'chegada', onde: 'depois', re: criar(`\\b${CHEGADA}\\b[^\\n]{0,40}?\\b${CONECTOR}\\b${LIGACAO}\\s+${NOME}`) },
  { id: 'indicacao', onde: 'depois', re: criar(`\\b${INDICACAO_FORTE}\\b${LIGACAO}\\s+${NOME}`) },
  { id: 'me-indicou', onde: 'depois', re: criar(`\\b(?:me|nos)\\s+${VERBOS}\\b${LIGACAO}\\s+${NOME}`) },
  { id: 'mencao-me-verbo', onde: 'antes', re: criar(`${NOME}(?:\\s+que)?\\s+(?:me|nos|mim)\\s+${VERBOS}\\b`) },
  { id: 'mencao-verbo', onde: 'antes', re: criar(`${NOME}\\s+(?:que\\s+)?${VERBOS_DIRETOS}\\b`) },
];

// Todos os padrões que casam, do que começa mais cedo na mensagem para o mais
// tarde; empate resolve pela ordem da lista (a leitura mais específica vem
// primeiro). Devolve a lista inteira porque um nome sem "@" pode ser recusado
// depois — aí vale tentar a próxima leitura em vez de desistir da mensagem.
function casamentos(texto, padroes) {
  const achados = [];
  for (const [ordem, p] of padroes.entries()) {
    const m = p.re.exec(texto);
    if (m && m.indices?.[1]) achados.push({ p, m, ordem });
  }
  return achados.sort((a, b) => a.m.index - b.m.index || a.ordem - b.ordem);
}

// Um nome sem "@" só vale se parecer nome próprio: começa com maiúscula (ou a
// mensagem inteira é em caixa alta) e não é palavra comum. `nomesConhecidos`
// (nomes já vistos no grupo, dobrados) libera também os escritos em minúscula.
function nomeAceitavel(bruto, nomesConhecidos) {
  const dobrado = dobrar(bruto);
  if (dobrado.length < 3) return false;
  if (PALAVRAS_COMUNS.has(dobrado)) return false;
  if (nomesConhecidos?.has(dobrado)) return true;
  return bruto[0] !== dobrado[0]; // primeira letra em maiúscula
}

/**
 * Analisa uma mensagem em busca de uma indicação.
 * Devolve `null` quando a mensagem não é uma indicação.
 *
 *   { padrao, token, digitos, viaMencao, frase }
 *
 * `token` é a indicadora como ela aparece no texto (sem o "@"); `digitos` é
 * preenchido quando o token é numérico (menção real do WhatsApp).
 */
export function analisarIndicacao(texto, { nomesConhecidos = null } = {}) {
  const original = desestilizar(texto);
  if (!original.trim()) return null;
  const alvo = dobrar(original);

  const [comMencao] = casamentos(alvo, PADROES_MENCAO);
  if (comMencao) return resultado(comMencao, original, true);

  for (const candidato of casamentos(alvo, PADROES_NOME)) {
    const [ini, fim] = candidato.m.indices[1];
    if (nomeAceitavel(original.slice(ini, fim), nomesConhecidos)) return resultado(candidato, original, false);
  }
  return null;
}

function resultado({ p, m }, original, viaMencao) {
  const [ini, fim] = m.indices[1];
  const token = original.slice(ini, fim);
  const digitos = /^\d+$/.test(token) ? token : null;
  return {
    padrao: p.id,
    onde: p.onde,
    token,
    digitos,
    viaMencao,
    frase: original.slice(m.index, m.index + m[0].length).trim().slice(0, 120),
  };
}

/* ── Menções reais da mensagem (Baileys) ───────────────────────────── */

// O "@5511..." do texto é só a grafia; o JID de verdade vem no contextInfo.
// Cada tipo de mensagem carrega o seu, daí a varredura.
export function extrairMencoes(msg) {
  const m = msg?.message ?? msg ?? {};
  const contextos = [
    m.extendedTextMessage?.contextInfo,
    m.imageMessage?.contextInfo,
    m.videoMessage?.contextInfo,
    m.documentMessage?.contextInfo,
    m.stickerMessage?.contextInfo,
    m.contextInfo,
  ];
  const jids = new Set();
  for (const ctx of contextos) {
    for (const jid of ctx?.mentionedJid ?? []) if (jid) jids.add(String(jid));
  }
  return [...jids];
}

/**
 * Casa a indicadora do texto com o JID mencionado de verdade.
 * Devolve { id, digitos, nome } — qualquer campo pode vir null: a indicadora
 * pode nunca ter falado no grupo, e mesmo assim a indicação conta.
 */
export function resolverIndicadora(analise, mencoes = []) {
  const lista = (mencoes ?? []).filter(Boolean).map(String);
  const digitos = analise?.digitos ?? null;
  let id = null;

  if (digitos) {
    id =
      lista.find((jid) => soDigitos(jid) === digitos) ??
      // O WhatsApp às vezes grafa o número sem o código do país (ou com o
      // nono dígito a mais) — comparar pelo fim casa as duas formas.
      lista.find((jid) => {
        const d = soDigitos(jid);
        return d && (d.endsWith(digitos) || digitos.endsWith(d));
      }) ??
      null;
  } else if (analise?.viaMencao && lista.length === 1) {
    // "@Ana" com uma menção só: o JID é dela, ainda que o texto traga o nome.
    id = lista[0];
  }

  return {
    id,
    digitos: digitos ?? (id ? soDigitos(id) : null),
    nome: analise?.digitos ? null : analise?.token ?? null,
  };
}
