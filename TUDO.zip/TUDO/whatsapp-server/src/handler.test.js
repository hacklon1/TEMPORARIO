// Telemetria (montante/contas) só de Operador = ADMINISTRADOR do grupo.
//
// O bug: qualquer participante que escrevesse "Montante: 300" virava lançamento
// financeiro. Mensagem de Brogueira é PEDIDO (vai para db.pedidos), não produção.
//
// DATA_DIR aponta para um diretório temporário ANTES de importar db.js — o
// handler persiste em disco e o db.json de produção não pode ser tocado.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-handler-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb, getConfigSessao } = await import('./db.js');
const { processMessage } = await import('./handler.js');
const { limparCacheMembros } = await import('./membros.js');

loadDb();

const GRUPO = '120363000000000000@g.us';
const ADMIN = '111111111111111@lid';
const MEMBRO = '222222222222222@lid';

// Como o WhatsApp entrega os participantes (admin: 'admin'|'superadmin'|null).
const MEMBROS = [
  { id: ADMIN, lid: ADMIN, pn: '5573981810457@s.whatsapp.net', admin: 'admin' },
  { id: MEMBRO, lid: MEMBRO, pn: '5573999999999@s.whatsapp.net', admin: null },
];

function preparar({ monitorPrivate = true } = {}) {
  const db = getDb();
  db.messages = [];
  db.pedidos = [];
  db.stats = { totalMessages: 0, totalGroups: 0, totalMontante: 0, totalContasValor: 0, totalContasQtd: 0, startedAt: null };
  Object.assign(getConfigSessao(), { monitorMode: 'all', monitorPrivate, autoReplyEnabled: false, welcomeEnabled: false });
  limparCacheMembros(); // o índice de admins tem TTL de 10 min entre os testes
  return db;
}

function msg(de, texto, { grupo = GRUPO, id = null } = {}) {
  return {
    key: grupo
      ? { remoteJid: grupo, participant: de, fromMe: false, id }
      : { remoteJid: de, fromMe: false, id },
    pushName: de === ADMIN ? 'Operador' : 'Brogueira',
    message: { conversation: texto },
  };
}

function deps({ membros = MEMBROS, erro = null } = {}) {
  const chamadas = [];
  const enviadas = [];
  return {
    chamadas,
    enviadas,
    reply: async (to, texto, opts) => { enviadas.push({ to, texto, mentions: opts?.mentions }); },
    getGroupName: async () => 'Grupo de Teste',
    getGroupMembers: async (jid) => {
      chamadas.push(jid);
      if (erro) throw erro;
      return membros;
    },
    getGroupParticipants: async () => ['x@lid', 'y@lid'],
  };
}

const FINANCEIRA = '✅ ATENDIMENTO\n𝗠𝗼𝗻𝘁𝗮𝗻𝘁𝗲: R$ 300,00\n💸 𝗩𝗮𝗹𝗼𝗿 R$ 6,00';

test('mensagem financeira de administrador vira lançamento', async () => {
  const db = preparar();
  await processMessage(msg(ADMIN, FINANCEIRA), deps());
  assert.equal(db.messages.length, 1);
  assert.equal(db.messages[0].montante, 300);
  assert.equal(db.messages[0].operatorId, ADMIN);
  assert.equal(db.stats.totalMontante, 300);
});

test('mesma mensagem vinda de Brogueira é ignorada pela telemetria', async () => {
  const db = preparar();
  await processMessage(msg(MEMBRO, FINANCEIRA), deps());
  assert.deepEqual(db.messages, []);
  assert.equal(db.stats.totalMessages, 0);
  assert.equal(db.stats.totalMontante, 0);
  assert.equal(db.stats.totalContasValor, 0);
});

test('sem conseguir ler os membros do grupo, não grava (papel desconhecido)', async () => {
  const db = preparar();
  await processMessage(msg(ADMIN, FINANCEIRA), deps({ erro: new Error('sem conexão') }));
  assert.deepEqual(db.messages, []);
});

test('pedido de Brogueira continua sendo registrado (e não vira telemetria)', async () => {
  const db = preparar();
  await processMessage(msg(MEMBRO, 'https://site.com/p?id=357497224 quero 400 de montante'), deps());
  assert.equal(db.pedidos.length, 1);
  assert.equal(db.pedidos[0].papel, 'brogueira');
  assert.deepEqual(db.messages, []);
});

test('o papel é resolvido uma vez só por mensagem', async () => {
  preparar();
  const d = deps();
  // Pedido + valores na mesma mensagem: passa pelo filtro de pedido e pelo de
  // telemetria, mas só pode consultar os membros do grupo uma vez.
  await processMessage(msg(ADMIN, `https://site.com/p?id=1 ${FINANCEIRA}`), d);
  assert.equal(d.chamadas.length, 1);
});

test('link repetido acima do limite alerta no grupo configurado, marcando todos', async () => {
  const db = preparar();
  db.alertas = { links: {}, dias: {}, ultimo: null };
  Object.assign(getConfigSessao(), {
    alertaRepetidosEnabled: true,
    alertaRepetidosGrupo: '120363999999999999@g.us',
    alertaRepetidosMensagem: 'Alerta, link repetido',
    alertaRepetidosPorLink: 2,
    alertaRepetidosPorDia: 0,
    alertaRepetidosMarcarTodos: true,
  });
  const d = deps();

  await processMessage(msg(MEMBRO, 'https://okok.com/?id=5 2 contas'), d);
  assert.equal(d.enviadas.length, 0, 'primeiro envio não alerta');

  await processMessage(msg(MEMBRO, 'https://okok.com/?id=5 3 contas'), d);
  assert.equal(d.enviadas.length, 1);
  assert.equal(d.enviadas[0].to, '120363999999999999@g.us', 'vai para o grupo de alerta, não para o de origem');
  assert.match(d.enviadas[0].texto, /Alerta, link repetido/);
  assert.match(d.enviadas[0].texto, /2ª vez/);
  assert.deepEqual(d.enviadas[0].mentions, ['x@lid', 'y@lid']);

  // Desligado, a mesma sequência não manda nada.
  preparar();
  db.alertas = { links: {}, dias: {}, ultimo: null };
  getConfigSessao().alertaRepetidosEnabled = false;
  const d2 = deps();
  await processMessage(msg(MEMBRO, 'https://okok.com/?id=7 2 contas'), d2);
  await processMessage(msg(MEMBRO, 'https://okok.com/?id=7 3 contas'), d2);
  assert.equal(d2.enviadas.length, 0);
});

test('conversa privada não depende de admin (não existe grupo)', async () => {
  const db = preparar();
  await processMessage(msg('5573981810457@s.whatsapp.net', FINANCEIRA, { grupo: null }), deps());
  assert.equal(db.messages.length, 1);
  assert.equal(db.messages[0].groupId, null);
});


/* ═══════════ Vários números no mesmo servidor ═══════════
   Cada número roda só os recursos que estão ligados nele, com a SUA config.
   E a mesma mensagem, vista por dois números, conta uma vez só. */

const { getSessao } = await import('./db.js');
const { recursosVazios } = await import('./sessoes.js');

// deps() de um número específico: recursos e config só deste número.
function depsDe(id, recursos = {}, config = {}, opts = {}) {
  const d = deps(opts);
  d.sessao = {
    id,
    nome: `Número ${id}`,
    ativa: true,
    recursos: { ...recursosVazios(), ...recursos },
    config: { monitorMode: 'all', monitorPrivate: true, autoReplyEnabled: false, ...config },
  };
  return d;
}

test('número sem o recurso "monitorar" não grava lançamento', async () => {
  const db = preparar();
  await processMessage(msg(ADMIN, FINANCEIRA, { id: 'MSG1' }), depsDe('n2', { pedidos: true }));
  assert.deepEqual(db.messages, [], 'o número 2 só cuida de pedidos');
});

test('número sem o recurso "pedidos" não grava pedido', async () => {
  const db = preparar();
  await processMessage(msg(MEMBRO, 'https://site.com/p?id=1 quero 400 de montante', { id: 'MSG2' }),
    depsDe('n2', { monitorar: true }));
  assert.deepEqual(db.pedidos, []);
});

test('cada número usa a SUA lista de grupos monitorados', async () => {
  const db = preparar();
  const fora = depsDe('n2', { monitorar: true }, { monitorMode: 'specific', monitoredGroups: ['outro@g.us'] });
  await processMessage(msg(ADMIN, FINANCEIRA, { id: 'MSG3' }), fora);
  assert.deepEqual(db.messages, [], 'o grupo não está na lista DESTE número');

  const dentro = depsDe('n2', { monitorar: true }, { monitorMode: 'specific', monitoredGroups: [GRUPO] });
  await processMessage(msg(ADMIN, FINANCEIRA, { id: 'MSG4' }), dentro);
  assert.equal(db.messages.length, 1);
  assert.equal(db.messages[0].sessaoId, 'n2', 'o lançamento fica marcado com o número que o viu');
});

test('DOIS números no mesmo grupo não contam a mesma mensagem duas vezes', async () => {
  const db = preparar();
  const mensagem = msg(ADMIN, FINANCEIRA, { id: 'MESMA-MSG' });

  await processMessage(mensagem, depsDe('n1', { monitorar: true }));
  await processMessage(mensagem, depsDe('n2', { monitorar: true }));

  assert.equal(db.messages.length, 1, 'a segunda cópia é descartada pelo id da mensagem');
  assert.equal(db.messages[0].sessaoId, 'n1', 'fica com quem chegou primeiro');
  assert.equal(db.stats.totalMontante, 300, 'e o total não dobra');
});

test('a deduplicação vale também para pedidos e indicações', async () => {
  const db = preparar();
  const pedido = msg(MEMBRO, 'https://site.com/p?id=99 quero 400 de montante', { id: 'PED-1' });
  await processMessage(pedido, depsDe('n1', { pedidos: true }));
  await processMessage(pedido, depsDe('n3', { pedidos: true }));
  assert.equal(db.pedidos.length, 1);

  db.indicacoes = [];
  const indicacao = msg(MEMBRO, 'vim por @5573981810457', { id: 'IND-1' });
  await processMessage(indicacao, depsDe('n1', { indicacoes: true }));
  await processMessage(indicacao, depsDe('n2', { indicacoes: true }));
  assert.equal(db.indicacoes.length, 1);
});

test('mensagens diferentes do mesmo número continuam contando normalmente', async () => {
  const db = preparar();
  await processMessage(msg(ADMIN, FINANCEIRA, { id: 'A' }), depsDe('n1', { monitorar: true }));
  await processMessage(msg(ADMIN, FINANCEIRA, { id: 'B' }), depsDe('n1', { monitorar: true }));
  assert.equal(db.messages.length, 2);
  assert.equal(db.stats.totalMontante, 600);
});

test('resposta automática e comandos obedecem ao recurso de cada número', async () => {
  preparar();
  // Resposta automática ligada na config, mas o recurso desligado no número.
  const semRecurso = depsDe('n2', {}, { autoReplyEnabled: true, autoReplyMessage: 'oi', autoReplyGroups: true });
  await processMessage(msg(MEMBRO, 'bom dia', { id: 'AR1' }), semRecurso);
  assert.equal(semRecurso.enviadas.length, 0);

  const comRecurso = depsDe('n2', { autoResposta: true }, { autoReplyEnabled: true, autoReplyMessage: 'oi', autoReplyGroups: true });
  await processMessage(msg(MEMBRO, 'bom dia', { id: 'AR2' }), comRecurso);
  assert.equal(comRecurso.enviadas.length, 1, 'auto-resposta com recurso ligado');

  // Comando: sem o recurso, silêncio total (nem "sem permissão").
  // O remetente é autorizado pelos dígitos do LID (é o que a mensagem de teste
  // carrega — sem participantPn, como acontece em grupo antes do resolve).
  const semComandos = depsDe('n2', {}, { commandAuthorizedNumbers: ['222222222222222'] });
  await processMessage(msg(MEMBRO, '!AJUDA', { id: 'CMD1' }), semComandos);
  assert.equal(semComandos.enviadas.length, 0, 'comando sem recurso = silêncio');

  const comComandos = depsDe('n2', { comandos: true }, { commandAuthorizedNumbers: ['222222222222222'] });
  await processMessage(msg(MEMBRO, '!AJUDA', { id: 'CMD2' }), comComandos);
  assert.equal(comComandos.enviadas.length, 1, 'comando com recurso ligado responde');
  assert.match(comComandos.enviadas[0].texto, /Comandos disponíveis/);
});

test('o alerta de link repetido sai pelo número que viu a repetição, com a config dele', async () => {
  const db = preparar();
  db.alertas = { links: {}, dias: {}, ultimo: null };
  const d = depsDe('n3', { pedidos: true, alertas: true }, {
    alertaRepetidosEnabled: true,
    alertaRepetidosGrupo: 'grupo-do-n3@g.us',
    alertaRepetidosPorLink: 2,
    alertaRepetidosMarcarTodos: false,
  });
  await processMessage(msg(MEMBRO, 'https://zz.com/?id=1 2 contas', { id: 'R1' }), d);
  await processMessage(msg(MEMBRO, 'https://zz.com/?id=1 3 contas', { id: 'R2' }), d);
  assert.equal(d.enviadas.length, 1);
  assert.equal(d.enviadas[0].to, 'grupo-do-n3@g.us');
  assert.equal(getSessao('n1').config.alertaRepetidosGrupo !== 'grupo-do-n3@g.us', true,
    'a config usada foi a do número 3, não a global');
});
