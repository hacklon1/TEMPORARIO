// Mídia dos agendamentos/envios: onde o arquivo mora e o que é aceito.
//
// O nome do arquivo vem do multer, mas ele também chega de volta pelo db.json
// (que é editável à mão) — por isso todo caminho passa por caminhoMidia(),
// que recusa qualquer nome capaz de escapar de uploads/.
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

export const UPLOAD_DIR = process.env.UPLOAD_DIR
  ? path.resolve(process.env.UPLOAD_DIR)
  : path.resolve(__dirname, '..', 'uploads');

// Formatos que o WhatsApp renderiza como imagem na conversa.
export const MIMES_IMAGEM = ['image/jpeg', 'image/png', 'image/webp'];
export const MAX_IMAGEM = 5 * 1024 * 1024; // 5 MB — acima disso o envio costuma falhar

export function ehImagemSuportada(mime) {
  return MIMES_IMAGEM.includes(String(mime || '').toLowerCase());
}

// Resolve um arquivo de mídia DENTRO de uploads/. Lança se o nome tentar sair
// do diretório (../, caminho absoluto, separadores).
export function caminhoMidia(nomeArquivo) {
  const nome = String(nomeArquivo ?? '');
  if (!nome || nome !== path.basename(nome) || nome === '.' || nome === '..') {
    throw new Error('nome de arquivo inválido');
  }
  const destino = path.join(UPLOAD_DIR, nome);
  if (path.dirname(destino) !== UPLOAD_DIR) throw new Error('nome de arquivo inválido');
  return destino;
}

// Forma canônica do campo `media` de um agendamento (ou null).
export function normalizarMidia(midia) {
  if (!midia || typeof midia !== 'object') return null;
  const file = String(midia.file ?? '').trim();
  if (!file) return null;
  caminhoMidia(file); // valida o nome; lança se for suspeito
  const mime = String(midia.mime ?? '').toLowerCase();
  if (!ehImagemSuportada(mime)) throw new Error(`formato não suportado: ${mime || 'desconhecido'}`);
  return { file, mime, nome: String(midia.nome ?? file).slice(0, 120) };
}

export function midiaExiste(midia) {
  try {
    return Boolean(midia?.file) && fs.existsSync(caminhoMidia(midia.file));
  } catch {
    return false;
  }
}

// Apaga o arquivo de uma mídia. Nunca lança — é chamado em limpeza.
export function removerMidia(midia) {
  try {
    if (!midia?.file) return false;
    fs.rmSync(caminhoMidia(midia.file), { force: true });
    return true;
  } catch {
    return false;
  }
}
