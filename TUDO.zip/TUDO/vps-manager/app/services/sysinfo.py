"""Metricas da VPS via psutil."""
from __future__ import annotations

import os
import platform
import shutil
import socket
import time

import psutil

_BOOT = psutil.boot_time()


def _bytes(n: float) -> float:
    return round(n / (1024 ** 3), 2)


def snapshot() -> dict:
    vm = psutil.virtual_memory()
    sw = psutil.swap_memory()
    du = shutil.disk_usage("/")
    la1, la5, la15 = os.getloadavg()
    net = psutil.net_io_counters()
    try:
        temps = psutil.sensors_temperatures() or {}
        temp = next((t[0].current for t in temps.values() if t), None)
    except Exception:
        temp = None
    return {
        "hostname": socket.gethostname(),
        "os": f"{platform.system()} {platform.release()}",
        "distro": _distro(),
        "kernel": platform.release(),
        "arch": platform.machine(),
        "python": platform.python_version(),
        "uptime_seconds": int(time.time() - _BOOT),
        "boot_time": _BOOT,
        "cpu": {
            "percent": psutil.cpu_percent(interval=None),
            "cores": psutil.cpu_count(logical=True),
            "physical": psutil.cpu_count(logical=False),
            "per_core": psutil.cpu_percent(interval=None, percpu=True),
            "load": [round(la1, 2), round(la5, 2), round(la15, 2)],
            "temp": temp,
        },
        "memory": {
            "total_gb": _bytes(vm.total), "used_gb": _bytes(vm.used),
            "available_gb": _bytes(vm.available), "percent": vm.percent,
            "swap_total_gb": _bytes(sw.total), "swap_used_gb": _bytes(sw.used),
            "swap_percent": sw.percent,
        },
        "disk": {
            "total_gb": _bytes(du.total), "used_gb": _bytes(du.used),
            "free_gb": _bytes(du.free),
            "percent": round(du.used / du.total * 100, 1) if du.total else 0,
        },
        "network": {
            "sent_gb": _bytes(net.bytes_sent), "recv_gb": _bytes(net.bytes_recv),
            "sent_bytes": net.bytes_sent, "recv_bytes": net.bytes_recv,
        },
        "processes": len(psutil.pids()),
    }


def _distro() -> str:
    try:
        with open("/etc/os-release", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("PRETTY_NAME="):
                    return line.split("=", 1)[1].strip().strip('"')
    except OSError:
        pass
    return platform.platform()


def top_processes(limit: int = 15, sort: str = "cpu") -> list[dict]:
    """Duas amostras separadas por um intervalo curto — sem isso o psutil
    devolve 0,0% para todo mundo na primeira leitura e a ordem fica sem sentido."""
    procs: dict[int, psutil.Process] = {}
    for p in psutil.process_iter():
        try:
            p.cpu_percent(None)          # zera o contador
            procs[p.pid] = p
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    time.sleep(0.25)

    cores = psutil.cpu_count(logical=True) or 1
    out = []
    for pid, p in procs.items():
        try:
            with p.oneshot():
                cpu = p.cpu_percent(None) / cores      # % da maquina inteira
                out.append({
                    "pid": pid,
                    "name": p.name(),
                    "user": p.username(),
                    "cpu": round(cpu, 1),
                    "mem": round(p.memory_percent(), 1),
                    "status": p.status(),
                    "cmd": " ".join(p.cmdline())[:160] or p.name(),
                })
        except (psutil.NoSuchProcess, psutil.AccessDenied, ZeroDivisionError):
            continue

    key = "mem" if sort == "mem" else "cpu"
    out.sort(key=lambda x: (x[key], x["mem"]), reverse=True)
    return out[:limit]


def listening_ports() -> list[dict]:
    out = []
    for c in psutil.net_connections(kind="inet"):
        if c.status != psutil.CONN_LISTEN or not c.laddr:
            continue
        name = ""
        if c.pid:
            try:
                name = psutil.Process(c.pid).name()
            except Exception:
                name = ""
        out.append({"addr": c.laddr.ip, "port": c.laddr.port, "pid": c.pid, "process": name})
    out.sort(key=lambda x: x["port"])
    # remove duplicados ipv4/ipv6 do mesmo processo+porta
    seen, uniq = set(), []
    for o in out:
        k = (o["port"], o["process"])
        if k in seen:
            continue
        seen.add(k)
        uniq.append(o)
    return uniq
