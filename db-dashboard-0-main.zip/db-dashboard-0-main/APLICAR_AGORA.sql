-- ============================================================
-- COLE ISTO NO SQL EDITOR DO SUPABASE E EXECUTE.
--
-- Feito para o estado atual do seu banco: não recria username nem
-- operator_type (a Lovable já criou), não mexe no handle_new_user
-- (o dela já preserva maiúsculas). Só o que está faltando.
--
-- Pode rodar mais de uma vez sem problema.
-- ============================================================


-- ------------------------------------------------------------
-- 1. DONO com poderes de Admin
--
-- Toda política RLS do sistema checa has_role(auth.uid(), 'admin').
-- Redefinindo essa função, o DONO passa a valer em todas de uma vez.
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND (
        role = _role
        OR (_role::text = 'admin' AND role::text = 'owner')
      )
  )
$$;


-- ------------------------------------------------------------
-- 2. Nenhum Admin pode remover ou rebaixar um DONO
-- ------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.protect_dono_role()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  actor UUID := auth.uid();
BEGIN
  -- service_role (edge functions) não tem auth.uid(); lá quem valida
  -- quem chamou é a própria função admin-users.
  IF actor IS NULL THEN
    IF TG_OP = 'DELETE' THEN RETURN OLD; END IF;
    RETURN NEW;
  END IF;

  IF TG_OP = 'DELETE' THEN
    IF OLD.role::text = 'owner' AND NOT public.is_dono(actor) THEN
      RAISE EXCEPTION 'Apenas um DONO pode remover outro DONO';
    END IF;
    RETURN OLD;
  END IF;

  IF TG_OP = 'UPDATE' THEN
    IF (OLD.role::text = 'owner' OR NEW.role::text = 'owner')
       AND NOT public.is_dono(actor) THEN
      RAISE EXCEPTION 'Apenas um DONO pode alterar o papel de DONO';
    END IF;
    RETURN NEW;
  END IF;

  IF NEW.role::text = 'owner' AND NOT public.is_dono(actor)
     AND public.dono_exists() THEN
    RAISE EXCEPTION 'Apenas um DONO pode conceder o papel de DONO';
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS protect_dono_role ON public.user_roles;
CREATE TRIGGER protect_dono_role
  BEFORE INSERT OR UPDATE OR DELETE ON public.user_roles
  FOR EACH ROW EXECUTE FUNCTION public.protect_dono_role();


-- ------------------------------------------------------------
-- 3. Senha visível para Admin/DONO
--
-- ATENÇÃO: guarda a senha em texto legível. O Supabase Auth continua
-- com o hash; esta tabela é só um espelho para exibição.
--
-- Sem nenhuma política de RLS, de propósito: ninguém lê isto pelo
-- navegador. O único caminho é a edge function admin-users, que usa
-- service_role e já valida se quem chamou é admin.
-- ------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.user_passwords (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  password TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.user_passwords ENABLE ROW LEVEL SECURITY;
REVOKE ALL ON public.user_passwords FROM PUBLIC;
REVOKE ALL ON public.user_passwords FROM anon;
REVOKE ALL ON public.user_passwords FROM authenticated;


-- ------------------------------------------------------------
-- 4. O "Nome" deixa de existir: vira espelho do usuário
--
-- A coluna continua no banco porque get_user_ranking, relatórios e a
-- tabela de Operações leem dela.
-- ------------------------------------------------------------
UPDATE public.profiles
   SET nome = username
 WHERE username IS NOT NULL
   AND nome IS DISTINCT FROM username;

CREATE OR REPLACE FUNCTION public.sync_nome_com_username()
RETURNS TRIGGER
LANGUAGE plpgsql
AS $$
BEGIN
  IF NEW.username IS NOT NULL THEN
    NEW.nome := NEW.username;
  END IF;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS sync_nome_com_username ON public.profiles;
CREATE TRIGGER sync_nome_com_username
  BEFORE INSERT OR UPDATE OF username, nome ON public.profiles
  FOR EACH ROW EXECUTE FUNCTION public.sync_nome_com_username();


-- ------------------------------------------------------------
-- CONFERÊNCIA — o resultado deve mostrar tem_poder_de_admin = true
-- para quem é DONO.
-- ------------------------------------------------------------
SELECT p.username,
       r.role,
       public.has_role(p.id, 'admin') AS tem_poder_de_admin
FROM public.profiles p
JOIN public.user_roles r ON r.user_id = p.id
ORDER BY r.role, p.username;
