ALTER TABLE public.operations
  ADD COLUMN lucro_contas numeric
  GENERATED ALWAYS AS ((saque_contas + salario_contas) - deposito_contas) STORED;

CREATE OR REPLACE FUNCTION public.get_user_ranking()
RETURNS TABLE(user_id uuid, nome text, lucro numeric, deposito numeric, saque numeric, pedidos bigint)
LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT o.user_id,
         COALESCE(p.nome, '—'),
         COALESCE(SUM(o.lucro + o.lucro_contas), 0),
         COALESCE(SUM(o.deposito + o.deposito_contas), 0),
         COALESCE(SUM(o.saque + o.saque_contas), 0),
         COUNT(*)::bigint
  FROM public.operations o
  LEFT JOIN public.profiles p ON p.id = o.user_id
  GROUP BY o.user_id, p.nome
  ORDER BY 3 DESC
$$;