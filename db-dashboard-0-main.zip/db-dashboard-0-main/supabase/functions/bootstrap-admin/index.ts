// Seeds the initial admin user. Idempotent — safe to call multiple times.
// No auth required: it only ever (re)provisions the single hard-coded admin.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

const ADMIN_EMAIL = "arao01@gmail.com";
const ADMIN_PASSWORD = "12345678";
const ADMIN_NAME = "Arão";

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const supabase = createClient(
      Deno.env.get("SUPABASE_URL")!,
      Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!,
    );

    // Try to find existing user
    const { data: list, error: listErr } = await supabase.auth.admin.listUsers({
      page: 1,
      perPage: 200,
    });
    if (listErr) throw listErr;

    let userId = list.users.find((u) => u.email === ADMIN_EMAIL)?.id;

    if (!userId) {
      const { data: created, error: createErr } =
        await supabase.auth.admin.createUser({
          email: ADMIN_EMAIL,
          password: ADMIN_PASSWORD,
          email_confirm: true,
          user_metadata: { nome: ADMIN_NAME },
        });
      if (createErr) throw createErr;
      userId = created.user!.id;
    } else {
      // Make sure the password matches what the spec requires.
      await supabase.auth.admin.updateUserById(userId, {
        password: ADMIN_PASSWORD,
        email_confirm: true,
      });
    }

    // Ensure profile exists
    await supabase.from("profiles").upsert({
      id: userId,
      nome: ADMIN_NAME,
      email: ADMIN_EMAIL,
    });

    // Ensure admin role exists (unique constraint => onConflict no-op)
    await supabase
      .from("user_roles")
      .upsert({ user_id: userId, role: "admin" }, {
        onConflict: "user_id,role",
      });

    return new Response(
      JSON.stringify({ ok: true, user_id: userId }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 200,
      },
    );
  } catch (e) {
    console.error("bootstrap-admin error", e);
    return new Response(
      JSON.stringify({ ok: false, error: String(e?.message ?? e) }),
      {
        headers: { ...corsHeaders, "Content-Type": "application/json" },
        status: 500,
      },
    );
  }
});
