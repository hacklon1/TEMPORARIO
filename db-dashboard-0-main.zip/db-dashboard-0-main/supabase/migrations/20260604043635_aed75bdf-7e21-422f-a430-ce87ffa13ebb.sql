
-- 1) Revoke EXECUTE on has_role from anon/public (keep for authenticated, needed by RLS policies)
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM PUBLIC;
REVOKE EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) FROM anon;
GRANT EXECUTE ON FUNCTION public.has_role(uuid, public.app_role) TO authenticated;

-- 2) Drop broad public SELECT policies that allow listing objects in public buckets.
-- Public buckets still serve files via direct URLs without needing storage.objects SELECT.
DROP POLICY IF EXISTS "Public read shortcut-images" ON storage.objects;
DROP POLICY IF EXISTS "Public view tables-files" ON storage.objects;
