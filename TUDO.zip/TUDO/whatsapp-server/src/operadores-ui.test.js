// A busca das Brogueiras e a aba Operadores, num DOM real (jsdom).
//
// As duas são filtro/render puro no navegador: sem teste aqui, um erro só
// apareceria na tela do usuário — e um erro de sintaxe no app.js derruba o
// painel INTEIRO, não só a aba nova.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const PUBLIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

const BROGUEIRAS = {
  resumo: { pedidos: 6, brogueirasAtivas: 3 },
  brogueiras: [
    { id: '111@lid', pn: '5573988887777@s.whatsapp.net', nome: 'Ana Paula', papel: 'brogueira', pedidos: 3, montanteTotal: 900, contasTotal: 0, links: ['a'], repetidos: 0, repetidosDeOutra: 0, dias: [] },
    { id: '222@lid', pn: '5511912345678@s.whatsapp.net', nome: 'Bianca', papel: 'brogueira', pedidos: 2, montanteTotal: 0, contasTotal: 7, links: ['b'], repetidos: 1, repetidosDeOutra: 0, dias: [] },
    { id: '333@lid', pn: null, nome: 'Cláudia', papel: 'desconhecido', pedidos: 1, montanteTotal: 200, contasTotal: 0, links: [], repetidos: 0, repetidosDeOutra: 0, dias: [] },
  ],
  plataformas: [],
  repetidos: { resumo: {}, grupos: [], autores: [] },
};

const RANKING = {
  resumo: {
    operadores: 3, servicos: 9, validados: 6, aguardando: 1, semComprovante: 2,
    montanteValidado: 2400, montanteAtendido: 3100, montanteLancado: 4200,
    lancamentos: 14, contasPegasQtd: 18, contasPegasValor: 144,
    contasValidadasQtd: 11, contasValidadasValor: 96, contasQtd: 15, contasValor: 120,
    taxa: 6 / 9, periodo: 'Este mês (01/08/2026 a 27/08/2026)',
  },
  operadores: [
    {
      id: 'OP1@lid', pn: '5573981810457@s.whatsapp.net', nome: 'Carlos', servicos: 5, validados: 4,
      aguardando: 1, semComprovante: 0, montanteValidado: 1600, montanteAtendido: 2000,
      contasPegasQtd: 12, contasPegasValor: 90,
      contasValidadasQtd: 7, contasValidadasValor: 56, lancamentos: 8, montanteLancado: 2400,
      contasQtd: 9, contasValor: 62, brogueiras: 4, taxa: 0.8,
      casamento: { citacao: 3, valor: 1, tempo: 0 },
      dias: [
        { day: '2026-08-27', servicos: 3, validados: 3, montanteValidado: 1200, contasPegasQtd: 8, contasValidadasQtd: 5, lancamentos: 5, montanteLancado: 1500, contasQtd: 6 },
        { day: '2026-08-26', servicos: 2, validados: 1, montanteValidado: 400, contasPegasQtd: 4, contasValidadasQtd: 2, lancamentos: 3, montanteLancado: 900, contasQtd: 3 },
      ],
      ultimosServicos: [
        { id: 'sv1', status: 'validado', day: '2026-08-27', brogueiraNome: 'Ana Paula', pedidoTexto: '400 montante 2 contas', tipo: 'montante', atendimentoTs: '2026-08-27T14:05:00.000-03:00', montante: 400, contasQtd: 2, casamento: 'citacao', comprovanteTs: '2026-08-27T14:31:00.000-03:00', comprovanteTipo: 'pdf' },
        { id: 'sv2', status: 'aguardando_comprovante', day: '2026-08-27', brogueiraNome: 'Bianca', pedidoTexto: '7 contas', tipo: 'conta', atendimentoTs: '2026-08-27T13:10:00.000-03:00', montante: 0, contasQtd: 7, casamento: 'valor', comprovanteTs: null, comprovanteTipo: null },
      ],
    },
    {
      id: 'OP2@lid', pn: '5511999990000@s.whatsapp.net', nome: 'Ana Operadora', servicos: 3, validados: 2,
      aguardando: 0, semComprovante: 1, montanteValidado: 600, montanteAtendido: 900,
      contasPegasQtd: 6, contasPegasValor: 54,
      contasValidadasQtd: 4, contasValidadasValor: 40, lancamentos: 4, montanteLancado: 1200,
      contasQtd: 5, contasValor: 34, brogueiras: 2, taxa: 2 / 3,
      casamento: { citacao: 1, valor: 1, tempo: 0 }, dias: [], ultimosServicos: [],
    },
    {
      id: 'OP3@lid', pn: null, nome: 'Só Lançou', servicos: 0, validados: 0,
      aguardando: 0, semComprovante: 0, montanteValidado: 0, montanteAtendido: 0,
      contasPegasQtd: 0, contasPegasValor: 0,
      contasValidadasQtd: 0, contasValidadasValor: 0, lancamentos: 2, montanteLancado: 600,
      contasQtd: 1, contasValor: 0, brogueiras: 0, taxa: 0,
      casamento: { citacao: 0, valor: 0, tempo: 0 }, dias: [], ultimosServicos: [],
    },
  ],
};

async function montarPainel() {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;
  window.Element.prototype.getBoundingClientRect = () => ({ left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0 });
  window.Element.prototype.scrollIntoView = () => {};
  const pedidos = [];
  window.fetch = async (url) => {
    pedidos.push(String(url));
    return {
      ok: true,
      status: 200,
      json: async () => (String(url).includes('/api/sessoes')
        ? { ok: true, recursos: [{ chave: 'monitorar', nome: 'Monitoramento', descricao: 'x' }], sessoes: [], conflitos: [] }
        : { ok: true, ...RANKING }),
    };
  };
  const tag = window.document.createElement('script');
  tag.textContent = fs.readFileSync(path.join(PUBLIC, 'app.js'), 'utf8');
  window.document.body.appendChild(tag);
  return {
    window,
    doc: window.document,
    pedidos,
    fechar: async () => { await new Promise((r) => setTimeout(r, 30)); dom.window.close(); },
  };
}

const linhas = (doc, sel) => [...doc.querySelectorAll(sel)];
const digitar = (window, doc, id, valor) => {
  const campo = doc.getElementById(id);
  campo.value = valor;
  campo.oninput({ target: campo });
};

/* ═══════════ Busca das Brogueiras ═══════════ */

test('a tabela de Brogueiras mostra o número embaixo do nome', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderBrogueiras(BROGUEIRAS);
    const tr = linhas(doc, '#tbl-bg tbody tr');
    assert.equal(tr.length, 3);
    assert.match(tr[0].textContent, /Ana Paula/);
    assert.match(tr[0].textContent, /\+55 73 98888-7777/);
    // Sem telefone conhecido, não inventa nada (o LID não diz nada a ninguém).
    assert.doesNotMatch(tr[2].textContent, /\+/);
  } finally { await fechar(); }
});

test('buscar por nome filtra sem acento e sem maiúscula', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderBrogueiras(BROGUEIRAS);
    digitar(window, doc, 'bg-busca', 'claudia');
    const tr = linhas(doc, '#tbl-bg tbody tr');
    assert.equal(tr.length, 1);
    assert.match(tr[0].textContent, /Cláudia/);
    assert.equal(doc.getElementById('bg-busca-conta').textContent, '1 de 3');
  } finally { await fechar(); }
});

test('buscar por pedaço do número acha a Brogueira', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderBrogueiras(BROGUEIRAS);
    digitar(window, doc, 'bg-busca', '91234');
    let tr = linhas(doc, '#tbl-bg tbody tr');
    assert.equal(tr.length, 1);
    assert.match(tr[0].textContent, /Bianca/);

    // Número escrito como a pessoa vê no celular também casa.
    digitar(window, doc, 'bg-busca', '(11) 91234-5678');
    tr = linhas(doc, '#tbl-bg tbody tr');
    assert.equal(tr.length, 1);
    assert.match(tr[0].textContent, /Bianca/);
  } finally { await fechar(); }
});

test('busca sem resultado explica o que aconteceu; limpar traz todas de volta', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderBrogueiras(BROGUEIRAS);
    digitar(window, doc, 'bg-busca', 'zzz');
    assert.match(doc.querySelector('#tbl-bg tbody').textContent, /Nenhuma Brogueira com esse nome ou número/);
    digitar(window, doc, 'bg-busca', '');
    assert.equal(linhas(doc, '#tbl-bg tbody tr').length, 3);
    assert.equal(doc.getElementById('bg-busca-conta').textContent, '');
  } finally { await fechar(); }
});

test('o período das Brogueiras oferece semana, mês e ano', async () => {
  const { doc, fechar } = await montarPainel();
  try {
    const periodos = linhas(doc, '#bg-periodo button').map((b) => b.dataset.period);
    assert.deepEqual(periodos, ['hoje', 'semana', 'mes', 'ano', 'geral']);
  } finally { await fechar(); }
});

/* ═══════════ Aba Operadores ═══════════ */

test('o ranking lista os operadores com pegos, validados, taxa e lançados', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    const tr = linhas(doc, '#tbl-op tbody tr');
    assert.equal(tr.length, 3);
    assert.match(tr[0].textContent, /Carlos/);
    assert.match(tr[0].textContent, /80%/);
    assert.match(tr[0].textContent, /\+55 73 98181-0457/);
    // Quem só lançou continua no ranking, com taxa vazia em vez de 0% falso.
    assert.match(tr[2].textContent, /Só Lançou/);
    assert.match(tr[2].querySelector('.taxa-pill').textContent, /—/);

    assert.equal(doc.getElementById('op-kpi-servicos').textContent, '9');
    assert.equal(doc.getElementById('op-kpi-validados').textContent, '6');
    assert.equal(doc.getElementById('op-kpi-taxa').textContent, '67% do que pegaram');
    assert.match(doc.getElementById('op-periodo-rotulo').textContent, /^Este mês/);
    assert.equal(linhas(doc, '#op-podio .rank-row').length, 3);
    assert.match(doc.getElementById('op-casamento').textContent, /Respondeu citando/);
  } finally { await fechar(); }
});

test('buscar no ranking não mexe na posição de quem sobrou', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    digitar(window, doc, 'op-busca', 'ana');
    const tr = linhas(doc, '#tbl-op tbody tr');
    assert.equal(tr.length, 1);
    assert.match(tr[0].textContent, /Ana Operadora/);
    // Ela é a 2ª do ranking inteiro — filtrar não pode promovê-la a 1ª.
    assert.equal(tr[0].querySelector('td').textContent, '2');
    assert.equal(doc.getElementById('op-busca-conta').textContent, '1 de 3');
  } finally { await fechar(); }
});

test('clicar num operador abre o detalhe com os dias e os serviços', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    doc.querySelector('#tbl-op tbody tr').onclick();
    const card = doc.getElementById('op-detalhe');
    assert.equal(card.classList.contains('hidden'), false);
    assert.match(doc.getElementById('op-detalhe-nome').textContent, /Carlos — 5 serviço\(s\) pego\(s\)/);
    const corpo = doc.getElementById('op-detalhe-corpo').textContent;
    assert.match(corpo, /27\/08\/2026/);
    assert.match(corpo, /Ana Paula/);
    assert.match(corpo, /PDF/);
    assert.match(corpo, /aguardando/); // o serviço que ainda não fechou
    doc.getElementById('op-fechar').onclick();
    assert.equal(card.classList.contains('hidden'), true);
  } finally { await fechar(); }
});

test('operador sem serviço casado mostra o aviso em vez de uma tabela vazia', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    window.abrirDetalheOperador('OP3@lid');
    assert.match(doc.getElementById('op-detalhe-corpo').textContent, /só lançamentos soltos/);
  } finally { await fechar(); }
});

test('abrir a aba Operadores busca o ranking do período escolhido', async () => {
  const { window, doc, pedidos, fechar } = await montarPainel();
  try {
    window.abrirAba('operadores');
    await new Promise((r) => setTimeout(r, 10));
    assert.ok(pedidos.some((u) => u.includes('/api/operadores/ranking?period=hoje')), pedidos.join(' | '));
    assert.equal(doc.getElementById('tab-operadores').classList.contains('hidden'), false);
    assert.equal(doc.getElementById('page-title').textContent, 'Operadores');

    // Trocar o período refaz a busca com o novo recorte.
    doc.querySelector('#op-periodo button[data-period="mes"]').onclick();
    await new Promise((r) => setTimeout(r, 10));
    assert.ok(pedidos.some((u) => u.includes('period=mes')), pedidos.join(' | '));
  } finally { await fechar(); }
});

/* ═══════════ Filtro por um dia específico ═══════════ */

const escolherDia = (doc, valor) => {
  const campo = doc.getElementById('op-dia');
  campo.value = valor;
  campo.onchange({ target: campo });
};

test('escolher um dia no seletor pede o ranking daquele dia', async () => {
  const { window, doc, pedidos, fechar } = await montarPainel();
  try {
    window.abrirAba('operadores');
    await new Promise((r) => setTimeout(r, 10));

    escolherDia(doc, '2026-08-27');
    await new Promise((r) => setTimeout(r, 10));
    assert.ok(pedidos.some((u) => u.includes('period=2026-08-27')), pedidos.join(' | '));

    // Enquanto o dia manda, nenhum botão de período fica aceso — os dois
    // controles são exclusivos.
    assert.equal(doc.querySelectorAll('#op-periodo button.active').length, 0);
    assert.equal(doc.getElementById('op-dia-nav').classList.contains('ativo'), true);

    // Voltar para um período nomeado apaga o dia escolhido.
    doc.querySelector('#op-periodo button[data-period="semana"]').onclick();
    await new Promise((r) => setTimeout(r, 10));
    assert.equal(doc.getElementById('op-dia').value, '');
    assert.equal(doc.getElementById('op-dia-nav').classList.contains('ativo'), false);
    assert.equal(doc.querySelector('#op-periodo button.active').dataset.period, 'semana');
  } finally { await fechar(); }
});

test('as setas andam um dia por vez e não passam de hoje', async () => {
  const { window, doc, pedidos, fechar } = await montarPainel();
  try {
    escolherDia(doc, '2026-08-27');
    await new Promise((r) => setTimeout(r, 10));

    doc.getElementById('op-dia-ant').onclick();
    await new Promise((r) => setTimeout(r, 10));
    assert.equal(doc.getElementById('op-dia').value, '2026-08-26');
    assert.ok(pedidos.some((u) => u.includes('period=2026-08-26')));

    doc.getElementById('op-dia-prox').onclick();
    await new Promise((r) => setTimeout(r, 10));
    assert.equal(doc.getElementById('op-dia').value, '2026-08-27');

    // Em cima de hoje, a seta de avançar fica travada (não existe amanhã).
    const hoje = doc.getElementById('op-dia').max;
    escolherDia(doc, hoje);
    await new Promise((r) => setTimeout(r, 10));
    assert.equal(doc.getElementById('op-dia-prox').disabled, true);
    doc.getElementById('op-dia-prox').onclick();
    assert.equal(doc.getElementById('op-dia').value, hoje);
  } finally { await fechar(); }
});

test('limpar o seletor de dia devolve o recorte para hoje', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    escolherDia(doc, '2026-08-27');
    await new Promise((r) => setTimeout(r, 10));
    escolherDia(doc, '');
    await new Promise((r) => setTimeout(r, 10));
    assert.equal(doc.querySelector('#op-periodo button.active').dataset.period, 'hoje');
    assert.equal(doc.getElementById('op-dia-nav').classList.contains('ativo'), false);
  } finally { await fechar(); }
});

test('no detalhe, clicar num dia filtra a aba inteira por aquele dia', async () => {
  const { window, doc, pedidos, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    doc.querySelector('#tbl-op tbody tr').onclick();
    const dia = doc.querySelector('#op-detalhe-corpo .dia-linha');
    assert.ok(dia, 'o dia a dia deveria ser clicável');
    dia.onclick();
    await new Promise((r) => setTimeout(r, 10));
    assert.ok(pedidos.some((u) => u.includes('period=2026-08-27')), pedidos.join(' | '));
    assert.equal(doc.getElementById('op-dia').value, '2026-08-27');
  } finally { await fechar(); }
});

/* ═══════════ Leitura visual: medidor, sparkline e barras ═══════════ */

test('o KPI de validados desenha a taxa, e o montante ganha a série do período', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.lerCores();
    window.renderOperadores(RANKING);
    // 6 de 9 = 67%.
    assert.equal(doc.querySelector('#op-kpi-meter i').style.width, '67%');
    // Dois dias no fixture → sparkline visível.
    assert.equal(doc.getElementById('op-kpi-foot').classList.contains('hidden'), false);
    assert.match(doc.getElementById('op-kpi-spark').innerHTML, /<svg/);

    // Um dia só não vira gráfico: linha reta não diz nada.
    window.renderOperadores({
      ...RANKING,
      operadores: RANKING.operadores.map((o) => ({ ...o, dias: (o.dias || []).slice(0, 1) })),
    });
    assert.equal(doc.getElementById('op-kpi-foot').classList.contains('hidden'), true);
  } finally { await fechar(); }
});

test('a tabela desenha a fatia do líder e marca os 3 primeiros', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    const barras = linhas(doc, '#tbl-op tbody .barra-cel i').map((i) => i.style.width);
    // Carlos R$ 1.600 é o teto; Ana R$ 600 = 38%.
    assert.equal(barras[0], '100%');
    assert.equal(barras[1], '38%');
    // Os 3 primeiros ganham disco; o 4º (se houvesse) não.
    const pos = linhas(doc, '#tbl-op tbody .pos');
    assert.equal(pos.length, 3);
    assert.equal(pos.every((p) => p.classList.contains('topo')), true);
  } finally { await fechar(); }
});

/* ═══════════ Filtro Validados x Todos ═══════════ */

// O ranking do fixture: Carlos 5 pegos/4 validados, Ana 3/2, Só Lançou 0/0.
const trocarFiltro = (doc, valor) => doc.querySelector(`#op-filtro button[data-filtro="${valor}"]`).onclick();

test('"Só os validados" tira quem não fechou nenhum serviço', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    assert.equal(linhas(doc, '#tbl-op tbody tr').length, 3);

    trocarFiltro(doc, 'validados');
    const tr = linhas(doc, '#tbl-op tbody tr');
    assert.equal(tr.length, 2, 'quem tem 0 validados deveria sair');
    assert.doesNotMatch(doc.querySelector('#tbl-op tbody').textContent, /Só Lançou/);
  } finally { await fechar(); }
});

test('o filtro reordena o ranking e recalcula as posições', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    // Ana valida mais que Carlos, mas pega menos: a ordem TEM que trocar.
    const dados = JSON.parse(JSON.stringify(RANKING));
    dados.operadores[1].validados = 9;
    dados.operadores[1].montanteValidado = 5000;
    window.renderOperadores(dados);

    let tr = linhas(doc, '#tbl-op tbody tr');
    assert.match(tr[0].textContent, /Carlos/); // por serviços pegos

    trocarFiltro(doc, 'validados');
    tr = linhas(doc, '#tbl-op tbody tr');
    assert.match(tr[0].textContent, /Ana Operadora/); // por validados
    assert.equal(tr[0].querySelector('td').textContent, '1');
    assert.match(tr[1].textContent, /Carlos/);
    assert.equal(tr[1].querySelector('td').textContent, '2');
  } finally { await fechar(); }
});

test('a seta marca qual coluna está mandando na ordem', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    assert.equal(doc.getElementById('op-th-pegos').classList.contains('ordenando'), true);
    assert.equal(doc.getElementById('op-th-validados').classList.contains('ordenando'), false);

    trocarFiltro(doc, 'validados');
    assert.equal(doc.getElementById('op-th-pegos').classList.contains('ordenando'), false);
    assert.equal(doc.getElementById('op-th-validados').classList.contains('ordenando'), true);
  } finally { await fechar(); }
});

test('o filtro explica o que está contando, no pódio e ao lado dos botões', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    assert.equal(doc.getElementById('op-podio-sub').textContent, 'por serviços pegos');
    assert.match(doc.getElementById('op-filtro-hint').textContent, /9 pegos · 1 aguardando · 2 sem comprovante/);

    trocarFiltro(doc, 'validados');
    assert.equal(doc.getElementById('op-podio-sub').textContent, 'por serviços validados');
    assert.match(doc.getElementById('op-filtro-hint').textContent, /6 de 9 serviços fecharam com comprovante/);
    assert.equal(linhas(doc, '#op-podio .rank-row').length, 2);
  } finally { await fechar(); }
});

test('no detalhe, "só validados" esconde os serviços sem comprovante', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    window.abrirDetalheOperador('OP1@lid');
    // Sem filtro aparecem os dois: o validado e o que está aguardando.
    assert.match(doc.getElementById('op-detalhe-corpo').textContent, /Bianca/);

    trocarFiltro(doc, 'validados');
    window.abrirDetalheOperador('OP1@lid');
    const corpo = doc.getElementById('op-detalhe-corpo').textContent;
    assert.match(corpo, /Ana Paula/);  // o validado fica
    assert.doesNotMatch(corpo, /Bianca/); // o que não fechou sai
    assert.match(doc.getElementById('op-detalhe-nome').textContent, /4 serviço\(s\) validado\(s\)/);
  } finally { await fechar(); }
});

test('sem nenhum serviço validado, o vazio manda de volta para "todos"', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    const dados = JSON.parse(JSON.stringify(RANKING));
    for (const o of dados.operadores) { o.validados = 0; o.montanteValidado = 0; }
    window.renderOperadores(dados);
    trocarFiltro(doc, 'validados');
    assert.match(doc.querySelector('#tbl-op tbody').textContent, /Todos os serviços pegos/);
    assert.match(doc.getElementById('op-podio').textContent, /Nenhum serviço validado/);
  } finally { await fechar(); }
});

test('trocar o filtro não vai ao servidor (os dois números já vieram juntos)', async () => {
  const { window, doc, pedidos, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    const antes = pedidos.length;
    trocarFiltro(doc, 'validados');
    trocarFiltro(doc, 'todos');
    assert.equal(pedidos.length, antes, 'a troca de filtro não deveria buscar nada');
  } finally { await fechar(); }
});

/* ═══════════ Contas pegas pelos Operadores ═══════════ */

test('a tabela mostra as contas pegas (quantidade e valor) de cada Operador', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    const celulas = [...doc.querySelectorAll('#tbl-op tbody tr')[0].querySelectorAll('td')];
    const contas = celulas[5]; // # | Operador | Pegos | Validados | Taxa | Contas | ...
    assert.match(contas.textContent, /^12/, 'a quantidade de contas pegas deveria abrir a célula');
    assert.match(contas.textContent, /R\$\s?90,00/);
    assert.equal(doc.getElementById('op-th-contas').textContent, 'Contas pegas');
  } finally { await fechar(); }
});

test('no filtro "só validados" a coluna passa a contar as contas que fecharam', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    trocarFiltro(doc, 'validados');
    assert.equal(doc.getElementById('op-th-contas').textContent, 'Contas validadas');
    const contas = [...doc.querySelectorAll('#tbl-op tbody tr')[0].querySelectorAll('td')][5];
    assert.match(contas.textContent, /^7/);
    assert.match(contas.textContent, /R\$\s?56,00/);
  } finally { await fechar(); }
});

test('o KPI de contas troca de recorte junto com o filtro', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    assert.equal(doc.getElementById('op-kpi-contas-label').textContent, 'Contas pegas');
    assert.equal(doc.getElementById('op-kpi-contas').textContent, '18');
    assert.match(doc.getElementById('op-kpi-contas-sub').textContent, /R\$\s?144,00/);
    // As contas lançadas (todas as mensagens financeiras) seguem visíveis no KPI de lançado.
    assert.match(doc.getElementById('op-kpi-lancamentos').textContent, /14 lançamentos · 15 contas/);

    trocarFiltro(doc, 'validados');
    assert.equal(doc.getElementById('op-kpi-contas-label').textContent, 'Contas validadas');
    assert.equal(doc.getElementById('op-kpi-contas').textContent, '11');
  } finally { await fechar(); }
});

test('o detalhe separa contas pegas, validadas e lançadas', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderOperadores(RANKING);
    window.abrirDetalheOperador('OP1@lid');
    const corpo = doc.getElementById('op-detalhe-corpo').textContent;
    assert.match(corpo, /Contas pegas12/);
    assert.match(corpo, /Contas validadas7/);
    assert.match(corpo, /Contas lançadas9/);
    // O dia a dia também conta as contas daquele dia.
    assert.match(corpo, /8 conta\(s\)/);
  } finally { await fechar(); }
});
