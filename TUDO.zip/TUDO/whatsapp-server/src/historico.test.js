// Ver dias anteriores: o calendário do histórico, a série que termina num dia
// escolhido e o snapshot em modo histórico.
//
// É o que separa "o painel de hoje" de "o painel de um dia qualquer": se o
// recorte vazar, o usuário olha para ontem e lê os números de hoje — o erro
// mais caro possível numa tela de conferência.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-historico-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb, saveDb } = await import('./db.js');
const {
  registrarEntrada, registrarPedido, diasComDados, mensagensPorDia, dayKey, periodoDoTexto,
} = await import('./store.js');
const { executarComando } = await import('./commands.js');
const { snapshot } = await import('./realtime.js');

loadDb();

// Datas fixas relativas a hoje: o teste não pode depender do dia em que roda.
const hoje = dayKey();
const diaAnterior = (n) => {
  const [a, m, d] = hoje.split('-').map(Number);
  const base = new Date(Date.UTC(a, m - 1, d));
  base.setUTCDate(base.getUTCDate() - n);
  return base.toISOString().slice(0, 10);
};
// Meio-dia no fuso de São Paulo (UTC-3) — nunca escorrega para o dia vizinho.
const meioDia = (dia) => new Date(`${dia}T15:00:00.000Z`).getTime();

const ONTEM = diaAnterior(1);
const ANTEONTEM = diaAnterior(2);

let seqSv = 0;

// Um lançamento do Operador que FECHOU os 3 passos: a mensagem financeira mais
// o serviço validado correspondente. "Montante" hoje é o validado, então um
// lançamento solto não move mais nenhum total — a fixture tem que validar.
function lancar(dia, { montante = 0, contasQtd = 0, contasTotal = 0, operador = 'OP1', validado = true } = {}) {
  const entrada = registrarEntrada({
    sessaoId: 'n1', msgId: `m-${dia}-${(seqSv += 1)}`, groupId: 'g1@g.us', groupName: 'Grupo 1',
    operatorId: `${operador}@lid`, operatorName: operador, text: 'lançamento',
    analise: { montante, contasQtd, contasTotal }, ts: meioDia(dia),
  });
  const db = getDb();
  if (!Array.isArray(db.servicos)) db.servicos = [];
  db.servicos.push({
    id: `sv-${dia}-${seqSv}`, day: dia, ts: new Date(meioDia(dia)).toISOString(),
    sessaoId: 'n1', groupId: 'g1@g.us', groupName: 'Grupo 1',
    status: validado ? 'validado' : 'sem_comprovante',
    pedidoTs: new Date(meioDia(dia)).toISOString(),
    brogueiraChave: 'B1', brogueiraNome: 'Ana', tipo: 'montante',
    montantePedido: montante, contasPedidas: 0, links: [],
    atendimento: {
      entradaId: entrada?.id ?? null, ts: new Date(meioDia(dia)).toISOString(),
      operatorId: `${operador}@lid`, operatorName: operador,
      montante, contasQtd, contasTotal, casamento: 'tempo',
    },
    comprovante: validado ? { msgId: `c-${seqSv}`, ts: new Date(meioDia(dia)).toISOString(), tipo: 'imagem', casamento: 'tempo' } : null,
    validadoEm: validado ? new Date(meioDia(dia)).toISOString() : null,
  });
  return entrada;
}

// Fixture: anteontem fraco, ontem forte, hoje só um lançamento.
lancar(ANTEONTEM, { montante: 100 });
lancar(ONTEM, { montante: 700, contasQtd: 3, contasTotal: 30 });
lancar(ONTEM, { montante: 300, operador: 'OP2' });
lancar(hoje, { montante: 50 });
registrarPedido({
  sessaoId: 'n1', msgId: 'p1', groupId: 'g1@g.us', groupName: 'Grupo 1',
  autorId: 'B1@lid', autorNome: 'Ana', papel: 'brogueira',
  pedido: { montante: 700, contasQtd: 0, links: [] }, text: '700', ts: meioDia(ONTEM),
});
saveDb();

test('diasComDados lista os dias com movimento, do mais novo ao mais velho', () => {
  const cal = diasComDados();
  assert.equal(cal.hoje, hoje);
  assert.equal(cal.ultimo, hoje);
  assert.equal(cal.primeiro, ANTEONTEM);
  assert.deepEqual(cal.dias.map((d) => d.day), [hoje, ONTEM, ANTEONTEM]);

  const ontem = cal.dias.find((d) => d.day === ONTEM);
  assert.equal(ontem.lancamentos, 2);
  assert.equal(ontem.pedidos, 1);
  assert.equal(ontem.montante, 1000);
});

test('a série de dias pode terminar num dia do passado', () => {
  const ateOntem = mensagensPorDia(3, null, ONTEM);
  assert.equal(ateOntem.at(-1).day, ONTEM, 'o último ponto tem que ser o dia pedido');
  assert.equal(ateOntem.at(-1).count, 2);
  assert.equal(ateOntem.at(-2).day, ANTEONTEM);

  // Sem `ate`, a janela continua terminando em hoje (o comportamento de sempre).
  assert.equal(mensagensPorDia(3).at(-1).day, hoje);
  // Data inválida não quebra a série — cai em hoje.
  assert.equal(mensagensPorDia(3, null, 'ontem').at(-1).day, hoje);
});

test('snapshot de um dia anterior traz os números daquele dia, não os de hoje', () => {
  const ao_vivo = snapshot('open', 'admin', null);
  assert.equal(ao_vivo.periodo.historico, false);
  assert.equal(ao_vivo.periodo.valor, 'today');
  assert.equal(ao_vivo.hoje.totais.montante, 50);

  const ontem = snapshot('open', 'admin', null, { day: ONTEM });
  assert.equal(ontem.periodo.historico, true);
  assert.equal(ontem.periodo.de, ONTEM);
  assert.equal(ontem.periodo.ate, ONTEM);
  assert.equal(ontem.hoje.totais.montante, 1000, 'o bloco de números tem que ser o do dia pedido');
  assert.equal(ontem.hoje.totais.qtdOperadores, 2);
  assert.equal(ontem.hoje.totais.contasValor, 30);
});

test('em modo histórico, "últimas mensagens" e a série são do dia escolhido', () => {
  const ontem = snapshot('open', 'admin', null, { day: ONTEM });
  assert.equal(ontem.ultimasMensagens.length, 2);
  assert.ok(ontem.ultimasMensagens.every((m) => m.day === ONTEM),
    'nenhuma mensagem de outro dia pode aparecer na lista');
  assert.equal(ontem.analytics.porDia.at(-1).day, ONTEM);

  // Os acumulados de sempre (stats) continuam sendo os totais do servidor: são
  // "desde que o bot existe", não do dia.
  assert.equal(ontem.stats.totalMessages, getDb().stats.totalMessages);
});

test('o dia sem movimento aparece zerado, e não como se fosse hoje', () => {
  const vazio = snapshot('open', 'admin', null, { day: diaAnterior(9) });
  assert.equal(vazio.hoje.totais.montante, 0);
  assert.equal(vazio.hoje.totais.qtdEntradas, 0);
  assert.equal(vazio.ultimasMensagens.length, 0);
  assert.equal(vazio.periodo.historico, true);
});

/* ═══════════ O vocabulário de período escrito por gente ═══════════ */

test('periodoDoTexto entende os nomes, "ontem" e as datas', () => {
  assert.equal(periodoDoTexto(''), 'today');
  assert.equal(periodoDoTexto('hoje'), 'today');
  assert.equal(periodoDoTexto('  GERAL '), 'all');
  assert.equal(periodoDoTexto('mes'), 'month');
  assert.deepEqual(periodoDoTexto('ontem'), { day: ONTEM });
  assert.deepEqual(periodoDoTexto(ANTEONTEM), { day: ANTEONTEM });

  // Como as pessoas escrevem no grupo: 28/08 e 28/08/2026.
  const [ano, mes, dia] = ONTEM.split('-');
  assert.deepEqual(periodoDoTexto(`${dia}/${mes}`), { day: ONTEM });
  assert.deepEqual(periodoDoTexto(`${dia}/${mes}/${ano}`), { day: ONTEM });

  // Lixo não vira "tudo" — cai em hoje, que é o recorte inofensivo.
  assert.equal(periodoDoTexto('semana passada'), 'today');
  assert.equal(periodoDoTexto('32/13'), 'today');
});

test('!RELATORIO aceita o dia e o relatório diz de qual dia é', () => {
  const config = { commandAuthorizedNumbers: ['5511999999999'], reportAuthorizedNumbers: [] };
  const de = (texto) => executarComando(texto, '5511999999999@s.whatsapp.net', config)?.reply ?? '';

  const hojeTxt = de('!RELATORIO');
  assert.match(hojeTxt, /Hoje/);
  assert.match(hojeTxt, /Montante validado: \*R\$\s?50,00\*/, 'hoje só teve um serviço de 50');

  const ontemTxt = de('!RELATORIO ontem');
  const brOntem = ONTEM.split('-').reverse().join('/');
  assert.match(ontemTxt, new RegExp(brOntem.replace(/\//g, '\\/')), 'o título tem que trazer a data');
  assert.match(ontemTxt, /Montante validado: \*R\$\s?1\.000,00\*/, 'ontem somou 1000');

  // Mesma coisa escrevendo a data como no grupo.
  const [a, m, d] = ONTEM.split('-');
  assert.equal(de(`!RELATORIO ${d}/${m}`), ontemTxt);
  assert.notEqual(de('!OPERADORES ontem'), de('!OPERADORES'));
});
