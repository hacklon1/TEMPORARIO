// Alerta de link repetido: quando as repetições passam do limite, o bot avisa
// num OUTRO grupo (o de operação), marcando todo mundo.
//
// Duas contagens, independentes e configuráveis (0 desliga cada uma):
//
//   por link → o MESMO link chegou ao número de envios configurado
//              (limite 3 = alerta no 3º envio de okok.com/?id=5)
//   por dia  → o dia juntou N reenvios, de links quaisquer
//
// Cada link alerta UMA vez e cada dia alerta UMA vez: o alerta marca o grupo
// inteiro, e repetir isso a cada nova mensagem do mesmo caso viraria spam —
// que é justamente o que se está tentando denunciar.
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';
import timezone from 'dayjs/plugin/timezone.js';
import { getDb, saveDb, getConfig } from './db.js';
import { daSessao } from './store.js';
import { logger } from './logger.js';

dayjs.extend(utc);
dayjs.extend(timezone);

// Teto do índice do que já foi alertado. É memória de deduplicação, não
// histórico: passando disso, os links mais antigos saem.
export const MAX_LINKS_ALERTADOS = 2000;

const inteiro = (v) => {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 0;
};

export function configAlertas(config = {}) {
  return {
    ativo: Boolean(config.alertaRepetidosEnabled),
    grupo: String(config.alertaRepetidosGrupo ?? '').trim(),
    mensagem: String(config.alertaRepetidosMensagem ?? '').trim() || 'Alerta, link repetido',
    porLink: inteiro(config.alertaRepetidosPorLink),
    porDia: inteiro(config.alertaRepetidosPorDia),
    marcarTodos: config.alertaRepetidosMarcarTodos !== false,
  };
}

function fuso(config) {
  const configurado = config?.timezone || 'America/Sao_Paulo';
  try {
    dayjs().tz(configurado);
    return configurado;
  } catch {
    return 'America/Sao_Paulo';
  }
}

const quando = (ts, config) => dayjs(ts).tz(fuso(config)).format('DD/MM HH:mm');

export function ordinal(n) {
  const v = Number(n);
  return Number.isFinite(v) && v > 0 ? `${Math.floor(v)}ª` : '—';
}

// Reenvios registrados no dia: uma mensagem repetida conta uma vez, mesmo que
// traga dois links repetidos. Só conta o que foi gravado COM a marca — pedido
// anterior a esta funcionalidade não tem o campo e fica de fora.
// `sessaoId` limita a contagem ao que AQUELE número viu: um número que só olha
// um grupo não deve disparar por reenvios que aconteceram no grupo de outro.
export function contarReenviosDoDia(db, day, sessaoId = null) {
  const pedidos = Array.isArray(db.pedidos) ? db.pedidos : [];
  return pedidos.filter(
    (p) => p.day === day && p.repetido && p.papel !== 'operador' && daSessao(p, sessaoId),
  ).length;
}

function estado(db) {
  if (!db.alertas || typeof db.alertas !== 'object') db.alertas = { links: {}, dias: {}, ultimo: null };
  if (!db.alertas.links || typeof db.alertas.links !== 'object') db.alertas.links = {};
  if (!db.alertas.dias || typeof db.alertas.dias !== 'object') db.alertas.dias = {};
  return db.alertas;
}

/**
 * Decide se ESTE pedido dispara alerta. Função pura: não envia nada e não
 * escreve no db — quem grava é marcarAlertado(), depois do envio dar certo
 * (falha de envio não pode consumir o alerta em silêncio).
 *
 * Devolve null quando não há o que alertar.
 */
export function avaliarAlerta({ entry, db = getDb(), agora = Date.now(), config = null } = {}) {
  // A configuração do alerta é do NÚMERO que viu a repetição: cada um avisa no
  // seu grupo, com o seu texto e os seus limites. O índice do que já foi
  // alertado (db.alertas) continua global — o mesmo link não deve gerar um
  // aviso por número.
  const cfgSessao = config ?? getConfig(entry?.sessaoId);
  const cfg = configAlertas(cfgSessao);
  if (!cfg.ativo || !cfg.grupo) return null;
  if (!entry?.repetido) return null; // o gatilho é sempre uma repetição
  if (entry.papel === 'operador') return null; // fora do recorte das Brogueiras

  const jaAlertado = estado(db);
  const motivos = [];

  // 1) O mesmo link chegou ao limite. Havendo mais de um link no pedido, vale
  //    o que está mais avançado.
  let repeticao = null;
  if (cfg.porLink > 0) {
    const candidatas = (entry.repeticoes ?? [])
      .filter((r) => r.vezes >= cfg.porLink && !jaAlertado.links[r.chave])
      .sort((a, b) => b.vezes - a.vezes);
    if (candidatas.length) {
      repeticao = candidatas[0];
      motivos.push('link');
    }
  }

  // 2) O dia juntou reenvios demais.
  let totalDia = null;
  if (cfg.porDia > 0 && !jaAlertado.dias[entry.day]) {
    const total = contarReenviosDoDia(db, entry.day, entry.sessaoId ?? null);
    if (total >= cfg.porDia) {
      totalDia = total;
      motivos.push('dia');
    }
  }

  if (!motivos.length) return null;

  return {
    motivos,
    grupo: cfg.grupo,
    marcarTodos: cfg.marcarTodos,
    chave: repeticao?.chave ?? null,
    day: entry.day,
    totalDia,
    texto: montarTexto({ cfg, entry, repeticao, totalDia, config: cfgSessao }),
    ts: new Date(agora).toISOString(),
  };
}

// A mensagem: o texto configurado e, embaixo, o caso concreto — sem os
// detalhes o grupo recebe "alerta" e não tem o que conferir.
export function montarTexto({ cfg, entry, repeticao, totalDia, config }) {
  const linhas = [cfg.mensagem];

  if (repeticao) {
    const autor = entry.autorNome || 'Alguém';
    linhas.push('');
    linhas.push(`🔁 *${autor}* mandou pela ${ordinal(repeticao.vezes)} vez:`);
    linhas.push(repeticao.link || repeticao.chave);
    if (repeticao.primeiroEm) {
      const primeiro = repeticao.deOutra
        ? `1ª vez foi de *${repeticao.primeiroPor || 'desconhecida'}*`
        : 'ela mesma já tinha mandado';
      linhas.push(`${primeiro} em ${quando(repeticao.primeiroEm, config)}`);
    }
    if (entry.groupName) linhas.push(`Grupo: ${entry.groupName}`);
  }

  if (totalDia != null) {
    linhas.push('');
    linhas.push(`📊 ${totalDia} reenvios de link hoje${entry.groupName && !repeticao ? ` em ${entry.groupName}` : ''}.`);
  }

  return linhas.join('\n');
}

// Só depois do envio dar certo: o link/dia passa a valer como já avisado.
export function marcarAlertado(db, alerta) {
  const jaAlertado = estado(db);
  if (alerta.chave) jaAlertado.links[alerta.chave] = alerta.ts;
  if (alerta.motivos.includes('dia')) jaAlertado.dias[alerta.day] = alerta.ts;
  jaAlertado.ultimo = { ts: alerta.ts, motivos: alerta.motivos, chave: alerta.chave, grupo: alerta.grupo };

  // Poda: índice de deduplicação não é histórico.
  const chaves = Object.keys(jaAlertado.links);
  if (chaves.length > MAX_LINKS_ALERTADOS) {
    chaves
      .sort((a, b) => String(jaAlertado.links[a]).localeCompare(String(jaAlertado.links[b])))
      .slice(0, chaves.length - MAX_LINKS_ALERTADOS)
      .forEach((k) => delete jaAlertado.links[k]);
  }
  // Dias: 90 chaves bastam para o painel mostrar "já avisei hoje".
  const dias = Object.keys(jaAlertado.dias).sort();
  if (dias.length > 90) dias.slice(0, dias.length - 90).forEach((d) => delete jaAlertado.dias[d]);

  saveDb();
  return jaAlertado;
}

/**
 * Manda o alerta. `deps.reply(to, texto, {mentions})` e
 * `deps.getGroupParticipants(jid)` vêm do whatsapp.js.
 *
 * "Marcar todos" é o mesmo mecanismo do agendamento: os participantes vão em
 * `mentions`, então todo mundo é notificado sem encher a mensagem de @número.
 */
export async function enviarAlerta(alerta, deps = {}) {
  const grupo = alerta.grupo;
  let mentions;
  if (alerta.marcarTodos && grupo.endsWith('@g.us') && deps.getGroupParticipants) {
    try {
      mentions = await deps.getGroupParticipants(grupo);
    } catch (err) {
      // Sem a lista de membros o alerta ainda vale mais do que não avisar.
      logger.warn({ err: err.message, grupo }, 'alerta: não deu para marcar todos');
    }
  }
  await deps.reply(grupo, alerta.texto, { mentions });
}

/**
 * Caminho completo, chamado pelo handler a cada pedido repetido: avalia,
 * envia e só então marca. Nunca lança — um alerta que falha não pode derrubar
 * o processamento da mensagem.
 */
export async function processarAlertaRepetido(entry, deps = {}, config = null) {
  try {
    const db = getDb();
    const alerta = avaliarAlerta({ entry, db, config });
    if (!alerta) return null;

    await enviarAlerta(alerta, deps);
    marcarAlertado(db, alerta);
    logger.warn(
      { sessao: entry?.sessaoId, grupo: alerta.grupo, motivos: alerta.motivos, chave: alerta.chave, totalDia: alerta.totalDia },
      'alerta de link repetido enviado',
    );
    return alerta;
  } catch (err) {
    // Sem marcar: na próxima repetição ele tenta de novo.
    logger.error(err, 'falha ao enviar alerta de link repetido');
    return null;
  }
}
