// Papel de quem manda mensagem num grupo:
//
//   Operador  = administrador do grupo (admin ou superadmin no WhatsApp)
//   Brogueira = membro comum
//
// A lista vem do groupMetadata, que é uma chamada de rede — por isso fica em
// cache por alguns minutos. Sem cache, cada mensagem do grupo (são centenas por
// dia) viraria uma consulta ao servidor do WhatsApp.
import { logger } from './logger.js';
import { soDigitos } from './jid.js';

export const OPERADOR = 'operador';
export const BROGUEIRA = 'brogueira';
export const DESCONHECIDO = 'desconhecido';

const TTL_MS = 10 * 60 * 1000; // 10 min
const cache = new Map(); // groupId -> { em, admins:Set, adminDigitos:Set, total }

export function limparCacheMembros(groupId) {
  if (groupId) cache.delete(groupId);
  else cache.clear();
}

// Chamada quando o WhatsApp avisa que o grupo mudou (entrou/saiu/virou admin):
// manter o cache velho classificaria alguém pelo papel de antes.
export function invalidarGrupo(groupId) {
  cache.delete(groupId);
}

async function indice(groupId, buscarMembros) {
  const guardado = cache.get(groupId);
  if (guardado && Date.now() - guardado.em < TTL_MS) return guardado;
  const membros = await buscarMembros(groupId);
  const admins = new Set();
  const adminDigitos = new Set();
  for (const m of membros ?? []) {
    if (!m?.admin) continue;
    for (const forma of [m.id, m.lid, m.pn]) {
      if (!forma) continue;
      admins.add(String(forma));
      const d = soDigitos(forma);
      if (d) adminDigitos.add(d);
    }
  }
  const entrada = { em: Date.now(), admins, adminDigitos, total: membros?.length ?? 0 };
  cache.set(groupId, entrada);
  return entrada;
}

// Resolve o papel do remetente (identidadeRemetente() do jid.js).
// `buscarMembros` é injetado para o módulo não depender do Baileys (e ser testável).
export async function papelDoRemetente(groupId, remetente, buscarMembros) {
  if (!groupId || typeof buscarMembros !== 'function') return DESCONHECIDO;
  try {
    const { admins, adminDigitos } = await indice(groupId, buscarMembros);
    for (const forma of [remetente?.id, remetente?.lid, remetente?.pn]) {
      if (forma && admins.has(String(forma))) return OPERADOR;
    }
    for (const d of remetente?.digitos ?? []) {
      if (adminDigitos.has(d)) return OPERADOR;
    }
    // Não é admin → membro comum. Quem saiu do grupo cai aqui também, o que é
    // o certo: a mensagem dela continua sendo de uma Brogueira.
    return BROGUEIRA;
  } catch (err) {
    // Sem a lista não dá para afirmar nada — melhor 'desconhecido' do que
    // classificar um Operador como Brogueira e sujar o relatório.
    logger.warn({ groupId, err: err.message }, 'não foi possível classificar o remetente');
    return DESCONHECIDO;
  }
}
