import { fireEvent, render, screen, waitFor } from "@testing-library/react";
import { beforeEach, describe, expect, it, vi } from "vitest";

const invoke = vi.fn();
vi.mock("@/integrations/supabase/client", () => ({
  supabase: { functions: { invoke: (...args: unknown[]) => invoke(...args) } },
}));

import { ConexaoColetor } from "@/components/ConexaoColetor";
import { limparLog } from "@/lib/coletorStore";

const diagnostico = {
  base: "https://exemplo.trycloudflare.com",
  caminho: "/api/v1/relatorios",
  data: "2026-08-31",
  token_configurado: true,
  timeout_ms: 20000,
  tentativas: 2,
  ms_total: 240,
  rotas: [
    {
      tipo: "montante",
      ok: true,
      status: 200,
      ms: 80,
      bytes: 2149,
      relatorio: { data: "2026-08-31", totais: { montante: 11446, validados: 62 } },
    },
    { tipo: "contas", ok: false, status: 401, ms: 40, codigo: "token_coletor", erro: "O token do coletor foi recusado" },
    { tipo: "operadores", ok: true, status: 200, ms: 95, bytes: 3430, relatorio: { operadores: [] } },
  ],
};

describe("painel de conexão com o coletor", () => {
  beforeEach(() => {
    limparLog();
    invoke.mockReset();
    invoke.mockResolvedValue({ data: { diagnostico }, error: null });
  });

  it("testa as três rotas e mostra sucesso e falha lado a lado", async () => {
    render(<ConexaoColetor />);
    fireEvent.click(screen.getByRole("button", { name: /testar conexão/i }));

    await waitFor(() => expect(screen.getByText(/HTTP 200 · 80 ms/)).toBeInTheDocument());
    // Aparece duas vezes de propósito: no cartão da rota e na linha do log.
    expect(screen.getAllByText("O token do coletor foi recusado")).toHaveLength(2);
    expect(screen.getByText(/total 240 ms/i)).toBeInTheDocument();
    expect(screen.getByText(/timeout 20s · 2 tentativas/i)).toBeInTheDocument();
    // A URL do servidor vem da Edge Function, não do bundle.
    expect(screen.getByText(/exemplo\.trycloudflare\.com\/api\/v1\/relatorios/)).toBeInTheDocument();
  });

  it("antes do teste, não expõe nenhuma URL do servidor no front-end", () => {
    render(<ConexaoColetor />);
    expect(screen.getByText(/via Edge Function relatorios-externos/)).toBeInTheDocument();
    expect(screen.queryByText(/179\.197/)).not.toBeInTheDocument();
  });

  it("manda só `data` para a Edge Function (sem inicio/fim, sem `dia`)", async () => {
    render(<ConexaoColetor />);
    fireEvent.click(screen.getByRole("button", { name: /testar conexão/i }));
    await waitFor(() => expect(invoke).toHaveBeenCalled());
    const body = invoke.mock.calls[0][1].body as Record<string, unknown>;
    expect(Object.keys(body).sort()).toEqual(["acao", "data"]);
    expect(body.data).toMatch(/^\d{4}-\d{2}-\d{2}$/);
  });

  it("registra uma linha de log por rota mais o resumo", async () => {
    render(<ConexaoColetor />);
    fireEvent.click(screen.getByRole("button", { name: /testar conexão/i }));

    await waitFor(() =>
      expect(screen.getByText(/Teste de conexão: 2\/3 rotas responderam/)).toBeInTheDocument(),
    );
    expect(screen.getByText("Log")).toBeInTheDocument();
    // 3 rotas + 1 resumo
    expect(screen.getByText("(4)")).toBeInTheDocument();
  });

  it("guarda o JSON cru recebido e o exibe na aba de dados", async () => {
    render(<ConexaoColetor />);
    fireEvent.click(screen.getByRole("button", { name: /testar conexão/i }));
    await waitFor(() => expect(screen.getByText(/total 240 ms/i)).toBeInTheDocument());

    fireEvent.click(screen.getByRole("button", { name: /dados recebidos/i }));
    expect(screen.getByText(/"montante": 11446/)).toBeInTheDocument();
    expect(screen.getByRole("button", { name: /copiar/i })).toBeInTheDocument();
  });
});
