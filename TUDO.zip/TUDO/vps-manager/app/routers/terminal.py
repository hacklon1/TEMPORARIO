"""Terminal SSH interativo sobre WebSocket (xterm.js <-> PTY remoto)."""
from __future__ import annotations

import asyncio
import json

from fastapi import APIRouter, Query, WebSocket, WebSocketDisconnect

from .. import db
from ..deps import ws_user
from ..services import sshmgr

router = APIRouter(tags=["terminal"])


@router.websocket("/ws/terminal")
async def terminal_ws(
    ws: WebSocket,
    host_id: int | None = Query(default=None),
    token: str | None = Query(default=None),
    cols: int = Query(default=120),
    rows: int = Query(default=32),
):
    user = ws_user(ws.cookies, token)
    if not user:
        await ws.close(code=4401)
        return

    await ws.accept()
    host = await sshmgr.get_host(host_id)
    term = sshmgr.Terminal(host, cols=max(20, min(cols, 500)), rows=max(5, min(rows, 200)))

    try:
        await term.open()
    except Exception as exc:  # noqa: BLE001
        await ws.send_text(json.dumps({"type": "error", "message": f"falha ao conectar: {exc}"}))
        await ws.close(code=1011)
        await db.audit("ssh.terminal", username=user["username"], target=host.hostname,
                       ok=False, detail=str(exc)[:300])
        return

    await ws.send_text(json.dumps({
        "type": "ready",
        "host": f"{host.username}@{host.hostname}:{host.port}",
        "name": host.name,
    }))
    await db.audit("ssh.terminal", username=user["username"],
                   target=f"{host.username}@{host.hostname}", ok=True, detail="sessao aberta")

    async def pump_out() -> None:
        """SSH -> navegador."""
        while True:
            data = await term.read()
            if data is None:
                break
            if data:
                await ws.send_text(json.dumps({"type": "data", "data": data}))
        await ws.send_text(json.dumps({"type": "closed"}))

    out_task = asyncio.create_task(pump_out())

    try:
        while True:
            raw = await ws.receive_text()
            try:
                msg = json.loads(raw)
            except json.JSONDecodeError:
                continue
            kind = msg.get("type")
            if kind == "input":
                await term.write(msg.get("data", ""))
            elif kind == "resize":
                await term.resize(int(msg.get("cols", 120)), int(msg.get("rows", 32)))
            elif kind == "ping":
                await ws.send_text(json.dumps({"type": "pong"}))
    except WebSocketDisconnect:
        pass
    except Exception:
        pass
    finally:
        out_task.cancel()
        await term.close()
        await db.audit("ssh.terminal", username=user["username"],
                       target=f"{host.username}@{host.hostname}", ok=True, detail="sessao encerrada")
        try:
            await ws.close()
        except Exception:
            pass
