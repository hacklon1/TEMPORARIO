-- Categorias de Operador.
--
--   bi       -> Operador BI: dashboard completo (comportamento atual)
--   montante -> Operador de Montante: só funcionalidades de Montante
--   contas   -> Operador de Contas: só funcionalidades de Contas
--
-- Admins e DONOS escolhem a categoria ao cadastrar o usuário.
-- Só faz sentido para o papel 'user' (Operador); admin e dono veem tudo.

DO $$
BEGIN
  IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'operator_type') THEN
    CREATE TYPE public.operator_type AS ENUM ('bi', 'montante', 'contas');
  END IF;
END $$;

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS operator_type public.operator_type NOT NULL DEFAULT 'bi';

COMMENT ON COLUMN public.profiles.operator_type IS
  'Categoria do Operador: bi (dashboard completo), montante ou contas.';
