-- Backup de comissões zeradas por usuário, com possibilidade de desfazer.
CREATE TABLE IF NOT EXISTS public.commission_resets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL,
  reset_by uuid,
  operations jsonb NOT NULL,
  total_comissao numeric NOT NULL DEFAULT 0,
  total_comissao_contas numeric NOT NULL DEFAULT 0,
  undone boolean NOT NULL DEFAULT false,
  undone_at timestamptz,
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE public.commission_resets ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "Admins manage commission resets" ON public.commission_resets;
CREATE POLICY "Admins manage commission resets"
  ON public.commission_resets FOR ALL TO authenticated
  USING (public.has_role(auth.uid(), 'admin'))
  WITH CHECK (public.has_role(auth.uid(), 'admin'));

CREATE INDEX IF NOT EXISTS idx_commission_resets_created_at ON public.commission_resets(created_at DESC);
