// Boas-vindas a novos participantes de grupo.
//
// O Baileys emite 'group-participants.update' com { id, author, participants[], action }.
// Só 'add' interessa aqui — 'remove'/'promote'/'demote' são ignorados.
import { getConfig } from './db.js';
import { logger } from './logger.js';
import { soDigitos } from './jid.js';

// Placeholders aceitos no template configurado pelo usuário.
const PLACEHOLDERS = /\{(nome|numero|mencao|grupo|total)\}/gi;

// Decide se o grupo deve receber boas-vindas conforme a config.
export function deveDarBoasVindas(config, groupId) {
  if (!config?.welcomeEnabled) return false;
  if (config.welcomeMode === 'specific') {
    return Array.isArray(config.welcomeGroups) && config.welcomeGroups.includes(groupId);
  }
  return config.welcomeMode === 'all';
}

// Monta o texto final. Devolve { texto, mentions } — `mentions` só é preenchido
// quando o template usa {mencao}, porque o WhatsApp exige o JID na lista para
// renderizar o @ como menção de verdade (e não como texto solto).
export function montarMensagem(template, { participante, nome, grupo, total } = {}) {
  const numero = soDigitos(participante);
  let usouMencao = false;

  const valores = {
    nome: nome || numero || 'amigo(a)',
    numero,
    grupo: grupo || '',
    total: total == null ? '' : String(total),
    mencao: numero ? `@${numero}` : nome || '',
  };

  const texto = String(template ?? '')
    .replace(PLACEHOLDERS, (_, chave) => {
      const k = chave.toLowerCase();
      if (k === 'mencao') usouMencao = true;
      return valores[k];
    })
    .trim();

  const mentions = usouMencao && participante ? [participante] : [];
  return { texto, mentions };
}

// O WhatsApp reemite o mesmo 'add' em algumas situações (reconexão, sync de
// histórico). Sem esta janela o novo membro receberia a saudação duplicada.
const JANELA_DEDUPE_MS = 60_000;
const recentes = new Map(); // `${groupId}:${participante}` -> timestamp

function jaSaudado(chave) {
  const agora = Date.now();
  for (const [k, ts] of recentes) if (agora - ts > JANELA_DEDUPE_MS) recentes.delete(k);
  if (recentes.has(chave)) return true;
  recentes.set(chave, agora);
  return false;
}

// Exposto só para os testes conseguirem partir de um estado limpo.
export function _limparDedupe() {
  recentes.clear();
}

// Processa um evento de entrada. `deps`:
//   sessao { id, config }            — o número que viu a entrada
//   reply(jid, texto, { mentions })  — envio
//   getGroupInfo(jid) -> { nome, total }
//   souEu(jid) -> boolean            — evita saudar o próprio bot
//
// A saudação sai pelo mesmo número que viu a entrada, com o texto e os grupos
// configurados NELE. A deduplicação por grupo+participante abaixo é global,
// então dois números no mesmo grupo ainda mandam uma saudação só.
export async function processarEntradaGrupo(update, deps = {}) {
  const { reply, getGroupInfo, souEu } = deps;
  if (update?.action !== 'add') return;

  const groupId = update.id;
  if (!groupId) return;

  const config = deps.sessao?.config
    ? { ...getConfig(deps.sessao.id), ...deps.sessao.config }
    : getConfig(deps.sessao?.id);
  if (!deveDarBoasVindas(config, groupId)) return;

  const template = String(config.welcomeMessage ?? '').trim();
  if (!template) {
    logger.warn({ groupId }, 'welcomeEnabled ativo mas welcomeMessage está vazia — nada enviado');
    return;
  }

  // Uma consulta de metadados por evento (não por participante): entradas em
  // lote são comuns e cada chamada é uma ida à rede.
  let nome = groupId;
  let total = null;
  try {
    const info = await getGroupInfo?.(groupId);
    if (info) ({ nome = groupId, total = null } = info);
  } catch (err) {
    logger.debug({ err, groupId }, 'falha ao obter metadados do grupo para boas-vindas');
  }

  for (const participante of update.participants ?? []) {
    if (!participante) continue;
    if (souEu?.(participante)) continue; // o próprio bot foi adicionado
    if (jaSaudado(`${groupId}:${participante}`)) continue;

    const { texto, mentions } = montarMensagem(template, { participante, grupo: nome, total });
    if (!texto) continue;

    try {
      await reply(groupId, texto, { mentions });
      logger.info({ groupId, participante }, 'boas-vindas enviadas');
    } catch (err) {
      // Um envio que falha não pode abortar os demais participantes do lote.
      logger.error({ err, groupId, participante }, 'falha ao enviar boas-vindas');
    }
  }
}
