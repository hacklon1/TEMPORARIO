// Orquestra cada mensagem recebida: monitoramento, auto-resposta, comandos e extração.
//
// Tudo aqui é POR NÚMERO. `deps.sessao` diz qual número recebeu a mensagem, o
// que ele tem permissão de fazer (`recursos`) e com que configuração
// (`config`). Um recurso desligado não roda — é assim que dois números no mesmo
// servidor têm funções diferentes sem um atrapalhar o outro.
import { getConfig, getSessao } from './db.js';
import { SESSAO_PADRAO } from './sessoes.js';
import { logger } from './logger.js';
import { extractText, analisarMensagem } from './parser.js';
import { analisarPedido } from './pedidos.js';
import { papelDoRemetente, OPERADOR, DESCONHECIDO } from './membros.js';
import { executarComando, parseComando } from './commands.js';
import { analisarIndicacao, extrairMencoes, resolverIndicadora } from './indicacoes.js';
import { processarAlertaRepetido } from './alertas.js';
import { detectarComprovante, citacaoDe, ROTULO_CASAMENTO } from './servicos.js';
import {
  registrarEntrada, registrarPedido, registrarIndicacao, registrarPessoa, nomesConhecidos, jaRegistrado,
  abrirServico, casarAtendimento, casarComprovante, comprovanteJaRegistrado,
} from './store.js';
import { emitUpdate, emit } from './realtime.js';
import { ehGrupo, identidadeRemetente } from './jid.js';

// Decide se um chat deve ser monitorado (extração financeira) conforme a config.
function deveMonitorar(config, remoteJid) {
  if (ehGrupo(remoteJid)) {
    if (config.monitorMode === 'none') return false;
    if (config.monitorMode === 'all') return true;
    if (config.monitorMode === 'specific') {
      return Array.isArray(config.monitoredGroups) && config.monitoredGroups.includes(remoteJid);
    }
    return false;
  }
  return Boolean(config.monitorPrivate);
}

/**
 * Contexto do número que recebeu a mensagem. `deps.sessao` vem do whatsapp.js;
 * a queda para o Número 1 existe para quem chama processMessage sem sessão
 * (testes e código antigo) continuar funcionando igual.
 */
function contexto(deps) {
  const bruta = deps?.sessao;
  const id = bruta?.id ?? SESSAO_PADRAO;
  const sessao = bruta ?? getSessao(id);
  return {
    id,
    nome: sessao?.nome ?? id,
    recursos: sessao?.recursos ?? {},
    // A config global (fuso, janela) entra por baixo da config do número.
    config: { ...getConfig(id), ...(bruta?.config ?? {}) },
  };
}

// Processa uma mensagem do Baileys. `deps` traz helpers de envio/nomes já
// amarrados ao número (reply, getGroupName, getGroupMembers, …).
export async function processMessage(msg, deps) {
  try {
    const { reply, getGroupName } = deps;
    const remoteJid = msg.key?.remoteJid;
    if (!remoteJid || remoteJid === 'status@broadcast') return;
    if (msg.key?.fromMe) return; // ignora as próprias mensagens

    const sessao = contexto(deps);
    const { recursos, config } = sessao;
    const grupo = ehGrupo(remoteJid);
    const remetente = identidadeRemetente(msg); // { id, lid, pn, digitos }
    const operatorName = msg.pushName || null;
    const text = extractText(msg);
    // Comprovante PIX (passo 3 da validação) vem como imagem/PDF e quase sempre
    // SEM legenda — daí a saída antecipada só valer quando não há nem texto nem
    // arquivo. Tudo o que lê texto abaixo devolve null para string vazia.
    const midia = detectarComprovante(msg);
    if (!text && !midia) return;
    // Mensagem citada (o "responder" do WhatsApp): é a prova mais forte de que
    // o Operador está falando COM aquela Brogueira, e de que o comprovante se
    // refere àquele atendimento.
    const citacao = citacaoDe(msg);

    // Id da mensagem no WhatsApp: é o MESMO em todos os números que a
    // receberam. É por ele que o store recusa gravar duas vezes quando dois
    // números estão no mesmo grupo com o mesmo recurso ligado.
    const msgId = msg.key?.id ?? null;

    const groupName = grupo ? await getGroupName(remoteJid) : null;
    const monitorado = deveMonitorar(config, remoteJid);

    // Papel do remetente no grupo (Operador = admin, Brogueira = membro comum).
    // Resolvido no máximo uma vez por mensagem — pedido, indicação e extração
    // financeira precisam do mesmo dado, e cada consulta pode ir à rede.
    let papelPendente = null;
    const obterPapel = () => {
      if (!papelPendente) {
        papelPendente = grupo
          ? papelDoRemetente(remoteJid, remetente, deps.getGroupMembers)
          : Promise.resolve(DESCONHECIDO);
      }
      return papelPendente;
    };

    // Memória de quem é quem. Cada mensagem ensina um par nome ↔ número, e é
    // só assim que "@5511999999999" numa indicação vira "Ana" — inclusive nas
    // indicações já gravadas, cujo nome é resolvido na hora do relatório.
    // Só faz sentido para os números que coletam alguma coisa.
    const coleta = recursos.monitorar || recursos.pedidos || recursos.indicacoes;
    if (monitorado && coleta) {
      registrarPessoa({ id: remetente.id, pn: remetente.pn, nome: operatorName, groupId: grupo ? remoteJid : null });
    }

    // 1) Comandos administrativos (funcionam em grupo ou privado)
    const ehComando = parseComando(text);
    if (ehComando) {
      if (!recursos.comandos) return; // este número não atende comandos
      const res = executarComando(text, remetente, config);
      // res === null → remetente não autorizado: silêncio proposital, para o
      // bot não responder a qualquer "!qualquercoisa" dentro dos grupos.
      if (res?.reply) {
        await reply(remoteJid, res.reply);
        emit('log', { tipo: 'comando', cmd: ehComando.cmd, de: remetente.pn ?? remetente.lid, sessaoId: sessao.id, ts: Date.now() });
      } else {
        logger.info({ cmd: ehComando.cmd, de: remetente.pn ?? remetente.lid, sessao: sessao.id }, 'comando ignorado (sem autorização)');
      }
      return; // comando não vira lançamento financeiro
    }

    // 2) Pedido de link (Brogueiras). Vem antes da extração financeira porque é
    //    outro tipo de mensagem: quem PEDE (link + "7 contas") x quem ATENDE
    //    (o comprovante com "Montante: 233"). Uma mensagem pode virar as duas
    //    coisas, então não há `return` aqui.
    if (grupo && monitorado && recursos.pedidos) {
      const pedido = analisarPedido(text);
      // Mesma mensagem já gravada por outro número (ou reentregue pelo próprio
      // WhatsApp numa reconexão): não conta duas vezes.
      if (pedido && !jaRegistrado('pedidos', msgId)) {
        const papel = await obterPapel();
        const registro = registrarPedido({
          sessaoId: sessao.id,
          msgId,
          groupId: remoteJid,
          groupName,
          autorId: remetente.id,
          autorPn: remetente.pn,
          autorNome: operatorName,
          papel,
          pedido,
          text,
        });
        emit('pedido', registro);
        // PASSO 1 da validação em 3 passos: o pedido abre um serviço, que fica
        // aguardando um Operador responder. Pedido de Operador não abre nada
        // (abrirServico recusa) — ele reposta divulgação, não pede serviço.
        const servico = abrirServico(registro);
        if (servico) emit('servico', { fase: 'pedido', servico });
        // Link repetido: avisa o painel na hora, sem esperar alguém abrir a
        // aba. Operador fora — ele reposta link o tempo todo (divulgação), e o
        // relatório das Brogueiras também o deixa de fora.
        if (registro.repetido && papel !== 'operador') {
          emit('repetido', {
            id: registro.id,
            ts: registro.ts,
            sessaoId: registro.sessaoId,
            autorNome: registro.autorNome,
            autorPn: registro.autorPn,
            papel: registro.papel,
            groupName: registro.groupName,
            pedido: registro.pedido,
            repeticoes: registro.repeticoes,
          });
          logger.warn(
            {
              sessao: sessao.id,
              de: registro.autorNome,
              links: registro.repeticoes.map((r) => r.link),
              vezes: registro.repeticoes.map((r) => r.vezes),
              deOutra: registro.repetidoDeOutra,
            },
            'link repetido no grupo',
          );
          // Passou do limite configurado? Avisa no grupo de operação marcando
          // todos — pelo MESMO número que viu a repetição. Não bloqueia o resto
          // do processamento e nunca lança.
          if (recursos.alertas) await processarAlertaRepetido(registro, deps, config);
        }
        emitUpdate();
        logger.debug({ sessao: sessao.id, tipo: pedido.tipo, papel, links: pedido.links.length }, 'pedido registrado');
      }
    }

    // 2.5) Indicação ("Vim por @fulana"). Só em grupo monitorado: é lá que as
    //      Brogueiras se apresentam. Não tem `return` — uma apresentação pode
    //      vir junto de um pedido, e as duas coisas devem ser registradas.
    if (grupo && monitorado && recursos.indicacoes && !jaRegistrado('indicacoes', msgId)) {
      const indicacao = analisarIndicacao(text, { nomesConhecidos: nomesConhecidos() });
      if (indicacao) {
        const indicadora = resolverIndicadora(indicacao, extrairMencoes(msg));
        const papel = await obterPapel();
        const registro = registrarIndicacao({
          sessaoId: sessao.id,
          msgId,
          groupId: remoteJid,
          groupName,
          indicada: { id: remetente.id, pn: remetente.pn, nome: operatorName, papel },
          indicadora,
          analise: indicacao,
          text,
        });
        // null = auto-indicação (citou o próprio número): nada a registrar.
        if (registro) {
          emit('indicacao', registro);
          emitUpdate();
          logger.info(
            { sessao: sessao.id, indicada: registro.indicadaNome, indicadora: registro.indicadoraNome, padrao: registro.padrao },
            registro.duplicada ? 'indicação repetida (fora do ranking)' : 'indicação registrada',
          );
        }
      }
    }

    // 3) Extração financeira (se o chat for monitorado)
    //
    // SÓ DE OPERADOR (admin do grupo). Montante e contas medem o trabalho de
    // quem ATENDE; a Brogueira que escreve "300 de montante" está PEDINDO, e
    // isso já foi registrado no passo 2. Sem esse filtro o mesmo valor entrava
    // duas vezes no painel — uma como pedido, outra como produção — e ainda
    // inventava "operadores" que nunca atenderam nada.
    if (monitorado && recursos.monitorar && !jaRegistrado('messages', msgId)) {
      const analise = analisarMensagem(text);
      if (analise) {
        // 'desconhecido' (falha ao ler os membros do grupo) também não entra:
        // sem confirmar que é admin, gravar é justamente o bug de volta.
        const papel = grupo ? await obterPapel() : null;
        if (grupo && papel !== OPERADOR) {
          // info (não debug): com LOG_LEVEL=info dá para conferir no journal que
          // o filtro está agindo. warn quando o papel não pôde ser confirmado —
          // aí pode ser lançamento de Operador sendo perdido por falha de rede.
          const nivel = papel === DESCONHECIDO ? 'warn' : 'info';
          logger[nivel](
            { sessao: sessao.id, papel, de: remetente.pn ?? remetente.lid, grupo: groupName ?? remoteJid },
            'telemetria ignorada: remetente não é administrador do grupo',
          );
        } else {
          const entry = registrarEntrada({
            sessaoId: sessao.id,
            msgId,
            groupId: grupo ? remoteJid : null,
            groupName,
            operatorId: remetente.id,
            operatorPn: remetente.pn,
            operatorName,
            text,
            analise,
          });
          emit('mensagem', entry);
          // PASSO 2: esta é a MESMA mensagem que já alimentava montante/contas.
          // Agora ela também tenta fechar o pedido de uma Brogueira — por
          // citação, pelo valor que bate ou, em último caso, por proximidade.
          if (grupo) {
            const servico = casarAtendimento(entry, { citacao });
            if (servico) {
              emit('servico', { fase: 'atendimento', servico });
              logger.info(
                {
                  sessao: sessao.id,
                  operador: entry.operatorName,
                  brogueira: servico.brogueiraNome,
                  casamento: servico.atendimento.casamento,
                },
                'atendimento casado com pedido',
              );
            }
          }
          emitUpdate();
          logger.debug({ sessao: sessao.id, montante: entry.montante, contas: entry.contasQtd }, 'lançamento registrado');
        }
      }
    }

    // 3.5) PASSO 3 da validação: comprovante PIX (imagem ou PDF) da Brogueira.
    //
    // Fecha o serviço que ELA pediu e que um Operador atendeu dentro do prazo.
    // Fica junto do recurso "pedidos" porque é a ponta dela do ciclo — o mesmo
    // número que registrou o pedido é quem valida o comprovante.
    if (midia && grupo && monitorado && recursos.pedidos && !comprovanteJaRegistrado(msgId)) {
      const validado = casarComprovante({
        groupId: remoteJid,
        autor: remetente,
        comprovante: midia,
        msgId,
        sessaoId: sessao.id,
        citacao,
      });
      if (validado) {
        emit('servico', { fase: 'validado', servico: validado });
        emitUpdate();
        logger.info(
          {
            sessao: sessao.id,
            brogueira: validado.brogueiraNome,
            operador: validado.atendimento?.operatorName,
            tipo: midia.tipo,
            casamento: ROTULO_CASAMENTO[validado.atendimento?.casamento] ?? null,
          },
          'serviço validado (3 passos)',
        );
      } else {
        logger.debug({ sessao: sessao.id, tipo: midia.tipo }, 'comprovante sem atendimento em aberto');
      }
    }

    // 4) Resposta automática (não responde a comandos nem a si mesmo)
    // Só para mensagem com texto: uma imagem solta nunca disparou resposta.
    if (text && recursos.autoResposta && config.autoReplyEnabled) {
      const podeResponder = grupo ? config.autoReplyGroups : true;
      const mensagem = String(config.autoReplyMessage ?? '').trim();
      if (podeResponder && mensagem) {
        await reply(remoteJid, mensagem);
      } else if (podeResponder && !mensagem) {
        logger.warn({ sessao: sessao.id }, 'autoReplyEnabled ativo mas autoReplyMessage está vazia — nada enviado');
      }
    }
  } catch (err) {
    logger.error(err, 'erro ao processar mensagem');
  }
}
