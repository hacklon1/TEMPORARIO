// Ponte de tempo real com o dashboard (Socket.IO). emitUpdate() empurra o snapshot.
// Papéis: 'admin' recebe tudo; 'viewer' recebe só os dados de monitoramento do Painel.
//
// Com mais de um número, o snapshot leva a lista das sessões (estado de cada
// conexão + recursos) e os eventos de QR/conexão passaram a dizer de QUAL número
// são: { sessaoId, ... }.
import { getDb } from './db.js';
import { dadosRelatorio } from './reports.js';
import {
  atividadePorHora, filtrarEntradas, intervaloPeriodo, mensagensPorDia, relatorioServicos,
  rotuloPeriodo, dayKey, validadosPorDia,
} from './store.js';
import { statusExport } from './exportador.js';

let io = null;

/**
 * Quem sabe o estado das conexões é o whatsapp.js — que já importa este módulo.
 * Em vez de um import circular, o server.js injeta a função aqui no boot.
 * Devolve { sessoes: [...], conflitos: [...], connection: 'open'|... }.
 */
let estadoProvider = () => ({ sessoes: [], conflitos: [], connection: null });

export function setEstadoProvider(fn) {
  if (typeof fn === 'function') estadoProvider = fn;
}

export function setIo(instance) {
  io = instance;
}

function estadoAtual() {
  try {
    return estadoProvider() ?? { sessoes: [], conflitos: [], connection: null };
  } catch {
    return { sessoes: [], conflitos: [], connection: null };
  }
}

export function connectionAtual() {
  return estadoAtual().connection;
}

export function emit(event, payload) {
  if (io) io.emit(event, payload);
}

/**
 * Evento só para administradores (sala 'admin').
 * A aba Relatórios é financeira e adminOnly: o aviso de "mudou alguma coisa"
 * não pode sair para a sala 'viewer', nem levando só um contador — quem não
 * pode ver os números também não precisa saber que eles mudaram.
 */
export function emitAdmin(event, payload) {
  if (io) io.to('admin').emit(event, payload);
}

/**
 * Snapshot enviado ao navegador.
 *   role   — 'viewer' não recebe config nem agendamentos.
 *   sessao — filtra os dados por número ('n1'|'n2'|'n3'); vazio = os três somados.
 *   period — recorte dos números: 'today' (o de sempre, que o socket empurra) ou
 *            um dia/intervalo do passado, quando o painel entra em modo histórico.
 *
 * O bloco continua se chamando `hoje` mesmo olhando para ontem: é o contrato que
 * o painel já consome, e renomeá-lo quebraria o snapshot de quem estiver com a
 * página aberta durante o deploy. O que ele está mostrando vai em `periodo`.
 */
export function snapshot(conn, role = 'admin', sessao = null, period = 'today') {
  const db = getDb();
  const estado = estadoAtual();
  const filtro = sessao || null;
  const intervalo = intervaloPeriodo(period);
  const historico = period !== 'today';
  // Em modo histórico a série de 7 dias termina no dia escolhido, e as "últimas
  // mensagens" são as daquele recorte — não as últimas que chegaram agora.
  const fimDaSerie = historico ? (intervalo?.ate ?? dayKey()) : null;
  const base = {
    connection: conn ?? estado.connection ?? null,
    role,
    sessaoFiltro: filtro,
    // Estado de cada número. O viewer vê nome/conexão (é o que o cabeçalho
    // mostra), mas não os recursos nem a configuração.
    sessoes: estado.sessoes.map((s) =>
      role === 'viewer'
        ? { id: s.id, nome: s.nome, ativa: s.ativa, connection: s.connection }
        : s),
    stats: db.stats,
    // O que a tela está mostrando: 'today' (ao vivo) ou um dia do passado.
    periodo: {
      valor: typeof period === 'string' ? period : (period?.day ?? 'today'),
      rotulo: rotuloPeriodo(period),
      de: intervalo?.de ?? null,
      ate: intervalo?.ate ?? null,
      historico,
    },
    hoje: dadosRelatorio(period, { sessao: filtro }),
    ultimasMensagens: (historico
      ? filtrarEntradas(period, filtro)
      : db.messages.filter((m) => !filtro || (m.sessaoId ?? 'n1') === filtro))
      .slice(-20)
      .reverse(),
    analytics: {
      porHora: atividadePorHora(period, filtro),
      porDia: mensagensPorDia(7, filtro, fimDaSerie),
      // A onda da semana: montante que fechou os 3 passos, dia a dia.
      validadoPorDia: validadosPorDia(7, filtro, fimDaSerie),
    },
    // DESEMPENHO DOS OPERADORES — só os serviços que passaram pelos 3 passos.
    // Vai no snapshot porque o quadro fica no Painel (que o viewer também vê);
    // o detalhe entra cortado — a lista inteira é pesada para um evento que sai
    // a cada mensagem, e a aba busca a versão completa em /api/servicos.
    servicos: relatorioServicos(period, { sessao: filtro, limiteDetalhe: 25 }),
  };
  if (role === 'viewer') return base; // só monitoramento
  return {
    ...base,
    // Config de cada número, sem as senhas.
    configs: Object.fromEntries(getDb().sessoes.map((s) => [s.id, sanitizeConfig(s.config)])),
    configGlobal: sanitizeConfigGlobal(db.config),
    // Exportação para o DB Dashboard: último envio, pendentes e último erro.
    export: statusExport(),
    // Sobreposições entre números (mesmo grupo, mesmo recurso) — o painel avisa.
    conflitos: estado.conflitos,
    schedules: db.schedules,
    // Último alerta de link repetido disparado (o painel mostra "já avisei").
    alertas: db.alertas?.ultimo ?? null,
  };
}

// Empurra o snapshot certo para cada papel (salas 'admin' e 'viewer').
// Sem filtro de número: quem estiver filtrando no painel recarrega pela API.
export function emitUpdate(conn) {
  if (!io) return;
  const atual = conn ?? estadoAtual().connection;
  io.to('admin').emit('update', snapshot(atual, 'admin'));
  io.to('viewer').emit('update', snapshot(atual, 'viewer'));
}

// QR é só para admins (pareamento) e sempre identificado pelo número.
export function emitQr(sessaoId, qr) {
  if (io) io.to('admin').emit('qr', { sessaoId, qr });
}

export function emitConnection(sessaoId, connection) {
  emit('connection', { sessaoId, connection, geral: estadoAtual().connection });
}

// Nunca vaza a senha de comandos para o navegador.
function sanitizeConfig(config) {
  const c = { ...config };
  c.commandPasswordSet = Boolean(config.commandPassword);
  delete c.commandPassword;
  return c;
}

/**
 * Config GLOBAL sem os segredos da exportação. O painel precisa saber se o
 * segredo ESTÁ preenchido (para o campo mostrar "salvo"), nunca qual é: o
 * snapshot viaja por Socket.IO a cada mensagem e fica no histórico do
 * navegador de quem abriu o painel.
 */
export function sanitizeConfigGlobal(config = {}) {
  const c = { ...config };
  c.exportSegredoSet = Boolean(config.exportSegredo);
  c.exportApiKeySet = Boolean(config.exportApiKey);
  delete c.exportSegredo;
  delete c.exportApiKey;
  return c;
}
