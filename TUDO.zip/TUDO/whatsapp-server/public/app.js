// Painel do Whatsap Server — cliente.
// Autentica, conecta o Socket.IO e renderiza KPIs, gráficos (SVG puro) e tabelas.
//
// Regras de visualização seguidas aqui (e por que):
//  · Séries categóricas em ordem fixa (1 = montante, 2 = contas). Nunca por rank:
//    a cor segue a métrica, então um filtro não repinta o que sobrou.
//  · Magnitude (heatmap) usa UMA hue, claro→escuro. Arco-íris não codifica ordem.
//  · Operadores são categorias, não uma série temporal → barras, não linha.
//  · Rótulo só no extremo; o resto fica no eixo, no tooltip e na tabela ao lado.
'use strict';

let TOKEN = localStorage.getItem('ws_token') || '';
let ROLE = localStorage.getItem('ws_role') || 'admin';
let socket = null;
let snap = null;
let msgPage = 0;

/* ═══ Números (até 3 sessões de WhatsApp) ═══
   O painel inteiro passou a ter um "de qual número?" — cada aba guarda a sua
   escolha, e o filtro do topo vale para os dados (Painel/Brogueiras/Indicações). */
let SESSOES = [];                 // estado de cada número (vem do snapshot)
let RECURSOS_CAT = [];            // catálogo de recursos (vem de /api/sessoes)
let cfgSessao = localStorage.getItem('ws_cfg_sessao') || 'n1';   // aba Configurações
let grpSessao = localStorage.getItem('ws_grp_sessao') || 'n1';   // aba Grupos
let filtroSessao = localStorage.getItem('ws_filtro_sessao') || 'todas'; // dados

const sessaoPorId = (id) => SESSOES.find((s) => s.id === id) || null;
// Consultas que precisam de UMA conta (listar grupos, ler membros): usa o
// número filtrado; sem filtro, o primeiro que estiver conectado.
const sessaoParaConsulta = () =>
  (filtroSessao !== 'todas' && filtroSessao)
  || SESSOES.find((s) => s.ativa && s.connection === 'open')?.id
  || 'n1';
const nomeSessao = (id) => sessaoPorId(id)?.nome || (id === 'n1' ? 'Número 1' : id);
// Config de um número (o snapshot traz a de todos, sem senhas).
// Config de um número JUNTO com o que é global (fuso, janelas de análise): o
// snapshot manda os dois separados, e a aba Configurações edita os dois na
// mesma tela. Sem juntar aqui, todo campo marcado "global" voltava ao padrão
// a cada snapshot — e o próximo Salvar gravaria esse padrão por cima.
const configDe = (id) =>
  (snap?.configs?.[id] ? { ...(snap.configGlobal ?? {}), ...snap.configs[id] } : null);
// Sufixo de query para as rotas que aceitam número.
const qsSessao = (id) => (id && id !== 'todas' ? 'sessao=' + encodeURIComponent(id) : '');

const ROTULO_CONEXAO = {
  open: 'conectado', connecting: 'conectando…', close: 'desconectado',
  desligado: 'desligado', erro: 'erro',
};

// Preenche um <select> de números preservando a escolha atual.
function preencherSelectSessoes(sel, { comTodas = false, valor = null } = {}) {
  if (!sel) return;
  const atual = valor ?? sel.value;
  const opcoes = (comTodas ? ['<option value="todas">Todos os números</option>'] : [])
    .concat(SESSOES.map((s) => {
      const estado = s.ativa ? (ROTULO_CONEXAO[s.connection] || s.connection) : 'desligado';
      return `<option value="${esc(s.id)}">${esc(s.nome)} · ${esc(estado)}</option>`;
    }));
  sel.innerHTML = opcoes.join('');
  if (atual && [...sel.options].some((o) => o.value === atual)) sel.value = atual;
}

const $ = (id) => document.getElementById(id);
const brl = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });
const esc = (s) => String(s ?? '').replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
const hora = (iso) => new Date(iso).toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' });
const num = (n) => Number(n || 0).toLocaleString('pt-BR');
const dataDia = (day) => String(day ?? '').split('-').reverse().join('/'); // 2026-08-27 → 27/08/2026

// Corta texto CONTANDO CARACTERE, não unidade UTF-16. Os nomes do grupo vêm em
// fonte estilizada (𝐀𝐒𝐒𝐈𝐒𝐓𝐄𝐍𝐓𝐄, bloco U+1D400) e com emoji — cada um ocupa duas
// unidades, e um slice() cru parte o par no meio, virando "�" na tela.
function cortar(texto, limite) {
  const chars = [...String(texto ?? '')];
  return chars.length > limite ? chars.slice(0, limite - 1).join('') + '…' : chars.join('');
}

// Valores compactos para eixos e KPIs (1,2 mil / 1,3 mi).
function compacto(n) {
  const v = Number(n) || 0;
  const a = Math.abs(v);
  if (a >= 1e6) return (v / 1e6).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mi';
  if (a >= 1e3) return (v / 1e3).toLocaleString('pt-BR', { maximumFractionDigits: 1 }) + ' mil';
  return v.toLocaleString('pt-BR', { maximumFractionDigits: 0 });
}
const brlCompacto = (n) => 'R$ ' + compacto(n);

// Cores lidas do CSS, para o tema claro/escuro trocar tudo num lugar só.
let C = {};
function lerCores() {
  const cs = getComputedStyle(document.documentElement);
  const g = (n) => cs.getPropertyValue(n).trim();
  C = {
    s1: g('--s1'), s2: g('--s2'), s2Claro: g('--s2-claro'), s3: g('--s3'),
    grid: g('--grid'), axis: g('--axis'), muted: g('--muted'),
    ink: g('--ink'), ink2: g('--ink-2'), surface: g('--surface'),
    seq: [g('--seq-100'), g('--seq-200'), g('--seq-300'), g('--seq-400'), g('--seq-500'), g('--seq-600'), g('--seq-700')],
    seqZero: g('--seq-zero'),
    // Serviços validados: UMA hue em dois tons (a hachura é o encoding
    // secundário) — ver o comentário do token no style.css.
    svOk: g('--sv-ok'), svPend: g('--sv-pend'), svPendLinha: g('--sv-pend-linha'),
  };
}

async function api(path, opts = {}) {
  const res = await fetch('/api' + path, {
    ...opts,
    headers: { 'Content-Type': 'application/json', Authorization: 'Bearer ' + TOKEN, ...(opts.headers || {}) },
  });
  if (res.status === 401) throw new Error('não autorizado');
  return res.json();
}

/* ═══════════════ Tooltip (camada de hover real) ═══════════════ */
const tip = $('tip');

function mostrarTip(html, x, y) {
  tip.innerHTML = html;
  tip.classList.add('on');
  posicionarTip(x, y);
}
function posicionarTip(x, y) {
  const pad = 14;
  const r = tip.getBoundingClientRect();
  let px = x + pad, py = y + pad;
  if (px + r.width > innerWidth - 8) px = x - r.width - pad;
  if (py + r.height > innerHeight - 8) py = y - r.height - pad;
  tip.style.left = Math.max(8, px) + 'px';
  tip.style.top = Math.max(8, py) + 'px';
}
const esconderTip = () => tip.classList.remove('on');

// Monta o conteúdo do tooltip: título + linhas rotuladas com o swatch da série.
function tipHtml(titulo, linhas) {
  return `<div class="t-title">${esc(titulo)}</div>` +
    linhas.map(([cor, rot, val]) =>
      `<div class="t-row">${cor ? `<i style="background:${cor}"></i>` : ''}${esc(rot)}<b>${esc(val)}</b></div>`).join('');
}
// Escapa para caber dentro de um atributo HTML.
const attr = (s) => String(s).replace(/"/g, '&quot;');

// Liga o hover/foco de tudo que tiver data-tip dentro de um container.
function ligarTips(root) {
  root.querySelectorAll('[data-tip]').forEach((el) => {
    const abrir = (e) => mostrarTip(el.dataset.tip, e.clientX, e.clientY);
    el.addEventListener('mouseenter', abrir);
    el.addEventListener('mousemove', (e) => posicionarTip(e.clientX, e.clientY));
    el.addEventListener('mouseleave', esconderTip);
    // Teclado vê o mesmo que o mouse.
    el.addEventListener('focus', () => {
      const r = el.getBoundingClientRect();
      mostrarTip(el.dataset.tip, r.left + r.width / 2, r.top);
    });
    el.addEventListener('blur', esconderTip);
  });
}

const vazio = (txt) => `<div class="empty">${esc(txt)}</div>`;

/* ── Busca por nome ou número ─────────────────────────────
   Um só filtro serve as duas tabelas (Brogueiras e Operadores). Nome casa sem
   acento e sem maiúscula; se o termo tiver dígitos, eles são comparados com o
   telefone E com o identificador interno — e por "termina com", porque o
   usuário digita "99999" e o número guardado é o completo com DDI. */
const semAcento = (t) => String(t ?? '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().trim();
const soNumeros = (t) => String(t ?? '').replace(/\D/g, '');

function casaBusca(item, termo) {
  const t = semAcento(termo);
  if (!t) return true;
  if (semAcento(item.nome).includes(t)) return true;
  const digitos = soNumeros(termo);
  if (!digitos) return false;
  return [item.pn, item.id].some((forma) => {
    const d = soNumeros(forma);
    return d && (d.includes(digitos) || digitos.includes(d));
  });
}

// "5573999999999" → "+55 73 99999-9999" (o que a pessoa reconhece no celular).
function telefoneVisivel(pn, id) {
  const d = soNumeros(pn);
  if (!d) return String(id ?? '').includes('@lid') ? '' : soNumeros(id);
  const m = /^(\d{2})(\d{2})(\d{4,5})(\d{4})$/.exec(d);
  return m ? `+${m[1]} ${m[2]} ${m[3]}-${m[4]}` : d;
}

/* ═══════════════ Gráficos ═══════════════ */

// Sparkline dos KPIs: área a ~10% + linha de 2px.
function spark(valores, cor) {
  const vals = (valores && valores.length) ? valores : [0, 0];
  const w = 120, h = 30, pad = 3;
  const max = Math.max(...vals, 1), min = Math.min(...vals, 0), rng = (max - min) || 1;
  const X = (i) => pad + i * (w - 2 * pad) / Math.max(vals.length - 1, 1);
  const Y = (v) => h - pad - ((v - min) / rng) * (h - 2 * pad);
  const linha = vals.map((v, i) => `${X(i).toFixed(1)},${Y(v).toFixed(1)}`).join(' ');
  const area = `${X(0).toFixed(1)},${h - pad} ${linha} ${X(vals.length - 1).toFixed(1)},${h - pad}`;
  const ultimo = vals[vals.length - 1];
  return `<svg viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-hidden="true">
    <polygon points="${area}" fill="${cor}" opacity=".10"/>
    <polyline points="${linha}" fill="none" stroke="${cor}" stroke-width="2" stroke-linejoin="round" stroke-linecap="round" vector-effect="non-scaling-stroke"/>
    <circle cx="${X(vals.length - 1).toFixed(1)}" cy="${Y(ultimo).toFixed(1)}" r="2.6" fill="${cor}" stroke="${C.surface}" stroke-width="2"/>
  </svg>`;
}

// Desempenho por operador: barras horizontais agrupadas, 2 séries, 1 eixo.
// Horizontal porque nome de operador é longo; agrupado porque montante e
// contas são grandezas distintas que se comparam lado a lado.
// Uma coluna vertical: topo arredondado em 4px, base quadrada na linha zero.
// `topo:false` é para o trecho de baixo de uma barra empilhada — só o segmento
// mais alto arredonda, senão a pilha ganha um degrau no meio.
function colunaV(x, largura, base, altura, cor, { topo = true, extra = '' } = {}) {
  if (altura <= 0) return '';
  const alt = Math.max(altura, 2);
  const y = base - alt;
  const X = x.toFixed(1), Yt = y.toFixed(1), B = base.toFixed(1), Lg = largura.toFixed(1);
  if (!topo) return `<rect x="${X}" y="${Yt}" width="${Lg}" height="${alt.toFixed(1)}" fill="${cor}" ${extra}/>`;
  const r = Math.min(4, alt, largura / 2);
  return `<path d="M${X} ${B} V${(y + r).toFixed(1)} a${r} ${r} 0 0 1 ${r} -${r} h${(largura - 2 * r).toFixed(1)} a${r} ${r} 0 0 1 ${r} ${r} V${B} Z" fill="${cor}" ${extra}/>`;
}

// Grade horizontal + rótulos do eixo de valor (à esquerda). Recessiva: hairline
// sólida, 4 divisões — a leitura fina vem do hover, não da grade.
function gradeV(L, w, R, T, ih, max, fmt = brlCompacto) {
  let out = '';
  for (let i = 0; i <= 4; i++) {
    const v = max * i / 4;
    const y = T + ih - (v / max) * ih;
    out += `<line x1="${L}" y1="${y.toFixed(1)}" x2="${w - R}" y2="${y.toFixed(1)}" stroke="${C.grid}" stroke-width="1"/>
      <text x="${L - 8}" y="${(y + 3.5).toFixed(1)}" text-anchor="end" fill="${C.muted}" font-size="10">${esc(fmt(v))}</text>`;
  }
  return out;
}

// Nome do operador embaixo da coluna. Cortado no que cabe na banda; o nome
// inteiro fica no tooltip e no <title>.
function rotuloEixo(nome, cx, y, banda) {
  const cabe = Math.max(6, Math.floor(banda / 6.6));
  return `<text x="${cx.toFixed(1)}" y="${y}" text-anchor="middle" fill="${C.ink2}" font-size="10.5">${esc(cortar(nome, cabe))}</text>`;
}


/* ═══════════════ QUADRO 2 — Serviços validados (3 passos) ═══════════════
   Barra empilhada por Operador: o que ele FECHOU (pedido → resposta →
   comprovante) e o que ele atendeu mas não fechou. É a mesma medida partida
   pelo desfecho, então UMA hue em dois tons, e não duas cores categóricas.

   A parte não validada é hachurada: quem não distingue as duas cores continua
   distinguindo a textura, e o valor exato está no hover e na tabela abaixo.

   DUAS pilhas por Operador (pedido do usuário): montante validado e CONTAS
   validadas — a MESMA série laranja "Contas (R$)" do quadro azul ao lado, agora
   recortada pelo ciclo dos 3 passos. As duas em R$ e no MESMO eixo: é o que faz
   os dois quadros falarem da mesma coisa, o da esquerda com tudo o que o
   Operador lançou e o da direita só com o que fechou. Grupo sem nenhuma conta
   não ganha a 2ª coluna — o quadro fica exatamente como era. */
/* A ONDA DA SEMANA — quanto de montante VALIDADO saiu em cada dia.
   Área suave porque a pergunta é de forma, não de comparação exata: "a semana
   subiu ou caiu, e onde ficou o pico?". A curva é uma Catmull-Rom convertida
   em bezier — passa por todos os pontos, sem inventar ondulação que o dado não
   tem.

   O desenho gasta a ousadia em UM lugar: a própria onda (traço grosso com
   brilho e enchimento em três paradas). Em volta, tudo recua — três linhas de
   grade em vez de cinco, um ponto só (hoje) em vez de sete, e o montante
   lançado como uma segunda onda quase transparente, água atrás da água, em vez
   de mais um traço competindo. */
function ondaDaSemana(dias, lancados) {
  const el = $('chart-onda');
  const data = Array.isArray(dias) ? dias : [];
  if (!data.length || data.every((d) => !d.montante)) {
    el.innerHTML = vazio('Nenhum montante validado nos últimos 7 dias');
    $('onda-legend').innerHTML = '';
    $('onda-resumo').textContent = '';
    return;
  }

  /* Mesma caixa e mesma área de plotagem do quadro de validados ao lado: os
     dois dividem a linha, e altura igual é o que deixa comparar de relance. */
  const w = 520, h = 220, L = 48, R = 10, T = 18, B = 48;
  const iw = w - L - R, ih = h - T - B, base = T + ih;
  const refs = Array.isArray(lancados) && lancados.length === data.length ? lancados : [];
  const max = Math.max(...data.map((d) => d.montante), ...refs.map((d) => d.montante || 0), 1);
  const X = (i) => L + (data.length === 1 ? iw / 2 : (i * iw) / (data.length - 1));
  const Y = (v) => base - (v / max) * ih;

  // Três linhas bastam para dar escala; cinco viram cerca na frente da onda.
  let grade = '';
  for (const parte of [0, 0.5, 1]) {
    const v = max * parte, y = Y(v);
    grade += `<line x1="${L}" y1="${y.toFixed(1)}" x2="${w - R}" y2="${y.toFixed(1)}"
        stroke="${C.grid}" stroke-width="1" ${parte === 0 ? '' : 'stroke-dasharray="2 4"'}/>
      <text x="${L - 10}" y="${(y + 3.5).toFixed(1)}" text-anchor="end" fill="${C.muted}" font-size="10">${compacto(v)}</text>`;
  }

  // Catmull-Rom → bezier cúbica: passa por todos os pontos, sem estourar.
  const curva = (pontos) => pontos.map((p, i) => {
    if (i === 0) return `M${p[0].toFixed(1)} ${p[1].toFixed(1)}`;
    const p0 = pontos[i - 2] || pontos[i - 1];
    const p1 = pontos[i - 1];
    const p2 = p;
    const p3 = pontos[i + 1] || p;
    const c1 = [p1[0] + (p2[0] - p0[0]) / 6, p1[1] + (p2[1] - p0[1]) / 6];
    const c2 = [p2[0] - (p3[0] - p1[0]) / 6, p2[1] - (p3[1] - p1[1]) / 6];
    return `C${c1[0].toFixed(1)} ${c1[1].toFixed(1)} ${c2[0].toFixed(1)} ${c2[1].toFixed(1)} ${p2[0].toFixed(1)} ${p2[1].toFixed(1)}`;
  }).join(' ');

  const fechar = (linha) => `${linha} L${X(data.length - 1).toFixed(1)} ${base.toFixed(1)} L${X(0).toFixed(1)} ${base.toFixed(1)} Z`;
  const linhaValidado = curva(data.map((d, i) => [X(i), Y(d.montante)]));

  // A água de trás: o montante lançado, sem traço, só um véu. Dá a referência
  // ("quanto passou") sem disputar a leitura com a onda que interessa.
  const veu = refs.length && refs.some((d) => d.montante)
    ? `<path d="${fechar(curva(refs.map((d, i) => [X(i), Y(d.montante || 0)])))}" fill="${C.s1}" opacity=".12"/>`
    : '';

  const hoje = data.find((d) => d.hoje);

  // Sem etiqueta de valor DENTRO da onda (pedido do usuário): o desenho é a
  // forma da semana, e o número escrito por cima disputava com ela. Os valores
  // continuam à mão — na dica de cada dia, no resumo do cabeçalho do card e nos
  // KPIs logo acima.

  let marcas = '';
  data.forEach((d, i) => {
    const x = X(i), y = Y(d.montante);
    const dica = attr(tipHtml(`${d.diaSemana} ${d.label}`, [
      [C.svOk, 'Montante validado', brl(d.montante)],
      [null, 'Serviços', num(d.servicos)],
      [null, 'Salário dos Operadores', brl(d.salario)],
      ...(refs[i] ? [[C.s1, 'Montante lançado', brl(refs[i].montante || 0)]] : []),
    ]));
    // Rótulo do dia numa linha só: "seg 25". A data inteira já está na dica.
    const forte = d.hoje;
    marcas += `<text x="${x.toFixed(1)}" y="${(base + 20).toFixed(1)}" text-anchor="middle"
      fill="${forte ? C.ink : C.muted}" font-size="10.5" ${forte ? 'font-weight="600"' : ''}>${esc(d.diaSemana)} ${esc(d.label.slice(0, 2))}</text>`;
    // Alvo largo de hover: a onda é fina demais para servir de área.
    marcas += `<rect class="hit" x="${(x - iw / data.length / 2).toFixed(1)}" y="${T}"
      width="${(iw / data.length).toFixed(1)}" height="${ih}" tabindex="0" data-tip="${dica}"><title>${esc(d.diaSemana)} ${esc(d.label)}</title></rect>`;
  });

  // O dia de hoje ganha um fio vertical e o único ponto do gráfico.
  let agora = '';
  if (hoje) {
    const x = X(data.indexOf(hoje)), y = Y(hoje.montante);
    agora = `<line x1="${x.toFixed(1)}" y1="${(y + 4).toFixed(1)}" x2="${x.toFixed(1)}" y2="${base.toFixed(1)}"
        stroke="${C.svOk}" stroke-width="1" stroke-dasharray="2 3" opacity=".55"/>
      <circle cx="${x.toFixed(1)}" cy="${y.toFixed(1)}" r="5" fill="${C.svOk}" stroke="${C.surface}" stroke-width="2.5"/>`;
  }

  el.innerHTML = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Montante validado por dia nos últimos 7 dias">
    <defs>
      <linearGradient id="ondaGrad" x1="0" x2="0" y1="0" y2="1">
        <stop offset="0%" stop-color="${C.svOk}" stop-opacity=".45"/>
        <stop offset="55%" stop-color="${C.svOk}" stop-opacity=".16"/>
        <stop offset="100%" stop-color="${C.svOk}" stop-opacity="0"/>
      </linearGradient>
      <filter id="ondaGlow" x="-20%" y="-40%" width="140%" height="200%">
        <feDropShadow dx="0" dy="2" stdDeviation="4" flood-color="${C.svOk}" flood-opacity=".45"/>
      </filter>
    </defs>
    ${grade}
    ${veu}
    <path d="${fechar(linhaValidado)}" fill="url(#ondaGrad)"/>
    <path class="onda-linha" d="${linhaValidado}" fill="none" stroke="${C.svOk}" stroke-width="3"
      stroke-linecap="round" stroke-linejoin="round" filter="url(#ondaGlow)"/>
    ${agora}
    <line x1="${L}" y1="${base}" x2="${w - R}" y2="${base}" stroke="${C.axis}" stroke-width="1"/>
    ${marcas}
  </svg>`;
  ligarTips(el);

  // A onda se desenha UMA vez, ao entrar. O snapshot chega a cada mensagem —
  // reanimar a cada chegada seria um piscar sem fim.
  if (!ondaDesenhada) {
    ondaDesenhada = true;
    const traco = el.querySelector('.onda-linha');
    if (traco && !window.matchMedia?.('(prefers-reduced-motion: reduce)')?.matches) {
      const comp = traco.getTotalLength?.() ?? 0;
      if (comp) {
        traco.style.strokeDasharray = comp;
        traco.style.strokeDashoffset = comp;
        traco.style.transition = 'stroke-dashoffset .9s ease-out';
        requestAnimationFrame(() => { traco.style.strokeDashoffset = '0'; });
      }
    }
  }

  $('onda-legend').innerHTML =
    `<span class="lg"><i style="background:${C.svOk}"></i>Montante validado</span>`
    + (veu ? `<span class="lg"><i style="background:${C.s1};opacity:.45"></i>Montante lançado</span>` : '');
  const total = data.reduce((a, b) => a + b.montante, 0);
  const servicos = data.reduce((a, b) => a + b.servicos, 0);
  $('onda-resumo').textContent = `${brl(total)} em ${num(servicos)} serviços`;
}
let ondaDesenhada = false;

function chartServicos(rel) {
  const el = $('chart-servicos');
  const ops = (rel?.operadores || []).slice(0, 6);
  const contasOk = (o) => o.contasRsValidado || 0;
  const contasPend = (o) => o.contasRsNaoValidado || 0;
  const temContas = ops.some((o) => contasOk(o) + contasPend(o) > 0);
  $('sv-legend').innerHTML =
    `<span><i style="background:${C.svOk}"></i>Montante validado (R$)</span>` +
    (temContas ? `<span><i style="background:${C.s2}"></i>Contas validadas (R$)</span>` : '') +
    `<span><i class="hachura"></i>Atendido, sem comprovante</span>`;

  const resumo = rel?.resumo;
  $('sv-resumo').textContent = resumo?.atendidos
    ? `${num(resumo.validados)}/${num(resumo.atendidos)} fechados · ${Math.round((resumo.taxa || 0) * 100)}%`
    : '';

  if (!ops.length) { el.innerHTML = vazio('Nenhum serviço atendido hoje'); return; }

  // Uma COLUNA por operador, empilhada: é a mesma medida (montante atendido)
  // partida pelo desfecho, então os dois trechos somam o total dele — o que
  // empilhar diz e agrupar não diria.
  // Mesma caixa do quadro azul, com um respiro a mais embaixo para a segunda
  // linha do eixo (a contagem de serviços). Manter a MESMA altura de área de
  // plotagem é o que deixa os dois comparáveis lado a lado.
  const w = 520, h = 220, L = 48, R = 10, T = 18, B = 48;
  const iw = w - L - R, ih = h - T - B, base = T + ih;
  // Um eixo só: montante e contas são os dois em R$, como no quadro azul.
  // Duas escalas fariam a coluna menor parecer do tamanho da maior.
  const max = Math.max(...ops.map((o) => Math.max(
    o.montanteValidado + o.montanteNaoValidado,
    contasOk(o) + contasPend(o),
  )), 1);
  const alt = (v) => (v / max) * ih;
  const banda = iw / ops.length;
  // Com as contas ao lado, duas colunas finas na banda (o mesmo idioma do
  // quadro azul); sem elas, a coluna larga de sempre, centrada.
  const bw = temContas ? Math.min(20, banda * 0.26) : Math.min(30, banda * 0.42);
  const gap = 3;

  // Uma pilha: trecho validado encostado na linha zero, pendente por cima, com
  // 2px de superfície entre eles — o espaçador que separa sem precisar de borda.
  const pilha = (x, hOk, hPend, cor, corPend, hachura, classe) => {
    const vao = hOk > 0 && hPend > 0 ? 2 : 0;
    let out = colunaV(x, bw, base, hOk, cor, { topo: hPend <= 0, extra: `class="mark ${classe}-ok"` });
    if (hPend > 0) {
      const topoPend = base - hOk - vao;
      out += colunaV(x, bw, topoPend, hPend, corPend, { extra: `class="mark ${classe}-pend"` });
      out += colunaV(x, bw, topoPend, hPend, `url(#${hachura})`, { extra: `class="mark ${classe}-pend hachurado"` });
    }
    return out;
  };

  let barras = '';
  ops.forEach((o, i) => {
    const cx = L + banda * (i + 0.5);
    const x = temContas ? cx - bw - gap / 2 : cx - bw / 2;
    const nome = o.nome || 'desconhecido';
    const hOk = alt(o.montanteValidado);
    const hPend = alt(o.montanteNaoValidado);

    // As classes identificam cada trecho da pilha — o teste de geometria se
    // apoia nelas (seg-* = montante, seg-contas-* = contas).
    barras += pilha(x, hOk, hPend, C.svOk, C.svPend, 'hachura', 'seg');
    if (temContas) {
      barras += pilha(
        cx + gap / 2,
        alt(contasOk(o)),
        alt(contasPend(o)),
        C.s2, C.s2Claro, 'hachura-contas', 'seg-contas',
      );
    }

    // Duas linhas no eixo: quem é, e quantos serviços dele fecharam. A
    // contagem não cabe no eixo de valor (que é em R$) e é o que o quadro mede.
    barras += rotuloEixo(nome, cx, h - 24, banda);
    barras += `<text x="${cx.toFixed(1)}" y="${h - 11}" text-anchor="middle" fill="${C.muted}" font-size="9.5">${o.validados}/${o.atendidos} serv.</text>`;

    const dica = attr(tipHtml(nome, [
      [C.svOk, 'Validado', `${brl(o.montanteValidado)} · ${o.validados} serviço(s)`],
      [C.svPendLinha, 'Sem comprovante', `${brl(o.montanteNaoValidado)} · ${o.atendidos - o.validados} serviço(s)`],
      [C.s2, 'Contas validadas', brl(contasOk(o))],
      ...(contasPend(o) ? [[null, 'Contas sem comprovante', brl(contasPend(o))]] : []),
      ...(o.contasQtd ? [[null, 'Contas pedidas que fecharam', num(o.contasQtd)]] : []),
      [null, 'Taxa de conclusão', `${Math.round((o.taxa || 0) * 100)}%`],
      [null, 'Casamento', `${o.casamento?.citacao || 0} citação · ${o.casamento?.valor || 0} valor · ${o.casamento?.tempo || 0} tempo`],
    ]));
    barras += `<rect class="hit" x="${(cx - banda / 2).toFixed(1)}" y="${T}" width="${banda.toFixed(1)}" height="${ih}" tabindex="0" data-tip="${dica}"><title>${esc(nome)} — ${brl(o.montanteValidado + o.montanteNaoValidado)}</title></rect>`;
  });

  el.innerHTML = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Montante e contas validados por operador, em reais">
    <defs>
      <pattern id="hachura" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2="6" stroke="${C.svPendLinha}" stroke-width="1.6"/>
      </pattern>
      <pattern id="hachura-contas" width="6" height="6" patternUnits="userSpaceOnUse" patternTransform="rotate(45)">
        <line x1="0" y1="0" x2="0" y2="6" stroke="${C.s2}" stroke-width="1.6"/>
      </pattern>
    </defs>
    ${gradeV(L, w, R, T, ih, max)}
    <line x1="${L}" y1="${base}" x2="${w - R}" y2="${base}" stroke="${C.axis}" stroke-width="1"/>
    ${barras}
  </svg>`;
  ligarTips(el);
}

// Funil: onde os pedidos param. Cada passo mostra quantos chegaram até ele e
// quanto se perdeu no caminho — é o que explica um número baixo no gráfico.
function renderFunil(rel) {
  const r = rel?.resumo || {};
  const base = Math.max(r.pedidos || 0, 1);
  const passos = [
    ['1', 'Pedidos das Brogueiras', r.pedidos || 0, r.pedidos || 0],
    ['2', 'Atendidos por um Operador', r.atendidos || 0, r.atendidos || 0],
    ['3', 'Com comprovante PIX', r.validados || 0, r.validados || 0],
  ];
  const perdas = [
    ['Ninguém atendeu', r.semAtendimento || 0],
    ['Sem comprovante no prazo', r.semComprovante || 0],
    ['Ainda no prazo', (r.aguardandoAtendimento || 0) + (r.aguardandoComprovante || 0)],
  ];

  $('sv-funil').innerHTML =
    passos.map(([n, rotulo, valor, largura]) => `
      <div class="funil-passo ${valor > 0 ? 'ok' : ''}">
        <span class="n">${n}</span><span class="l">${esc(rotulo)}</span><span class="v">${num(valor)}</span>
        <span class="funil-barra"><i style="width:${((largura / base) * 100).toFixed(1)}%"></i></span>
      </div>`).join('') +
    perdas.map(([rotulo, valor]) => `
      <div class="funil-passo funil-perdido">
        <span class="n">·</span><span class="l">${esc(rotulo)}</span><span class="v">${num(valor)}</span>
      </div>`).join('');

  const c = r.porCasamento || {};
  $('sv-casamento').innerHTML = [
    ['Respondeu citando', c.citacao || 0],
    ['Valor confere', c.valor || 0],
    ['Por proximidade', c.tempo || 0],
    ['Brogueiras atendidas', r.brogueiras || 0],
  ].map(([l, v]) => `<div class="mini"><span class="l">${l}</span><span class="v">${esc(String(num(v)))}</span></div>`).join('');
}

let svFiltro = 'validados';

// A tabela é a prova do gráfico: as três mensagens, com hora, lado a lado.
// (Também é a "table view" que o gráfico precisa ter para quem não distingue
// os dois tons da barra.)
function tabelaServicos(rel) {
  const corpo = document.querySelector('#tbl-servicos tbody');
  if (!corpo) return;
  const todos = rel?.servicos || [];
  const lista = (svFiltro === 'validados' ? todos.filter((s) => s.status === 'validado') : todos).slice(0, 40);

  if (!lista.length) {
    corpo.innerHTML = `<tr><td colspan="6">${vazio(svFiltro === 'validados' ? 'Nenhum serviço validado hoje' : 'Nenhum atendimento hoje')}</td></tr>`;
    return;
  }

  const ROT = { citacao: 'citou', valor: 'valor', tempo: 'proximidade' };
  corpo.innerHTML = lista.map((s) => {
    const pedido = s.pedidoTexto || (s.tipo === 'conta' ? `${s.contasPedidas} contas` : brl(s.montantePedido));
    const cas = s.casamento || 'tempo';
    return `<tr>
      <td>
        <b>${esc(s.brogueiraNome)}</b>
        <div class="tag-passo">${esc(hora(s.pedidoTs))} · ${esc(cortar(pedido, 40))}</div>
      </td>
      <td>${esc(s.operatorName)}<div class="tag-passo">${esc(hora(s.atendimentoTs))}</div></td>
      <td class="num">${esc(brl(s.montante))}</td>
      <td class="num">${num(s.contasQtd)}</td>
      <td>${s.comprovanteTs
        ? `<span class="tag-passo">${esc(hora(s.comprovanteTs))} · ${s.comprovanteTipo === 'pdf' ? 'PDF' : 'imagem'}</span>`
        : `<span class="tag-passo falta">${s.status === 'aguardando_comprovante' ? 'aguardando' : 'não veio'}</span>`}</td>
      <td><span class="tag-cas ${esc(cas)}">${esc(ROT[cas] ?? cas)}</span></td>
    </tr>`;
  }).join('');
}

document.querySelectorAll('#sv-filtro button').forEach((b) => {
  b.onclick = () => {
    svFiltro = b.dataset.filtro;
    document.querySelectorAll('#sv-filtro button').forEach((x) => x.classList.toggle('active', x === b));
    tabelaServicos(snap?.servicos);
  };
});

// Lançamentos por dia (7d): série única → UMA cor, sem gradiente decorativo.
function chartDias(dias) {
  const el = $('chart-dias');
  const data = dias || [];
  if (!data.length) { el.innerHTML = vazio('Sem histórico'); return; }

  const w = 520, h = 210, L = 44, R = 10, T = 16, B = 30;
  const iw = w - L - R, ih = h - T - B;
  const max = Math.max(...data.map((d) => d.count), 1);
  const banda = iw / data.length;
  const bw = Math.min(24, banda * 0.5); // barra fina: nunca preenche a banda
  const Y = (v) => T + ih - (v / max) * ih;

  let grade = '';
  for (let i = 0; i <= 4; i++) {
    const v = Math.round(max * i / 4), y = Y(v);
    grade += `<line x1="${L}" y1="${y.toFixed(1)}" x2="${w - R}" y2="${y.toFixed(1)}" stroke="${C.grid}" stroke-width="1"/>
      <text x="${L - 8}" y="${(y + 3.5).toFixed(1)}" text-anchor="end" fill="${C.muted}" font-size="10">${v}</text>`;
  }

  const pico = data.reduce((a, b) => (b.count > a.count ? b : a), data[0]);
  let barras = '';
  data.forEach((d, i) => {
    const cx = L + banda * (i + 0.5);
    const x = cx - bw / 2;
    const y = Y(d.count);
    const alt = Math.max(T + ih - y, d.count > 0 ? 2 : 0);
    const r = Math.min(4, alt);
    const dica = attr(tipHtml(d.label, [
      [C.s1, 'Lançamentos', num(d.count)],
      [null, 'Montante', brl(d.montante)],
      [null, 'Contas', num(d.contas)],
    ]));
    if (d.count > 0) {
      // Topo arredondado 4px, base quadrada na linha zero.
      barras += `<path d="M${x.toFixed(1)} ${(y + alt).toFixed(1)} V${(y + r).toFixed(1)} a${r} ${r} 0 0 1 ${r} -${r} h${(bw - 2 * r).toFixed(1)} a${r} ${r} 0 0 1 ${r} ${r} V${(y + alt).toFixed(1)} Z" fill="${C.s1}" class="mark"/>`;
    }
    if (d === pico && d.count > 0) {
      barras += `<text x="${cx.toFixed(1)}" y="${(y - 6).toFixed(1)}" text-anchor="middle" fill="${C.ink}" font-size="11" font-weight="600">${d.count}</text>`;
    }
    barras += `<text x="${cx.toFixed(1)}" y="${h - 10}" text-anchor="middle" fill="${C.muted}" font-size="10">${esc(d.label)}</text>`;
    barras += `<rect class="hit" x="${(cx - banda / 2).toFixed(1)}" y="${T}" width="${banda.toFixed(1)}" height="${ih}" tabindex="0" data-tip="${dica}"><title>${esc(d.label)}</title></rect>`;
  });

  el.innerHTML = `<svg viewBox="0 0 ${w} ${h}" role="img" aria-label="Lançamentos por dia nos últimos 7 dias">
    ${grade}
    <line x1="${L}" y1="${T + ih}" x2="${w - R}" y2="${T + ih}" stroke="${C.axis}" stroke-width="1"/>
    ${barras}
  </svg>`;
  ligarTips(el);

  const total = data.reduce((a, b) => a + b.count, 0);
  $('dias-total').textContent = `${num(total)} no período`;
}

// Atividade por hora: magnitude → rampa de UMA hue, clara→escura.
function heatmap(horas) {
  const el = $('chart-heat');
  const vals = horas || Array(24).fill(0);
  const max = Math.max(...vals, 1);
  const total = vals.reduce((a, b) => a + b, 0);

  const w = 520, cellH = 54, gap = 2, cw = (w - 23 * gap) / 24, T = 4;
  // 7 degraus da rampa; 0 tem cor própria (não é "pouco", é "nada").
  const cor = (v) => (v <= 0 ? C.seqZero : C.seq[Math.min(6, Math.round((v / max) * 6.999 - 0.5))]);

  let cells = '';
  vals.forEach((v, i) => {
    const x = i * (cw + gap);
    const dica = attr(tipHtml(`${String(i).padStart(2, '0')}h — ${String(i).padStart(2, '0')}:59`, [
      [v > 0 ? cor(v) : null, 'Lançamentos', num(v)],
    ]));
    cells += `<rect x="${x.toFixed(1)}" y="${T}" width="${cw.toFixed(1)}" height="${cellH}" rx="3" fill="${cor(v)}" class="mark"/>
      <rect class="hit" x="${x.toFixed(1)}" y="${T}" width="${cw.toFixed(1)}" height="${cellH}" tabindex="0" data-tip="${dica}"><title>${String(i).padStart(2, '0')}h: ${v}</title></rect>`;
  });

  const ticks = [0, 6, 12, 18, 23].map((hh) => {
    const x = hh * (cw + gap) + cw / 2;
    return `<text x="${x.toFixed(1)}" y="${T + cellH + 15}" fill="${C.muted}" font-size="10" text-anchor="middle">${String(hh).padStart(2, '0')}h</text>`;
  }).join('');

  el.innerHTML = `<svg viewBox="0 0 ${w} ${cellH + 24}" role="img" aria-label="Lançamentos por hora do dia">${cells}${ticks}</svg>`;
  ligarTips(el);

  $('heat-ramp').innerHTML = C.seq.map((c) => `<i style="background:${c}"></i>`).join('');
  const picoIdx = vals.indexOf(Math.max(...vals));
  $('heat-pico').textContent = total ? `Pico às ${String(picoIdx).padStart(2, '0')}h` : 'Sem atividade hoje';
}

// Montante por grupo — barras horizontais em HTML, série única, uma cor.
function gruposBarras(grupos) {
  const el = $('grupos-list');
  const data = (grupos || []).slice(0, 6);
  if (!data.length) { el.innerHTML = vazio('Sem grupos hoje'); return; }
  const max = Math.max(...data.map((g) => g.montante), 1);
  el.innerHTML = data.map((g) => {
    const dica = attr(tipHtml(g.nome || 'privado', [
      [C.s1, 'Montante', brl(g.montante)],
      [null, 'Contas (R$)', brl(g.contasValor)],
      [null, 'Contas (qtd)', num(g.contasQtd)],
    ]));
    return `<div class="bar-row" tabindex="0" data-tip="${dica}">
      <span class="n">${esc(g.nome || 'privado')}</span>
      <span class="v">${esc(brlCompacto(g.montante))}</span>
      <span class="bar-track"><span class="bar-fill" style="width:${Math.max((g.montante / max) * 100, 1.5).toFixed(1)}%"></span></span>
    </div>`;
  }).join('');
  ligarTips(el);
}

// Ranking de operadores. A cor NÃO varia com a posição.
function topOperadores(ops) {
  const el = $('top-ops');
  const data = (ops || []).slice(0, 5);
  if (!data.length) { el.innerHTML = vazio('Sem operadores hoje'); return; }
  el.innerHTML = data.map((o, i) => `
    <div class="rank-row">
      <span class="rank-n">${String(i + 1).padStart(2, '0')}</span>
      <span class="rank-body">
        <span class="rank-name">${esc(o.nome || 'desconhecido')}</span>
        <span class="rank-sub">${num(o.entradas)} lançamento(s) · ${esc(brlCompacto(o.contasValor))} em contas</span>
      </span>
      <span class="rank-val">${esc(brlCompacto(o.montante))}</span>
    </div>`).join('');
}

/* ═══════════════ Render principal ═══════════════ */

// Variação de hoje contra ontem, para o delta do stat tile.
function delta(hoje, ontem) {
  if (!ontem) return { cls: 'flat', txt: '' };
  const p = ((hoje - ontem) / ontem) * 100;
  if (!isFinite(p) || Math.abs(p) < 0.5) return { cls: 'flat', txt: '0%' };
  return { cls: p > 0 ? 'up' : 'down', txt: `${p > 0 ? '↑' : '↓'} ${Math.abs(p).toFixed(0)}%` };
}
function setDelta(id, hoje, ontem) {
  const el = $(id); if (!el) return;
  const d = delta(hoje, ontem);
  el.className = 'delta ' + d.cls;
  el.textContent = d.txt;
}

function renderSnapshot(s) {
  // Modo histórico: o socket continua empurrando o dia corrente. Aproveitamos
  // só o estado das conexões (isso é sempre "agora") e descartamos os números
  // — senão a tela voltaria para hoje sozinha a cada mensagem que chegasse.
  if (diaPainel && !s.periodo?.historico) {
    if (Array.isArray(s.sessoes)) atualizarSessoes(s.sessoes);
    if (s.connection) renderConexao(s.connection);
    return;
  }

  // Filtro de número ligado: o snapshot que chega pelo socket é o somado.
  // Busca a versão filtrada em vez de mostrar o número errado.
  if (filtroSessao !== 'todas' && (s.sessaoFiltro ?? 'todas') !== filtroSessao) {
    recarregarPainel();
    // Segue com o render: as sessões/config/agendamentos do snapshot geral
    // valem de qualquer forma, e os dados são corrigidos logo em seguida.
  }
  snap = s;
  lerCores();
  document.querySelectorAll('.content').forEach((c) => c.classList.remove('stale'));
  if (Array.isArray(s.sessoes)) atualizarSessoes(s.sessoes);
  if (s.connection) renderConexao(s.connection);

  const t = s.hoje?.totais || {};
  const dias = s.analytics?.porDia || [];
  const hj = dias[dias.length - 1] || {};
  const on = dias[dias.length - 2] || {};
  // O KPI "Montante" é o VALIDADO (3 passos). `t.montante` já vem validado do
  // servidor; a variação e o sparkline ao lado dele têm de vir da mesma série,
  // senão o número diria uma coisa e a seta ao lado outra.
  const val = s.analytics?.validadoPorDia || [];
  const valOn = val[val.length - 2] || {};

  // Montantes PEGOS: a SOMA em R$ do que os Operadores atenderam — validado ou
  // não. Fica à esquerda do "Montante validado" de propósito: os dois são em
  // reais, então a diferença entre eles (o que foi atendido e não comprovou)
  // se lê direto, sem conta na cabeça. As contagens vão no rodapé.
  const sv = s.servicos?.resumo || {};
  const pego = (sv.montanteValidado || 0) + (sv.montanteNaoValidado || 0);
  $('s-pegos').textContent = brlCompacto(pego);
  $('d-pegos').textContent = sv.montantesPegos
    ? `${num(sv.montantesPegos)} montantes · ${num(sv.montantesValidados ?? 0)} validados`
    : '';
  $('d-pegos').className = `delta ${sv.montantesValidados ? 'ok' : 'flat'}`;

  $('s-msg').textContent = num(s.stats?.totalMessages ?? 0);
  $('s-montante').textContent = brlCompacto(t.montante);
  $('s-contas').textContent = brlCompacto(t.contasValor);
  // Contas validadas: o "Valor:" que os Operadores cobraram nos serviços que
  // chegaram ao comprovante. Mesma série que a onda usa como `salario`.
  $('s-cval').textContent = brlCompacto(sv.contasRsValidado ?? 0);

  // O delta acompanha o número que está ao lado dele. "Mensagens processadas"
  // é acumulado desde sempre — uma variação percentual ali leria como se o
  // total tivesse crescido tanto, então mostramos o volume do dia.
  $('d-msg').className = 'delta flat';
  $('d-msg').textContent = `+${num(hj.count ?? 0)} ${diaPainel ? 'em ' + dataBR(diaPainel).slice(0, 5) : 'hoje'}`;
  setDelta('d-montante', t.montante ?? 0, valOn.montante ?? 0);
  setDelta('d-contas', t.contasValor ?? 0, on.contasValor ?? 0);
  setDelta('d-cval', sv.contasRsValidado ?? 0, valOn.contas ?? 0);

  $('spark-msg').innerHTML = spark(dias.map((d) => d.count), C.s1);
  $('spark-montante').innerHTML = spark(val.map((d) => d.montante), C.svOk);
  $('spark-contas').innerHTML = spark(dias.map((d) => d.contasValor ?? 0), C.s2);
  $('spark-cval').innerHTML = spark(val.map((d) => d.contas ?? 0), C.s2);

  if (s.export) renderExport(s.export);

  ondaDaSemana(s.analytics?.validadoPorDia, s.analytics?.porDia);
  topOperadores(s.hoje?.operadores);
  // Quadro 2: só o que passou pelos 3 passos.
  chartServicos(s.servicos);
  renderFunil(s.servicos);
  tabelaServicos(s.servicos);
  chartDias(dias);
  heatmap(s.analytics?.porHora);
  linhaViva(s.analytics?.porHora);
  gruposBarras(t.grupos);
  renderResumo(s);
  renderMensagens();
  renderAvisoHistorico();

  // A aba Configurações mostra o número escolhido no seletor dela.
  if (s.configs?.[cfgSessao]) preencherConfig(configDe(cfgSessao));
  renderSchedules(s.schedules || []);
}

function renderResumo(s) {
  const st = s.stats || {};
  $('resumo-kpis').innerHTML = [
    ['Lançamentos', num(st.totalMessages)],
    ['Montante', brlCompacto(st.totalMontante)],
    ['Contas (R$)', brlCompacto(st.totalContasValor)],
    ['Contas (qtd)', num(st.totalContasQtd)],
  ].map(([l, v]) => `<div class="mini"><span class="l">${l}</span><span class="v">${esc(String(v))}</span></div>`).join('');
}

function renderMensagens() {
  const msgs = snap?.ultimasMensagens || [];
  const por = 8, paginas = Math.max(1, Math.ceil(msgs.length / por));
  msgPage = Math.min(Math.max(msgPage, 0), paginas - 1);
  const fatia = msgs.slice(msgPage * por, msgPage * por + por);
  document.querySelector('#tbl-msg tbody').innerHTML = fatia.map((m) => `
    <tr>
      <td>${hora(m.ts)}</td>
      <td>${esc(m.groupName || 'privado')}</td>
      <td>${esc(m.operatorName || 'desconhecido')}</td>
      <td class="num">${esc(brl(m.montante))}</td>
      <td class="num">${esc(brl(m.contasTotal ?? 0))}</td>
    </tr>`).join('') || `<tr><td colspan="5" class="muted">Sem lançamentos</td></tr>`;

  $('pager-msg').innerHTML =
    `<span>${msgs.length ? msgPage + 1 : 0} de ${paginas}</span>
     <button id="pm-prev" ${msgPage === 0 ? 'disabled' : ''} aria-label="Página anterior">‹</button>
     <button id="pm-next" ${msgPage >= paginas - 1 ? 'disabled' : ''} aria-label="Próxima página">›</button>`;
  $('pm-prev').onclick = () => { msgPage--; renderMensagens(); };
  $('pm-next').onclick = () => { msgPage++; renderMensagens(); };
}

/* ═══════════════ A linha viva ═══════════════
   Um traço por hora do dia; a altura é o volume de mensagens daquela hora e a
   hora corrente pulsa. Quando chega mensagem nova, o traço de agora pisca em
   verde por um segundo — o "recebi" que nenhum número dá. */
function linhaViva(porHora) {
  const caixa = $('linha-viva');
  if (!caixa) return;
  const horas = Array.isArray(porHora) && porHora.length === 24 ? porHora : Array(24).fill(0);
  const agora = new Date().getHours();
  const maximo = Math.max(...horas, 1);

  if (caixa.children.length !== 24) {
    caixa.innerHTML = '<i></i>'.repeat(24);
  }
  [...caixa.children].forEach((barra, h) => {
    const v = horas[h] || 0;
    // Altura entre 2px e 16px: mesmo a hora vazia deixa o traço visível, senão
    // a linha teria buracos e pareceria quebrada.
    barra.style.height = `${v ? 2 + Math.round((v / maximo) * 14) : 2}px`;
    barra.className = h === agora ? 'agora' : (h > agora ? 'futura' : (v ? '' : 'vazia'));
    barra.title = `${String(h).padStart(2, '0')}h · ${v} lançamento(s)`;
  });
}

// Piscada de "chegou agora" no traço da hora corrente.
let pulsoTimer = null;
function pulsarLinhaViva() {
  const caixa = $('linha-viva');
  const barra = caixa?.children?.[new Date().getHours()];
  if (!barra) return;
  barra.classList.add('bateu');
  clearTimeout(pulsoTimer);
  pulsoTimer = setTimeout(() => barra.classList.remove('bateu'), 900);
}

/* ═══════════════ Conexão / QR ═══════════════ */
// O evento do socket virou { sessaoId, connection, geral } — string ainda é
// aceita (chamadas internas, como o 'erro' do connect_error).
function renderConexao(evento) {
  const geral = typeof evento === 'string' ? evento : (evento?.geral ?? evento?.connection);
  const rotulos = { open: 'Conectado', connecting: 'Conectando…', close: 'Desconectado', erro: 'Erro' };
  $('conn-dot').className = 'dot ' + (['open', 'connecting', 'erro'].includes(geral) ? geral : '');

  // Com mais de um número no ar, o cabeçalho conta quantos estão conectados.
  const ligados = SESSOES.filter((s) => s.ativa);
  const abertos = ligados.filter((s) => s.connection === 'open').length;
  $('conn-text').textContent = ligados.length > 1
    ? `${abertos}/${ligados.length} conectados`
    : (rotulos[geral] || geral || 'Desconectado');

  if (typeof evento === 'object' && evento?.sessaoId) {
    const s = sessaoPorId(evento.sessaoId);
    if (s) { s.connection = evento.connection; atualizarCartoesNumeros(); }
  }
}

// QR chega como { sessaoId, qr }. Cada número tem o seu, na aba Números.
const qrPendentes = new Map(); // sessaoId -> true enquanto houver QR

function renderQr(evento) {
  if (ROLE !== 'admin') return;
  const sessaoId = typeof evento === 'object' ? evento?.sessaoId : 'n1';
  const qr = typeof evento === 'object' ? evento?.qr : evento;
  if (!sessaoId) return;
  if (qr) qrPendentes.set(sessaoId, Date.now());
  else qrPendentes.delete(sessaoId);
  const s = sessaoPorId(sessaoId);
  if (s) s.hasQr = Boolean(qr);
  atualizarCartoesNumeros();
  renderAvisoQr();
}

// No Painel fica só o aviso; o código em si mora na aba Números.
function renderAvisoQr() {
  const box = $('qr-box');
  if (!box) return;
  const esperando = SESSOES.filter((s) => s.ativa && (s.hasQr || qrPendentes.has(s.id)));
  if (!esperando.length || ROLE !== 'admin') { box.classList.add('hidden'); return; }
  box.classList.remove('hidden');
  $('qr-aviso-quais').textContent =
    `${esperando.map((s) => s.nome).join(', ')} — escaneie o código para conectar.`;
}


/* ═══════════════ Números (sessões de WhatsApp) ═══════════════
   Cada número tem: conexão própria (QR próprio), nome, chave liga/desliga e a
   lista de recursos que executa. Recurso marcado aqui = função que AQUELE
   número faz; o que ele faz não interfere no que os outros fazem. */

// Chegou estado novo: guarda, atualiza os seletores das abas e os cartões.
function atualizarSessoes(lista) {
  SESSOES = lista;
  preencherSelectSessoes($('filtro-sessao'), { comTodas: true, valor: filtroSessao });
  preencherSelectSessoes($('cfg-sessao'), { valor: cfgSessao });
  preencherSelectSessoes($('grp-sessao'), { valor: grpSessao });
  preencherSelectSessoes($('send-sessao'), { valor: $('send-sessao')?.value || 'n1' });
  preencherSelectSessoes($('sch-sessao'), { valor: $('sch-sessao')?.value || 'n1' });
  renderNumeros();
  renderConflitos(snap?.conflitos);
  renderAvisoQr();
}

// Catálogo de recursos: vem do servidor para não haver duas listas para manter.
async function carregarCatalogoRecursos() {
  if (RECURSOS_CAT.length) return RECURSOS_CAT;
  try {
    const r = await api('/sessoes');
    RECURSOS_CAT = r.recursos || [];
    if (r.sessoes) atualizarSessoes(r.sessoes);
    renderConflitos(r.conflitos);
  } catch {
    /* sem sessão — o login cuida */
  }
  return RECURSOS_CAT;
}

const cartaoDe = (id) => document.querySelector(`.num-card[data-sessao="${id}"]`);

// Assinatura do que exige remontar o cartão (o resto é atualizado no lugar,
// para não apagar o que o usuário está digitando no nome).
const assinaturaNumeros = () =>
  SESSOES.map((s) => `${s.id}:${s.ativa}:${Object.entries(s.recursos || {}).map(([k, v]) => k + (v ? 1 : 0)).join('')}`).join('|')
  + '#' + RECURSOS_CAT.length;

let assinaturaAtual = '';

// Tentativas de buscar o catálogo. Sem teto, uma falha (token vencido, servidor
// fora do ar) devolvia lista vazia e o `.then(renderNumeros)` chamava tudo de
// novo na hora — um laço infinito batendo em /api/sessoes sem parar.
let catalogoTentativas = 0;
const MAX_TENTATIVAS_CATALOGO = 5;

function renderNumeros() {
  const box = $('num-cards');
  if (!box || ROLE !== 'admin') return;
  if (!RECURSOS_CAT.length) {
    if (catalogoTentativas >= MAX_TENTATIVAS_CATALOGO) return;
    catalogoTentativas += 1;
    carregarCatalogoRecursos().then((cat) => {
      if (cat.length) { catalogoTentativas = 0; renderNumeros(); return; }
      // Deu vazio: tenta de novo mais tarde, espaçando — o servidor pode estar
      // voltando. Depois do teto, para de vez (o F5 recomeça).
      setTimeout(renderNumeros, 1000 * catalogoTentativas);
    });
    return;
  }

  const assinatura = assinaturaNumeros();
  if (assinatura !== assinaturaAtual) {
    assinaturaAtual = assinatura;
    box.innerHTML = SESSOES.map(cartaoNumero).join('');
    ligarEventosNumeros();
  }
  atualizarCartoesNumeros();
}

function cartaoNumero(s) {
  const recursos = RECURSOS_CAT.map((r) => `
    <label class="chk num-recurso" title="${esc(r.descricao)}">
      <input type="checkbox" data-recurso="${esc(r.chave)}" ${s.recursos?.[r.chave] ? 'checked' : ''} />
      <span>${esc(r.nome)}</span>
    </label>`).join('');

  return `
    <div class="card num-card" data-sessao="${esc(s.id)}">
      <div class="card-head">
        <span class="dot num-dot"></span>
        <input class="num-nome" value="${esc(s.nome)}" maxlength="40" aria-label="Nome do número" />
        <div class="spacer"></div>
        <label class="chk num-liga"><input type="checkbox" class="num-ativa" ${s.ativa ? 'checked' : ''} /> Ligado</label>
      </div>

      <p class="hint num-status"></p>

      <div class="num-qr hidden">
        <img class="num-qr-img" alt="QR Code para conectar este número" />
        <ol class="num-qr-passos">
          <li>Abra o WhatsApp <b>deste número</b></li>
          <li>Toque em <b>Dispositivos conectados</b></li>
          <li>Toque em <b>Conectar dispositivo</b> e aponte para o código</li>
        </ol>
      </div>

      <div class="num-recursos">
        <div class="num-recursos-cab">O que este número faz</div>
        ${recursos}
      </div>

      <div class="form-actions">
        <button class="btn-ghost num-reconectar">Reconectar</button>
        <button class="btn-ghost num-desvincular" title="Apaga a sessão salva e pede um QR novo">Desvincular</button>
        <span class="ok num-msg"></span>
      </div>
    </div>`;
}

// Atualiza estado/QR sem remontar (não atrapalha quem está digitando o nome).
function atualizarCartoesNumeros() {
  for (const s of SESSOES) {
    const card = cartaoDe(s.id);
    if (!card) continue;
    const conectado = s.ativa && s.connection === 'open';
    card.querySelector('.num-dot').className = 'dot num-dot ' + (s.ativa ? (s.connection === 'open' ? 'open' : s.connection === 'connecting' ? 'connecting' : '') : '');
    card.classList.toggle('off', !s.ativa);

    const nome = card.querySelector('.num-nome');
    if (document.activeElement !== nome) nome.value = s.nome;

    const linhas = [];
    if (!s.ativa) linhas.push('Desligado — não conecta nem processa nada.');
    else if (conectado) linhas.push(`Conectado${s.me?.id ? ` como ${String(s.me.id).split(':')[0].split('@')[0]}` : ''}.`);
    else if (s.hasQr || qrPendentes.has(s.id)) linhas.push('Aguardando leitura do QR.');
    else linhas.push(ROTULO_CONEXAO[s.connection] || s.connection || '—');
    if (s.ativa && s.lastError && !conectado) linhas.push(`Último erro: ${s.lastError}`);
    if (s.ativa && s.proximaTentativaEm) linhas.push(`Nova tentativa às ${hora(s.proximaTentativaEm)}.`);
    card.querySelector('.num-status').textContent = linhas.join(' ');

    const caixaQr = card.querySelector('.num-qr');
    const img = card.querySelector('.num-qr-img');
    const temQr = s.ativa && (s.hasQr || qrPendentes.has(s.id));
    caixaQr.classList.toggle('hidden', !temQr);
    if (temQr) {
      const carimbo = qrPendentes.get(s.id) || 0;
      const alvo = `/api/sessoes/${s.id}/qr?token=${encodeURIComponent(TOKEN)}&t=${carimbo}`;
      if (!img.src.endsWith(`&t=${carimbo}`)) img.src = alvo; // só recarrega em QR novo
    }
  }
}

async function patchSessao(id, corpo, card) {
  const msg = card?.querySelector('.num-msg');
  try {
    const r = await api('/sessoes/' + id, { method: 'PATCH', body: JSON.stringify(corpo) });
    if (!r.ok) throw new Error(r.error || 'falha ao salvar');
    if (r.sessao) {
      const i = SESSOES.findIndex((s) => s.id === id);
      if (i >= 0) SESSOES[i] = r.sessao;
    }
    renderConflitos(r.conflitos);
    if (msg) { msg.className = 'ok num-msg'; msg.textContent = 'Salvo ✓'; setTimeout(() => { msg.textContent = ''; }, 2000); }
    atualizarCartoesNumeros();
    preencherSelectSessoes($('filtro-sessao'), { comTodas: true, valor: filtroSessao });
  } catch (e) {
    if (msg) { msg.className = 'err num-msg'; msg.textContent = e.message; }
  }
}

function ligarEventosNumeros() {
  document.querySelectorAll('.num-card').forEach((card) => {
    const id = card.dataset.sessao;

    card.querySelector('.num-ativa').onchange = (ev) =>
      patchSessao(id, { ativa: ev.target.checked }, card);

    // Cada recurso vale na hora: a próxima mensagem já respeita a mudança.
    card.querySelectorAll('.num-recurso input').forEach((chk) => {
      chk.onchange = () => patchSessao(id, { recursos: { [chk.dataset.recurso]: chk.checked } }, card);
    });

    const nome = card.querySelector('.num-nome');
    nome.onblur = () => {
      const valor = nome.value.trim();
      if (!valor || valor === sessaoPorId(id)?.nome) return;
      patchSessao(id, { nome: valor }, card);
    };
    nome.onkeydown = (e) => { if (e.key === 'Enter') nome.blur(); };

    card.querySelector('.num-reconectar').onclick = async () => {
      const r = await api(`/sessoes/${id}/reconnect`, { method: 'POST' });
      const msg = card.querySelector('.num-msg');
      msg.className = r.ok ? 'ok num-msg' : 'err num-msg';
      msg.textContent = r.ok ? 'Reconectando…' : 'ligue o número primeiro';
      setTimeout(() => { msg.textContent = ''; }, 3000);
    };

    card.querySelector('.num-desvincular').onclick = async () => {
      const s = sessaoPorId(id);
      if (!confirm(`Desvincular ${s?.nome || id}? A sessão salva é apagada e será preciso ler um QR novo.`)) return;
      const msg = card.querySelector('.num-msg');
      msg.className = 'ok num-msg';
      msg.textContent = 'Desvinculando…';
      const r = await api(`/sessoes/${id}/desvincular`, { method: 'POST' });
      msg.className = r.ok ? 'ok num-msg' : 'err num-msg';
      msg.textContent = r.ok ? 'Pronto — leia o QR novo.' : `erro: ${r.error}`;
    };
  });
}

// Sobreposição: dois números fazendo a mesma coisa no mesmo grupo.
function renderConflitos(lista) {
  const box = $('num-conflitos');
  if (!box) return;
  const itens = lista || [];
  box.classList.toggle('hidden', itens.length === 0);
  if (!itens.length) return;
  const nomeDoRecurso = (chave) => RECURSOS_CAT.find((r) => r.chave === chave)?.nome || chave;
  $('num-conflitos-lista').innerHTML = itens.map((c) => `
    <p class="hint">
      <b>${esc(nomeDoRecurso(c.recurso))}</b> está ligado em
      <b>${esc(c.sessoes.map(nomeSessao).join(' e '))}</b> para <b>${esc(c.nome)}</b>.
      ${c.certeza === 'confirmado'
        ? 'A mesma mensagem seria trabalhada duas vezes — deixe o recurso em um número só.'
        : 'Se os dois estiverem nos mesmos chats, o trabalho é feito duas vezes.'}
    </p>`).join('') +
    '<p class="hint">A contagem em si está protegida: o registro é recusado quando a mesma mensagem já foi gravada por outro número.</p>';
}

/* ── Filtro de número (Painel / Brogueiras / Operadores / Indicações) ── */
async function recarregarPainel() {
  try {
    const partes = [qsSessao(filtroSessao), diaPainel ? 'period=' + diaPainel : ''].filter(Boolean);
    const r = await api('/snapshot' + (partes.length ? '?' + partes.join('&') : ''));
    if (r.ok) renderSnapshot(r);
  } catch {
    /* sem sessão — o login cuida */
  }
}

/* ═══════════════ Dia em exibição (modo histórico) ═══════════════
   O painel nasce ao vivo, mostrando hoje. Escolher uma data no topo coloca
   TODAS as telas de número (Painel, Brogueiras, Operadores, Indicações) no
   mesmo dia do passado — um só recorte, para não existir a dúvida de qual
   aba está mostrando o quê.

   Enquanto um dia está escolhido, o socket continua chegando com o dia
   corrente e é ignorado nos números: quem pediu ontem quer ver ontem parado,
   não a tela pulando para hoje a cada mensagem que entra. */
let diaPainel = '';        // '' = hoje, ao vivo
let calendarioDias = null; // resumo de /api/dias: até onde dá para voltar

const ehDataISO = (v) => /^\d{4}-\d{2}-\d{2}$/.test(String(v ?? ''));
const dataBR = (iso) => String(iso || '').split('-').reverse().join('/');

// Período que uma aba deve pedir: o dia global manda; sem ele, o botão da aba.
const periodoDaAba = (padrao) => diaPainel || padrao;

/**
 * Calendário do histórico (primeiro dia gravado, dias com movimento).
 * Serve para o seletor não deixar escolher um dia que nunca existiu e para o
 * aviso dizer o que aquele dia tem.
 */
async function carregarCalendario() {
  try {
    const qs = qsSessao(filtroSessao);
    const r = await api('/dias' + (qs ? '?' + qs : ''));
    if (r.ok) {
      calendarioDias = r;
      const campo = $('dia-painel');
      if (campo) { campo.min = r.primeiro; campo.max = r.hoje; }
      atualizarNavDia();
    }
  } catch {
    /* sem sessão — o login cuida */
  }
}

// Acende/apaga os controles conforme o dia escolhido.
function atualizarNavDia() {
  const nav = $('dia-nav');
  if (!nav) return;
  nav.classList.toggle('ativo', Boolean(diaPainel));
  const campo = $('dia-painel');
  if (campo && campo.value !== (diaPainel || '')) campo.value = diaPainel || '';
  const hoje = calendarioDias?.hoje || hojeISO();
  const primeiro = calendarioDias?.primeiro || '2020-01-01';
  // Não dá para ver amanhã; nem antes do primeiro dia gravado.
  $('dia-prox').disabled = !diaPainel || diaPainel >= hoje;
  $('dia-ant').disabled = Boolean(diaPainel) && diaPainel <= primeiro;

  // Os seletores de período das abas ficam apagados enquanto o dia global manda.
  ['bg-periodo', 'ind-periodo', 'op-periodo'].forEach((id) => {
    const seg = $(id);
    if (seg) {
      seg.classList.toggle('travado', Boolean(diaPainel));
      seg.title = diaPainel ? 'Um dia está escolhido no topo — volte para hoje para usar estes períodos' : '';
    }
  });
  sincronizarNavsDiaAba();
  renderAvisoHistorico();
}

// Aviso do topo do Painel + rótulos dos KPIs ("Montante hoje" → "Montante em 29/08").
function renderAvisoHistorico() {
  const box = $('hist-aviso');
  if (!box) return;
  box.classList.toggle('hidden', !diaPainel);
  if (diaPainel) {
    const dia = calendarioDias?.dias?.find((d) => d.day === diaPainel);
    $('hist-dia').textContent = `Vendo ${dataBR(diaPainel)}`;
    $('hist-detalhe').textContent = dia
      ? `${num(dia.lancamentos)} lançamentos · ${num(dia.pedidos)} pedidos · ${num(dia.servicos)} serviços — sem atualização ao vivo.`
      : 'nenhum movimento registrado neste dia — sem atualização ao vivo.';
  }
  const sufixo = diaPainel ? `em ${dataBR(diaPainel).slice(0, 5)}` : 'hoje';
  const rotulos = {
    'lbl-pegos': 'Montantes pegos', 'lbl-montante': 'Montante validado',
    'lbl-contas': 'Contas', 'lbl-cval': 'Contas validadas',
  };
  Object.entries(rotulos).forEach(([id, base]) => {
    const el = $(id);
    if (el) el.textContent = `${base} ${sufixo}`;
  });
}

/**
 * Troca o dia em exibição e recarrega o que está aberto.
 * `valor` vazio (ou 'hoje') volta para o modo ao vivo.
 */
function aplicarDiaPainel(valor) {
  diaPainel = ehDataISO(valor) ? String(valor) : '';
  atualizarNavDia();
  recarregarPainel();
  // As abas de relatório seguem o mesmo dia — só recarrega a que está aberta.
  if (!$('tab-brogueiras').classList.contains('hidden')) carregarBrogueiras();
  if (!$('tab-indicacoes').classList.contains('hidden')) carregarIndicacoes();
  // A aba Operadores tem o seu próprio navegador: ele acompanha mesmo fechado,
  // senão abriria depois mostrando um dia diferente do resto do painel.
  sincronizarDiaOperadores();
}

// A aba Operadores tem o seu próprio navegador de dias (veio antes deste):
// ele espelha o dia global para os dois nunca discordarem na tela.
function sincronizarDiaOperadores() {
  if (!$('op-dia')) return;
  sincronizandoDia = true;
  try { aplicarPeriodo(diaPainel || 'hoje'); } finally { sincronizandoDia = false; }
}

/* ── Navegador de dias das abas (Brogueiras, Indicações) ──────────────────
   O mesmo controle da aba Operadores, no cabeçalho do card: ‹ data ›. Todos
   mexem no MESMO estado (`diaPainel`), então nenhuma aba mostra um dia
   diferente do resto do painel — e o campo vazio quer dizer hoje, ao vivo. */
const NAVS_DIA_ABA = [
  { nav: 'bg-dia-nav', campo: 'bg-dia', ant: 'bg-dia-ant', prox: 'bg-dia-prox' },
  { nav: 'ind-dia-nav', campo: 'ind-dia', ant: 'ind-dia-ant', prox: 'ind-dia-prox' },
];

// Espelha o dia global nos campos e apaga as setas que não levam a lugar
// nenhum (antes do primeiro dia gravado, depois de hoje).
function sincronizarNavsDiaAba() {
  const hoje = calendarioDias?.hoje || hojeISO();
  const primeiro = calendarioDias?.primeiro || '2020-01-01';
  for (const n of NAVS_DIA_ABA) {
    const campo = $(n.campo);
    if (!campo) continue;
    $(n.nav).classList.toggle('ativo', Boolean(diaPainel));
    if (campo.value !== (diaPainel || '')) campo.value = diaPainel || '';
    campo.min = primeiro;
    campo.max = hoje;
    $(n.prox).disabled = !diaPainel || diaPainel >= hoje;
    $(n.ant).disabled = Boolean(diaPainel) && diaPainel <= primeiro;
  }
}

function montarNavsDiaAba() {
  for (const n of NAVS_DIA_ABA) {
    const campo = $(n.campo);
    if (!campo) continue;
    // Limpar o campo devolve o recorte para hoje: sem período a aba ficaria vazia.
    campo.onchange = (ev) => aplicarDiaPainel(ev.target.value);
    $(n.ant).onclick = () => aplicarDiaPainel(somarDias(diaPainel || hojeISO(), -1));
    $(n.prox).onclick = () => {
      // Chegar em hoje é voltar para o ao vivo — hoje não é histórico.
      const proximo = somarDias(diaPainel || hojeISO(), 1);
      aplicarDiaPainel(proximo >= (calendarioDias?.hoje || hojeISO()) ? '' : proximo);
    };
  }
  sincronizarNavsDiaAba(); // estado inicial (ao vivo): nada de avançar para amanhã
}
montarNavsDiaAba();

if ($('dia-painel')) {
  $('dia-painel').onchange = (ev) => aplicarDiaPainel(ev.target.value);
  $('dia-ant').onclick = () => aplicarDiaPainel(somarDias(diaPainel || hojeISO(), -1));
  $('dia-prox').onclick = () => {
    const proximo = somarDias(diaPainel || hojeISO(), 1);
    aplicarDiaPainel(proximo >= (calendarioDias?.hoje || hojeISO()) ? '' : proximo);
  };
  $('dia-hoje').onclick = () => aplicarDiaPainel('');
  $('hist-voltar').onclick = () => aplicarDiaPainel('');
}

if ($('filtro-sessao')) {
  $('filtro-sessao').onchange = (ev) => {
    filtroSessao = ev.target.value;
    localStorage.setItem('ws_filtro_sessao', filtroSessao);
    carregarCalendario();
    recarregarPainel();
    if (!$('tab-brogueiras').classList.contains('hidden')) carregarBrogueiras();
    if (!$('tab-operadores').classList.contains('hidden')) carregarOperadores();
    if (!$('tab-indicacoes').classList.contains('hidden')) carregarIndicacoes();
  };
}

/* ═══════════════ Login / papéis / socket ═══════════════ */
function mostrarApp() {
  $('login').classList.add('hidden');
  $('app').classList.remove('hidden');
  aplicarRole();
  conectarSocket();
  carregarCalendario(); // até que dia dá para voltar (e o que cada dia tem)
  if (ROLE === 'admin') carregarGrupos();
}

// 'viewer' só enxerga o Painel.
function aplicarRole() {
  const viewer = ROLE === 'viewer';
  document.body.dataset.role = ROLE;
  document.querySelectorAll('.nav-item').forEach((b) => {
    if (b.dataset.tab !== 'painel') b.classList.toggle('hidden', viewer);
  });
  if (viewer) {
    abrirAba('painel');
    $('qr-box').classList.add('hidden');
  }
}

async function fazerLogin(username, password) {
  const res = await fetch('/api/login', {
    method: 'POST', headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ username, password }),
  });
  const r = await res.json().catch(() => ({}));
  if (!res.ok || !r.ok) throw new Error(r.error || 'falha no login');
  TOKEN = r.token; ROLE = r.role;
  localStorage.setItem('ws_token', TOKEN);
  localStorage.setItem('ws_role', ROLE);
  mostrarApp();
}

async function retomarSessao(token) {
  const res = await fetch('/api/status', { headers: { Authorization: 'Bearer ' + token } });
  if (!res.ok) throw new Error('sessão inválida');
  const r = await res.json();
  TOKEN = token; ROLE = r.role || 'admin';
  localStorage.setItem('ws_role', ROLE);
  mostrarApp();
}

$('token-btn').onclick = async () => {
  $('login-err').textContent = '';
  try { await fazerLogin($('user-input').value.trim(), $('token-input').value); }
  catch (e) { $('login-err').textContent = e.message || 'Usuário ou senha inválidos.'; }
};
['user-input', 'token-input'].forEach((id) => {
  $(id).onkeydown = (e) => { if (e.key === 'Enter') $('token-btn').click(); };
});
$('logout').onclick = async () => {
  try { await fetch('/api/logout', { method: 'POST', headers: { Authorization: 'Bearer ' + TOKEN } }); } catch {}
  localStorage.removeItem('ws_token'); localStorage.removeItem('ws_role');
  location.reload();
};

function conectarSocket() {
  socket = io({ auth: { token: TOKEN } });
  socket.on('update', (s) => { renderSnapshot(s); pulsarLinhaViva(); });
  socket.on('connection', renderConexao);
  socket.on('qr', renderQr);
  socket.on('connect_error', () => renderConexao('erro'));
  // Chegou pedido novo: se a aba das Brogueiras estiver aberta, recarrega.
  // (o snapshot não carrega esses dados — são pesados e só interessam ali)
  socket.on('pedido', () => {
    if (!$('tab-brogueiras').classList.contains('hidden')) carregarBrogueiras();
  });
  // Link repetido: avisa em qualquer aba, porque é o tipo de coisa que se
  // quer ver na hora — não só quem estiver olhando a aba Brogueiras.
  socket.on('repetido', (r) => {
    avisarRepetido(r);
    if (!$('tab-brogueiras').classList.contains('hidden')) carregarBrogueiras();
  });
  // Serviço fechou os 3 passos: aviso curto em qualquer aba. O snapshot vem
  // logo atrás e redesenha o quadro — aqui é só o "aconteceu agora".
  socket.on('servico', (ev) => {
    if (ev?.fase === 'validado') avisarServico(ev.servico);
    // O ranking não vem no snapshot (é por período): recarrega se estiver aberto.
    if (!$('tab-operadores').classList.contains('hidden')) carregarOperadores();
  });
  // Mexeram nas operações (outro admin, ou a própria aba): se ela estiver
  // aberta, recarrega — é o equivalente ao "invalidate" do Realtime.
  socket.on('operacoes', () => {
    if (!$('tab-relatorios').classList.contains('hidden')) carregarRelatorios();
  });
  // Chegou uma indicação nova ("Vim por @fulana") — mesmo trato.
  socket.on('indicacao', () => {
    if (!$('tab-indicacoes').classList.contains('hidden')) carregarIndicacoes();
  });
  // Em vez de piscar um skeleton, o render anterior fica esmaecido.
  socket.on('disconnect', () => document.querySelectorAll('.content').forEach((c) => c.classList.add('stale')));
}

/* ═══════════════ Configurações ═══════════════ */
// A aba edita UM número por vez (o do seletor). O snapshot traz a config de
// todos, então trocar de número não precisa ir ao servidor.
function trocarSessaoConfig(id) {
  cfgSessao = id;
  localStorage.setItem('ws_cfg_sessao', id);
  const c = configDe(id);
  if (c) preencherConfig(c);
  carregarGruposAlerta();
  const hint = $('cfg-sessao-hint');
  if (hint) {
    hint.innerHTML = `Tudo nesta aba vale só para <b>${esc(nomeSessao(id))}</b> — menos os campos marcados como <b>global</b>.`;
  }
}

function preencherConfig(c) {
  $('c-autoReplyEnabled').checked = !!c.autoReplyEnabled;
  $('c-autoReplyGroups').checked = !!c.autoReplyGroups;
  $('c-autoReplyMessage').value = c.autoReplyMessage || '';
  $('c-welcomeEnabled').checked = !!c.welcomeEnabled;
  $('c-welcomeMode').value = c.welcomeMode || 'all';
  $('c-welcomeMessage').value = c.welcomeMessage || '';
  $('c-monitorMode').value = c.monitorMode || 'all';
  $('c-monitorPrivate').checked = !!c.monitorPrivate;
  $('c-repetidosJanelaHoras').value = Number(c.repetidosJanelaHoras ?? 0);
  $('c-servicosEnabled').checked = c.servicosEnabled !== false;
  $('c-servicosModoCasamento').value = c.servicosModoCasamento || 'cascata';
  $('c-servicosJanelaAtendimentoMin').value = Number(c.servicosJanelaAtendimentoMin ?? 60);
  $('c-servicosJanelaComprovanteMin').value = Number(c.servicosJanelaComprovanteMin ?? 120);
  $('c-alertaRepetidosEnabled').checked = !!c.alertaRepetidosEnabled;
  $('c-alertaRepetidosMarcarTodos').checked = c.alertaRepetidosMarcarTodos !== false;
  $('c-alertaRepetidosMensagem').value = c.alertaRepetidosMensagem || '';
  $('c-alertaRepetidosPorLink').value = Number(c.alertaRepetidosPorLink ?? 0);
  $('c-alertaRepetidosPorDia').value = Number(c.alertaRepetidosPorDia ?? 0);
  definirGrupoAlerta(c.alertaRepetidosGrupo || '');
  $('c-commandAuthorizedNumbers').value = (c.commandAuthorizedNumbers || []).join('\n');
  $('c-reportAuthorizedNumbers').value = (c.reportAuthorizedNumbers || []).join('\n');
  $('c-commandPassword').placeholder = c.commandPasswordSet ? '•••• (definida) — vazio p/ manter' : 'sem senha';
  // Exportação (global). Os segredos NÃO vêm do servidor — só a informação de
  // que existem, que vira o placeholder.
  $('c-comissaoMensagem').value = c.comissaoMensagem ?? '';
  $('c-exportEnabled').checked = !!c.exportEnabled;
  $('c-exportUrl').value = c.exportUrl || '';
  $('c-exportIntervaloMin').value = Number(c.exportIntervaloMin ?? 5);
  $('c-exportSegredo').placeholder = c.exportSegredoSet ? '•••• (salvo) — vazio p/ manter' : 'sem segredo';
  $('c-exportApiKey').placeholder = c.exportApiKeySet ? '•••• (salva) — vazio p/ manter' : 'opcional';
}

/* ── Exportação para o DB Dashboard ───────────────────────
   O card mostra o que já foi, o que está pendente e o último erro: uma
   exportação que parou de funcionar não pode ficar só no log do servidor. */
function renderExport(st) {
  if (!st || !$('exp-status')) return;
  const marca = $('exp-estado');
  const erro = st.ultimoErro?.erro;
  marca.textContent = !st.ligado ? 'desligado' : erro ? 'com erro' : 'ligado';
  marca.classList.toggle('falta', Boolean(!st.ligado || erro));

  const linhas = [
    ['Último envio', st.ultimoEnvioEm ? `${dataDia(st.ultimoEnvioEm.slice(0, 10))} ${hora(st.ultimoEnvioEm)}` : '—'],
    ['Na fila', `${num(st.pendentes)} serviço(s)`],
    ['Já enviados', num(st.totalEnviados)],
    ['Intervalo', `${num(st.intervaloMin)} min`],
  ];
  if (erro) {
    linhas.push(['Último erro', `${esc(erro)}${st.tentativas ? ` · ${num(st.tentativas)} tentativa(s)` : ''}`]);
    if (st.proximaEm) linhas.push(['Próxima tentativa', hora(st.proximaEm)]);
  }
  $('exp-status').innerHTML = linhas
    .map(([l, v]) => `<div class="mini"><span class="l">${esc(l)}</span><span class="v">${esc(String(v))}</span></div>`)
    .join('');
}

/* ── Alerta de link repetido ──────────────────────────────
   O destino é um grupo de verdade, então a lista vem do WhatsApp. Se o grupo
   salvo não estiver na lista (bot desconectado, ou saiu do grupo), ele entra
   como opção mesmo assim — trocar o destino em silêncio seria pior. */
function definirGrupoAlerta(jid) {
  const sel = $('c-alertaRepetidosGrupo');
  if (!sel) return;
  if (jid && ![...sel.options].some((o) => o.value === jid)) {
    const nome = nomesGrupos.get(jid) || jid;
    sel.insertAdjacentHTML('beforeend', `<option value="${esc(jid)}">${esc(nome)}</option>`);
  }
  sel.value = jid || '';
}

async function carregarGruposAlerta() {
  const sel = $('c-alertaRepetidosGrupo');
  const atual = configDe(cfgSessao)?.alertaRepetidosGrupo ?? sel.value;
  try {
    // Os grupos são os da conta DESTE número.
    const r = await api('/groups?' + qsSessao(cfgSessao));
    definirNomesGrupos(r.groups);
    sel.innerHTML = '<option value="">nenhum (alerta parado)</option>' +
      (r.groups || []).map((g) => `<option value="${esc(g.id)}">${esc(g.nome)} (${num(g.participantes)})</option>`).join('');
  } catch {
    /* sem conexão: fica o que já estava na lista */
  }
  definirGrupoAlerta(atual);
  mostrarUltimoAlerta();
}

function mostrarUltimoAlerta() {
  const el = $('alerta-ultimo');
  if (!el) return;
  const u = snap?.alertas;
  if (!u?.ts) { el.textContent = 'Nenhum alerta enviado ainda.'; return; }
  const motivo = (u.motivos || []).includes('dia') ? 'total do dia' : 'link repetido';
  el.textContent = `Último alerta: ${dataHora(u.ts)} (${motivo}${u.chave ? ` · ${u.chave}` : ''}).`;
}

$('alerta-testar').onclick = async () => {
  const sel = $('c-alertaRepetidosGrupo');
  if (!sel.value) return aviso('alerta-testar-res', 'escolha o grupo de destino', true);
  // O teste usa o que já está SALVO no servidor — avisar disso evita o "mudei
  // o grupo e o teste foi para o antigo".
  if (sel.value !== (configDe(cfgSessao)?.alertaRepetidosGrupo || '')) {
    return aviso('alerta-testar-res', 'salve as configurações antes de testar', true);
  }
  const nome = sel.options[sel.selectedIndex]?.textContent || sel.value;
  if (!confirm(`Enviar um alerta de TESTE agora em "${nome}"${$('c-alertaRepetidosMarcarTodos').checked ? ', marcando todo mundo' : ''}?`)) return;
  $('alerta-testar').disabled = true;
  try {
    // O teste sai pelo mesmo número que dispararia o alerta de verdade.
    const r = await api('/alertas/testar', { method: 'POST', body: JSON.stringify({ sessao: cfgSessao }) });
    aviso('alerta-testar-res', r.ok ? 'Alerta de teste enviado ✓' : `erro: ${r.error}`, !r.ok);
  } catch (err) {
    aviso('alerta-testar-res', `erro: ${err.message}`, true);
  } finally {
    $('alerta-testar').disabled = false;
  }
};

const aviso = (id, txt, erro = false) => {
  const el = $(id); if (!el) return;
  el.textContent = txt;
  el.className = erro ? 'err' : 'ok';
  setTimeout(() => { el.textContent = ''; }, 3000);
};

$('save-config').onclick = async () => {
  const linhas = (id) => $(id).value.split('\n').map((s) => s.replace(/\D/g, '')).filter(Boolean);
  const body = {
    autoReplyEnabled: $('c-autoReplyEnabled').checked,
    autoReplyGroups: $('c-autoReplyGroups').checked,
    autoReplyMessage: $('c-autoReplyMessage').value,
    welcomeEnabled: $('c-welcomeEnabled').checked,
    welcomeMode: $('c-welcomeMode').value,
    welcomeMessage: $('c-welcomeMessage').value,
    monitorMode: $('c-monitorMode').value,
    monitorPrivate: $('c-monitorPrivate').checked,
    // Campo vazio = 0 (histórico inteiro), não "não mexer": Number('') é 0.
    repetidosJanelaHoras: Number($('c-repetidosJanelaHoras').value || 0),
    servicosEnabled: $('c-servicosEnabled').checked,
    servicosModoCasamento: $('c-servicosModoCasamento').value,
    // Campo vazio volta ao padrão (60/120) — o validador do servidor recusa 0.
    servicosJanelaAtendimentoMin: Number($('c-servicosJanelaAtendimentoMin').value || 60),
    servicosJanelaComprovanteMin: Number($('c-servicosJanelaComprovanteMin').value || 120),
    alertaRepetidosEnabled: $('c-alertaRepetidosEnabled').checked,
    alertaRepetidosGrupo: $('c-alertaRepetidosGrupo').value,
    alertaRepetidosMensagem: $('c-alertaRepetidosMensagem').value,
    alertaRepetidosPorLink: Number($('c-alertaRepetidosPorLink').value || 0),
    alertaRepetidosPorDia: Number($('c-alertaRepetidosPorDia').value || 0),
    alertaRepetidosMarcarTodos: $('c-alertaRepetidosMarcarTodos').checked,
    commandAuthorizedNumbers: linhas('c-commandAuthorizedNumbers'),
    reportAuthorizedNumbers: linhas('c-reportAuthorizedNumbers'),
    comissaoMensagem: $('c-comissaoMensagem').value,
    exportEnabled: $('c-exportEnabled').checked,
    exportUrl: $('c-exportUrl').value.trim(),
    exportIntervaloMin: Number($('c-exportIntervaloMin').value || 5),
  };
  const pw = $('c-commandPassword').value;
  if (pw) body.commandPassword = pw;
  // Segredos: campo vazio mantém o que está salvo (não apaga sem querer).
  if ($('c-exportSegredo').value) body.exportSegredo = $('c-exportSegredo').value;
  if ($('c-exportApiKey').value) body.exportApiKey = $('c-exportApiKey').value;
  body.sessao = cfgSessao; // salva na configuração do número escolhido
  const r = await api('/config', { method: 'POST', body: JSON.stringify(body) });
  $('c-commandPassword').value = '';
  $('c-exportSegredo').value = '';
  $('c-exportApiKey').value = '';
  aviso('config-msg', r.ok ? 'Salvo ✓' : `erro: ${r.error}`, !r.ok);
};

async function acaoExport(botao, caminho, sucesso) {
  const b = $(botao);
  b.disabled = true;
  aviso('exp-msg', 'enviando…');
  try {
    const r = await api(caminho, { method: 'POST' });
    renderExport(r.status_export);
    const detalhe = r.enviados != null ? ` (${num(r.enviados)} serviço(s), ${num(r.operadores || 0)} linha(s) de operador)` : '';
    aviso('exp-msg', r.ok ? `${sucesso}${detalhe}` : `erro: ${r.erro || r.motivo || 'falhou'}`, !r.ok);
  } catch (err) {
    aviso('exp-msg', `erro: ${err.message}`, true);
  } finally {
    b.disabled = false;
  }
}

$('exp-testar').onclick = () => acaoExport('exp-testar', '/export/testar', 'Conexão OK ✓');
$('exp-sincronizar').onclick = () => acaoExport('exp-sincronizar', '/export/sincronizar', 'Sincronizado ✓');

/* ═══════════════ Apagar dados coletados ═══════════════ */
const ROTULO_ESCOPO = {
  tudo: 'TODO o histórico de lançamentos e as estatísticas',
  historico: 'o histórico de lançamentos',
  estatisticas: 'as estatísticas acumuladas',
};

async function carregarBackups() {
  try {
    const r = await api('/dados/backups');
    const bks = r.backups || [];
    $('backups-list').innerHTML = bks.length
      ? `<p class="hint">Backups disponíveis (mais recente primeiro):</p>` +
        bks.map((b) => `<div class="backup-row"><span>${esc(b.nome)}</span><span>${(b.tamanho / 1024).toFixed(0)} kB</span></div>`).join('')
      : '<p class="hint">Nenhum backup ainda.</p>';
  } catch { $('backups-list').innerHTML = ''; }
}

$('btn-limpar').onclick = async () => {
  const escopo = $('d-escopo').value;
  const antesDe = $('d-antesDe').value || null;
  const recorte = antesDe && escopo !== 'estatisticas' ? `\nApenas lançamentos anteriores a ${antesDe}.` : '';
  if (!confirm(`Apagar ${ROTULO_ESCOPO[escopo]}?${recorte}\n\nUm backup é gravado antes, mas a ação não se desfaz sozinha.`)) return;

  $('limpar-msg').textContent = 'apagando…';
  const body = { escopo, confirmar: true };
  if (antesDe) body.antesDe = antesDe;
  try {
    const r = await api('/dados/limpar', { method: 'POST', body: JSON.stringify(body) });
    if (r.ok) {
      aviso('limpar-msg', `✓ ${r.removidas} apagado(s), ${r.restantes} restante(s) · backup ${r.backup}`);
      carregarBackups();
    } else {
      aviso('limpar-msg', `erro: ${r.error || 'falha ao apagar'}`, true);
    }
  } catch (e) {
    aviso('limpar-msg', `erro: ${e.message}`, true);
  }
};

/* ═══════════════ Grupos ═══════════════ */
const linhaGrupo = (g, marcados) =>
  `<label class="check-row">
     <input type="checkbox" value="${esc(g.id)}" ${marcados.includes(g.id) ? 'checked' : ''}/>
     <span class="n">${esc(g.nome)}</span><span class="c">${num(g.participantes)} membros</span>
   </label>`;

async function carregarGrupos() {
  const semConexao = `<p class="hint">Conecte ${esc(nomeSessao(grpSessao))} para listar os grupos dele.</p>`;
  try {
    const r = await api('/groups?' + qsSessao(grpSessao));
    const grupos = r.groups || [];
    const nenhum = '<p class="hint">Nenhum grupo encontrado.</p>';
    const cfg = configDe(grpSessao) || {};
    const monit = cfg.monitoredGroups || [];
    const bv = cfg.welcomeGroups || [];
    $('groups-list').innerHTML = grupos.map((g) => linhaGrupo(g, monit)).join('') || nenhum;
    $('welcome-groups-list').innerHTML = grupos.map((g) => linhaGrupo(g, bv)).join('') || nenhum;
  } catch {
    $('groups-list').innerHTML = semConexao;
    $('welcome-groups-list').innerHTML = semConexao;
  }
}
$('reload-groups').onclick = carregarGrupos;

const idsMarcados = (sel) => [...document.querySelectorAll(`${sel} input:checked`)].map((c) => c.value);
$('save-groups').onclick = async () => {
  const r = await api('/config', { method: 'POST', body: JSON.stringify({ sessao: grpSessao, monitoredGroups: idsMarcados('#groups-list') }) });
  aviso('groups-msg', r.ok ? 'Salvo ✓' : `erro: ${r.error}`, !r.ok);
  if (r.ok) carregarDestinos(); // a lista de destinos do agendamento vem daqui
};
$('save-welcome-groups').onclick = async () => {
  const r = await api('/config', { method: 'POST', body: JSON.stringify({ sessao: grpSessao, welcomeGroups: idsMarcados('#welcome-groups-list') }) });
  aviso('welcome-groups-msg', r.ok ? 'Salvo ✓' : `erro: ${r.error}`, !r.ok);
};

/* ═══════════════ Enviar / upload ═══════════════ */
$('send-btn').onclick = async () => {
  const r = await api('/send', {
    method: 'POST',
    body: JSON.stringify({ sessao: $('send-sessao').value, to: $('send-to').value, message: $('send-msg').value }),
  });
  aviso('send-res', r.ok ? 'Enviado ✓' : `erro: ${r.error}`, !r.ok);
  if (r.ok) $('send-msg').value = '';
};
$('upload-btn').onclick = async () => {
  const f = $('upload-file').files[0];
  if (!f) return aviso('upload-res', 'selecione um arquivo', true);
  const fd = new FormData();
  fd.append('file', f);
  const res = await fetch('/api/upload', { method: 'POST', headers: { Authorization: 'Bearer ' + TOKEN }, body: fd });
  const r = await res.json();
  aviso('upload-res', r.ok ? `Salvo: ${r.file.nome}` : `erro: ${r.error}`, !r.ok);
};

/* ═══════════════ Brogueiras (pedidos de link) ═══════════════
   Membros comuns do grupo = Brogueiras; administradores = Operadores.
   Cada pedido é um link + o que ela quer nele (contas ou montante). */
let bgPeriodo = 'hoje';
let bgDados = null;
let bgAberta = null; // id da brogueira com o detalhe aberto
let bgRepFiltro = 'todos'; // 'todos' | 'outras' (só link que passou de uma Brogueira para outra)
let bgBusca = ''; // filtro por nome ou número, aplicado só na tabela

const TIPO_ROTULO = { conta: 'Conta', montante: 'Montante', indefinido: '?' };
const ORDINAL = ['', '1ª', '2ª', '3ª', '4ª', '5ª', '6ª', '7ª', '8ª', '9ª', '10ª'];
const ordinal = (n) => ORDINAL[n] ?? `${n}ª`;
// Data curta + hora: tanto os links repetidos quanto o ranking "geral" das
// indicações cruzam vários dias, e só a hora seria ambígua.
const dataHora = (iso) =>
  new Date(iso).toLocaleString('pt-BR', { day: '2-digit', month: '2-digit', hour: '2-digit', minute: '2-digit' });

async function carregarBrogueiras() {
  try {
    const r = await api('/brogueiras?period=' + periodoDaAba(bgPeriodo) + (qsSessao(filtroSessao) ? '&' + qsSessao(filtroSessao) : ''));
    if (!r.ok) return;
    renderBrogueiras(r);
  } catch {
    /* sem sessão — o login cuida */
  }
}

function renderBrogueiras(d) {
  bgDados = d; // o detalhe lê daqui — guardar no render mantém os dois em sincronia
  const res = d.resumo || {};
  $('bg-kpi-pedidos').textContent = num(res.pedidos || 0);
  $('bg-kpi-ativas').textContent = `${num(res.brogueirasAtivas || 0)} brogueiras`;
  $('bg-kpi-montante').textContent = brlCompacto(res.montanteTotal || 0);
  $('bg-kpi-montante-qtd').textContent = `${num(res.montantePedidos || 0)} pedidos`;
  $('bg-kpi-contas').textContent = num(res.contasTotal || 0);
  $('bg-kpi-contas-qtd').textContent = `${num(res.contasPedidos || 0)} pedidos`;
  $('bg-kpi-links').textContent = num(res.links || 0);
  $('bg-kpi-indef').textContent = `${num(res.indefinidos || 0)} sem classificar`;
  $('bg-kpi-repetidos').textContent = num(res.linksRepetidos || 0);
  $('bg-kpi-repetidos-sub').textContent =
    `${num(res.repeticoes || 0)} reenvios · ${num(res.repeticoesDeOutras || 0)} de outra`;
  // O card só acende quando há repetição de uma Brogueira para outra — é o
  // caso que pede ação; reenvio do próprio link é rotina.
  $('bg-kpi-card-rep').classList.toggle('alerta', (res.repeticoesDeOutras || 0) > 0);

  renderTabelaBrogueiras();

  const plat = d.plataformas || [];
  const maior = Math.max(1, ...plat.map((p) => p.qtd));
  $('bg-plataformas').innerHTML = plat.slice(0, 12).map((p) => `
    <div class="plat-row">
      <span class="plat-nome">${esc(p.dominio)}</span>
      <span class="plat-barra"><i style="width:${(p.qtd / maior) * 100}%"></i></span>
      <span class="plat-qtd">${num(p.qtd)}</span>
    </div>`).join('') || '<p class="hint">Nenhum link no período.</p>';

  renderRepetidos(d.repetidos);
  if (bgAberta) abrirDetalheBrogueira(bgAberta, { manter: true });
}

// A tabela é redesenhada tanto quando chegam dados novos quanto a cada tecla
// da busca — por isso ela é uma função separada do render do relatório.
function renderTabelaBrogueiras() {
  const tb = document.querySelector('#tbl-bg tbody');
  if (!tb) return;
  const todas = bgDados?.brogueiras || [];
  const lista = todas.filter((b) => casaBusca(b, bgBusca));

  $('bg-busca-conta').textContent = bgBusca && todas.length
    ? `${num(lista.length)} de ${num(todas.length)}`
    : '';

  if (!lista.length) {
    tb.innerHTML = `<tr><td colspan="6" class="muted">${bgBusca
      ? 'Nenhuma Brogueira com esse nome ou número no período.'
      : 'Nenhum pedido no período'}</td></tr>`;
    return;
  }

  tb.innerHTML = lista.map((b) => {
    const fone = telefoneVisivel(b.pn, b.id);
    return `
    <tr class="bg-row" data-id="${esc(b.id ?? b.nome)}">
      <td>
        <span class="linha-nome">
          <span>${esc(b.nome)}${b.papel === 'desconhecido' ? '<span class="tag-aviso" title="Não deu para confirmar o papel no grupo">?</span>' : ''}</span>
          ${fone ? `<span class="linha-num">${esc(fone)}</span>` : ''}
        </span>
      </td>
      <td class="num">${num(b.pedidos)}</td>
      <td class="num">${b.montanteTotal ? brl(b.montanteTotal) : '—'}</td>
      <td class="num">${b.contasTotal ? num(b.contasTotal) : '—'}</td>
      <td class="num">${num(b.links.length)}</td>
      <td class="num">${b.repetidos
        ? `<span class="tag-rep ${b.repetidosDeOutra ? 'outra' : 'mesma'}" title="${num(b.repetidos)} pedido(s) com link já mandado antes${b.repetidosDeOutra ? `, ${num(b.repetidosDeOutra)} de outra Brogueira` : ''}">${num(b.repetidos)}</span>`
        : '—'}</td>
    </tr>`;
  }).join('');

  tb.querySelectorAll('.bg-row').forEach((tr) => {
    tr.onclick = () => abrirDetalheBrogueira(tr.dataset.id);
  });
}

// Digitar não vai ao servidor: o relatório do período já veio inteiro, então o
// filtro é local e responde na tecla.
$('bg-busca').oninput = (ev) => {
  bgBusca = ev.target.value;
  renderTabelaBrogueiras();
};

/* ── Links repetidos ──────────────────────────────────────
   Um bloco por link, do mais repetido para o menos. Aberto por padrão só o
   primeiro: com 150 links no "Geral", tudo aberto vira um paredão. */
function renderRepetidos(rep) {
  const alvo = $('bg-repetidos');
  const todos = rep?.grupos || [];
  const grupos = bgRepFiltro === 'outras' ? todos.filter((g) => g.deOutras) : todos;

  if (!grupos.length) {
    alvo.innerHTML = `<p class="hint">${todos.length
      ? 'Nenhum link passou de uma Brogueira para outra no período.'
      : 'Nenhum link repetido no período. 👍'}</p>`;
    return;
  }

  alvo.innerHTML = grupos.map((g, i) => {
    const primeiro = g.envios[0];
    const repetidoras = [...new Set(g.envios.slice(1).map((e) => e.autorNome))];
    return `
    <details class="rep-item ${g.deOutras ? 'outra' : 'mesma'}"${i === 0 ? ' open' : ''}>
      <summary>
        <span class="tag-rep ${g.deOutras ? 'outra' : 'mesma'}">${num(g.vezes)}×</span>
        <span class="rep-link" title="${esc(g.link)}">${esc(g.chave)}</span>
        <span class="rep-quem">${esc(primeiro.autorNome)} <span class="muted">→</span> ${esc(repetidoras.join(', '))}</span>
        <span class="rep-quando">${esc(dataHora(g.ultimoEm))}</span>
      </summary>
      <div class="rep-corpo">
        <a href="${esc(g.link)}" target="_blank" rel="noopener noreferrer nofollow" class="link-ped">${esc(g.link)}</a>
        <table class="tbl">
          <thead><tr><th>#</th><th>Quando</th><th>Quem</th><th>Pedido</th><th class="num">Valor</th></tr></thead>
          <tbody>${g.envios.map((e) => `
            <tr class="${e.noPeriodo ? '' : 'fora'}">
              <td>${e.ordem === 1 ? '<span class="tag-rep mesma">1ª</span>' : `<span class="tag-rep ${e.autorChave === primeiro.autorChave ? 'mesma' : 'outra'}">${esc(ordinal(e.ordem))}</span>`}</td>
              <td>${esc(dataHora(e.ts))}</td>
              <td>${esc(e.autorNome)}${e.papel === 'operador' ? '<span class="tag-aviso" title="Operador (admin do grupo)">op</span>' : ''}</td>
              <td class="pedido-txt">${esc(e.pedido)}</td>
              <td class="num">${e.tipo === 'montante' ? brl(e.montante) : e.contas != null ? num(e.contas) + ' contas' : '—'}</td>
            </tr>`).join('')}</tbody>
        </table>
      </div>
    </details>`;
  }).join('');
}

/* Aviso flutuante de link repetido. Fica 20 s (tempo de ler o nome e o link)
   ou até clicarem; no máximo 4 na tela, senão uma rajada cobre o painel. */
function avisarRepetido(r) {
  const caixa = $('avisos');
  // Viewer não tem a aba Brogueiras (o servidor nega /api/brogueiras) — avisar
  // sobre algo que ele não pode abrir só atrapalharia.
  if (!caixa || ROLE !== 'admin') return;
  const rep = (r?.repeticoes || [])[0];
  if (!rep) return;
  const deOutra = (r.repeticoes || []).some((x) => x.deOutra);

  const el = document.createElement('div');
  el.className = `aviso-toast ${deOutra ? 'outra' : 'mesma'}`;
  el.innerHTML = `
    <b>${esc(r.autorNome || 'Brogueira')}</b> mandou link repetido
    <span class="tag-rep ${deOutra ? 'outra' : 'mesma'}">${esc(ordinal(rep.vezes))} vez</span>
    <div class="aviso-link">${esc(rep.chave)}</div>
    <div class="aviso-sub">${deOutra
      ? `1ª vez foi de <b>${esc(rep.primeiroPor || '—')}</b> em ${esc(dataHora(rep.primeiroEm))}`
      : `ela mesma já tinha mandado em ${esc(dataHora(rep.primeiroEm))}`}</div>`;
  el.onclick = () => {
    el.remove();
    abrirAba('brogueiras');
  };
  caixa.prepend(el);
  while (caixa.children.length > 4) caixa.lastElementChild.remove();
  setTimeout(() => el.remove(), 20000);
}

// Serviço validado: quem pediu, quem atendeu e quanto.
function avisarServico(s) {
  const caixa = $('avisos');
  if (!caixa || !s) return;
  const el = document.createElement('div');
  el.className = 'aviso-toast validado';
  el.innerHTML = `
    <b>${esc(s.atendimento?.operatorName || 'Operador')}</b> fechou um serviço
    <span class="tag-cas citacao">validado</span>
    <div class="aviso-sub">${esc(s.brogueiraNome || 'Brogueira')} · ${esc(brl(s.atendimento?.montante))}
      · comprovante ${s.comprovante?.tipo === 'pdf' ? 'em PDF' : 'em imagem'}</div>`;
  el.onclick = () => el.remove();
  caixa.prepend(el);
  while (caixa.children.length > 4) caixa.lastElementChild.remove();
  setTimeout(() => el.remove(), 15000);
}

document.querySelectorAll('#bg-rep-filtro button').forEach((b) => {
  b.onclick = () => {
    bgRepFiltro = b.dataset.filtro;
    document.querySelectorAll('#bg-rep-filtro button').forEach((x) => x.classList.toggle('active', x === b));
    renderRepetidos(bgDados?.repetidos);
  };
});

// Selo "2ª vez" numa linha de pedido. `rep` vem do backend (null = link inédito).
function tagRepeticao(rep) {
  if (!rep) return '';
  const quem = rep.deOutra ? `1ª vez foi de ${rep.primeiroPor}` : 'ela mesma já tinha mandado';
  return `<span class="tag-rep ${rep.deOutra ? 'outra' : 'mesma'}" title="${esc(`${quem} em ${dataHora(rep.primeiroEm)}`)}">`
    + `${esc(ordinal(rep.ordem))} vez${rep.deOutra ? ' · de outra' : ''}</span>`;
}

// Detalhe: os links que ela mandou, separados por dia.
function abrirDetalheBrogueira(id, { manter = false } = {}) {
  const b = (bgDados?.brogueiras || []).find((x) => (x.id ?? x.nome) === id);
  if (!b) { fecharDetalhe(); return; }
  bgAberta = id;
  $('bg-detalhe').classList.remove('hidden');
  $('bg-detalhe-nome').textContent = `${b.nome} — ${num(b.pedidos)} pedidos · ${brl(b.montanteTotal)} em montante · ${num(b.contasTotal)} contas`;
  $('bg-detalhe-corpo').innerHTML = (b.dias || []).map((dia) => `
    <div class="dia-bloco">
      <div class="dia-cab">${esc(dia.day)} <span class="muted">· ${num(dia.pedidos.length)} pedidos</span></div>
      <table class="tbl">
        <thead><tr><th>Hora</th><th>Tipo</th><th class="num">Valor</th><th>Pedido</th><th>Link</th></tr></thead>
        <tbody>${dia.pedidos.map((p) => `
          <tr>
            <td>${esc(hora(p.ts))}</td>
            <td><span class="tag-tipo ${esc(p.tipo)}">${esc(TIPO_ROTULO[p.tipo] || p.tipo)}</span></td>
            <td class="num">${p.tipo === 'montante' ? brl(p.montante) + (p.contas ? ` <span class="muted">em ${num(p.contas)}</span>` : '') : p.contas != null ? num(p.contas) + ' contas' : '—'}</td>
            <td class="pedido-txt">${esc(p.pedido)}</td>
            <td>${p.links.map((l) => `<a href="${esc(l)}" target="_blank" rel="noopener noreferrer nofollow" class="link-ped">${esc(l)}</a>`).join('<br>')}
              ${tagRepeticao(p.repeticao)}</td>
          </tr>`).join('')}</tbody>
      </table>
    </div>`).join('') || '<p class="hint">Sem pedidos.</p>';
  if (!manter) $('bg-detalhe').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function fecharDetalhe() {
  bgAberta = null;
  $('bg-detalhe').classList.add('hidden');
}
$('bg-fechar').onclick = fecharDetalhe;
$('bg-reload').onclick = carregarBrogueiras;
document.querySelectorAll('#bg-periodo button').forEach((b) => {
  b.onclick = () => {
    bgPeriodo = b.dataset.period;
    document.querySelectorAll('#bg-periodo button').forEach((x) => x.classList.toggle('active', x === b));
    fecharDetalhe();
    carregarBrogueiras();
  };
});

// Lista de membros do grupo, já separada em Operadores x Brogueiras.
async function carregarMembrosGrupo() {
  const jid = $('bg-grupo').value;
  const alvo = $('bg-membros');
  if (!jid) { alvo.innerHTML = ''; return; }
  alvo.innerHTML = '<p class="hint">carregando…</p>';
  try {
    const r = await api(`/groups/${encodeURIComponent(jid)}/membros?` + qsSessao(sessaoParaConsulta()));
    if (!r.ok) { alvo.innerHTML = `<p class="hint">erro: ${esc(r.error)}</p>`; return; }
    const linha = (m) => `<div class="membro-row"><code>${esc(m.pn || m.id)}</code></div>`;
    alvo.innerHTML = `
      <div class="membros-cab">${num(r.total)} membros · <b>${num(r.operadores.length)}</b> operadores · <b>${num(r.brogueiras.length)}</b> brogueiras</div>
      <details class="membros-lista"><summary>Operadores (${num(r.operadores.length)})</summary>${r.operadores.map(linha).join('')}</details>
      <details class="membros-lista"><summary>Brogueiras (${num(r.brogueiras.length)})</summary>${r.brogueiras.slice(0, 100).map(linha).join('')}
        ${r.brogueiras.length > 100 ? `<p class="hint">mostrando 100 de ${num(r.brogueiras.length)}</p>` : ''}</details>`;
  } catch {
    alvo.innerHTML = '<p class="hint">não foi possível consultar o grupo.</p>';
  }
}
$('bg-grupo').onchange = carregarMembrosGrupo;

async function carregarGruposBrogueiras() {
  const sel = $('bg-grupo');
  if (sel.options.length > 1) return; // já preenchido
  try {
    const r = await api('/groups?' + qsSessao(sessaoParaConsulta()));
    definirNomesGrupos(r.groups);
    sel.innerHTML = '<option value="">escolha um grupo…</option>' +
      (r.groups || []).map((g) => `<option value="${esc(g.id)}">${esc(g.nome)} (${num(g.participantes)})</option>`).join('');
  } catch {
    sel.innerHTML = '<option value="">conecte o WhatsApp</option>';
  }
}

/* ═══════════════ Operadores (ranking) ═══════════════
   "Quais e quanto os Operadores pegaram de serviço", no período escolhido.
   Serviço PEGO = pedido de Brogueira que ele atendeu; VALIDADO = ela mandou o
   comprovante depois. O lançamento bruto vem junto porque nem toda mensagem
   financeira casa com um pedido — e quem só lança não pode sumir do ranking. */

let opPeriodo = 'hoje';
// Um dia exato (YYYY-MM-DD) é um período como qualquer outro para o servidor
// (`periodoDaReq` aceita a data crua); no painel ele mora no seletor de dia, e
// os botões Hoje/Semana/… ficam todos apagados enquanto ele manda.
// 'todos' = conta tudo o que o Operador pegou; 'validados' = só o que fechou
// com comprovante PIX. Muda a ORDEM do ranking, quem entra nele e o detalhe —
// os dados já vêm inteiros do servidor, então a troca é instantânea.
let opFiltro = 'todos';
let opBusca = '';
let opDados = null;
let opAberto = null; // id do Operador com o detalhe aberto

const ehDia = (p) => /^\d{4}-\d{2}-\d{2}$/.test(String(p ?? ''));

// Data de hoje no fuso do navegador, no formato do <input type="date">.
function hojeISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`;
}

// Soma/subtrai dias de uma data ISO sem passar por fuso (o Date do navegador
// leria "2026-08-30" como UTC e voltaria um dia em quem está a oeste).
function somarDias(iso, n) {
  const [a, m, d] = String(iso).split('-').map(Number);
  const base = new Date(a, m - 1, d);
  base.setDate(base.getDate() + n);
  return `${base.getFullYear()}-${String(base.getMonth() + 1).padStart(2, '0')}-${String(base.getDate()).padStart(2, '0')}`;
}

/**
 * Troca o período e recarrega. `valor` é 'hoje'|'semana'|… ou uma data.
 * Um lugar só para acender/apagar os dois controles — eles são exclusivos: ou
 * manda o botão, ou manda o dia escolhido.
 */
let sincronizandoDia = false;

function aplicarPeriodo(valor) {
  // Um dia escolhido aqui é o mesmo dia do seletor do topo: os dois navegadores
  // mexem no mesmo estado, senão a aba mostraria um dia e o painel outro.
  if (!sincronizandoDia) {
    if (ehDia(valor) && valor !== diaPainel) { aplicarDiaPainel(valor); return; }
    if (!ehDia(valor) && diaPainel && valor === 'hoje') { aplicarDiaPainel(''); return; }
  }
  opPeriodo = valor;
  const dia = ehDia(valor);
  document.querySelectorAll('#op-periodo button').forEach((b) => {
    b.classList.toggle('active', !dia && b.dataset.period === valor);
  });
  const nav = $('op-dia-nav');
  nav.classList.toggle('ativo', dia);
  $('op-dia').value = dia ? valor : '';
  // Não dá para pedir o ranking de amanhã.
  $('op-dia-prox').disabled = dia && valor >= hojeISO();
  fecharDetalheOperador();
  carregarOperadores();
}

async function carregarOperadores() {
  try {
    const qs = qsSessao(filtroSessao);
    const r = await api('/operadores/ranking?period=' + opPeriodo + (qs ? '&' + qs : ''));
    if (!r.ok) return;
    renderOperadores(r);
  } catch {
    /* sem sessão — o login cuida */
  }
}

/**
 * Montante validado por dia no período — a soma do `dias[]` de todos os
 * Operadores. O servidor manda a série por pessoa; o KPI quer a do grupo.
 * Devolve [] quando o recorte é de um dia só (uma linha reta não diz nada).
 */
function serieDiaria(d) {
  const porDia = new Map();
  for (const o of d?.operadores || []) {
    for (const dia of o.dias || []) {
      porDia.set(dia.day, (porDia.get(dia.day) ?? 0) + (dia.montanteValidado || 0));
    }
  }
  if (porDia.size < 2) return [];
  return [...porDia.entries()]
    .sort((a, b) => a[0].localeCompare(b[0]))
    .slice(-14)
    .map(([, v]) => v);
}

function renderOperadores(d) {
  opDados = d;
  const r = d.resumo || {};
  $('op-periodo-rotulo').textContent = r.periodo || '';
  $('op-kpi-servicos').textContent = num(r.servicos || 0);
  $('op-kpi-ops').textContent = `${num(r.operadores || 0)} operadores`;
  $('op-kpi-validados').textContent = num(r.validados || 0);
  $('op-kpi-taxa').textContent = r.servicos
    ? `${Math.round((r.taxa || 0) * 100)}% do que pegaram`
    : 'nenhum serviço pego ainda';
  // Contas seguem o mesmo recorte do filtro: pegas (todo serviço atendido) ou
  // só as que fecharam com comprovante.
  const soValidados = opFiltro === 'validados';
  $('op-kpi-contas-label').textContent = soValidados ? 'Contas validadas' : 'Contas pegas';
  $('op-kpi-contas').textContent = num(soValidados ? r.contasValidadasQtd || 0 : r.contasPegasQtd || 0);
  $('op-kpi-contas-sub').textContent = brl(soValidados ? r.contasValidadasValor || 0 : r.contasPegasValor || 0);
  // Medidor da taxa: a mesma informação do texto, lida sem ler.
  $('op-kpi-meter').firstElementChild.style.width = `${Math.round((r.taxa || 0) * 100)}%`;
  $('op-kpi-meter').classList.toggle('vazio', !r.servicos);

  $('op-kpi-montante').textContent = brlCompacto(r.montanteValidado || 0);
  $('op-kpi-montante-sub').textContent = `${num(r.validados || 0)} serviços validados`;
  // Sparkline do montante validado dia a dia — só faz sentido em período com
  // mais de um dia (num recorte de um dia só, o quadro fica escondido).
  const serie = serieDiaria(d);
  $('op-kpi-foot').classList.toggle('hidden', !serie.length);
  $('op-kpi-spark').innerHTML = serie.length ? spark(serie, C.svOk || '#199e70') : '';
  $('op-kpi-lancado').textContent = brlCompacto(r.montanteLancado || 0);
  $('op-kpi-lancamentos').textContent = `${num(r.lancamentos || 0)} lançamentos · ${num(r.contasQtd || 0)} contas`;

  const casamento = (d.operadores || []).reduce((acc, o) => {
    for (const k of ['citacao', 'valor', 'tempo']) acc[k] += o.casamento?.[k] || 0;
    return acc;
  }, { citacao: 0, valor: 0, tempo: 0 });
  $('op-casamento').innerHTML = [
    ['Respondeu citando', casamento.citacao],
    ['Valor confere', casamento.valor],
    ['Por proximidade', casamento.tempo],
    ['Sem comprovante', r.semComprovante || 0],
  ].map(([l, v]) => `<div class="mini"><span class="l">${l}</span><span class="v">${esc(String(num(v)))}</span></div>`).join('');

  // O que o filtro está contando, dito em palavras — o número sozinho não
  // deixa claro se inclui ou não quem ficou sem comprovante.
  $('op-podio-sub').textContent = soValidados ? 'por serviços validados' : 'por serviços pegos';
  $('op-filtro-hint').textContent = soValidados
    ? `${num(r.validados || 0)} de ${num(r.servicos || 0)} serviços fecharam com comprovante`
    : `${num(r.servicos || 0)} pegos · ${num(r.aguardando || 0)} aguardando · ${num(r.semComprovante || 0)} sem comprovante`;

  const podio = rankingAtual().slice(0, 5);
  // A barra é a fatia do líder — o pódio passa a ser lido pela forma, não só
  // pela ordem das linhas (a diferença entre 1º e 2º some numa lista crua).
  const teto = Math.max(...podio.map((o) => (soValidados ? o.validados : o.servicos) || 0), 1);
  $('op-podio').innerHTML = podio.length
    ? podio.map((o, i) => `
      <div class="rank-row">
        <span class="rank-n">${String(i + 1).padStart(2, '0')}</span>
        <span class="rank-body">
          <span class="rank-name">${esc(o.nome)}</span>
          <span class="rank-sub">${soValidados
            ? `${num(o.validados)} validado(s) · ${num(o.contasValidadasQtd)} conta(s)`
            : `${num(o.servicos)} pego(s) · ${num(o.contasPegasQtd)} conta(s) · ${num(o.lancamentos)} lançamento(s)`}</span>
          <span class="barra-cel"><i style="width:${Math.round(100 * ((soValidados ? o.validados : o.servicos) || 0) / teto)}%"></i></span>
        </span>
        <span class="rank-val">${esc(brlCompacto(soValidados ? o.montanteValidado : (o.montanteValidado || o.montanteLancado)))}</span>
      </div>`).join('')
    : vazio(soValidados ? 'Nenhum serviço validado no período' : 'Nenhum operador no período');

  renderTabelaOperadores();
  if (opAberto) abrirDetalheOperador(opAberto, { manter: true });
}

/**
 * O ranking conforme o filtro escolhido.
 *
 * 'todos'     → todo Operador que apareceu no período (inclusive quem só lançou
 *               sem pedido casado), ordenado por serviços pegos.
 * 'validados' → só quem fechou pelo menos um serviço com comprovante, ordenado
 *               por serviços validados. A posição é recalculada: é outro
 *               ranking, não o mesmo com linhas escondidas.
 */
function rankingAtual() {
  const todos = opDados?.operadores || [];
  if (opFiltro !== 'validados') return todos; // já vem ordenado do servidor
  return todos
    .filter((o) => o.validados > 0)
    .slice()
    .sort((a, b) => b.validados - a.validados || b.montanteValidado - a.montanteValidado);
}

// Só os serviços que o filtro manda mostrar no detalhe do Operador.
const servicosDoFiltro = (o) =>
  (o?.ultimosServicos || []).filter((sv) => opFiltro !== 'validados' || sv.status === 'validado');

// Pill da taxa: verde a partir de 70%, âmbar abaixo de 40%; o resto neutro.
// A cor é reforço — o número está escrito do lado.
function pillTaxa(o) {
  if (!o.servicos) return '<span class="taxa-pill">—</span>';
  const pct = Math.round((o.taxa || 0) * 100);
  const classe = pct >= 70 ? 'alta' : pct < 40 ? 'baixa' : '';
  return `<span class="taxa-pill ${classe}">${pct}%</span>`;
}

// Redesenhada tanto no dado novo quanto a cada tecla da busca.
function renderTabelaOperadores() {
  const tb = document.querySelector('#tbl-op tbody');
  if (!tb) return;
  const validados = opFiltro === 'validados';
  const todos = rankingAtual();
  const lista = todos.filter((o) => casaBusca(o, opBusca));

  // A seta diz qual coluna está mandando na ordem — senão a troca de filtro
  // reordena a tabela sem explicação nenhuma.
  $('op-th-pegos').classList.toggle('ordenando', !validados);
  $('op-th-validados').classList.toggle('ordenando', validados);
  // O cabeçalho diz de quais contas a coluna está falando.
  const thContas = $('op-th-contas');
  thContas.textContent = validados ? 'Contas validadas' : 'Contas pegas';
  thContas.title = validados
    ? 'Contas dos serviços que fecharam com comprovante'
    : 'Contas dos serviços que ele pegou, tenham fechado ou não';

  $('op-busca-conta').textContent = opBusca && todos.length ? `${num(lista.length)} de ${num(todos.length)}` : '';

  if (!lista.length) {
    const semNada = opBusca
      ? 'Nenhum Operador com esse nome ou número no período.'
      : validados
        ? 'Nenhum serviço fechou com comprovante no período. Em "Todos os serviços pegos" aparece quem atendeu e não recebeu o comprovante.'
        : 'Nenhum lançamento nem serviço no período.';
    tb.innerHTML = `<tr><td colspan="8" class="muted">${semNada}</td></tr>`;
    return;
  }

  // Teto do período para a barra da coluna de montante: a linha do topo enche,
  // as outras mostram a fatia. É o que faz a tabela ter forma além de números.
  const tetoMontante = Math.max(...todos.map((o) => o.montanteValidado || 0), 1);

  tb.innerHTML = lista.map((o) => {
    // A posição é a do ranking INTEIRO, não a da lista filtrada — buscar
    // alguém não pode fazer ele virar o 1º colocado.
    const pos = todos.indexOf(o) + 1;
    const fone = telefoneVisivel(o.pn, o.id);
    const contasQtd = validados ? o.contasValidadasQtd : o.contasPegasQtd;
    const contasValor = validados ? o.contasValidadasValor : o.contasPegasValor;
    return `
    <tr class="op-row" data-id="${esc(o.id ?? o.nome)}">
      <td class="num"><span class="pos${pos <= 3 ? ' topo' : ''}">${pos}</span></td>
      <td>
        <span class="linha-nome">
          <span>${esc(o.nome)}</span>
          ${fone ? `<span class="linha-num">${esc(fone)}</span>` : ''}
        </span>
      </td>
      <td class="num">${num(o.servicos)}</td>
      <td class="num">${num(o.validados)}</td>
      <td class="num">${pillTaxa(o)}</td>
      <td class="num">${contasQtd
        ? `${num(contasQtd)}<span class="linha-num">${esc(brl(contasValor))}</span>`
        : '—'}</td>
      <td class="num">${o.montanteValidado
        ? `${brl(o.montanteValidado)}<span class="barra-cel"><i style="width:${Math.round(100 * o.montanteValidado / tetoMontante)}%"></i></span>`
        : '—'}</td>
      <td class="num">${o.montanteLancado || o.lancamentos
        ? `${esc(brl(o.montanteLancado))}<span class="linha-num">${num(o.lancamentos)} lanç. · ${num(o.contasQtd)} contas</span>`
        : '—'}</td>
    </tr>`;
  }).join('');

  tb.querySelectorAll('.op-row').forEach((tr) => {
    tr.onclick = () => abrirDetalheOperador(tr.dataset.id);
  });
}

const CASAMENTO_ROTULO = { citacao: 'citou', valor: 'valor', tempo: 'proximidade' };
const STATUS_SERV_ROTULO = {
  validado: 'validado',
  aguardando_comprovante: 'aguardando',
  expirado_sem_comprovante: 'não veio',
};

// Detalhe: o dia a dia do Operador e os serviços que ele pegou.
function abrirDetalheOperador(id, { manter = false } = {}) {
  const o = (opDados?.operadores || []).find((x) => String(x.id ?? x.nome) === String(id));
  if (!o) { fecharDetalheOperador(); return; }
  opAberto = id;
  $('op-detalhe-nome').textContent = opFiltro === 'validados'
    ? `${o.nome} — ${num(o.validados)} serviço(s) validado(s)`
    : `${o.nome} — ${num(o.servicos)} serviço(s) pego(s) · ${num(o.lancamentos)} lançamento(s)`;

  // Dia a dia: a barra é a fatia do melhor dia dele, para o padrão da semana
  // aparecer sem precisar de outro gráfico. Clicar no dia filtra a aba inteira
  // por aquele dia — é o caminho mais curto entre "esse dia foi estranho" e
  // "quem mais trabalhou nele".
  const tetoDia = Math.max(...(o.dias || []).map((d) => d.montanteValidado || 0), 1);
  const dias = (o.dias || []).map((d) => `
    <button type="button" class="dia-linha" data-dia="${esc(d.day)}" title="Filtrar a aba por este dia">
      <span class="dia-data">${esc(dataDia(d.day))}</span>
      <span class="dia-barra"><i style="width:${Math.round(100 * (d.montanteValidado || 0) / tetoDia)}%"></i></span>
      <span class="dia-nums">${num(d.validados)}/${num(d.servicos)} validados · ${num(d.contasPegasQtd)} conta(s)
        · ${num(d.lancamentos)} lanç. · ${esc(brlCompacto(d.montanteValidado || 0))}</span>
    </button>`).join('');

  const servicos = servicosDoFiltro(o).map((sv) => `
    <tr>
      <td>${esc(dataDia(sv.day))} ${esc(hora(sv.atendimentoTs))}</td>
      <td>${esc(sv.brogueiraNome)}<div class="tag-passo">${esc(cortar(sv.pedidoTexto, 38))}</div></td>
      <td class="num">${sv.montante ? brl(sv.montante) : '—'}</td>
      <td class="num">${num(sv.contasQtd)}</td>
      <td><span class="tag-cas ${esc(sv.casamento || 'tempo')}">${esc(CASAMENTO_ROTULO[sv.casamento] ?? sv.casamento ?? '—')}</span></td>
      <td><span class="tag-passo${sv.comprovanteTs ? '' : ' falta'}">${sv.comprovanteTs
        ? `${esc(hora(sv.comprovanteTs))} · ${sv.comprovanteTipo === 'pdf' ? 'PDF' : 'imagem'}`
        : esc(STATUS_SERV_ROTULO[sv.status] ?? sv.status)}</span></td>
    </tr>`).join('');

  $('op-detalhe-corpo').innerHTML = `
    <div class="mini-list">
      <div class="mini"><span class="l">Montante validado</span><span class="v">${esc(brl(o.montanteValidado))}</span></div>
      <div class="mini"><span class="l">Montante lançado</span><span class="v">${esc(brl(o.montanteLancado))}</span></div>
      <div class="mini"><span class="l">Contas pegas</span><span class="v">${num(o.contasPegasQtd)} (${esc(brl(o.contasPegasValor))})</span></div>
      <div class="mini"><span class="l">Contas validadas</span><span class="v">${num(o.contasValidadasQtd)} (${esc(brl(o.contasValidadasValor))})</span></div>
      <div class="mini"><span class="l">Contas lançadas</span><span class="v">${num(o.contasQtd)} (${esc(brl(o.contasValor))})</span></div>
      <div class="mini"><span class="l">Brogueiras atendidas</span><span class="v">${num(o.brogueiras)}</span></div>
    </div>
    ${dias ? `<div class="dias-lista">${dias}</div>` : '<p class="hint">Sem atividade no período.</p>'}
    ${servicos ? `<div class="tbl-wrap"><table class="tbl">
      <thead><tr><th>Atendeu em</th><th>Brogueira</th><th class="num">Montante</th><th class="num">Contas</th><th>Casamento</th><th>Comprovante</th></tr></thead>
      <tbody>${servicos}</tbody></table></div>`
      : `<p class="hint">${opFiltro === 'validados'
        ? 'Nenhum serviço dele fechou com comprovante no período.'
        : 'Nenhum pedido de Brogueira casado com este Operador no período — só lançamentos soltos.'}</p>`}`;

  // Cada dia do detalhe é um atalho para o filtro de dia da aba.
  $('op-detalhe-corpo').querySelectorAll('.dia-linha').forEach((b) => {
    b.onclick = () => aplicarPeriodo(b.dataset.dia);
  });

  $('op-detalhe').classList.remove('hidden');
  if (!manter) $('op-detalhe').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function fecharDetalheOperador() {
  opAberto = null;
  $('op-detalhe').classList.add('hidden');
}

$('op-fechar').onclick = fecharDetalheOperador;
$('op-reload').onclick = carregarOperadores;
$('op-busca').oninput = (ev) => {
  opBusca = ev.target.value;
  renderTabelaOperadores();
};
document.querySelectorAll('#op-filtro button').forEach((b) => {
  b.onclick = () => {
    opFiltro = b.dataset.filtro;
    document.querySelectorAll('#op-filtro button').forEach((x) => x.classList.toggle('active', x === b));
    // Não vai ao servidor: o relatório do período já traz pegos e validados.
    if (opDados) renderOperadores(opDados);
  };
});

document.querySelectorAll('#op-periodo button').forEach((b) => {
  b.onclick = () => aplicarPeriodo(b.dataset.period);
});

$('op-dia').max = hojeISO();
$('op-dia').onchange = (ev) => {
  const v = ev.target.value;
  // Limpar o campo devolve o recorte para "hoje" — sem período nenhum a aba
  // ficaria sem dado e sem botão aceso.
  aplicarPeriodo(v || 'hoje');
};
$('op-dia-ant').onclick = () => aplicarPeriodo(somarDias(ehDia(opPeriodo) ? opPeriodo : hojeISO(), -1));
$('op-dia-prox').onclick = () => {
  const proximo = somarDias(ehDia(opPeriodo) ? opPeriodo : hojeISO(), 1);
  if (proximo <= hojeISO()) aplicarPeriodo(proximo);
};

/* ═══════════════ Indicações (quem trouxe quem) ═══════════════
   O bot lê as apresentações no grupo ("Vim por @fulana") e conta um ponto
   para quem foi citada. Cada indicada vale uma vez: a repetição fica no
   histórico, fora do ranking. */
let indPeriodo = 'hoje';
let indDados = null;
let indAberta = null; // chave da indicadora com o detalhe aberto

async function carregarIndicacoes() {
  try {
    const r = await api('/indicacoes?period=' + periodoDaAba(indPeriodo) + (qsSessao(filtroSessao) ? '&' + qsSessao(filtroSessao) : ''));
    if (!r.ok) return;
    renderIndicacoes(r);
  } catch {
    /* sem sessão — o login cuida */
  }
}

function renderIndicacoes(d) {
  indDados = d;
  const res = d.resumo || {};
  const ranking = d.ranking || [];

  $('ind-kpi-total').textContent = num(res.indicacoes || 0);
  $('ind-kpi-repetidas').textContent = `${num(res.duplicadas || 0)} repetidas`;
  $('ind-kpi-indicadoras').textContent = num(res.indicadoras || 0);
  $('ind-kpi-lider').textContent = ranking.length
    ? `líder: ${ranking[0].nome} (${num(ranking[0].indicacoes)})`
    : '—';
  $('ind-kpi-indicadas').textContent = num(res.indicadas || 0);
  $('ind-kpi-semmencao').textContent = num(res.semMencao || 0);
  $('ind-kpi-naoident').textContent = `${num(res.naoIdentificadas || 0)} sem nome`;

  // Barra de magnitude: uma hue só, comprimento proporcional ao topo. A cor
  // não muda com a posição — um empate não repinta ninguém.
  const maior = Math.max(1, ...ranking.map((r) => r.indicacoes));
  const tb = document.querySelector('#tbl-ind tbody');
  tb.innerHTML = ranking.map((r, i) => `
    <tr class="ind-row" data-chave="${esc(r.chave)}">
      <td class="num pos">${i + 1}</td>
      <td>${esc(r.nome)}${r.identificada ? '' : '<span class="tag-aviso" title="Ainda não falou no grupo — só o número é conhecido">?</span>'}</td>
      <td class="num">${num(r.indicacoes)}</td>
      <td><span class="plat-barra"><i style="width:${(r.indicacoes / maior) * 100}%"></i></span></td>
      <td class="muted">${esc(dataHora(r.ultimaEm))}</td>
    </tr>`).join('') || '<tr><td colspan="5" class="muted">Nenhuma indicação no período</td></tr>';

  tb.querySelectorAll('.ind-row').forEach((tr) => {
    tr.onclick = () => abrirDetalheIndicadora(tr.dataset.chave);
  });

  $('ind-indicadas').innerHTML = (d.indicadas || []).slice(0, 60).map((x) => `
    <div class="ind-item">
      <span class="ind-nome">${esc(x.nome)}</span>
      <span class="ind-por">por ${esc(x.indicadoraNome)}${x.viaMencao ? '' : ' <span class="tag-aviso" title="Escrito sem menção — confira">?</span>'}</span>
      <span class="ind-quando">${esc(dataHora(x.ts))}</span>
    </div>`).join('') || '<p class="hint">Nenhuma indicada no período.</p>';

  if (indAberta) abrirDetalheIndicadora(indAberta, { manter: true });
}

// Detalhe: quem essa indicadora trouxe, com a frase que registrou cada uma.
function abrirDetalheIndicadora(chave, { manter = false } = {}) {
  const r = (indDados?.ranking || []).find((x) => x.chave === chave);
  if (!r) { fecharDetalheIndicacao(); return; }
  indAberta = chave;
  $('ind-detalhe').classList.remove('hidden');
  const plural = r.indicacoes === 1 ? 'indicação' : 'indicações';
  $('ind-detalhe-nome').textContent = `${r.nome} — ${num(r.indicacoes)} ${plural}`;
  $('ind-detalhe-corpo').innerHTML = `
    <table class="tbl">
      <thead><tr><th>Quando</th><th>Indicada</th><th>Grupo</th><th>Mensagem</th></tr></thead>
      <tbody>${r.indicadas.map((x) => `
        <tr>
          <td>${esc(dataHora(x.ts))}</td>
          <td>${esc(x.nome)}</td>
          <td class="muted">${esc(x.groupName || '—')}</td>
          <td class="pedido-txt">${esc(x.frase)}${x.viaMencao ? '' : '<span class="tag-aviso" title="Sem menção: o nome foi escrito à mão">?</span>'}</td>
        </tr>`).join('')}</tbody>
    </table>`;
  if (!manter) $('ind-detalhe').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
}

function fecharDetalheIndicacao() {
  indAberta = null;
  $('ind-detalhe').classList.add('hidden');
}
$('ind-fechar').onclick = fecharDetalheIndicacao;
$('ind-reload').onclick = carregarIndicacoes;
document.querySelectorAll('#ind-periodo button').forEach((b) => {
  b.onclick = () => {
    indPeriodo = b.dataset.period;
    document.querySelectorAll('#ind-periodo button').forEach((x) => x.classList.toggle('active', x === b));
    fecharDetalheIndicacao();
    carregarIndicacoes();
  };
});

/* ═══════════════ Agendamentos ═══════════════ */

/* ── Relógio (mostrador de 24h, como o do celular) ──────────
   Anel de fora = 1–12, anel de dentro = 13–00. Clicar na hora passa
   automaticamente para os minutos, que é o gesto que as pessoas já conhecem. */
const DIAS_CURTOS = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
const relogio = { h: 9, m: 0, modo: 'h' };
const dd = (n) => String(n).padStart(2, '0');

// Posição no anel (0 = topo, sentido horário) de um valor do modo atual.
function posicaoHora(h) {
  if (h === 0) return { p: 0, interno: true };
  if (h === 12) return { p: 0, interno: false };
  return h > 12 ? { p: h - 12, interno: true } : { p: h, interno: false };
}

function pontoDoAnel(p, raio, total) {
  const ang = (p / total) * 2 * Math.PI - Math.PI / 2; // -90° põe o 0 no topo
  return { x: 120 + raio * Math.cos(ang), y: 120 + raio * Math.sin(ang) };
}

const R_EXTERNO = 94;
const R_INTERNO = 62;

function desenharRelogio() {
  const svg = $('clk-dial');
  if (!svg) return;
  const partes = ['<circle class="clk-face" cx="120" cy="120" r="114"/>'];
  const selecionado = relogio.modo === 'h' ? posicaoHora(relogio.h) : { p: relogio.m / 5, interno: false };
  const raioSel = selecionado.interno ? R_INTERNO : R_EXTERNO;
  const ponta = pontoDoAnel(selecionado.p, raioSel, 12);

  // ponteiro primeiro, para os números ficarem por cima do disco
  partes.push(`<line class="clk-hand" x1="120" y1="120" x2="${ponta.x.toFixed(1)}" y2="${ponta.y.toFixed(1)}"/>`);
  partes.push(`<circle class="clk-knob" cx="${ponta.x.toFixed(1)}" cy="${ponta.y.toFixed(1)}" r="17"/>`);
  partes.push('<circle class="clk-center" cx="120" cy="120" r="3.5"/>');

  const marcado = (v) => (relogio.modo === 'h' ? relogio.h === v : relogio.m === v);

  if (relogio.modo === 'h') {
    for (let p = 0; p < 12; p++) {
      const externo = p === 0 ? 12 : p;
      const interno = p === 0 ? 0 : p + 12;
      const a = pontoDoAnel(p, R_EXTERNO, 12);
      const b = pontoDoAnel(p, R_INTERNO, 12);
      partes.push(`<text class="clk-num${marcado(externo) ? ' sel' : ''}" x="${a.x.toFixed(1)}" y="${a.y.toFixed(1)}">${dd(externo)}</text>`);
      partes.push(`<text class="clk-num inner${marcado(interno) ? ' sel' : ''}" x="${b.x.toFixed(1)}" y="${b.y.toFixed(1)}">${dd(interno)}</text>`);
    }
  } else {
    for (let p = 0; p < 12; p++) {
      const v = p * 5;
      const a = pontoDoAnel(p, R_EXTERNO, 12);
      partes.push(`<text class="clk-num${marcado(v) ? ' sel' : ''}" x="${a.x.toFixed(1)}" y="${a.y.toFixed(1)}">${dd(v)}</text>`);
    }
    // marquinhas de 1 min: mostram que dá para parar fora dos múltiplos de 5
    for (let v = 0; v < 60; v++) {
      if (v % 5 === 0) continue;
      const t = pontoDoAnel(v / 5, R_EXTERNO, 12);
      partes.push(`<circle class="clk-tick" cx="${t.x.toFixed(1)}" cy="${t.y.toFixed(1)}" r="1.4"/>`);
    }
  }

  svg.innerHTML = partes.join('');
  svg.setAttribute('aria-valuetext', `${dd(relogio.h)}:${dd(relogio.m)}`);
  $('clk-h').textContent = dd(relogio.h);
  $('clk-m').textContent = dd(relogio.m);
  $('clk-h').classList.toggle('active', relogio.modo === 'h');
  $('clk-m').classList.toggle('active', relogio.modo === 'm');
}

// Converte a posição do ponteiro (mouse/toque) no valor apontado do mostrador.
function valorNoPonto(ev) {
  const svg = $('clk-dial');
  const r = svg.getBoundingClientRect();
  const x = ((ev.clientX - r.left) / r.width) * 240 - 120;
  const y = ((ev.clientY - r.top) / r.height) * 240 - 120;
  const graus = (Math.atan2(x, -y) * 180) / Math.PI; // 0 = topo, horário
  const ang = (graus + 360) % 360;
  const dist = Math.hypot(x, y);
  if (relogio.modo === 'm') return { m: Math.round(ang / 6) % 60 };
  const p = Math.round(ang / 30) % 12;
  const interno = dist < (R_EXTERNO + R_INTERNO) / 2;
  return { h: interno ? (p === 0 ? 0 : p + 12) : p === 0 ? 12 : p };
}

function aplicarPonto(ev) {
  Object.assign(relogio, valorNoPonto(ev));
  desenharRelogio();
  atualizarResumo();
}

(function ligarRelogio() {
  const svg = $('clk-dial');
  if (!svg) return;
  let arrastando = false;
  svg.addEventListener('pointerdown', (ev) => {
    arrastando = true;
    svg.setPointerCapture(ev.pointerId);
    aplicarPonto(ev);
  });
  svg.addEventListener('pointermove', (ev) => { if (arrastando) aplicarPonto(ev); });
  svg.addEventListener('pointerup', (ev) => {
    arrastando = false;
    svg.releasePointerCapture(ev.pointerId);
    // escolheu a hora → o passo seguinte é sempre o minuto
    if (relogio.modo === 'h') { relogio.modo = 'm'; desenharRelogio(); }
  });
  // Teclado: o mostrador é um alvo pequeno demais para quem não usa mouse.
  svg.addEventListener('keydown', (ev) => {
    const passo = ev.key === 'ArrowUp' || ev.key === 'ArrowRight' ? 1 : ev.key === 'ArrowDown' || ev.key === 'ArrowLeft' ? -1 : 0;
    if (passo) {
      if (relogio.modo === 'h') relogio.h = (relogio.h + passo + 24) % 24;
      else relogio.m = (relogio.m + passo + 60) % 60;
    } else if (ev.key === 'Enter' || ev.key === ' ') {
      relogio.modo = relogio.modo === 'h' ? 'm' : 'h';
    } else return;
    ev.preventDefault();
    desenharRelogio();
    atualizarResumo();
  });
  $('clk-h').onclick = () => { relogio.modo = 'h'; desenharRelogio(); };
  $('clk-m').onclick = () => { relogio.modo = 'm'; desenharRelogio(); };
})();

/* ── Frequência → expressão cron ───────────────────────────── */
let freq = 'dia';
const diasSemana = new Set();

function selecionarFreq(nome) {
  freq = nome;
  document.querySelectorAll('#sch-freq button').forEach((x) => x.classList.toggle('active', x.dataset.freq === nome));
  $('freq-semana').classList.toggle('hidden', nome !== 'semana');
  $('freq-intervalo').classList.toggle('hidden', nome !== 'intervalo');
  atualizarResumo();
}
document.querySelectorAll('#sch-freq button').forEach((b) => { b.onclick = () => selecionarFreq(b.dataset.freq); });

function marcarDias(dias) {
  diasSemana.clear();
  (dias || []).forEach((d) => diasSemana.add(d));
  document.querySelectorAll('#sch-dias button').forEach((b) => b.classList.toggle('active', diasSemana.has(Number(b.dataset.dow))));
}
document.querySelectorAll('#sch-dias button').forEach((b) => {
  b.onclick = () => {
    const d = Number(b.dataset.dow);
    if (diasSemana.has(d)) diasSemana.delete(d); else diasSemana.add(d);
    b.classList.toggle('active', diasSemana.has(d));
    atualizarResumo();
  };
});
$('sch-cada').oninput = atualizarResumo;
$('sch-unidade').onchange = atualizarResumo;
$('sch-cron').oninput = atualizarResumo;

// Devolve { cron, texto } ou { erro } quando falta escolher algo.
function montarAgenda() {
  const manual = $('sch-cron').value.trim();
  if (manual) return { cron: manual, texto: 'Cron manual', manual: true };

  const { h, m } = relogio;
  const hhmm = `${dd(h)}:${dd(m)}`;
  if (freq === 'intervalo') {
    const unidade = $('sch-unidade').value;
    const n = Number($('sch-cada').value);
    const teto = unidade === 'min' ? 59 : 23;
    if (!Number.isInteger(n) || n < 1 || n > teto) return { erro: `intervalo deve ser de 1 a ${teto} ${unidade === 'min' ? 'minutos' : 'horas'}` };
    return unidade === 'min'
      ? { cron: `*/${n} * * * *`, texto: `A cada ${n} minutos` }
      : { cron: `${m} */${n} * * *`, texto: `A cada ${n} horas, no minuto ${dd(m)}` };
  }
  if (freq === 'semana') {
    if (!diasSemana.size) return { erro: 'escolha pelo menos um dia da semana' };
    const dias = [...diasSemana].sort();
    return { cron: `${m} ${h} * * ${dias.join(',')}`, texto: `${dias.map((d) => DIAS_CURTOS[d]).join(', ')} às ${hhmm}` };
  }
  return { cron: `${m} ${h} * * *`, texto: `Todo dia às ${hhmm}` };
}

function atualizarResumo() {
  const a = montarAgenda();
  const el = $('sch-resumo');
  el.classList.toggle('erro', Boolean(a.erro));
  el.innerHTML = a.erro ? esc(a.erro) : `${esc(a.texto)} · <code>${esc(a.cron)}</code>`;
}

// Caminho inverso do montarAgenda(): traduz um cron nos controles do formulário.
// Devolve null quando a expressão não cabe no relógio (aí vai para o campo manual).
function lerCron(expr) {
  const p = String(expr || '').trim().split(/\s+/);
  if (p.length !== 5) return null;
  const [m, h, dom, mes, dow] = p;
  if (dom !== '*' || mes !== '*') return null;
  if (/^\*\/\d+$/.test(m) && h === '*' && dow === '*') return { freq: 'intervalo', unidade: 'min', cada: Number(m.slice(2)), h: 0, m: 0 };
  if (/^\d+$/.test(m) && /^\*\/\d+$/.test(h) && dow === '*') return { freq: 'intervalo', unidade: 'hora', cada: Number(h.slice(2)), h: 0, m: Number(m) };
  if (!/^\d+$/.test(m) || !/^\d+$/.test(h)) return null;
  if (Number(h) > 23 || Number(m) > 59) return null;
  if (dow === '*') return { freq: 'dia', h: Number(h), m: Number(m) };
  if (/^[0-6](,[0-6])*$/.test(dow)) return { freq: 'semana', h: Number(h), m: Number(m), dias: dow.split(',').map(Number) };
  return null;
}

// Lê uma expressão cron de volta para uma frase (usado na tabela).
function descreverCron(expr) {
  const [m, h, , , dow] = String(expr || '').trim().split(/\s+/);
  if (!m || !h) return expr;
  if (m.startsWith('*/')) return `A cada ${m.slice(2)} min`;
  if (h.startsWith('*/')) return `A cada ${h.slice(2)}h, min ${m}`;
  if (!/^\d+$/.test(m) || !/^\d+$/.test(h)) return expr;
  const hhmm = `${dd(h)}:${dd(m)}`;
  if (dow && dow !== '*') {
    const nomes = dow.split(',').map((d) => DIAS_CURTOS[Number(d) % 7] ?? d);
    return `${nomes.join(', ')} às ${hhmm}`;
  }
  return `Todo dia às ${hhmm}`;
}

/* ── Imagem do agendamento ─────────────────────────────────── */
const MAX_IMG = 5 * 1024 * 1024;

$('sch-img').onchange = () => {
  const f = $('sch-img').files[0];
  if (!f) return limparImagem();
  if (f.size > MAX_IMG) {
    limparImagem();
    return aviso('sch-res', 'imagem acima de 5 MB', true);
  }
  $('sch-img-thumb').src = URL.createObjectURL(f);
  $('sch-img-nome').textContent = `${f.name} · ${(f.size / 1024).toFixed(0)} KB`;
  $('sch-img-prev').classList.remove('hidden');
};
function limparImagem() {
  $('sch-img').value = '';
  const thumb = $('sch-img-thumb');
  if (thumb.src.startsWith('blob:')) URL.revokeObjectURL(thumb.src);
  thumb.removeAttribute('src');
  $('sch-img-prev').classList.add('hidden');
}
$('sch-img-clear').onclick = () => {
  // Editando, "Remover" tem de chegar ao servidor: sem o aviso, não mandar
  // arquivo nenhum significaria "mantém a que já está lá".
  if (editando && midiaExistente) imagemRemovida = true;
  limparImagem();
};

/* ── Destino: só os grupos monitorados ─────────────────────── */
// Um agendamento vai para um grupo que o bot acompanha — é lá que a mensagem
// tem sentido. Digitar o JID à mão era fácil de errar (e não dava erro visível).
const nomesGrupos = new Map();

// Exportada (declaração de função = global) para os testes conseguirem semear nomes.
function definirNomesGrupos(grupos) {
  for (const g of grupos || []) nomesGrupos.set(g.id, g.nome);
}

// Quais grupos contam como monitorados, conforme a configuração do bot.
function gruposMonitorados(grupos, config) {
  const lista = grupos || [];
  if (config?.monitorMode === 'all') return lista;
  if (config?.monitorMode === 'specific') {
    const marcados = config.monitoredGroups || [];
    return lista.filter((g) => marcados.includes(g.id));
  }
  return [];
}

let tentativasDestinos = 0;

// O destino é sempre um grupo que o NÚMERO ESCOLHIDO monitora: é a conta dele
// que vai enviar, e ela só alcança os grupos de que participa.
async function carregarDestinos() {
  const sel = $('sch-to');
  const hint = $('sch-to-hint');
  const anterior = sel.value;
  const sessaoId = $('sch-sessao')?.value || 'n1';
  // A aba pode abrir antes do primeiro snapshot; sem a config não dá para saber
  // quais grupos são monitorados — espera um pouco em vez de dizer "nenhum".
  if (!configDe(sessaoId) && tentativasDestinos < 5) {
    tentativasDestinos++;
    sel.innerHTML = '<option value="">carregando…</option>';
    setTimeout(carregarDestinos, 700);
    return;
  }
  tentativasDestinos = 0;
  const cfg = configDe(sessaoId);
  try {
    const r = await api('/groups?' + qsSessao(sessaoId));
    definirNomesGrupos(r.groups);
    const monitorados = gruposMonitorados(r.groups, cfg);
    if (!monitorados.length) {
      sel.innerHTML = '<option value="">nenhum grupo monitorado</option>';
      hint.innerHTML = cfg?.monitorMode === 'none'
        ? `O monitoramento de <b>${esc(nomeSessao(sessaoId))}</b> está <b>desligado</b>. Ligue em <b>Configurações</b> para poder agendar.`
        : `Nenhum grupo monitorado por <b>${esc(nomeSessao(sessaoId))}</b> — marque os grupos na aba <b>Grupos</b>.`;
      return;
    }
    sel.innerHTML = monitorados.map((g) => `<option value="${esc(g.id)}">${esc(g.nome)}</option>`).join('');
    if (anterior && monitorados.some((g) => g.id === anterior)) sel.value = anterior;
    hint.innerHTML = `Grupos monitorados por <b>${esc(nomeSessao(sessaoId))}</b>. A seleção sai da aba <b>Grupos</b>.`;
  } catch {
    sel.innerHTML = '<option value="">conecte este número para listar</option>';
    hint.innerHTML = `<b>${esc(nomeSessao(sessaoId))}</b> não está conectado — não dá para listar os grupos dele agora.`;
  }
}

/* ── Edição ────────────────────────────────────────────────── */
// O mesmo formulário cria e edita: dois formulários iguais lado a lado seriam
// duas cópias da mesma validação (e do mesmo relógio) para manter em sincronia.
let editando = null; // id do agendamento em edição, ou null
let midiaExistente = false; // o agendamento em edição já tinha imagem salva
let imagemRemovida = false; // marcou "remover" nessa imagem

function entrarModoEdicao(s) {
  editando = s.id;
  imagemRemovida = false;
  midiaExistente = Boolean(s.media);
  $('sch-titulo').textContent = 'Editando: ' + s.name;
  $('sch-add').textContent = 'Salvar alterações';
  $('sch-cancel').classList.remove('hidden');
  $('sch-name').value = s.name === 'sem nome' ? '' : s.name;
  $('sch-msg').value = s.message || '';
  $('sch-mention').checked = Boolean(s.mentionAll);
  if ($('sch-sessao')) $('sch-sessao').value = s.sessaoId || 'n1';

  // O destino pode ser um grupo que não é mais monitorado — mantém a opção
  // para a edição não trocar o destino sem o usuário pedir.
  const sel = $('sch-to');
  if (![...sel.options].some((o) => o.value === s.to)) {
    sel.insertAdjacentHTML('afterbegin', `<option value="${esc(s.to)}">${esc(nomesGrupos.get(s.to) || s.to)} (fora do monitoramento)</option>`);
  }
  sel.value = s.to;

  const lido = lerCron(s.cron);
  $('sch-cron').value = lido ? '' : s.cron; // não coube no relógio → campo manual
  if (lido) {
    relogio.h = lido.h;
    relogio.m = lido.m;
    relogio.modo = 'h';
    if (lido.freq === 'intervalo') {
      $('sch-cada').value = lido.cada;
      $('sch-unidade').value = lido.unidade;
    }
    marcarDias(lido.dias);
    selecionarFreq(lido.freq);
    desenharRelogio();
  } else {
    document.querySelector('.avancado').open = true;
    atualizarResumo();
  }

  limparImagem();
  if (s.media) {
    $('sch-img-nome').textContent = s.media.nome + ' (já salva)';
    $('sch-img-prev').classList.remove('hidden');
    carregarMiniatura(s.id, $('sch-img-thumb'));
  }
  document.querySelector('#tab-agendar .card:last-child').scrollIntoView({ behavior: 'smooth', block: 'nearest' });
  aviso('sch-res', '', false);
}

function sairModoEdicao() {
  editando = null;
  imagemRemovida = false;
  midiaExistente = false;
  $('sch-titulo').textContent = 'Novo agendamento';
  $('sch-add').textContent = 'Agendar';
  $('sch-cancel').classList.add('hidden');
  $('sch-name').value = '';
  $('sch-msg').value = '';
  $('sch-cron').value = '';
  $('sch-mention').checked = false;
  limparImagem();
  carregarDestinos(); // repõe a lista sem a opção "fora do monitoramento"
  atualizarResumo();
}
$('sch-cancel').onclick = sairModoEdicao;
if ($('sch-sessao')) $('sch-sessao').onchange = () => carregarDestinos();

/* ── Tabela ────────────────────────────────────────────────── */
// As miniaturas exigem o token no cabeçalho, então vêm por fetch → blob.
// O cache evita refazer o download a cada snapshot do Socket.IO.
const miniaturas = new Map();

async function carregarMiniatura(id, img) {
  if (miniaturas.has(id)) { img.src = miniaturas.get(id); return; }
  try {
    const res = await fetch(`/api/schedules/${id}/media`, { headers: { Authorization: 'Bearer ' + TOKEN } });
    if (!res.ok) return;
    const url = URL.createObjectURL(await res.blob());
    miniaturas.set(id, url);
    img.src = url;
  } catch {
    /* sem miniatura — a linha continua legível */
  }
}

function renderSchedules(lista) {
  const tb = document.querySelector('#tbl-sch tbody');
  tb.innerHTML = lista.map((s) => `
    <tr>
      <td><span class="sch-nome">${s.media ? `<img class="sch-thumb" data-sch="${esc(s.id)}" alt=""/>` : ''}${esc(s.name)}${
        s.mentionAll ? '<span class="tag-todos" title="Marca todos do grupo">@todos</span>' : ''}${
        s.lastError ? `<span class="sch-erro" title="${esc(s.lastError.erro)}">⚠</span>` : ''}</span></td>
      <td class="sch-num">${esc(nomeSessao(s.sessaoId || 'n1'))}</td>
      <td class="sch-quando">${esc(descreverCron(s.cron))}<br><code>${esc(s.cron)}</code></td>
      <td>${esc(nomesGrupos.get(s.to) || s.to)}</td>
      <td><input type="checkbox" data-id="${esc(s.id)}" class="sch-toggle" ${s.enabled ? 'checked' : ''} aria-label="Ativar"/></td>
      <td class="acoes">
        <button class="btn-ghost sch-edit" data-id="${esc(s.id)}" aria-label="Editar" title="Editar">✎</button>
        <button class="btn-ghost sch-del" data-id="${esc(s.id)}" aria-label="Remover" title="Remover">✕</button>
      </td>
    </tr>`).join('') || '<tr><td colspan="6" class="muted">Nenhum agendamento</td></tr>';

  tb.querySelectorAll('.sch-edit').forEach((b) => {
    b.onclick = () => {
      const s = (lista || []).find((x) => x.id === b.dataset.id);
      if (s) entrarModoEdicao(s);
    };
  });
  tb.querySelectorAll('.sch-del').forEach((b) => {
    b.onclick = () => {
      if (!confirm('Remover este agendamento? A imagem anexada também é apagada.')) return;
      miniaturas.delete(b.dataset.id);
      if (editando === b.dataset.id) sairModoEdicao(); // não deixa o formulário editando um fantasma
      api('/schedules/' + b.dataset.id, { method: 'DELETE' });
    };
  });
  tb.querySelectorAll('.sch-toggle').forEach((c) => {
    c.onchange = () => api('/schedules/' + c.dataset.id, { method: 'PATCH', body: JSON.stringify({ enabled: c.checked }) });
  });
  tb.querySelectorAll('.sch-thumb').forEach((img) => carregarMiniatura(img.dataset.sch, img));
}

$('sch-add').onclick = async () => {
  const agenda = montarAgenda();
  if (agenda.erro) return aviso('sch-res', agenda.erro, true);
  const destino = $('sch-to').value;
  if (!destino) return aviso('sch-res', 'escolha o grupo de destino', true);
  if ($('sch-mention').checked && !destino.endsWith('@g.us')) {
    return aviso('sch-res', '"marcar todos" só funciona em grupo', true);
  }
  const imagem = $('sch-img').files[0] || null;
  // Na edição a imagem já salva conta como conteúdo, a não ser que esteja sendo removida.
  const temImagem = Boolean(imagem) || (midiaExistente && !imagemRemovida);
  if (!$('sch-msg').value.trim() && !temImagem) return aviso('sch-res', 'escreva a mensagem ou anexe uma imagem', true);

  // multipart sempre: o multer no servidor lê os campos de texto do mesmo jeito
  const fd = new FormData();
  fd.append('name', $('sch-name').value);
  fd.append('sessaoId', $('sch-sessao').value);
  fd.append('cron', agenda.cron);
  fd.append('to', destino);
  fd.append('message', $('sch-msg').value);
  fd.append('mentionAll', $('sch-mention').checked ? 'true' : 'false');
  if (imagem) fd.append('image', imagem);
  if (editando && imagemRemovida && !imagem) fd.append('removerImagem', 'true');

  const alvo = editando ? `/api/schedules/${editando}` : '/api/schedules';
  const metodo = editando ? 'PUT' : 'POST';
  $('sch-add').disabled = true;
  try {
    const res = await fetch(alvo, { method: metodo, headers: { Authorization: 'Bearer ' + TOKEN }, body: fd });
    const r = await res.json();
    aviso('sch-res', r.ok ? (editando ? 'Salvo ✓' : 'Agendado ✓') : `erro: ${r.error}`, !r.ok);
    if (r.ok) {
      miniaturas.delete(r.schedule.id); // a imagem pode ter mudado
      // Mostra na lista já — o snapshot do Socket.IO chega logo atrás e confirma.
      if (snap) {
        const outros = (snap.schedules || []).filter((x) => x.id !== r.schedule.id);
        snap.schedules = [...outros, r.schedule];
        renderSchedules(snap.schedules);
      }
      sairModoEdicao();
    }
  } catch (err) {
    aviso('sch-res', `erro: ${err.message}`, true);
  } finally {
    $('sch-add').disabled = false;
  }
};

desenharRelogio();
atualizarResumo();

/* ═══════════════ Navegação ═══════════════ */
const TITULOS = {
  painel: 'Painel', relatorios: 'Relatórios por usuário',
  brogueiras: 'Brogueiras', operadores: 'Operadores', indicacoes: 'Indicações',
  config: 'Configurações', grupos: 'Grupos', enviar: 'Enviar', agendar: 'Agendamentos',
  numeros: 'Números',
};

function abrirAba(nome) {
  document.querySelectorAll('.nav-item').forEach((b) => b.classList.toggle('active', b.dataset.tab === nome));
  document.querySelectorAll('.content').forEach((s) => s.classList.toggle('hidden', s.id !== 'tab-' + nome));
  $('page-title').textContent = TITULOS[nome] || 'Painel';
  if (nome === 'numeros') { carregarCatalogoRecursos().then(renderNumeros); }
  if (nome === 'grupos') carregarGrupos();
  if (nome === 'config') { carregarBackups(); trocarSessaoConfig(cfgSessao); }
  if (nome === 'agendar') carregarDestinos();
  if (nome === 'relatorios') carregarRelatorios();
  if (nome === 'brogueiras') { carregarBrogueiras(); carregarGruposBrogueiras(); }
  if (nome === 'operadores') carregarOperadores();
  if (nome === 'indicacoes') carregarIndicacoes();
}
document.querySelectorAll('.nav-item').forEach((b) => { b.onclick = () => abrirAba(b.dataset.tab); });
document.querySelectorAll('[data-goto]').forEach((b) => { b.onclick = () => abrirAba(b.dataset.goto); });

// Seletores de número das abas Configurações e Grupos.
if ($('cfg-sessao')) $('cfg-sessao').onchange = (ev) => trocarSessaoConfig(ev.target.value);
if ($('grp-sessao')) {
  $('grp-sessao').onchange = (ev) => {
    grpSessao = ev.target.value;
    localStorage.setItem('ws_grp_sessao', grpSessao);
    carregarGrupos();
  };
}

/* ═══════════════ Temas ═══════════════
   Cinco paletas, todas escritas nos MESMOS tokens do style.css — nenhum
   componente conhece cor fixa, então trocar o `data-theme` do <html> recolore
   o painel inteiro, gráficos incluídos (por isso o lerCores + redesenho).
   As amostras de cada item são as cores que o tema realmente usa: superfície,
   acento, série 1 e o vermelho de status. */
const TEMAS = [
  { id: 'dark', nome: 'Escuro (padrão)', amostras: ['#0A0F16', '#3987e5', '#199e70', '#d03b3b'] },
  { id: 'light', nome: 'Claro', amostras: ['#F1F4F8', '#2a78d6', '#1baf7a', '#d03b3b'] },
  { id: 'noir', nome: 'Preto & Dourado', amostras: ['#0d0d0d', '#1e40af', '#e0b34a', '#dc2626'] },
  { id: 'dourado', nome: 'Branco & Dourado', amostras: ['#ffffff', '#e0b34a', '#0d0d0d', '#dc2626'] },
  { id: 'azul', nome: 'Azul & Vermelho', amostras: ['#0b1d4a', '#3b82f6', '#ef4444', '#ffffff'] },
];

const temaValido = (id) => (TEMAS.some((t) => t.id === id) ? id : 'dark');

function aplicarTema(tema) {
  const escolhido = temaValido(tema);
  document.documentElement.dataset.theme = escolhido;
  localStorage.setItem('ws_theme', escolhido);
  marcarTemaAtivo(escolhido);
  lerCores();
  if (snap) renderSnapshot(snap); // redesenha os SVGs com as cores do tema novo
}

function marcarTemaAtivo(id) {
  document.querySelectorAll('#tema-menu .tema-item').forEach((b) => {
    b.setAttribute('aria-checked', String(b.dataset.tema === id));
  });
}

function montarMenuTemas() {
  const menu = $('tema-menu');
  if (!menu) return;
  menu.innerHTML = TEMAS.map((t) => `
    <button class="tema-item" role="menuitemradio" aria-checked="false" data-tema="${t.id}">
      <span class="tema-amostras">${t.amostras.map((c) => `<i style="background:${c}"></i>`).join('')}</span>
      <span class="nome">${t.nome}</span>
      <svg class="check" viewBox="0 0 24 24"><use href="#i-tick"/></svg>
    </button>`).join('');
  menu.querySelectorAll('.tema-item').forEach((b) => {
    b.onclick = () => { aplicarTema(b.dataset.tema); fecharMenuTemas(); };
  });
}

function fecharMenuTemas() {
  $('tema-menu')?.classList.add('hidden');
  $('theme-btn')?.setAttribute('aria-expanded', 'false');
}

montarMenuTemas();
$('theme-btn').onclick = (ev) => {
  ev.stopPropagation();
  const menu = $('tema-menu');
  const abrindo = menu.classList.contains('hidden');
  menu.classList.toggle('hidden', !abrindo);
  $('theme-btn').setAttribute('aria-expanded', String(abrindo));
};
document.addEventListener('click', (ev) => {
  if (!ev.target.closest('.tema-wrap')) fecharMenuTemas();
});
document.addEventListener('keydown', (ev) => { if (ev.key === 'Escape') fecharMenuTemas(); });

aplicarTema(localStorage.getItem('ws_theme') || 'dark');
lerCores();

if (TOKEN) {
  retomarSessao(TOKEN).catch(() => {
    localStorage.removeItem('ws_token');
    localStorage.removeItem('ws_role');
  });
}
