"""Login, logout, sessao e troca de senha."""
from __future__ import annotations

import datetime as dt
import time

from fastapi import APIRouter, Depends, HTTPException, Request, Response
from pydantic import BaseModel, Field

from .. import db
from ..config import settings
from ..deps import admin_user, client_ip, current_user
from ..security import COOKIE_NAME, create_token, hash_password, needs_rehash, verify_password

router = APIRouter(prefix="/api/auth", tags=["auth"])

_attempts: dict[str, list[float]] = {}


def _rate_limited(ip: str) -> bool:
    now = time.time()
    hits = [t for t in _attempts.get(ip, []) if now - t < 60]
    hits.append(now)
    _attempts[ip] = hits
    return len(hits) > settings.rate_login_per_min


class LoginReq(BaseModel):
    username: str = Field(min_length=1, max_length=64)
    password: str = Field(min_length=1, max_length=256)


class PasswordReq(BaseModel):
    current_password: str
    new_password: str = Field(min_length=10, max_length=256)


@router.post("/login")
async def login(body: LoginReq, request: Request, response: Response):
    ip = client_ip(request)
    if _rate_limited(ip):
        raise HTTPException(status_code=429, detail="muitas tentativas, aguarde um minuto")

    row = await db.fetch_one("SELECT * FROM users WHERE username=?", (body.username,))
    if not row or not row["is_active"]:
        await db.audit("login", username=body.username, ip=ip, ok=False, detail="usuario inexistente/inativo")
        raise HTTPException(status_code=401, detail="usuario ou senha invalidos")

    if row["locked_until"]:
        locked = dt.datetime.fromisoformat(row["locked_until"])
        if locked > dt.datetime.now(dt.timezone.utc).replace(tzinfo=None):
            raise HTTPException(status_code=423, detail=f"conta bloqueada ate {row['locked_until']} UTC")

    if not verify_password(body.password, row["password_hash"]):
        fails = int(row["failed_logins"]) + 1
        locked_until = None
        if fails >= settings.max_failed_logins:
            locked_until = (dt.datetime.utcnow() + dt.timedelta(minutes=settings.lockout_minutes)).isoformat(" ", "seconds")
            fails = 0
        await db.execute("UPDATE users SET failed_logins=?, locked_until=? WHERE id=?",
                         (fails, locked_until, row["id"]))
        await db.audit("login", username=body.username, ip=ip, ok=False, detail="senha incorreta")
        raise HTTPException(status_code=401, detail="usuario ou senha invalidos")

    if needs_rehash(row["password_hash"]):
        await db.execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(body.password), row["id"]))

    await db.execute("UPDATE users SET failed_logins=0, locked_until=NULL, last_login=datetime('now') WHERE id=?",
                     (row["id"],))
    token = create_token(row["username"], row["role"])
    response.set_cookie(
        COOKIE_NAME, token, httponly=True, secure=True, samesite="lax",
        max_age=settings.access_ttl_min * 60, path="/",
    )
    await db.audit("login", username=row["username"], ip=ip, ok=True)
    return {"ok": True, "username": row["username"], "role": row["role"], "token": token}


@router.post("/logout")
async def logout(request: Request, response: Response, user: dict = Depends(current_user)):
    response.delete_cookie(COOKIE_NAME, path="/")
    await db.audit("logout", username=user["username"], ip=client_ip(request))
    return {"ok": True}


@router.get("/me")
async def me(user: dict = Depends(current_user)):
    row = await db.fetch_one("SELECT username, role, last_login, created_at FROM users WHERE username=?",
                             (user["username"],))
    return row or user


@router.post("/password")
async def change_password(body: PasswordReq, request: Request, user: dict = Depends(admin_user)):
    row = await db.fetch_one("SELECT * FROM users WHERE username=?", (user["username"],))
    if not row or not verify_password(body.current_password, row["password_hash"]):
        await db.audit("password_change", username=user["username"], ip=client_ip(request), ok=False)
        raise HTTPException(status_code=403, detail="senha atual incorreta")
    await db.execute("UPDATE users SET password_hash=? WHERE id=?", (hash_password(body.new_password), row["id"]))
    await db.audit("password_change", username=user["username"], ip=client_ip(request), ok=True)
    return {"ok": True}


@router.get("/audit")
async def audit_log(limit: int = 100, user: dict = Depends(admin_user)):
    limit = max(1, min(limit, 500))
    return await db.fetch_all("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))
