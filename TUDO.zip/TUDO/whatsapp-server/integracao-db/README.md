# Integração: Whatsap Server → DB Dashboard

O bot **empurra** os dados para o site (https://dbdashboard-o.lovable.app).
O site nunca puxa — o painel do bot está atrás de um certificado autoassinado
num IP puro, e uma edge function do Supabase recusaria essa conexão.

```
  Whatsap Server                         Supabase do DB Dashboard
  ──────────────                         ────────────────────────
  a cada 5 min (só o que mudou)
  POST  x-db-secret: ••••      ────────▶  edge function ingest-whatsapp
        { operadores[], servicos[] }              │ upsert
                                                  ▼
                                         wa_operadores_dia   wa_servicos
                                                  │
                                                  ▼
                                          Dashboard / Relatórios / Tabelas
```

## O que é enviado

| Tabela | Uma linha por | Serve para |
|--------|---------------|------------|
| `wa_operadores_dia` | Operador × dia | ranking, KPIs, evolução diária |
| `wa_servicos` | serviço (os 3 passos) | funil, auditoria, relatório detalhado |

O envio é **incremental**: só vai o serviço cujo estado mudou (abriu, foi
atendido, validou, expirou) e o dia cujo ranking mudou. E é **idempotente**:
a chave é `(dia, operador_id)` e o `id` do serviço, então reenviar o mesmo lote
atualiza em vez de duplicar — é isso que deixa a retentativa ser segura.

Nada é marcado como enviado antes da resposta OK: se o site cair, o próximo
ciclo manda tudo de novo, com espera crescente (1, 2, 4, 8, 16, 30 min).

## Passo a passo (lado do site)

1. **Tabelas** — rode `01-schema.sql` no SQL Editor do Supabase do projeto.
   Cria as duas tabelas, os índices, RLS (leitura para quem está logado; escrita
   só pela `service_role`) e duas views de conveniência (`wa_ranking_hoje`,
   `wa_totais_dia`).
2. **Função** — publique `02-ingest-whatsapp.ts` como a edge function
   `ingest-whatsapp`:
   ```bash
   supabase functions deploy ingest-whatsapp --no-verify-jwt
   supabase secrets set WHATSAPP_INGEST_SECRET='<escolha um segredo longo>'
   ```
   `--no-verify-jwt` porque quem chama é um servidor, não um usuário logado: a
   autorização é o segredo compartilhado, conferido em tempo constante.
3. **Bot** — no painel, aba **Configurações** → *Exportar para o DB Dashboard*:
   - URL: `https://<projeto>.supabase.co/functions/v1/ingest-whatsapp`
   - Segredo: o mesmo do passo 2
   - Intervalo: 5 min · marque **Ligar a exportação automática** · **Salvar**
   - **Testar conexão** → manda um lote vazio marcado como `teste`, que a função
     responde sem gravar nada. Depois, **Sincronizar agora** para o 1º envio.

Se a função for publicada **com** verificação de JWT, preencha também o campo
*Chave anon do Supabase* no painel — o bot passa a mandar `apikey` e
`Authorization: Bearer`.

## Conferindo do lado de lá

```sql
select * from public.wa_totais_dia limit 7;
select * from public.wa_ranking_hoje;
select status, count(*) from public.wa_servicos group by status;  -- o funil
```

## Segurança

- O segredo viaja no cabeçalho `x-db-secret`, e o painel do bot **recusa URL que
  não seja HTTPS** — em HTTP ele iria em claro.
- O segredo e a chave anon **não saem** do servidor do bot: nem o snapshot do
  Socket.IO nem `GET /api/config` os devolvem (só um `…Set: true`).
- A `service_role` fica só dentro da edge function; o bot nunca a conhece.
