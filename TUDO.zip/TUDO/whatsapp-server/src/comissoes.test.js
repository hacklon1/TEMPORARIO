// Comissão cobrada dos Operadores: a base é o `Valor` da mensagem que ele
// manda para a Brogueira (o salário dele), e só conta quando o serviço fecha
// os 3 passos. Um erro aqui cobra dinheiro que não existe — ou deixa de cobrar.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-comissoes-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb, saveDb } = await import('./db.js');
const { STATUS } = await import('./servicos.js');
const c = await import('./comissoes.js');
const { extractContas, extractSalario } = await import('./parser.js');
const { dayKey } = await import('./store.js');
const { salvarMetas } = await import('./operacoes.js');

loadDb();

const MENSAGEM_DO_OPERADOR = `━━━━━━━━━━━━━━━

🔸 Montante: 500
💸 Valor: R$ 100,00

📊 Até 1 conta

━━━━━━━━━━━━━━━

⚡ Envio após confirmação do pagamento

📩 Envie o comprovante para dar continuidade`;

function servico({ id, dia, operador, nome, valor, montante = 0, status = STATUS.VALIDADO }) {
  return {
    id, day: dia, ts: `${dia}T15:00:00.000Z`, status, sessaoId: 'n1',
    brogueiraNome: 'Brogueira', tipo: 'montante', montantePedido: 500,
    atendimento: {
      operatorId: operador, operatorPn: `${operador}@s.whatsapp.net`, operatorName: nome,
      montante, contasQtd: 1, contasTotal: valor, ts: `${dia}T15:01:00.000Z`,
    },
  };
}

function base(servicos) {
  const db = getDb();
  db.servicos = servicos;
  db.comissoesCobradas = [];
  db.comissoesConfig = { padraoPct: 0, porOperador: {} };
  saveDb();
}

/* ═══════════ A base do cálculo ═══════════ */

test('o salário é o "Valor" da mensagem do Operador — o mesmo que o parser separa', () => {
  // O parser lê R$ 100,00 como o valor das contas; é ele que vira o salário.
  assert.equal(extractContas(MENSAGEM_DO_OPERADOR).total, 100);
  assert.equal(c.salarioDoServico({ atendimento: { contasTotal: 100 } }), 100);
  assert.equal(c.salarioDoServico({ atendimento: {} }), 0);
});

/* O bug de 31/08/2026: `salarioDoServico` lia `contasTotal`, que só existe
   quando a mensagem traz a palavra "Valor". No template mais usado do grupo o
   preço vem solto ("💸 R$ 20"), e 167 dos 315 serviços do histórico ficaram
   com salário 0 — o Operador pegava montante e a comissão não somava nada. */
test('o salário vem do campo próprio, não das contas — o template sem "Valor" cobra', () => {
  const semRotulo = '🔸 Montante: 100\n💸 R$ 20,00\n📊 Até 1 conta';
  // O parser separa as duas medidas: não é conta, mas é salário.
  assert.equal(extractContas(semRotulo).total, 0);
  assert.equal(extractSalario(semRotulo), 20);

  // E a comissão lê o campo certo.
  assert.equal(c.salarioDoServico({ atendimento: { salario: 20, contasTotal: 0 } }), 20);
  // Registro antigo (anterior ao campo) ainda cai em contasTotal.
  assert.equal(c.salarioDoServico({ atendimento: { contasTotal: 100 } }), 100);
});

test('só serviço validado é cobrável', () => {
  assert.equal(c.cobravel(servico({ id: 's1', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100 })), true);
  assert.equal(c.cobravel(servico({ id: 's2', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100, status: STATUS.AGUARDANDO_COMPROVANTE })), false);
  assert.equal(c.cobravel({ status: 'validado' }), false, 'sem atendimento não há salário');
});

/* ═══════════ Porcentagem ═══════════ */

test('a porcentagem é por Operador, com um padrão da casa', () => {
  base([]);
  assert.equal(c.pctDoOperador('op1'), 0, 'nasce sem cobrar nada');
  c.definirPct({ pct: 10 });                    // padrão da casa
  assert.equal(c.pctDoOperador('op1'), 10);
  c.definirPct({ operadorId: 'op1', pct: 15 }); // regra própria vence o padrão
  assert.equal(c.pctDoOperador('op1'), 15);
  assert.equal(c.pctDoOperador('op2'), 10);
  c.limparPct('op1');
  assert.equal(c.pctDoOperador('op1'), 10, 'sem regra própria, volta ao padrão');
  // Fora da faixa é aparado: ninguém cobra 300%.
  c.definirPct({ operadorId: 'op1', pct: 300 });
  assert.equal(c.pctDoOperador('op1'), 100);
  c.definirPct({ operadorId: 'op1', pct: -5 });
  assert.equal(c.pctDoOperador('op1'), 0);
});

test('15% de um salário de 100 cobra 15 — e o não validado não entra', () => {
  base([
    servico({ id: 's1', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100 }),
    servico({ id: 's2', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 40 }),
    servico({ id: 's3', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 999, status: STATUS.AGUARDANDO_COMPROVANTE }),
  ]);
  c.definirPct({ operadorId: 'op1', pct: 15 });

  const r = c.comissoesOperadores({});
  const ana = r.operadores[0];
  assert.equal(ana.servicos, 2);
  assert.equal(ana.salario, 140, 'só os validados somam');
  assert.equal(ana.pct, 15);
  assert.equal(ana.comissao, 21, '15% de 140');
  assert.equal(r.resumo.comissao, 21);
});

test('cada Operador é cobrado pela sua própria porcentagem', () => {
  base([
    servico({ id: 's1', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100 }),
    servico({ id: 's2', dia: '2026-08-20', operador: 'op2', nome: 'Bia', valor: 100 }),
  ]);
  c.definirPct({ operadorId: 'op1', pct: 15 });
  c.definirPct({ operadorId: 'op2', pct: 5 });

  const { operadores, resumo } = c.comissoesOperadores({});
  assert.equal(operadores.find((o) => o.nome === 'Ana').comissao, 15);
  assert.equal(operadores.find((o) => o.nome === 'Bia').comissao, 5);
  assert.equal(resumo.comissao, 20);
  assert.equal(operadores[0].nome, 'Ana', 'ordenado pela comissão devida');
});

test('o período recorta pelo dia do serviço', () => {
  base([
    servico({ id: 's1', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100 }),
    servico({ id: 's2', dia: '2026-08-25', operador: 'op1', nome: 'Ana', valor: 200 }),
  ]);
  c.definirPct({ operadorId: 'op1', pct: 10 });
  assert.equal(c.comissoesOperadores({ de: '2026-08-20', ate: '2026-08-20' }).resumo.comissao, 10);
  assert.equal(c.comissoesOperadores({ de: '2026-08-21', ate: '2026-08-31' }).resumo.comissao, 20);
  assert.equal(c.comissoesOperadores({}).resumo.comissao, 30, 'sem filtro, tudo');
});

/* ═══════════ Cobrança ═══════════ */

test('cobrar guarda a lista de serviços e não cobra a mesma validação duas vezes', () => {
  base([
    servico({ id: 's1', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100 }),
    servico({ id: 's2', dia: '2026-08-20', operador: 'op2', nome: 'Bia', valor: 60 }),
  ]);
  c.definirPct({ pct: 10 });

  const r = c.cobrar({ por: 'admin' });
  assert.equal(r.cobrancas.length, 2, 'uma cobrança por Operador');
  assert.equal(r.servicos, 2);
  assert.equal(r.total, 16, '10% de 160');

  const depois = c.comissoesOperadores({});
  assert.equal(depois.resumo.comissao, 0, 'nada em aberto depois de cobrar');
  assert.equal(depois.resumo.comissaoCobrada, 16, 'mas o histórico do período mostra o cobrado');
  assert.equal(depois.resumo.comissaoTotal, 16, 'o total do período não muda por ter sido cobrado');
  assert.equal(depois.resumo.salarioTotal, 160);
  assert.equal(c.cobrar({}).servicos, 0, 'cobrar de novo não pega nada');
});

test('cobrar de um Operador só não mexe nos outros', () => {
  base([
    servico({ id: 's1', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100 }),
    servico({ id: 's2', dia: '2026-08-20', operador: 'op2', nome: 'Bia', valor: 100 }),
  ]);
  c.definirPct({ pct: 20 });
  c.cobrar({ operadorId: 'op1' });
  const r = c.comissoesOperadores({});
  assert.equal(r.operadores.find((o) => o.nome === 'Ana').comissao, 0);
  assert.equal(r.operadores.find((o) => o.nome === 'Bia').comissao, 20);
});

test('a cobrança guarda a porcentagem do dia — mudar depois não reescreve o passado', () => {
  base([servico({ id: 's1', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100 })]);
  c.definirPct({ operadorId: 'op1', pct: 15 });
  const { cobrancas } = c.cobrar({});
  c.definirPct({ operadorId: 'op1', pct: 50 });
  assert.equal(c.listarCobrancas()[0].pct, 15);
  assert.equal(c.listarCobrancas()[0].valor, 15);
  assert.equal(cobrancas[0].servicoIds.length, 1);
  // E a coluna "já cobrado" continua mostrando os 15 que saíram, não 50.
  assert.equal(c.comissoesOperadores({}).operadores[0].comissaoCobrada, 15);
  assert.equal(c.comissoesOperadores({}).resumo.comissaoCobrada, 15);
  // Zerar a porcentagem também não apaga o que já foi cobrado.
  c.definirPct({ operadorId: 'op1', pct: 0 });
  assert.equal(c.comissoesOperadores({}).operadores[0].comissaoCobrada, 15);
});

test('desfazer devolve os serviços para "em aberto"', () => {
  base([servico({ id: 's1', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100 })]);
  c.definirPct({ operadorId: 'op1', pct: 15 });
  const { cobrancas } = c.cobrar({});
  const r = c.desfazerCobranca(cobrancas[0].id);

  assert.equal(r.valor, 15);
  assert.equal(c.comissoesOperadores({}).resumo.comissao, 15, 'voltou a ser cobrável');
  assert.equal(c.listarCobrancas()[0].desfeita, true);
  assert.throws(() => c.desfazerCobranca(cobrancas[0].id), /já foi desfeita/);
  assert.throws(() => c.desfazerCobranca('não-existe'), /não encontrada/);
});

test('a lista de Operadores conhecidos vem do histórico inteiro', () => {
  base([
    servico({ id: 's1', dia: '2026-08-20', operador: 'op1', nome: 'Ana', valor: 100 }),
    servico({ id: 's2', dia: '2026-08-20', operador: 'op2', nome: 'Bia', valor: 30, status: STATUS.SEM_COMPROVANTE }),
  ]);
  c.definirPct({ operadorId: 'op1', pct: 12 });
  const lista = c.operadoresConhecidos();
  assert.deepEqual(lista.map((o) => o.nome), ['Ana', 'Bia']);
  assert.equal(lista[0].validados, 1);
  assert.equal(lista[0].salarioTotal, 100);
  assert.equal(lista[0].pct, 12);
  assert.equal(lista[0].pctPropria, true);
  assert.equal(lista[1].validados, 0, 'quem nunca validou aparece para combinar a porcentagem');
  assert.equal(lista[1].pctPropria, false);
});

/* ═══════════ Semana e navegação por dia ═══════════ */

test('a semana vai de segunda a domingo', () => {
  // 2026-08-26 é uma quarta.
  assert.deepEqual(c.semanaDe('2026-08-26'), { de: '2026-08-24', ate: '2026-08-30' });
  assert.deepEqual(c.semanaDe('2026-08-24'), { de: '2026-08-24', ate: '2026-08-30' }, 'a própria segunda');
  assert.deepEqual(c.semanaDe('2026-08-30'), { de: '2026-08-24', ate: '2026-08-30' }, 'domingo fecha a semana');
  assert.deepEqual(c.semanaDe('2026-08-31'), { de: '2026-08-31', ate: '2026-09-06' }, 'segunda abre a próxima');
});

test('o resumo da semana soma tudo e abre dia a dia', () => {
  base([
    servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: 'Ana', valor: 100 }),   // segunda
    servico({ id: 's2', dia: '2026-08-26', operador: 'op1', nome: 'Ana', valor: 50 }),    // quarta
    servico({ id: 's3', dia: '2026-08-26', operador: 'op2', nome: 'Bia', valor: 200 }),   // quarta
    servico({ id: 's4', dia: '2026-08-31', operador: 'op1', nome: 'Ana', valor: 999 }),   // semana seguinte
  ]);
  c.definirPct({ pct: 10 });

  const r = c.resumoSemana({ referencia: '2026-08-26' });
  assert.equal(r.semana.de, '2026-08-24');
  assert.equal(r.semana.ate, '2026-08-30');
  assert.equal(r.resumo.salarioTotal, 350, 'a semana soma tudo o que foi pego nela');
  assert.equal(r.resumo.comissao, 35, 'e o que ainda há para cobrar');
  assert.equal(r.dias.reduce((s, d) => s + d.salario, 0), r.resumo.salarioTotal,
    'a soma dos dias tem que fechar com o total da semana');

  assert.equal(r.dias.length, 7);
  assert.deepEqual(r.dias.map((d) => d.rotulo), ['seg', 'ter', 'qua', 'qui', 'sex', 'sáb', 'dom']);
  const seg = r.dias.find((d) => d.day === '2026-08-24');
  const qua = r.dias.find((d) => d.day === '2026-08-26');
  assert.equal(seg.salario, 100);
  assert.equal(qua.salario, 250, 'os dois Operadores no mesmo dia');
  assert.equal(qua.comissao, 25);
  assert.equal(r.dias.find((d) => d.day === '2026-08-25').servicos, 0, 'dia sem serviço aparece zerado');

  // E cada Operador traz o seu próprio dia a dia.
  const ana = r.operadores.find((o) => o.nome === 'Ana');
  assert.equal(ana.porDia['2026-08-24'].salario, 100);
  assert.equal(ana.porDia['2026-08-26'].comissao, 5);
  assert.equal(ana.porDia['2026-08-31'], undefined, 'a semana seguinte não vaza');
});

test('a navegação anda de semana em semana e não entra no futuro', () => {
  base([]);
  const r = c.resumoSemana({ referencia: '2026-08-26' });
  assert.equal(r.anterior, '2026-08-17');
  const atual = c.resumoSemana({});
  assert.equal(atual.atual, true);
  assert.equal(atual.proxima, null, 'não existe navegar para a semana que não começou');
  assert.ok(atual.dias.some((d) => d.hoje), 'o dia de hoje é marcado');
});

/* ═══════════ Apelido ═══════════ */

test('o apelido troca o nome na tela sem tocar no histórico', () => {
  base([servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: '🥷🏻', valor: 100 })]);
  c.definirPct({ pct: 10 });
  assert.equal(c.comissoesOperadores({}).operadores[0].nome, '🥷🏻');

  c.definirApelido({ operadorId: 'op1', apelido: 'Carlos (turno da noite)' });
  const linha = c.comissoesOperadores({}).operadores[0];
  assert.equal(linha.nome, 'Carlos (turno da noite)');
  assert.equal(linha.apelido, 'Carlos (turno da noite)');
  assert.equal(linha.nomeOriginal, '🥷🏻', 'o nome do WhatsApp continua guardado');
  assert.equal(getDb().servicos[0].atendimento.operatorName, '🥷🏻', 'o histórico não é reescrito');

  c.definirApelido({ operadorId: 'op1', apelido: '   ' });
  assert.equal(c.comissoesOperadores({}).operadores[0].nome, '🥷🏻', 'apelido vazio volta ao original');
  assert.throws(() => c.definirApelido({ apelido: 'x' }), /informe o operador/);
});

/* ═══════════ Isentos ═══════════ */

test('operador isento não é cobrado nem aparece no quadro', () => {
  base([
    servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: 'Ana', valor: 100 }),
    servico({ id: 's2', dia: '2026-08-24', operador: 'op2', nome: 'Sócio', valor: 300 }),
  ]);
  c.definirPct({ pct: 10 });
  assert.equal(c.comissoesOperadores({}).resumo.comissao, 40);

  c.definirIsento({ operadorId: 'op2', isento: true });
  const r = c.comissoesOperadores({});
  assert.deepEqual(r.operadores.map((o) => o.nome), ['Ana'], 'o isento some do quadro');
  assert.equal(r.resumo.comissao, 10, 'e não entra no total a cobrar');
  assert.equal(c.resumoSemana({ referencia: '2026-08-24' }).resumo.salario, 100);

  // Cobrar tudo não pega o isento nem por engano.
  const cob = c.cobrar({});
  assert.equal(cob.cobrancas.length, 1);
  assert.equal(cob.cobrancas[0].operadorNome, 'Ana');
  assert.equal(c.cobrar({ operadorId: 'op2' }).servicos, 0, 'nem cobrando ele diretamente');

  // Mas continua visível na tela de ajuste, para dar para voltar atrás.
  const conhecido = c.operadoresConhecidos().find((o) => o.operadorId === 'op2');
  assert.equal(conhecido.isento, true);
  assert.equal(conhecido.validados, 1);

  c.definirIsento({ operadorId: 'op2', isento: false });
  assert.equal(c.comissoesOperadores({}).operadores.length, 2, 'tirar a isenção devolve ao quadro');
});

test('incluirIsentos traz todo mundo (é o que a tela de ajuste usa)', () => {
  base([
    servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: 'Ana', valor: 100 }),
    servico({ id: 's2', dia: '2026-08-24', operador: 'op2', nome: 'Sócio', valor: 300 }),
  ]);
  c.definirIsento({ operadorId: 'op2', isento: true });
  const todos = c.comissoesOperadores({ incluirIsentos: true });
  assert.equal(todos.operadores.length, 2);
  assert.equal(todos.operadores.find((o) => o.nome === 'Sócio').isento, true);
});

/* ═══════════ Montante validado (os dois quadros do topo) ═══════════ */

test('o montante validado soma o que fechou os 3 passos — hoje e na semana', () => {
  const hoje = dayKey();
  base([]);
  const db = getDb();
  // A semana dos quadros é a da CASA (sábado 05h): o outro dia do fixture
  // precisa cair dentro dela, senão só o de hoje conta.
  const janela = c.semanaDaCasa();
  const outroDia = janela.diaDe === hoje ? hoje : janela.diaDe;
  db.servicos = [
    servico({ id: 'h1', dia: hoje, operador: 'op1', nome: 'Ana', valor: 40, montante: 500 }),
    servico({ id: 'h2', dia: hoje, operador: 'op2', nome: 'Bia', valor: 30, montante: 300 }),
    // Pego mas ainda sem comprovante: não conta.
    servico({ id: 'h3', dia: hoje, operador: 'op1', nome: 'Ana', valor: 99, montante: 9999, status: STATUS.AGUARDANDO_COMPROVANTE }),
    // Outro dia da mesma semana da casa.
    servico({ id: 'w1', dia: outroDia, operador: 'op1', nome: 'Ana', valor: 20, montante: 200 }),
  ];
  saveDb();

  const r = c.montanteValidado({});
  assert.equal(r.hoje.dia, hoje);
  assert.equal(r.hoje.montante, 800, 'só os validados de hoje');
  assert.equal(r.hoje.servicos, 2);
  assert.equal(r.semana.montante, outroDia === hoje ? 800 : 1000, 'a semana soma os outros dias');
  assert.equal(r.semana.de, janela.diaDe);
  assert.equal(r.semana.montantes, outroDia === hoje ? 2 : 3, 'a contagem é de montantes validados');
});

test('o quadro usa a meta quando ela existe, e some quando não existe', () => {
  const hoje = dayKey();
  base([servico({ id: 'h1', dia: hoje, operador: 'op1', nome: 'Ana', valor: 10, montante: 250 })]);

  salvarMetas({ metaDiariaBlogueira: 0, metaSemanalBlogueira: 0 });
  assert.equal(c.montanteValidado({}).hoje.pct, null, 'sem meta não existe percentual');

  salvarMetas({ metaDiariaBlogueira: 500, metaSemanalBlogueira: 5000 });
  const r = c.montanteValidado({});
  assert.equal(r.hoje.pct, 50, '250 de 500');
  assert.equal(r.hoje.meta, 500);
  salvarMetas({ metaDiariaBlogueira: 0, metaSemanalBlogueira: 0 });
});

test('operador isento fica fora do montante do topo (como no resto da aba)', () => {
  const hoje = dayKey();
  base([
    servico({ id: 'h1', dia: hoje, operador: 'op1', nome: 'Ana', valor: 10, montante: 400 }),
    servico({ id: 'h2', dia: hoje, operador: 'op2', nome: 'Sócio', valor: 10, montante: 600 }),
  ]);
  assert.equal(c.montanteValidado({}).hoje.montante, 1000);
  c.definirIsento({ operadorId: 'op2', isento: true });
  assert.equal(c.montanteValidado({}).hoje.montante, 400,
    'o número do topo tem que fechar com a tabela de baixo, que já não mostra o isento');
  c.definirIsento({ operadorId: 'op2', isento: false });
});

test('o montante entra no dia a dia da semana, junto do salário', () => {
  base([
    servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: 'Ana', valor: 100, montante: 900 }),
  ]);
  const r = c.resumoSemana({ referencia: '2026-08-24' });
  assert.equal(r.dias.find((d) => d.day === '2026-08-24').montante, 900);
  assert.equal(r.resumo.montante, 900);
  assert.equal(r.operadores[0].porDia['2026-08-24'].montante, 900);
});

/* ═══════════ A semana da casa: sábado 05h → sábado 05h ═══════════ */

test('a semana vira no sábado às 5 da manhã, não à meia-noite', () => {
  // Sábado 05/09/2026, 04h de São Paulo (= 07h UTC): ainda é a semana que fecha.
  const antes = c.semanaDaCasa('2026-09-05T07:00:00.000Z');
  assert.equal(antes.diaDe, '2026-08-29');
  assert.match(antes.rotulo, /sáb 29\/08 05h → sáb 05\/09 05h/);

  // Uma hora depois (06h), a semana é outra.
  const depois = c.semanaDaCasa('2026-09-05T09:00:00.000Z');
  assert.equal(depois.diaDe, '2026-09-05');

  // No meio da semana (quarta), a janela continua sendo a do sábado anterior.
  assert.equal(c.semanaDaCasa('2026-09-02T15:00:00.000Z').diaDe, '2026-08-29');
  // A janela tem exatamente 7 dias.
  const j = c.semanaDaCasa('2026-09-02T15:00:00.000Z');
  assert.equal((new Date(j.ate) - new Date(j.de)) / 3600000, 168);
});

test('o resumo da semana da casa conta pelo relógio, não pelo campo `day`', () => {
  base([]);
  const db = getDb();
  const sv = (id, quandoISO, valor, montante) => ({
    id, day: quandoISO.slice(0, 10), ts: quandoISO, validadoEm: quandoISO,
    status: STATUS.VALIDADO, sessaoId: 'n1',
    atendimento: { operatorId: 'op1', operatorName: 'Ana', montante, contasQtd: 1, contasTotal: valor, ts: quandoISO },
  });
  db.servicos = [
    // Sábado 03h de SP (06h UTC) — ainda é a semana anterior, mesmo o `day`
    // já sendo sábado. É exatamente o caso que o corte das 5h resolve.
    sv('s1', '2026-09-05T06:00:00.000Z', 10, 100),
    // Sábado 07h de SP — semana nova.
    sv('s2', '2026-09-05T10:00:00.000Z', 20, 200),
    // Terça da semana nova.
    sv('s3', '2026-09-08T15:00:00.000Z', 30, 300),
  ];
  saveDb();

  const nova = c.resumoSemanaDaCasa({ agora: '2026-09-08T18:00:00.000Z' });
  assert.equal(nova.montantes, 2, 'o de 03h de sábado não entra na semana nova');
  assert.equal(nova.montante, 500);
  assert.equal(nova.salario, 50);
  assert.equal(nova.operadores, 1);

  const anterior = c.resumoSemanaDaCasa({ agora: '2026-09-04T18:00:00.000Z' });
  assert.equal(anterior.montantes, 1, 'ele fica na semana que estava fechando');
  assert.equal(anterior.montante, 100);
});

test('os quadros do topo trazem a contagem, o salário e a janela da semana', () => {
  base([]);
  const db = getDb();
  const quando = '2026-09-02T15:00:00.000Z';     // quarta
  db.servicos = [
    { id: 'a', day: '2026-09-02', ts: quando, validadoEm: quando, status: STATUS.VALIDADO, sessaoId: 'n1',
      atendimento: { operatorId: 'op1', operatorName: 'Ana', montante: 400, contasQtd: 1, contasTotal: 25, ts: quando } },
    { id: 'b', day: '2026-09-02', ts: quando, validadoEm: quando, status: STATUS.VALIDADO, sessaoId: 'n1',
      atendimento: { operatorId: 'op2', operatorName: 'Bia', montante: 600, contasQtd: 1, contasTotal: 35, ts: quando } },
  ];
  saveDb();

  const r = c.montanteValidado({ agora: quando });
  assert.equal(r.semana.montantes, 2, 'quantidade de montantes validados');
  assert.equal(r.semana.salario, 60, 'o que as Brogueiras pagaram de salário');
  assert.equal(r.semana.montante, 1000);
  assert.equal(r.semana.operadores, 2);
  assert.match(r.semana.rotulo, /05h → /);
});

test('isento também fica fora da semana da casa', () => {
  const quando = '2026-09-02T15:00:00.000Z';
  c.definirIsento({ operadorId: 'op2', isento: true });
  const r = c.resumoSemanaDaCasa({ agora: quando });
  assert.equal(r.montantes, 1);
  assert.equal(r.salario, 25);
  c.definirIsento({ operadorId: 'op2', isento: false });
});

/* ═══════════ A mensagem de cobrança ═══════════ */

test('a mensagem troca os campos pelos números do Operador', () => {
  const modelo = 'Olá {operador}, comissão de {valor} ({pct}%) sobre {salario} em {servicos} serviços — {periodo}.';
  const texto = c.montarMensagemCobranca(modelo, {
    operador: 'Ana', valor: 'R$ 60,00', pct: 15, salario: 'R$ 400,00', servicos: 4, periodo: 'esta semana',
  });
  assert.equal(texto, 'Olá Ana, comissão de R$ 60,00 (15%) sobre R$ 400,00 em 4 serviços — esta semana.');
  // Campo que não existe fica visível em vez de virar buraco silencioso.
  assert.equal(c.montarMensagemCobranca('oi {fulano}', {}), 'oi {fulano}');
  assert.equal(c.montarMensagemCobranca(null, {}), '');
});

test('a cobrança de um Operador traz destino, valores e texto pronto', () => {
  base([
    servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: 'Ana', valor: 200, montante: 1000 }),
  ]);
  c.definirPct({ operadorId: 'op1', pct: 15 });
  getDb().config.comissaoMensagem = '{operador}: {valor} de {salario} ({pct}%) · {servicos} serviços · {periodo}';

  const cob = c.cobrancaDoOperador('op1', { de: '2026-08-24', ate: '2026-08-24' });
  assert.equal(cob.nome, 'Ana');
  assert.equal(cob.para, 'op1@s.whatsapp.net', 'o destino é o número do Operador');
  assert.equal(cob.comissao, 30);
  assert.equal(cob.servicos, 1);
  assert.match(cob.mensagem, /^Ana: R\$\s?30,00 de R\$\s?200,00 \(15%\) · 1 serviços · 24\/08\/2026$/);
});

test('a cobrança recusa o isento — e só ele', () => {
  base([servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: 'Ana', valor: 100, montante: 500 })]);
  c.definirIsento({ operadorId: 'op1', isento: true });
  assert.throws(() => c.cobrancaDoOperador('op1', { de: '2026-08-24', ate: '2026-08-24' }), /isento/);
  c.definirIsento({ operadorId: 'op1', isento: false });
  // Dia sem movimento não é motivo para recusar: o dono cobra assim mesmo.
  assert.equal(c.cobrancaDoOperador('op1', { de: '2026-08-25', ate: '2026-08-25' }).comissao, 0);
});

test('o apelido escolhido é o nome que vai na mensagem', () => {
  base([servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: '🥷🏻', valor: 100, montante: 500 })]);
  getDb().config.comissaoMensagem = 'Olá {operador}!';
  c.definirApelido({ operadorId: 'op1', apelido: 'Carlos' });
  assert.equal(c.cobrancaDoOperador('op1', { de: '2026-08-24', ate: '2026-08-24' }).mensagem, 'Olá Carlos!');
  c.definirApelido({ operadorId: 'op1', apelido: '' });
});

/* ═══════════ Cobrar mesmo com o painel zerado ═══════════ */

test('depois do "Zerar comissão", a cobrança continua trazendo o valor apurado', () => {
  base([
    servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: 'Ana', valor: 200, montante: 1000 }),
  ]);
  c.definirPct({ operadorId: 'op1', pct: 15 });
  getDb().config.comissaoMensagem = '{operador} deve {valor} ({servicos} serviços)';

  const antes = c.cobrancaDoOperador('op1', { de: '2026-08-24', ate: '2026-08-24' });
  assert.equal(antes.comissao, 30);
  assert.equal(antes.comissaoAberta, 30);
  assert.equal(antes.comissaoApurada, 0);

  // Dá baixa: o painel passa a mostrar zero EM ABERTO...
  c.cobrar({ operadorId: 'op1', de: '2026-08-24', ate: '2026-08-24' });
  assert.equal(c.comissoesOperadores({ de: '2026-08-24', ate: '2026-08-24' }).resumo.comissao, 0);

  // ...mas a pessoa continua devendo, e a cobrança tem que sair com o valor.
  const depois = c.cobrancaDoOperador('op1', { de: '2026-08-24', ate: '2026-08-24' });
  assert.equal(depois.comissao, 30, 'o valor cobrado é o do período, não só o que sobrou em aberto');
  assert.equal(depois.comissaoAberta, 0);
  assert.equal(depois.comissaoApurada, 30);
  // A contagem citada na mensagem é a do PERÍODO, igual ao valor. Antes vinha
  // do "em aberto" e saía "deve R$ 30,00 (0 serviços)" — o Operador leria uma
  // cobrança que se contradiz.
  assert.equal(depois.servicos, 1);
  assert.equal(depois.salario, 200);
  assert.match(depois.mensagem, /Ana deve R\$\s?30,00 \(1 serviços\)/);
});

test('sem serviço no período, a cobrança sai zerada em vez de dar erro', () => {
  base([servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: 'Ana', valor: 200, montante: 1000 })]);
  c.definirApelido({ operadorId: 'op1', apelido: 'Aninha' });
  getDb().config.comissaoMensagem = '{operador}: {valor}';

  const vazia = c.cobrancaDoOperador('op1', { de: '2026-09-10', ate: '2026-09-10' });
  assert.equal(vazia.comissao, 0);
  assert.equal(vazia.servicos, 0);
  assert.equal(vazia.nome, 'Aninha', 'o apelido continua valendo');
  assert.equal(vazia.para, 'op1@s.whatsapp.net', 'e o destino também');
  assert.match(vazia.mensagem, /Aninha: R\$\s?0,00/);
  c.definirApelido({ operadorId: 'op1', apelido: '' });
});

test('o isento continua sendo a única cobrança recusada', () => {
  base([servico({ id: 's1', dia: '2026-08-24', operador: 'op1', nome: 'Ana', valor: 100, montante: 500 })]);
  c.definirIsento({ operadorId: 'op1', isento: true });
  assert.throws(() => c.cobrancaDoOperador('op1', { de: '2026-08-24', ate: '2026-08-24' }), /isento/);
  c.definirIsento({ operadorId: 'op1', isento: false });
  assert.doesNotThrow(() => c.cobrancaDoOperador('op1', { de: '2026-08-24', ate: '2026-08-24' }));
});

/* ═══════════ SÓ MONTANTE VALIDADO ENTRA NA ABA RELATÓRIOS ═══════════
   Pedido do usuário (31/08/2026): certificar que a aba não conta montante que
   o Operador pegou mas a Brogueira nunca comprovou. Todo caminho da aba passa
   por `cobravel()`; este teste planta os quatro desfechos possíveis de uma vez
   e cobra cada número que a aba mostra. Uma regressão que trocasse um filtro
   por `filtrarServicos()` cru apareceria aqui, não no fim do mês. */

test('Relatórios: montante atendido e NÃO validado fica de fora de todos os números', () => {
  const hoje = dayKey();
  // Mesmo Operador, mesmo dia, mesmos valores: só o desfecho muda.
  base([
    servico({ id: 'v1', dia: hoje, operador: 'op1', nome: 'Ana', valor: 20, montante: 100 }),
    servico({ id: 'v2', dia: hoje, operador: 'op1', nome: 'Ana', valor: 30, montante: 200 }),
    servico({ id: 'x1', dia: hoje, operador: 'op1', nome: 'Ana', valor: 99, montante: 900, status: STATUS.AGUARDANDO_COMPROVANTE }),
    servico({ id: 'x2', dia: hoje, operador: 'op1', nome: 'Ana', valor: 99, montante: 900, status: STATUS.SEM_COMPROVANTE }),
    servico({ id: 'x3', dia: hoje, operador: 'op1', nome: 'Ana', valor: 99, montante: 900, status: STATUS.SEM_ATENDIMENTO }),
  ]);

  // 1) A tabela de comissão.
  const { operadores, resumo } = c.comissoesOperadores({ de: hoje, ate: hoje });
  assert.equal(resumo.servicos, 2, 'só os dois validados');
  assert.equal(resumo.montante, 300, '100 + 200 — os 2.700 em aberto não entram');
  assert.equal(resumo.salario, 50);
  assert.equal(operadores.length, 1);
  assert.equal(operadores[0].montante, 300);
  assert.deepEqual(operadores[0].servicoIds.sort(), ['v1', 'v2']);
  // A quebra por dia é a mesma medida — não pode somar o que o total não soma.
  assert.equal(operadores[0].porDia[hoje].montante, 300);
  assert.equal(operadores[0].porDia[hoje].servicos, 2);

  // 2) A faixa da semana (navegação por dia).
  const semana = c.resumoSemana({ referencia: hoje });
  const dia = semana.dias.find((d) => d.day === hoje);
  assert.equal(dia.montante, 300);
  assert.equal(dia.servicos, 2);

  // 3) Os dois quadros do topo da aba.
  const v = c.montanteValidado({});
  assert.equal(v.hoje.montante, 300, 'o quadro do dia');
  assert.equal(v.hoje.servicos, 2);

  // 4) E o fechamento da semana da casa, que ancora no validadoEm.
  // `agora` fixo às 15h locais: sem ele o teste quebraria se rodasse num
  // sábado antes das 5h, quando a semana da casa ainda é a anterior e os
  // serviços de hoje caem fora da janela.
  const casa = c.resumoSemanaDaCasa({ agora: `${hoje}T18:00:00.000Z` });
  assert.equal(casa.montante, 300);
  assert.equal(casa.montantes, 2);
  assert.equal(casa.salario, 50);
});

test('Relatórios: um serviço que fecha DEPOIS passa a contar — e só então', () => {
  const hoje = dayKey();
  const pendente = servico({
    id: 'p1', dia: hoje, operador: 'op1', nome: 'Ana', valor: 40, montante: 500,
    status: STATUS.AGUARDANDO_COMPROVANTE,
  });
  base([pendente]);
  assert.equal(c.comissoesOperadores({ de: hoje, ate: hoje }).resumo.montante, 0);

  // Chega o comprovante.
  pendente.status = STATUS.VALIDADO;
  pendente.validadoEm = `${hoje}T15:02:00.000Z`;
  saveDb();
  const depois = c.comissoesOperadores({ de: hoje, ate: hoje }).resumo;
  assert.equal(depois.montante, 500);
  assert.equal(depois.salario, 40);
});

/* ═══════════ A cobrança fala do MESMO conjunto que o valor ═══════════
   `comissao` da cobrança é a do PERÍODO (aberta + já apurada no "Zerar"). Se o
   salário e a contagem de serviços da mensagem viessem só do que está aberto,
   depois de uma baixa a mensagem sairia dizendo "Salário recebido: R$ 0,00 /
   Comissão (10%): R$ 20,00" — e o Operador contestaria a conta, com razão. */
test('a mensagem de cobrança mostra o salário que gera a comissão, mesmo após a baixa', () => {
  const hoje = dayKey();
  base([
    servico({ id: 'a', dia: hoje, operador: 'op1', nome: 'Ana', valor: 100, montante: 500 }),
    servico({ id: 'b', dia: hoje, operador: 'op1', nome: 'Ana', valor: 100, montante: 500 }),
  ]);
  c.definirPct({ pct: 10 });
  getDb().config.comissaoMensagem = [
    '• Serviços validados: {servicos}',
    '• Salário recebido: {salario}',
    '• Comissão ({pct}%): *{valor}*',
  ].join('\n');
  const recorte = { de: hoje, ate: hoje };

  const antes = c.cobrancaDoOperador('op1', recorte);
  assert.equal(antes.salario, 200);
  assert.equal(antes.servicos, 2);
  assert.equal(antes.comissao, 20, '10% de 200');
  assert.match(antes.mensagem, /Salário recebido: R\$\s?200,00/);
  assert.match(antes.mensagem, /Comissão \(10%\): \*R\$\s?20,00\*/);

  // Dá baixa: a tabela zera o "em aberto", mas a dívida continua existindo.
  c.cobrar({ operadorId: 'op1', ...recorte, por: 'teste' });
  assert.equal(c.comissoesOperadores(recorte).operadores[0].salario, 0, 'em aberto zerou');

  const depois = c.cobrancaDoOperador('op1', recorte);
  assert.equal(depois.comissao, 20, 'a cobrança do período não muda com a baixa');
  assert.equal(depois.salario, 200, 'e o salário citado tem de ser o que gera esses 20');
  assert.equal(depois.servicos, 2);
  assert.match(depois.mensagem, /Salário recebido: R\$\s?200,00/);
  assert.match(depois.mensagem, /Comissão \(10%\): \*R\$\s?20,00\*/);
});

test('a comissão é exatamente a % sobre o salário das mensagens — sem arredondar a favor', () => {
  const hoje = dayKey();
  base([
    // Salários que não dão conta redonda: 15% de 33,33 = 4,9995.
    servico({ id: 'a', dia: hoje, operador: 'op1', nome: 'Ana', valor: 33.33, montante: 100 }),
    servico({ id: 'b', dia: hoje, operador: 'op1', nome: 'Ana', valor: 66.67, montante: 200 }),
  ]);
  c.definirPct({ pct: 15 });
  const linha = c.comissoesOperadores({ de: hoje, ate: hoje }).operadores[0];
  assert.equal(linha.salario, 100, '33,33 + 66,67');
  assert.equal(linha.comissao, 15, '15% de 100 — a % incide na SOMA, não serviço a serviço');
});

/* ═══════════ "Ver mais": tudo o que o Operador pegou ═══════════
   A tabela de comissão só enxerga serviço validado. Este é o outro recorte:
   o que ele atendeu no período, tenha fechado ou não — é o que se mostra
   quando ele contesta a cobrança. */

test('servicosDoOperador lista o que ele pegou, validado ou não', () => {
  base([
    servico({ id: 'v1', dia: '2026-08-24', operador: 'op1', nome: 'Nk', valor: 100, montante: 500 }),
    servico({ id: 'v2', dia: '2026-08-25', operador: 'op1', nome: 'Nk', valor: 50, montante: 200 }),
    // Pego e não fechado: some da comissão, aparece aqui.
    servico({ id: 'x1', dia: '2026-08-25', operador: 'op1', nome: 'Nk', valor: 80, montante: 300,
      status: STATUS.SEM_COMPROVANTE }),
    // De outro Operador: não é dele.
    servico({ id: 'v3', dia: '2026-08-25', operador: 'op2', nome: 'Ruan', valor: 70 }),
  ]);
  c.definirPct({ operadorId: 'op1', pct: 10 });

  const d = c.servicosDoOperador('op1', { de: '2026-08-24', ate: '2026-08-30' });
  assert.equal(d.nome, 'Nk');
  assert.deepEqual(d.servicos.map((s) => s.id).sort(), ['v1', 'v2', 'x1']);
  assert.equal(d.resumo.pegos, 3);
  assert.equal(d.resumo.validados, 2);
  assert.equal(d.resumo.taxa, 67);
  assert.equal(d.resumo.salarioPego, 230);       // 100 + 50 + 80
  assert.equal(d.resumo.salarioValidado, 150);   // o não validado não entra
  assert.equal(d.resumo.montanteValidado, 700);
  // A comissão é a mesma que a tabela cobra: 10% só do que fechou.
  assert.equal(d.resumo.comissao, 15);
  const naoFechado = d.servicos.find((s) => s.id === 'x1');
  assert.equal(naoFechado.validado, false);
  assert.equal(naoFechado.comissao, 0, 'serviço sem comprovante não gera comissão');
  assert.equal(naoFechado.statusRotulo, 'sem comprovante');
});

test('servicosDoOperador respeita o recorte de dia e marca o que já foi cobrado', () => {
  base([
    servico({ id: 'a', dia: '2026-08-24', operador: 'op1', nome: 'Nk', valor: 100 }),
    servico({ id: 'b', dia: '2026-08-25', operador: 'op1', nome: 'Nk', valor: 40 }),
  ]);
  c.definirPct({ operadorId: 'op1', pct: 10 });
  c.cobrar({ operadorId: 'op1', de: '2026-08-24', ate: '2026-08-24' });

  const dia = c.servicosDoOperador('op1', { de: '2026-08-24', ate: '2026-08-24' });
  assert.deepEqual(dia.servicos.map((s) => s.id), ['a']);
  assert.equal(dia.servicos[0].cobrado, true);
  assert.equal(dia.servicos[0].comissao, 10, 'já cobrado continua mostrando o valor daquele serviço');
  assert.equal(c.servicosDoOperador('op1', { de: '2026-08-25', ate: '2026-08-25' }).servicos[0].cobrado, false);
});

test('Operador isento aparece na lista, mas sem comissão', () => {
  base([servico({ id: 'a', dia: '2026-08-24', operador: 'op1', nome: 'Nk', valor: 100 })]);
  c.definirPct({ operadorId: 'op1', pct: 10 });
  c.definirIsento({ operadorId: 'op1', isento: true });
  const d = c.servicosDoOperador('op1', { de: '2026-08-24', ate: '2026-08-24' });
  assert.equal(d.isento, true);
  assert.equal(d.servicos.length, 1, 'ele operou — o serviço não some da conferência');
  assert.equal(d.resumo.comissao, 0);
  c.definirIsento({ operadorId: 'op1', isento: false });
});
