// Os casos abaixo são as mensagens reais que o usuário passou como
// especificação — se algum deles quebrar, o relatório das Brogueiras mente.
import test from 'node:test';
import assert from 'node:assert/strict';
import { analisarPedido, classificarPedido, extrairLinks, dominioDoLink } from './pedidos.js';

const p = (texto) => analisarPedido(texto);

test('pedidos de CONTAS — exemplos reais do grupo', () => {
  const casos = [
    ['https://670win.me/?id=357497224\n7 contas variadas', 7],
    ['https://boispin.bet/?id=763865456\n8 contas variadas 10 e 11', 8],
    ['https://www.calcadapg.vip/?id=195624946\n10 contas 10 e 13', 10],
    ['https://www.810win.me/?id=179113901\n5 contas de 10', 5],
    ['https://otimopg.co/?id=610612864\n6 contas de 10 a 11', 6],
  ];
  for (const [texto, qtd] of casos) {
    const r = p(texto);
    assert.equal(r.tipo, 'conta', `deveria ser conta: ${texto}`);
    assert.equal(r.contas, qtd, `qtd errada em: ${texto}`);
    assert.equal(r.montante, 0);
  }
});

test('pedidos de MONTANTE — exemplos reais do grupo', () => {
  const casos = [
    ['https://www.okokathena.win/?id=393339299\n520 em 4', 520, 4],
    ['https://okokathena.com/?id=920808049\nQuero 400', 400, null],
    ['https://otimopg.co/?id=610612864\n200 2 contas', 200, 2],
    ['https://www.w1-cuisinepg.com/?id=201482067\n200/2', 200, 2],
    ['https://www.lasanhapg.co/?id=534739675\n300 2 contas', 300, 2],
    ['https://www.lasanhapg.co/?id=534739675\n400 2 contas', 400, 2],
    ['https://www.lasanhapg.co/?id=534739675\n500 3 contas', 500, 3],
    ['https://www.lasanhapg.co/?id=534739675\n600 4 contas', 600, 4],
    ['https://www.lasanhapg.co/?id=534739675\n1000 7 contas', 1000, 7],
  ];
  for (const [texto, valor, contas] of casos) {
    const r = p(texto);
    assert.equal(r.tipo, 'montante', `deveria ser montante: ${texto}`);
    assert.equal(r.montante, valor, `valor errado em: ${texto}`);
    assert.equal(r.contas, contas, `divisão errada em: ${texto}`);
  }
});

test('o id do link nunca vira valor', () => {
  // 357497224 é o id da URL — sem remover o link viraria um montante absurdo
  const r = p('https://670win.me/?id=357497224\n7 contas variadas');
  assert.equal(r.montante, 0);
  assert.equal(r.contas, 7);
  assert.deepEqual(r.links, ['https://670win.me/?id=357497224']);
});

test('sem link não é pedido', () => {
  assert.equal(p('bom dia pessoal'), null);
  assert.equal(p('7 contas variadas'), null); // pedido sem link fica de fora
  assert.equal(p(''), null);
});

test('extrairLinks pega http, www e domínio nu', () => {
  assert.deepEqual(extrairLinks('veja https://a.com/x e www.b.net/y'), ['https://a.com/x', 'www.b.net/y']);
  assert.deepEqual(extrairLinks('otimopg.co/?id=1 agora'), ['otimopg.co/?id=1']);
  // pontuação colada no fim não faz parte do link
  assert.deepEqual(extrairLinks('entra em https://a.com/x.'), ['https://a.com/x']);
  // repetido conta uma vez só
  assert.deepEqual(extrairLinks('https://a.com/x https://a.com/x'), ['https://a.com/x']);
  assert.deepEqual(extrairLinks('sem link aqui'), []);
});

test('dominioDoLink normaliza para agrupar por plataforma', () => {
  assert.equal(dominioDoLink('https://www.lasanhapg.co/?id=534739675'), 'lasanhapg.co');
  assert.equal(dominioDoLink('otimopg.co/?id=1'), 'otimopg.co');
  assert.equal(dominioDoLink('https://670win.me/?id=357497224'), '670win.me');
});

test('mensagem com vários links guarda todos', () => {
  const r = p('https://a.com/?id=1\nhttps://b.net/?id=2\n5 contas');
  assert.equal(r.tipo, 'conta');
  assert.equal(r.contas, 5);
  assert.deepEqual(r.links, ['https://a.com/?id=1', 'https://b.net/?id=2']);
  assert.deepEqual(r.dominios, ['a.com', 'b.net']);
});

test('variações de escrita que aparecem no dia a dia', () => {
  assert.deepEqual(classificarPedido('7 contas'), { tipo: 'conta', montante: 0, contas: 7 });
  assert.deepEqual(classificarPedido('1 conta de 10'), { tipo: 'conta', montante: 0, contas: 1 });
  assert.deepEqual(classificarPedido('300 de montante 2 contas'), { tipo: 'montante', montante: 300, contas: 2 });
  assert.deepEqual(classificarPedido('quero 1.000 em 5'), { tipo: 'montante', montante: 1000, contas: 5 });
  assert.deepEqual(classificarPedido('500 montante'), { tipo: 'montante', montante: 500, contas: null });
  // fonte estilizada do WhatsApp
  assert.deepEqual(classificarPedido('𝟳 𝗰𝗼𝗻𝘁𝗮𝘀 variadas'), { tipo: 'conta', montante: 0, contas: 7 });
});

test('textão com link é divulgação, não pedido', () => {
  // Mensagem real de operador: sem o limite de tamanho, o "10" de "PAGO 10 NA
  // DE 50" virava um montante de R$ 10 no relatório da Brogueira.
  const promo = '*PAGO 10 NA DE 50*\n*PAGO 11 NA DE 60*\n*PAGO 15 NA DE 100*\n' +
    'https://647win.bet/?id=969528925\n✅DEPÓSITO R$10\n✅SAQUE MÍNIMO R$10\n✅SEM BARRINHA';
  const r = p(promo);
  assert.equal(r.tipo, 'indefinido');
  assert.equal(r.montante, 0);
  assert.deepEqual(r.links, ['https://647win.bet/?id=969528925']); // o link continua registrado

  const anuncio = '▪️MEIA•BANCA▪️\n🔗 https://www.784win.win/?id=622961969\n‼️SOMENTE 3 VAGAS ‼️\nValor:\n50/10\nMe chama 🔈';
  assert.equal(p(anuncio).tipo, 'indefinido');

  // um pedido de verdade, mesmo educado, continua passando
  assert.equal(p('https://a.com/?id=1\nboa noite, quero 500 em 2 contas por favor').tipo, 'montante');
});

test('casos reais do histórico que quase saíram errados', () => {
  // "1mil" — o regex de número leria só o "1"
  assert.deepEqual(
    classificarPedido('1mil em montante 5 contas'),
    { tipo: 'montante', montante: 1000, contas: 5 },
  );
  assert.deepEqual(classificarPedido('quero 2 mil em 4'), { tipo: 'montante', montante: 2000, contas: 4 });
  // "1 montante 500": o 1 é contagem, o valor é o maior dos dois
  assert.deepEqual(
    classificarPedido('1 montante 500 5 contas'),
    { tipo: 'montante', montante: 500, contas: 5 },
  );
});

test('link sem pedido legível vira "indefinido", não some', () => {
  const r = p('https://a.com/?id=1\nboa noite');
  assert.equal(r.tipo, 'indefinido');
  assert.equal(r.montante, 0);
  assert.deepEqual(r.links, ['https://a.com/?id=1']);
});
