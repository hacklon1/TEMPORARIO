// Cobre o endereçamento LID e a autorização de comandos por número.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// DATA_DIR num diretório temporário ANTES de importar db.js — nenhum teste pode
// tocar no db.json de produção.
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-jid-'));

const { identidadeRemetente, soDigitos, ehGrupo } = await import('./jid.js');
const { executarComando } = await import('./commands.js');
const { loadDb, getDb, getConfigSessao } = await import('./db.js');

loadDb();

// Mensagem de grupo como o WhatsApp entrega hoje: participant é um @lid e o
// número real vem em participantPn.
const msgGrupo = {
  key: {
    remoteJid: '120363406925469701@g.us',
    fromMe: false,
    id: 'A52028F300E315498A42499C3B79F7A0',
    participant: '277945201520675@lid',
    participantPn: '558381890298@s.whatsapp.net',
  },
};

test('soDigitos remove sufixo de device e servidor', () => {
  assert.equal(soDigitos('558381890298@s.whatsapp.net'), '558381890298');
  assert.equal(soDigitos('557381806477:8@s.whatsapp.net'), '557381806477');
  assert.equal(soDigitos('277945201520675@lid'), '277945201520675');
  assert.equal(soDigitos(undefined), '');
});

test('ehGrupo distingue grupo de privado', () => {
  assert.equal(ehGrupo('120363406925469701@g.us'), true);
  assert.equal(ehGrupo('558381890298@s.whatsapp.net'), false);
});

test('identidadeRemetente resolve LID e número real em grupo', () => {
  const id = identidadeRemetente(msgGrupo);
  assert.equal(id.lid, '277945201520675@lid');
  assert.equal(id.pn, '558381890298@s.whatsapp.net');
  // id de agregação continua sendo o LID (mantém o histórico já gravado)
  assert.equal(id.id, '277945201520675@lid');
  assert.deepEqual(id.digitos, ['277945201520675', '558381890298']);
});

test('identidadeRemetente funciona sem participantPn (mensagem antiga)', () => {
  const id = identidadeRemetente({
    key: { remoteJid: '120363@g.us', participant: '5511999999999@s.whatsapp.net' },
  });
  assert.equal(id.pn, '5511999999999@s.whatsapp.net');
  assert.deepEqual(id.digitos, ['5511999999999']);
});

test('identidadeRemetente em chat privado usa remoteJid/senderPn', () => {
  const priv = identidadeRemetente({ key: { remoteJid: '5511888888888@s.whatsapp.net' } });
  assert.equal(priv.pn, '5511888888888@s.whatsapp.net');

  const privLid = identidadeRemetente({
    key: { remoteJid: '115869929721892@lid', senderPn: '5527992011657@s.whatsapp.net' },
  });
  assert.equal(privLid.pn, '5527992011657@s.whatsapp.net');
  assert.equal(privLid.lid, '115869929721892@lid');
});

test('REGRESSÃO: comando autorizado pelo número real, não pelo LID', () => {
  const config = getConfigSessao();
  const backup = { ...config };
  config.commandAuthorizedNumbers = ['558381890298'];
  config.reportAuthorizedNumbers = [];
  config.commandPassword = '';

  const id = identidadeRemetente(msgGrupo);
  const res = executarComando('!STATUS', id);
  assert.ok(res, 'deveria responder — o número está autorizado');
  assert.match(res.reply, /Status/);

  Object.assign(config, backup);
});

test('remetente não autorizado recebe silêncio (sem spam no grupo)', () => {
  const config = getConfigSessao();
  const backup = { ...config };
  config.commandAuthorizedNumbers = ['5511000000000'];
  config.reportAuthorizedNumbers = [];

  const id = identidadeRemetente(msgGrupo);
  assert.equal(executarComando('!STATUS', id), null);
  assert.equal(executarComando('!AJUDA', id), null);
  assert.equal(executarComando('!qualquercoisa', id), null);

  Object.assign(config, backup);
});

test('autorização tolera 9º dígito e código do país', () => {
  const config = getConfigSessao();
  const backup = { ...config };
  config.commandPassword = '';
  const id = { digitos: ['5573981806477'] };

  config.commandAuthorizedNumbers = ['557381806477']; // sem o 9
  assert.ok(executarComando('!STATUS', id), 'deveria casar sem o nono dígito');

  config.commandAuthorizedNumbers = ['+55 (73) 98180-6477']; // formatado
  assert.ok(executarComando('!STATUS', id), 'deveria casar com número formatado');

  Object.assign(config, backup);
});

test('senha é exigida quando configurada', () => {
  const config = getConfigSessao();
  const backup = { ...config };
  config.commandAuthorizedNumbers = ['558381890298'];
  config.commandPassword = 'segredo';

  const id = identidadeRemetente(msgGrupo);
  assert.match(executarComando('!STATUS', id).reply, /Senha incorreta/);
  assert.match(executarComando('!STATUS senha=segredo', id).reply, /Status/);

  Object.assign(config, backup);
});
