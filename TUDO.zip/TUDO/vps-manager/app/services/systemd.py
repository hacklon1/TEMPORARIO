"""Controle de servicos systemd via systemctl."""
from __future__ import annotations

import asyncio

from ..config import settings

ACTIONS = {"start", "stop", "restart", "reload", "status", "enable", "disable"}


async def _run(args: list[str], timeout: int = 25) -> tuple[int, str, str]:
    proc = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.PIPE
    )
    try:
        out, err = await asyncio.wait_for(proc.communicate(), timeout=timeout)
    except asyncio.TimeoutError:
        proc.kill()
        return 124, "", "timeout"
    return proc.returncode or 0, out.decode(errors="replace"), err.decode(errors="replace")


def _unit(name: str) -> str:
    return name if name.endswith(".service") else f"{name}.service"


async def list_units() -> list[dict]:
    units = settings.units
    result = []
    for name in units:
        u = _unit(name)
        rc, out, _ = await _run([
            "systemctl", "show", u, "--no-page",
            "--property=ActiveState,SubState,UnitFileState,Description,MainPID,ExecMainStartTimestamp",
        ])
        props = {}
        for line in out.splitlines():
            if "=" in line:
                k, v = line.split("=", 1)
                props[k] = v
        result.append({
            "name": name,
            "unit": u,
            "description": props.get("Description", ""),
            "active": props.get("ActiveState", "unknown"),
            "sub": props.get("SubState", ""),
            "enabled": props.get("UnitFileState", ""),
            "pid": props.get("MainPID", "0"),
            "since": props.get("ExecMainStartTimestamp", ""),
        })
    return result


async def control(name: str, action: str) -> dict:
    if action not in ACTIONS:
        return {"ok": False, "error": "acao invalida"}
    if name not in settings.units:
        return {"ok": False, "error": "servico nao gerenciado"}
    rc, out, err = await _run(["systemctl", action, _unit(name)], timeout=40)
    return {"ok": rc == 0, "rc": rc, "stdout": out, "stderr": err}


async def journal(name: str, lines: int = 200) -> str:
    if name not in settings.units:
        return "servico nao gerenciado"
    lines = max(10, min(int(lines), 2000))
    rc, out, err = await _run(["journalctl", "-u", _unit(name), "-n", str(lines), "--no-pager", "--output=short-iso"], timeout=30)
    return out or err
