/* Relatórios do coletor — a API que o Dash consome.
 *
 * O Dash (dashboard externo) puxa o dia inteiro a cada 5 minutos por GET, com
 * `Authorization: Bearer <RELATORIOS_TOKEN>`. Aqui só se MONTA o JSON no
 * formato combinado; a autenticação e as rotas ficam no server.js.
 *
 * ── A fonte é o WhatsApp, não o livro-caixa ────────────────────────────
 * O coletor tem duas fontes de dinheiro: `db.operations` (a aba Relatórios do
 * painel, preenchida à mão) e `db.servicos` (o que o bot registra dos grupos).
 * A primeira nunca foi usada — ligar o Dash nela devolvia 200 zerado todo dia.
 * Estes relatórios leem os SERVIÇOS.
 *
 * O que existe nessa fonte: o montante que passou pelo Operador, o salário que
 * a Brogueira pagou a ele e a comissão que a casa cobra sobre esse salário.
 * O que NÃO existe: depósito e saque — são conceitos do livro-caixa manual.
 * Eles vão no JSON como 0, porque o contrato do Dash pede os campos; devolver
 * 0 é honesto, inventar número não seria. Os valores que a fonte tem de
 * verdade e o contrato não previa (`montante`, `validados`) vão como campos
 * EXTRA — o Dash ignora o que não conhece.
 *
 * ── O dia ──────────────────────────────────────────────────────────────
 * O dia do Dash começa às 5h. Atenção: o campo `day` do serviço é o dia de
 * CALENDÁRIO (é o que o painel usa nas telas de serviços), então aqui o filtro
 * é pelo timestamp com o corte das 5h, não por `day`. Um serviço das 2h da
 * madrugada aparece no Dash no dia anterior e no painel no dia seguinte — é a
 * mesma divergência que já existe entre as abas do painel.
 */
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';
import timezone from 'dayjs/plugin/timezone.js';
import { getDb } from './db.js';
import { diaOperacional, metas } from './operacoes.js';
import {
  salarioDoServico, montanteDoServico, cobravel, pctDoOperador, nomeDeExibicao, isento,
} from './comissoes.js';
import { STATUS } from './servicos.js';

dayjs.extend(utc);
dayjs.extend(timezone);

const ONLINE_MIN = 15; // sem atender nada há 15 min, o Operador sai do "online"

const num = (v) => (Number.isFinite(Number(v)) ? Number(v) : 0);
const cent = (v) => Math.round(num(v) * 100) / 100;

function tz() {
  const configurado = getDb().config?.timezone || 'America/Sao_Paulo';
  try {
    dayjs().tz(configurado);
    return configurado;
  } catch {
    return 'America/Sao_Paulo';
  }
}

/** ISO 8601 com o fuso da operação (o Dash lê o offset, não adivinha). */
const iso = (ts = undefined) => dayjs(ts).tz(tz()).format('YYYY-MM-DDTHH:mm:ssZ');

/**
 * O dia operacional pedido. `data` manda; sem ela, deduz de `inicio` (que o
 * Dash manda como as 5h daquele dia); sem nada, o dia corrente.
 *
 * `data` ilegível devolve null — quem chama responde 400. Cair de volta em
 * "hoje" seria pior: o Dash mostraria um dia achando que pediu outro.
 */
export function diaDaConsulta({ data = null, inicio = null } = {}) {
  if (data !== null && data !== undefined && String(data) !== '') {
    const d = String(data).slice(0, 10);
    // O formato não basta: 2026-13-45 passa no regex e não é um dia.
    if (!/^\d{4}-\d{2}-\d{2}$/.test(d) || !dayjs(d, 'YYYY-MM-DD').isValid()
        || dayjs(d).format('YYYY-MM-DD') !== d) return null;
    return d;
  }
  if (inicio && dayjs(inicio).isValid()) return diaOperacional(inicio);
  return diaOperacional();
}

const cabecalho = (dia) => ({ data: dia, gerado_em: iso(), moeda: 'BRL' });

/* ═══════════ A fonte ═══════════ */

/** O instante que situa o serviço no dia: quando a Brogueira pediu. */
const momento = (sv) => sv?.pedidoTs || sv?.ts;

/** Quando o serviço mudou pela última vez — é o `atualizado_em` do Dash. */
const ultimoToque = (sv) => sv?.validadoEm || sv?.comprovante?.ts || sv?.atendimento?.ts || momento(sv);

export function servicosDoDia(dia) {
  return (getDb().servicos ?? []).filter((sv) => diaOperacional(momento(sv)) === dia);
}

/**
 * A comissão que a casa cobra daquele serviço (a % é por Operador).
 * Operador isento não paga — mas continua nos relatórios: ele operou, o
 * dinheiro passou por ele, e o Dash precisa fechar o volume do dia.
 */
function comissaoDoServico(sv) {
  if (!cobravel(sv)) return 0;
  const id = operadorDoServico(sv).id;
  if (isento(id)) return 0;
  return cent(salarioDoServico(sv) * pctDoOperador(id) / 100);
}

function operadorDoServico(sv) {
  const a = sv?.atendimento;
  return {
    id: a?.operatorId || a?.operatorPn || a?.operatorName || 'desconhecido',
    pn: a?.operatorPn ?? null,
    nome: a?.operatorName || 'desconhecido',
  };
}

/* Status da conta, no vocabulário do Dash. O serviço tem três destinos e eles
   mapeiam um a um: fechou os 3 passos → "sacou"; expirou pelo caminho →
   "zerou"; ainda em jogo → "aberta". */
function statusDoServico(sv) {
  if (sv?.status === STATUS.VALIDADO) return 'sacou';
  if (sv?.status === STATUS.SEM_ATENDIMENTO || sv?.status === STATUS.SEM_COMPROVANTE) return 'zerou';
  return 'aberta';
}

/** As 24 horas do dia operacional, em ordem: 05:00 … 04:00. */
function horasDoDia() {
  return Array.from({ length: 24 }, (_, i) => `${String((5 + i) % 24).padStart(2, '0')}:00`);
}

/* ═══════════ ROTA 1 — montante ═══════════ */
export function montante(dia = diaOperacional()) {
  const svs = servicosDoDia(dia);
  const validados = svs.filter(cobravel);
  const soma = (lista, fn) => cent(lista.reduce((s, sv) => s + fn(sv), 0));

  const comissao = soma(validados, comissaoDoServico);
  const buckets = new Map(horasDoDia().map((h) => [h, {
    hora: h, deposito: 0, saque: 0, lucro: 0, montante: 0, blogueira: 0,
  }]));
  for (const sv of validados) {
    const b = buckets.get(dayjs(momento(sv)).tz(tz()).format('HH:00'));
    if (!b) continue;
    b.lucro += comissaoDoServico(sv);
    b.montante += montanteDoServico(sv);
    b.blogueira += salarioDoServico(sv);
  }

  return {
    ...cabecalho(dia),
    totais: {
      pedidos: svs.length,
      // Depósito e saque não existem nesta fonte (ver o cabeçalho do arquivo).
      deposito: 0,
      saque: 0,
      // O salário que as Brogueiras pagaram aos Operadores.
      blogueira: soma(validados, salarioDoServico),
      comissao,
      // O que fica com a casa é justamente a comissão.
      lucro: comissao,
      // Extras: é o que esta fonte tem de melhor e o contrato não previa.
      montante: soma(validados, montanteDoServico),
      validados: validados.length,
    },
    por_hora: [...buckets.values()].map((b) => ({
      hora: b.hora,
      deposito: 0,
      saque: 0,
      lucro: cent(b.lucro),
      montante: cent(b.montante),
      blogueira: cent(b.blogueira),
    })),
  };
}

/* ═══════════ ROTA 2 — contas ═══════════
   Uma linha por pedido de conta. Não há cadastro de contas com nome próprio na
   fonte: quem identifica a linha é a Brogueira que pediu — é o nome que o
   pessoal reconhece na tela. */
export function contas(dia = diaOperacional()) {
  const svs = servicosDoDia(dia).filter((sv) => sv.tipo === 'conta');

  const itens = svs
    .map((sv) => {
      const salario = cobravel(sv) ? salarioDoServico(sv) : 0;
      const lucro = comissaoDoServico(sv);
      return {
        nome_conta: sv.brogueiraNome || 'sem nome',
        deposito: 0,
        saque: 0,
        salario,
        lucro,
        status: statusDoServico(sv),
        atualizado_em: iso(ultimoToque(sv)),
        // Extras.
        contas: num(sv.contasPedidas),
        montante: cobravel(sv) ? montanteDoServico(sv) : 0,
        operador: cobravel(sv)
          ? nomeDeExibicao(operadorDoServico(sv).id, operadorDoServico(sv).nome) : null,
      };
    })
    .sort((a, b) => String(b.atualizado_em).localeCompare(String(a.atualizado_em)));

  const soma = (campo) => cent(itens.reduce((s, i) => s + i[campo], 0));
  const contar = (status) => itens.filter((i) => i.status === status).length;

  return {
    ...cabecalho(dia),
    totais: {
      // Quantas contas foram PEDIDAS (não quantas linhas): "3 contas de 10" é 3.
      contas_solicitadas: itens.reduce((s, i) => s + i.contas, 0),
      deposito: 0,
      saque: 0,
      salario: soma('salario'),
      comissao: soma('lucro'),
      lucro: soma('lucro'),
      // Contagens de LINHAS, não dinheiro.
      zerou: contar('zerou'),
      sacou: contar('sacou'),
      aberta: contar('aberta'),
      pedidos: itens.length,
      montante: soma('montante'),
    },
    itens,
  };
}

/* ═══════════ ROTA 3 — operadores ═══════════ */
export function operadores(dia = diaOperacional()) {
  const svs = servicosDoDia(dia).filter((sv) => sv.atendimento);

  const porOperador = new Map();
  for (const sv of svs) {
    const op = operadorDoServico(sv);
    const linha = porOperador.get(op.id) ?? {
      id: op.id, pn: op.pn, nomeOriginal: op.nome,
      pedidos: 0, validados: 0, contas: 0, montantes: 0,
      blogueira: 0, comissao: 0, montante: 0, ultima: null,
    };
    linha.pedidos += 1;
    if (sv.tipo === 'conta') linha.contas += 1; else linha.montantes += 1;
    if (cobravel(sv)) {
      linha.validados += 1;
      linha.blogueira += salarioDoServico(sv);
      linha.comissao += comissaoDoServico(sv);
      linha.montante += montanteDoServico(sv);
    }
    const quando = String(ultimoToque(sv));
    if (!linha.ultima || quando > linha.ultima) linha.ultima = quando;
    linha.nomeOriginal = op.nome || linha.nomeOriginal;
    porOperador.set(op.id, linha);
  }

  const metaDiaria = cent(metas().metaDiariaBlogueira);
  const limiteOnline = dayjs().subtract(ONLINE_MIN, 'minute');

  const lista = [...porOperador.values()].map((l) => {
    const blogueira = cent(l.blogueira);
    const comissao = cent(l.comissao);
    return {
      id: l.id,                                   // @lid: estável entre dias
      nome: nomeDeExibicao(l.id, l.nomeOriginal), // apelido, quando há
      usuario: apelidoDeOperador(l),
      // A fonte não classifica o Operador: o dia dele é que decide. "bi" não
      // tem equivalente aqui e nunca é emitido.
      categoria: l.contas > l.montantes ? 'contas' : 'montante',
      pedidos: l.pedidos,
      deposito: 0,
      saque: 0,
      blogueira,                                  // o que ele recebeu das Brogueiras
      comissao,                                   // o que ele deve à casa
      lucro: cent(blogueira - comissao),          // o que sobra para ele
      meta_diaria: metaDiaria,
      online: Boolean(l.ultima) && dayjs(l.ultima).isAfter(limiteOnline),
      ultima_operacao: l.ultima ? iso(l.ultima) : null,
      // Extras.
      validados: l.validados,
      montante: cent(l.montante),
      pct: isento(l.id) ? 0 : pctDoOperador(l.id),
      isento: isento(l.id),
    };
  });

  return { ...cabecalho(dia), operadores: lista.sort((a, b) => b.lucro - a.lucro) };
}

// `usuario` é só um identificador legível: o telefone sem o sufixo do WhatsApp,
// ou o nome sem acento/espaço. O `id` é que é a chave estável no Dash.
function apelidoDeOperador(l) {
  const telefone = String(l.pn ?? '').split('@')[0].replace(/\D/g, '');
  if (telefone) return telefone;
  return String(nomeDeExibicao(l.id, l.nomeOriginal) ?? '')
    .normalize('NFD').replace(/[\u0300-\u036f]/g, '')
    .toLowerCase().replace(/[^a-z0-9]+/g, '.').replace(/^\.|\.$/g, '') || String(l.id);
}

export const RELATORIOS = { montante, contas, operadores };
