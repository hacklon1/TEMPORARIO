import { useEffect, useState } from "react";
import { Shield, Save, RotateCcw } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { toast } from "sonner";
import {
  DEFAULT_MONTANTE_TEMPLATE,
  DEFAULT_CONTAS_TEMPLATE,
  MONTANTE_PLACEHOLDERS,
  CONTAS_PLACEHOLDERS,
} from "@/lib/pixTemplates";

export function PixTemplatesAdmin() {
  const qc = useQueryClient();

  const { data } = useQuery({
    queryKey: ["pix-templates-admin"],
    queryFn: async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("pix_template_global, pix_template_contas_global")
        .eq("id", 1)
        .maybeSingle();
      return data ?? null;
    },
  });

  const [montanteDraft, setMontanteDraft] = useState("");
  const [contasDraft, setContasDraft] = useState("");

  useEffect(() => {
    setMontanteDraft((data as any)?.pix_template_global ?? DEFAULT_MONTANTE_TEMPLATE);
    setContasDraft((data as any)?.pix_template_contas_global ?? DEFAULT_CONTAS_TEMPLATE);
  }, [data]);

  const save = async (which: "montante" | "contas") => {
    const payload =
      which === "montante"
        ? { pix_template_global: montanteDraft }
        : { pix_template_contas_global: contasDraft };
    const { error } = await supabase.from("app_settings").update(payload).eq("id", 1);
    if (error) return toast.error("Erro ao salvar", { description: error.message });
    toast.success("Template salvo");
    qc.invalidateQueries({ queryKey: ["pix-templates-admin"] });
    qc.invalidateQueries({ queryKey: ["pix-template-global"] });
    qc.invalidateQueries({ queryKey: ["pix-template-contas-global"] });
  };

  return (
    <div className="glass-strong space-y-6 rounded-2xl border border-accent/40 p-5">
      <div className="flex items-center gap-2">
        <Shield className="h-4 w-4 text-accent" />
        <h2 className="text-sm font-bold uppercase tracking-wider text-accent">
          Templates de Mensagem PIX (ADM)
        </h2>
      </div>
      <p className="-mt-3 text-xs text-muted-foreground">
        Edite as mensagens padrão geradas pelas calculadoras. Use os marcadores entre chaves
        — eles são substituídos automaticamente pelos valores calculados.
      </p>

      <TemplateBlock
        title="Calculadora de Montante"
        value={montanteDraft}
        onChange={setMontanteDraft}
        onSave={() => save("montante")}
        onReset={() => setMontanteDraft(DEFAULT_MONTANTE_TEMPLATE)}
        placeholders={MONTANTE_PLACEHOLDERS}
      />

      <TemplateBlock
        title="Calculadora de Contas"
        value={contasDraft}
        onChange={setContasDraft}
        onSave={() => save("contas")}
        onReset={() => setContasDraft(DEFAULT_CONTAS_TEMPLATE)}
        placeholders={CONTAS_PLACEHOLDERS}
      />
    </div>
  );
}

function TemplateBlock({
  title,
  value,
  onChange,
  onSave,
  onReset,
  placeholders,
}: {
  title: string;
  value: string;
  onChange: (v: string) => void;
  onSave: () => void;
  onReset: () => void;
  placeholders: string[];
}) {
  return (
    <div className="space-y-2 rounded-xl border border-border bg-background/50 p-4">
      <Label className="text-xs font-semibold uppercase tracking-wider">{title}</Label>
      <div className="flex flex-wrap gap-1">
        {placeholders.map((p) => (
          <button
            key={p}
            type="button"
            onClick={() => {
              navigator.clipboard.writeText(p).catch(() => {});
              toast.success(`Copiado: ${p}`);
            }}
            className="rounded-md border border-border bg-muted/40 px-1.5 py-0.5 font-mono text-[10px] text-muted-foreground hover:border-primary/50 hover:text-foreground"
            title="Clique para copiar"
          >
            {p}
          </button>
        ))}
      </div>
      <Textarea
        value={value}
        onChange={(e) => onChange(e.target.value)}
        rows={10}
        className="font-mono text-xs"
      />
      <div className="flex justify-end gap-2">
        <Button type="button" size="sm" variant="ghost" onClick={onReset}>
          <RotateCcw className="h-3 w-3" /> Restaurar padrão
        </Button>
        <Button type="button" size="sm" onClick={onSave} className="bg-gradient-primary shadow-glow">
          <Save className="h-3 w-3" /> Salvar
        </Button>
      </div>
    </div>
  );
}
