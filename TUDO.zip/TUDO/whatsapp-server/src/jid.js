// Identidade do remetente sob o endereçamento LID do WhatsApp.
//
// Desde 2025 o WhatsApp entrega o participante de um grupo como um JID "@lid"
// (ex.: '277945201520675@lid') em vez do número de telefone. O número real vem
// em campos paralelos da key: `participantPn` (grupos) e `senderPn` (privado).
// Autorizar comandos comparando dígitos com o LID nunca casa com um telefone
// configurado — por isso resolvemos as duas formas e comparamos com ambas.

export const ehGrupo = (jid) => String(jid ?? '').endsWith('@g.us');
export const ehLid = (jid) => String(jid ?? '').endsWith('@lid');

// Extrai só os dígitos de um JID/número.
// '5511999999999:8@s.whatsapp.net' -> '5511999999999'
export function soDigitos(jid) {
  const bruto = String(jid ?? '');
  const semSufixo = bruto.split('@')[0].split(':')[0];
  return semSufixo.replace(/[^\d]/g, '');
}

// Resolve quem enviou a mensagem. Retorna { id, lid, pn, digitos }.
// - `lid`: identificador estável do remetente (usado como chave histórica)
// - `pn` : JID com o número de telefone real, quando o WhatsApp o envia
// - `digitos`: todas as formas em dígitos, para checagem de autorização
export function identidadeRemetente(msg) {
  const key = msg?.key ?? {};
  const grupo = ehGrupo(key.remoteJid);

  const bruto = grupo ? key.participant : key.remoteJid;
  const telefone = grupo
    ? key.participantPn ?? key.participantAlt ?? null
    : key.senderPn ?? key.remoteJidAlt ?? null;

  const lid = bruto ?? null;
  const pn = telefone ?? (ehLid(bruto) ? null : bruto ?? null);

  const digitos = [...new Set([soDigitos(lid), soDigitos(pn)].filter(Boolean))];

  return {
    // Chave de agregação: mantemos o LID para não quebrar o histórico já
    // gravado (todos os lançamentos existentes estão indexados por @lid).
    id: lid ?? pn ?? null,
    lid,
    pn,
    digitos,
  };
}
