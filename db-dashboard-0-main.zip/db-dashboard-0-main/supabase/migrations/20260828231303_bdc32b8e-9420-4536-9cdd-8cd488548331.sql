ALTER TABLE public.app_settings
  ADD COLUMN IF NOT EXISTS promo_ativa boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS promo_valor_minimo numeric NOT NULL DEFAULT 0,
  ADD COLUMN IF NOT EXISTS promo_percentual numeric NOT NULL DEFAULT 0;

NOTIFY pgrst, 'reload schema';