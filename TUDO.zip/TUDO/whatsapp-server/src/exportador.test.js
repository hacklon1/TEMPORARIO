// Exportação para o DB Dashboard.
//
// O que precisa estar travado aqui: (1) só vai o que mudou, (2) nada é marcado
// como enviado antes da resposta OK, (3) uma falha vira espera crescente em vez
// de martelar o site. Sem teste, o jeito de descobrir seria o site duplicando
// linha — ou parando de receber sem ninguém notar.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-export-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb } = await import('./db.js');
const {
  configExport, versaoServico, servicosPendentes, assinaturaDia, linhaServico, linhaOperador,
  montarLote, postar, sincronizarExport, testarExport, statusExport, estadoExport,
  proximaJanela, INTERVALO_PADRAO_MIN,
} = await import('./exportador.js');

loadDb();

const AGORA = Date.parse('2026-08-30T15:00:00.000Z');
const HOJE = new Date(AGORA).toISOString().slice(0, 10);

function servico(over = {}) {
  return {
    id: 's1', day: HOJE, ts: new Date(AGORA).toISOString(), sessaoId: 'n1',
    groupId: 'G@g.us', groupName: 'DB Contas e Montantes', status: 'aguardando_atendimento',
    pedidoTs: new Date(AGORA).toISOString(), brogueiraNome: 'Bia', brogueiraPn: '5511@s.whatsapp.net',
    tipo: 'montante', montantePedido: 400, contasPedidas: 2, pedidoTexto: '400 montante 2 contas',
    atendimento: null, comprovante: null,
    ...over,
  };
}

const atendido = (over = {}) => servico({
  status: 'aguardando_comprovante',
  atendimento: {
    msgId: 'M2', ts: new Date(AGORA).toISOString(), operatorId: 'OP1@lid',
    operatorPn: '5573@s.whatsapp.net', operatorName: 'Carlos',
    montante: 400, contasQtd: 1, contasTotal: 40, casamento: 'valor',
  },
  ...over,
});

// Config e estado limpos a cada teste — o db é o mesmo arquivo temporário.
function preparar(config = {}) {
  const db = getDb();
  db.servicos = [];
  db.export = { dias: {}, ultimoEnvioEm: null, ultimoErro: null, tentativas: 0, proximaEm: null, enviados: 0 };
  Object.assign(db.config, {
    exportEnabled: true,
    exportUrl: 'https://exemplo.supabase.co/functions/v1/ingest',
    exportSegredo: 'segredo-123',
    exportApiKey: '',
    exportIntervaloMin: 5,
    ...config,
  });
  return db;
}

// fetch de mentira: guarda o que recebeu e devolve o que o teste mandar.
function fetchFalso(resposta = { ok: true, status: 200, texto: '{"ok":true}' }) {
  const chamadas = [];
  const fn = async (url, opts) => {
    chamadas.push({ url, opts, corpo: JSON.parse(opts.body) });
    if (resposta.lancar) throw new Error(resposta.lancar);
    return { ok: resposta.ok, status: resposta.status, text: async () => resposta.texto ?? '' };
  };
  fn.chamadas = chamadas;
  return fn;
}

const rankingFalso = () => ({
  operadores: [{
    id: 'OP1@lid', pn: '5573@s.whatsapp.net', nome: 'Carlos', servicos: 2, validados: 1,
    aguardando: 1, semComprovante: 0, taxa: 0.5, montanteValidado: 400, montanteAtendido: 800,
    montanteLancado: 900, lancamentos: 3, contasPegasQtd: 0, contasPegasValor: 0,
    contasValidadasQtd: 0, contasValidadasValor: 0, contasQtd: 2, contasValor: 80,
    casamento: { citacao: 1, valor: 0, tempo: 0 }, brogueiras: 2,
  }],
});

/* ═══════════ Regras puras ═══════════ */

test('config: só liga com o campo explícito; intervalo cai no padrão quando é lixo', () => {
  assert.equal(configExport({}).ligado, false);
  assert.equal(configExport({ exportEnabled: true }).ligado, true);
  assert.equal(configExport({ exportIntervaloMin: 'x' }).intervaloMin, INTERVALO_PADRAO_MIN);
  assert.equal(configExport({ exportIntervaloMin: 15 }).intervaloMin, 15);
  assert.equal(configExport({ exportUrl: '  https://x/y  ' }).url, 'https://x/y');
});

test('a versão do serviço muda a cada passo do ciclo', () => {
  const aberto = servico();
  const comAtendimento = atendido();
  const validado = atendido({ status: 'validado', comprovante: { msgId: 'M3', ts: 'x', tipo: 'pdf' } });
  const versoes = new Set([aberto, comAtendimento, validado].map(versaoServico));
  assert.equal(versoes.size, 3, 'cada passo tem de ser uma versão diferente');
});

test('pendentes: só o que mudou desde o último envio, e no máximo o teto do lote', () => {
  const enviado = atendido({ id: 's-ok' });
  enviado.exportadoVersao = versaoServico(enviado);
  const mudou = atendido({ id: 's-mudou' });
  mudou.exportadoVersao = 'versao-velha';
  const novo = servico({ id: 's-novo' });

  const fora = servicosPendentes([enviado, mudou, novo]);
  assert.deepEqual(fora.map((s) => s.id), ['s-mudou', 's-novo']);
  assert.equal(servicosPendentes([enviado, mudou, novo], 1).length, 1);
});

test('a linha do serviço leva os 3 passos e os valores como o painel os mede', () => {
  const l = linhaServico(atendido({ status: 'validado', comprovante: { ts: 'T3', tipo: 'imagem', msgId: 'M3' } }));
  assert.equal(l.id, 's1');
  assert.equal(l.status, 'validado');
  assert.equal(l.operador_nome, 'Carlos');
  assert.equal(l.montante, 400);
  assert.equal(l.contas_valor, 40); // o R$ rotulado "Valor:"
  assert.equal(l.contas_pedidas, 2);
  assert.equal(l.casamento, 'valor');
  assert.equal(l.comprovante_tipo, 'imagem');
});

test('a linha do operador carrega os três recortes de contas', () => {
  const o = rankingFalso().operadores[0];
  const l = linhaOperador(o, HOJE);
  assert.equal(l.dia, HOJE);
  assert.equal(l.operador_id, 'OP1@lid');
  assert.equal(l.montante_validado, 400);
  assert.equal(l.contas_lancadas_qtd, 2);
  assert.equal(l.contas_lancadas_valor, 80);
  assert.equal(l.taxa, 0.5);
});

test('montar lote: nada novo devolve null, e dia com a mesma assinatura não vai de novo', () => {
  const s = atendido();
  s.exportadoVersao = versaoServico(s);
  const linhas = rankingFalso().operadores.map((o) => linhaOperador(o, HOJE));
  const estado = { dias: { [HOJE]: assinaturaDia(linhas) } };

  assert.equal(montarLote({ servicos: [s], estado, agora: AGORA, rankingDe: rankingFalso }), null);

  // O mesmo serviço, um passo adiante: agora tem o que mandar.
  s.status = 'validado';
  const lote = montarLote({ servicos: [s], estado, agora: AGORA, rankingDe: rankingFalso });
  assert.equal(lote.lote.servicos.length, 1);
  assert.equal(lote.lote.operadores.length, 0, 'o dia não mudou de assinatura — só o serviço vai');
});

/* ═══════════ Envio ═══════════ */

test('postar manda o segredo no cabeçalho e trata a resposta de erro', async () => {
  const fetchImpl = fetchFalso();
  const cfg = configExport({ exportUrl: 'https://x/y', exportSegredo: 's3', exportApiKey: 'anon' });
  const r = await postar({ a: 1 }, cfg, { fetchImpl });
  assert.equal(r.ok, true);
  const { opts } = fetchImpl.chamadas[0];
  assert.equal(opts.headers['x-db-secret'], 's3');
  assert.equal(opts.headers.apikey, 'anon');
  assert.equal(opts.headers.authorization, 'Bearer anon');

  const ruim = await postar({ a: 1 }, cfg, { fetchImpl: fetchFalso({ ok: false, status: 401, texto: 'no' }) });
  assert.equal(ruim.ok, false);
  assert.match(ruim.erro, /401/);

  // Rede caiu: vira erro tratado, nunca exceção.
  const caiu = await postar({ a: 1 }, cfg, { fetchImpl: fetchFalso({ lancar: 'ECONNREFUSED' }) });
  assert.equal(caiu.ok, false);
  assert.match(caiu.erro, /ECONNREFUSED/);
});

test('sincronizar: envia o que mudou e só marca depois do OK', async () => {
  const db = preparar();
  db.servicos = [atendido({ id: 's-a' }), servico({ id: 's-b' })];
  const fetchImpl = fetchFalso();

  const r = await sincronizarExport({ agora: AGORA, deps: { fetchImpl, rankingDe: rankingFalso } });
  assert.equal(r.ok, true);
  assert.equal(r.enviados, 2);
  assert.equal(fetchImpl.chamadas.length, 1);

  const corpo = fetchImpl.chamadas[0].corpo;
  assert.equal(corpo.origem, 'whatsapp-server');
  assert.equal(corpo.servicos.length, 2);
  assert.equal(corpo.operadores.length, 1);
  assert.equal(corpo.operadores[0].dia, HOJE);

  // Marcados — o próximo ciclo não repete.
  assert.equal(db.servicos.every((s) => s.exportadoVersao === versaoServico(s)), true);
  const r2 = await sincronizarExport({ agora: AGORA + 10 * 60_000, forcar: true, deps: { fetchImpl, rankingDe: rankingFalso } });
  assert.equal(r2.enviados, 0);
  assert.equal(fetchImpl.chamadas.length, 1, 'não devia ter havido 2ª requisição');
});

test('sincronizar: falha não marca nada e agenda a próxima tentativa mais longe', async () => {
  const db = preparar();
  db.servicos = [atendido({ id: 's-a' })];
  const fetchImpl = fetchFalso({ ok: false, status: 500, texto: 'boom' });

  const r = await sincronizarExport({ agora: AGORA, deps: { fetchImpl, rankingDe: rankingFalso } });
  assert.equal(r.ok, false);
  assert.equal(db.servicos[0].exportadoVersao, undefined, 'falha não pode marcar como enviado');

  const estado = estadoExport();
  assert.equal(estado.tentativas, 1);
  assert.ok(Date.parse(estado.proximaEm) > AGORA, 'devia ter agendado a próxima tentativa');
  assert.match(estado.ultimoErro.erro, /500/);

  // Enquanto a espera não vence, o ciclo automático nem tenta.
  const espera = await sincronizarExport({ agora: AGORA + 10_000, deps: { fetchImpl, rankingDe: rankingFalso } });
  assert.equal(espera.motivo, 'ainda no intervalo');
  assert.equal(fetchImpl.chamadas.length, 1);

  // A segunda falha espera mais que a primeira.
  const primeira = Date.parse(estado.proximaEm);
  await sincronizarExport({ agora: AGORA + 60 * 60_000, deps: { fetchImpl, rankingDe: rankingFalso } });
  assert.equal(estado.tentativas, 2);
  assert.ok(Date.parse(estado.proximaEm) - (AGORA + 60 * 60_000) > primeira - AGORA);
});

test('sincronizar respeita o intervalo, e "forçar" passa por cima dele', async () => {
  const db = preparar({ exportIntervaloMin: 5 });
  db.servicos = [atendido({ id: 's-a' })];
  const fetchImpl = fetchFalso();
  await sincronizarExport({ agora: AGORA, deps: { fetchImpl, rankingDe: rankingFalso } });

  db.servicos.push(servico({ id: 's-b' }));
  const cedo = await sincronizarExport({ agora: AGORA + 60_000, deps: { fetchImpl, rankingDe: rankingFalso } });
  assert.equal(cedo.motivo, 'ainda no intervalo');

  const forcado = await sincronizarExport({ agora: AGORA + 60_000, forcar: true, deps: { fetchImpl, rankingDe: rankingFalso } });
  assert.equal(forcado.enviados, 1);

  // E a janela normal volta a valer depois do intervalo.
  assert.equal(
    proximaJanela(estadoExport(), configExport(getDb().config), AGORA) <= AGORA + 5 * 60_000 + 60_000,
    true,
  );
});

test('desligado não envia nada, nem quando forçam', async () => {
  const db = preparar({ exportEnabled: false });
  db.servicos = [atendido()];
  const fetchImpl = fetchFalso();
  const r = await sincronizarExport({ agora: AGORA, forcar: true, deps: { fetchImpl, rankingDe: rankingFalso } });
  assert.equal(r.ok, false);
  assert.equal(r.motivo, 'desligado');
  assert.equal(fetchImpl.chamadas.length, 0);
});

test('o teste de conexão manda um lote vazio marcado e não mexe no estado', async () => {
  const db = preparar();
  db.servicos = [atendido()];
  const fetchImpl = fetchFalso();

  const r = await testarExport({ fetchImpl });
  assert.equal(r.ok, true);
  const corpo = fetchImpl.chamadas[0].corpo;
  assert.equal(corpo.teste, true);
  assert.equal(corpo.servicos.length, 0);
  assert.equal(corpo.operadores.length, 0);
  assert.equal(db.servicos[0].exportadoVersao, undefined);
  assert.equal(estadoExport().ultimoEnvioEm, null);
});

test('o status conta os pendentes e diz se o segredo está preenchido', async () => {
  const db = preparar();
  db.servicos = [atendido({ id: 's-a' }), servico({ id: 's-b' })];
  const st = statusExport();
  assert.equal(st.ligado, true);
  assert.equal(st.temSegredo, true);
  assert.equal(st.pendentes, 2);
  assert.equal(st.intervaloMin, 5);
  // O segredo em si nunca sai daqui.
  assert.equal(Object.values(st).includes('segredo-123'), false);
});
