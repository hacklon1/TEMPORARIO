import { useEffect, useState } from "react";
import { Tag, Save } from "lucide-react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { formatBRL } from "@/lib/format";
import { toast } from "sonner";

/**
 * Promoção da Calculadora de % (Montante).
 *
 * Vale para todos os usuários — Donos, Admins e Operadores — porque fica em
 * app_settings, que qualquer autenticado lê e só admin escreve.
 */
export function PromocaoAdmin() {
  const qc = useQueryClient();

  const { data, error: erroLeitura } = useQuery({
    queryKey: ["promo-admin"],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("app_settings")
        .select("promo_ativa, promo_valor_minimo, promo_percentual")
        .eq("id", 1)
        .maybeSingle();
      // Sem isso o erro some e o painel só aparece vazio, sem explicar nada.
      if (error) throw error;
      return data ?? null;
    },
    retry: false,
  });

  const colunasFaltando = /promo_(ativa|valor_minimo|percentual)/.test(
    String((erroLeitura as any)?.message ?? ""),
  );

  const [ativa, setAtiva] = useState(false);
  const [valorMinimo, setValorMinimo] = useState("");
  const [percentual, setPercentual] = useState("");
  const [salvando, setSalvando] = useState(false);

  useEffect(() => {
    if (!data) return;
    setAtiva(Boolean(data.promo_ativa));
    setValorMinimo(String(data.promo_valor_minimo ?? 0));
    setPercentual(String(data.promo_percentual ?? 0));
  }, [data]);

  const salvar = async () => {
    const min = Number(valorMinimo);
    const pct = Number(percentual);

    if (ativa && !(min > 0)) {
      return toast.error("Informe o valor mínimo do montante");
    }
    if (ativa && !(pct > 0 && pct <= 100)) {
      return toast.error("A porcentagem precisa ficar entre 0 e 100");
    }

    setSalvando(true);
    const { error } = await supabase
      .from("app_settings")
      .update({
        promo_ativa: ativa,
        promo_valor_minimo: min || 0,
        promo_percentual: pct || 0,
      })
      .eq("id", 1);
    setSalvando(false);

    if (error) return toast.error("Erro ao salvar", { description: error.message });
    toast.success(ativa ? "Promoção ativada" : "Promoção desativada");
    qc.invalidateQueries({ queryKey: ["promo-admin"] });
    qc.invalidateQueries({ queryKey: ["promo-calculadora"] });
  };

  const min = Number(valorMinimo) || 0;
  const pct = Number(percentual) || 0;

  return (
    <div className="glass-strong space-y-5 rounded-2xl border border-accent/40 p-5">
      <div className="flex items-center justify-between gap-3">
        <div className="flex items-center gap-2">
          <Tag className="h-4 w-4 text-accent" />
          <h2 className="text-sm font-bold uppercase tracking-wider text-accent">
            Promoção da Calculadora (ADM)
          </h2>
        </div>
        <div className="flex items-center gap-2">
          <Label htmlFor="promo-ativa" className="text-xs text-muted-foreground">
            {ativa ? "Ativa" : "Desativada"}
          </Label>
          <Switch id="promo-ativa" checked={ativa} onCheckedChange={setAtiva} />
        </div>
      </div>

      <p className="-mt-3 text-xs text-muted-foreground">
        Quando ativa, a Calculadora de % troca a porcentagem automaticamente
        assim que o montante alcança o valor definido. Vale para todos os
        usuários e só afeta a calculadora de Montante.
      </p>

      {erroLeitura && (
        <div className="rounded-lg border border-destructive/40 bg-destructive/10 p-3 text-xs text-destructive">
          {colunasFaltando ? (
            <>
              <p className="font-bold">A promoção ainda não existe no banco.</p>
              <p className="mt-1">
                Rode a migração <span className="font-mono">20260827120000_promocao_calculadora.sql</span>{" "}
                no SQL Editor do Supabase. Ela cria as colunas{" "}
                <span className="font-mono">promo_ativa</span>,{" "}
                <span className="font-mono">promo_valor_minimo</span> e{" "}
                <span className="font-mono">promo_percentual</span>.
              </p>
            </>
          ) : (
            <>
              <p className="font-bold">Não foi possível ler a promoção.</p>
              <p className="mt-1 font-mono">{String((erroLeitura as any)?.message ?? erroLeitura)}</p>
            </>
          )}
        </div>
      )}

      <div className="grid gap-3 sm:grid-cols-2">
        <div className="space-y-1.5">
          <Label htmlFor="promo-min" className="text-xs">
            Montante a partir de (R$)
          </Label>
          <Input
            id="promo-min"
            type="number"
            inputMode="decimal"
            min={0}
            step="0.01"
            placeholder="ex: 400"
            value={valorMinimo}
            onChange={(e) => setValorMinimo(e.target.value)}
          />
        </div>
        <div className="space-y-1.5">
          <Label htmlFor="promo-pct" className="text-xs">
            Porcentagem aplicada (%)
          </Label>
          <Input
            id="promo-pct"
            type="number"
            inputMode="decimal"
            min={0}
            max={100}
            step="0.01"
            placeholder="ex: 18"
            value={percentual}
            onChange={(e) => setPercentual(e.target.value)}
          />
        </div>
      </div>

      {min > 0 && pct > 0 && (
        <p className="rounded-lg border border-border bg-background/40 p-3 text-xs text-muted-foreground">
          Montantes de <span className="font-bold text-foreground">{formatBRL(min)}</span> para
          cima passam a calcular com{" "}
          <span className="font-bold text-accent">{pct}%</span>.
        </p>
      )}

      <div className="flex justify-end">
        <Button type="button" size="sm" onClick={salvar} disabled={salvando}>
          <Save className="mr-2 h-3 w-3" /> Salvar promoção
        </Button>
      </div>
    </div>
  );
}
