"""Rasteriza o favicon do VPS Manager sem dependencias externas."""
import struct, zlib, math

S = 4          # supersampling
BG   = (0x0D, 0x14, 0x20)
EDGE = (0x22, 0x34, 0x4E)
CYAN = (0x38, 0xBD, 0xF8)
GREY = (0x5A, 0x77, 0x96)
GREEN= (0x22, 0xC5, 0x5E)

def seg_dist(px, py, ax, ay, bx, by):
    vx, vy = bx-ax, by-ay
    wx, wy = px-ax, py-ay
    L = vx*vx + vy*vy
    t = 0.0 if L == 0 else max(0.0, min(1.0, (wx*vx + wy*vy)/L))
    dx, dy = px-(ax+t*vx), py-(ay+t*vy)
    return math.hypot(dx, dy)

def rrect(px, py, x, y, w, h, r):
    """distancia com sinal ao retangulo arredondado (<0 = dentro)"""
    cx, cy = abs(px-(x+w/2)) - (w/2-r), abs(py-(y+h/2)) - (h/2-r)
    return math.hypot(max(cx,0), max(cy,0)) + min(max(cx,cy), 0) - r

def render(size):
    n = size*S
    k = n/32.0                                   # escala do viewBox 32
    px_rows = []
    for j in range(n):
        row = []
        for i in range(n):
            x, y = (i+0.5)/k, (j+0.5)/k          # coords no viewBox
            d_bg = rrect(x, y, 0, 0, 32, 32, 7)
            if d_bg > 0.6:
                row.append((0, 0, 0, 0)); continue
            col = BG
            d_edge = abs(rrect(x, y, 1, 1, 30, 30, 6.5))
            if d_edge < 0.7:
                col = EDGE
            d_ch = min(seg_dist(x, y, 8.5, 10.5, 14, 16), seg_dist(x, y, 14, 16, 8.5, 21.5))
            if d_ch < 1.5:
                col = CYAN
            if rrect(x, y, 16.5, 19.5, 8, 2.8, 1.4) < 0:
                col = GREY
            if math.hypot(x-23.5, y-9.5) < 2.6:
                col = GREEN
            a = 255 if d_bg < -0.3 else int(255 * max(0.0, min(1.0, (0.6-d_bg)/0.9)))
            row.append((col[0], col[1], col[2], a))
        px_rows.append(row)

    # downsample SxS
    out = bytearray()
    for j in range(size):
        out.append(0)                            # filtro None
        for i in range(size):
            r=g=b=a=0
            for dy in range(S):
                for dx in range(S):
                    p = px_rows[j*S+dy][i*S+dx]
                    r+=p[0]*p[3]; g+=p[1]*p[3]; b+=p[2]*p[3]; a+=p[3]
            if a:
                out += bytes((r//a, g//a, b//a, a//(S*S)))
            else:
                out += b"\0\0\0\0"
    return bytes(out)

def png(size, raw):
    def chunk(tag, data):
        c = tag + data
        return struct.pack(">I", len(data)) + c + struct.pack(">I", zlib.crc32(c) & 0xffffffff)
    ihdr = struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0)
    return (b"\x89PNG\r\n\x1a\n" + chunk(b"IHDR", ihdr)
            + chunk(b"IDAT", zlib.compress(raw, 9)) + chunk(b"IEND", b""))

W = "/opt/vps-manager/web/"
imgs = {}
for s in (32, 180, 192):
    data = png(s, render(s))
    imgs[s] = data
open(W+"apple-touch-icon.png", "wb").write(imgs[180])
open(W+"icon-192.png", "wb").write(imgs[192])

# favicon.ico com payload PNG 32x32
p = imgs[32]
ico = struct.pack("<HHH", 0, 1, 1) + struct.pack("<BBBBHHII", 32, 32, 0, 0, 1, 32, len(p), 22) + p
open(W+"favicon.ico", "wb").write(ico)
print("gerados:", {k: len(v) for k, v in imgs.items()}, "ico:", len(ico))
