// Formatadores Intl são caros de criar. Instanciamos uma vez por módulo
// e reutilizamos — a tabela de operações chama isso milhares de vezes por render.
const brl = new Intl.NumberFormat("pt-BR", {
  style: "currency",
  currency: "BRL",
  minimumFractionDigits: 2,
});

const num = new Intl.NumberFormat("pt-BR", {
  minimumFractionDigits: 2,
  maximumFractionDigits: 2,
});

const dateTime = new Intl.DateTimeFormat("pt-BR", {
  day: "2-digit",
  month: "2-digit",
  year: "numeric",
  hour: "2-digit",
  minute: "2-digit",
});

export const formatBRL = (value: number | string) => {
  const n = typeof value === "string" ? Number(value) : value;
  if (!Number.isFinite(n)) return "R$ 0,00";
  return brl.format(n);
};

export const formatNumber = (value: number) => num.format(value);

export const formatDate = (value: string | Date) => {
  const d = typeof value === "string" ? new Date(value) : value;
  return dateTime.format(d);
};
