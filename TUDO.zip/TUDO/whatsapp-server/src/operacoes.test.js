// Relatórios por usuário: o corte das 5h, líquido x bruto, a comissão que
// exclui a chefia e o zerar-com-backup (que nunca pode apagar dinheiro sem
// deixar como voltar atrás).
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-operacoes-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb, saveDb } = await import('./db.js');
const op = await import('./operacoes.js');

loadDb();

function zerarBase() {
  const db = getDb();
  db.usuarios = [];
  db.operations = [];
  db.commissionResets = [];
  db.operationAudit = [];
  db.appSettings = { metaDiariaBlogueira: 0, metaSemanalBlogueira: 0 };
  saveDb();
}

/* ═══════════ Dia operacional ═══════════ */

test('o dia operacional só vira às 5h da manhã', () => {
  // 02h de 30/08 em São Paulo (= 05h UTC) ainda é o turno do dia 29.
  assert.equal(op.diaOperacional('2026-08-30T05:00:00.000Z'), '2026-08-29');
  // 05h01 já é o dia 30.
  assert.equal(op.diaOperacional('2026-08-30T08:01:00.000Z'), '2026-08-30');
  // 23h de 30/08 (= 02h UTC do dia 31) continua no dia 30.
  assert.equal(op.diaOperacional('2026-08-31T02:00:00.000Z'), '2026-08-30');
});

test('a semana operacional começa na segunda, com o mesmo corte', () => {
  // Domingo 30/08/2026 23h → ainda é a semana que começou na segunda 24/08.
  assert.equal(op.inicioSemanaOperacional('2026-08-31T02:00:00.000Z'), '2026-08-24');
  // Segunda 31/08 às 04h (madrugada) → ainda é a semana anterior.
  assert.equal(op.inicioSemanaOperacional('2026-08-31T07:00:00.000Z'), '2026-08-24');
  // Segunda 31/08 às 06h → semana nova.
  assert.equal(op.inicioSemanaOperacional('2026-08-31T09:00:00.000Z'), '2026-08-31');
});

/* ═══════════ Dinheiro ═══════════ */

test('lucro líquido soma o resultado das contas; bruto ignora o lucro informado', () => {
  const linha = {
    deposito: 1000, saque: 1500, lucro: 500,
    deposito_contas: 200, saque_contas: 350, salario_contas: 100,
  };
  // 500 + (350 - 200 + 100)
  assert.equal(op.lucroLiquido(linha), 750);
  // (1500 - 1000) + (350 - 200)
  assert.equal(op.lucroBruto(linha), 650);
  assert.equal(op.depositoTotal(linha), 1200);
  assert.equal(op.saqueTotal(linha), 1500 + 350);
  assert.equal(op.blogueiraTotal({ blogueira: 80, salario_contas: 20 }), 100);
  assert.equal(op.lucroDe(linha, 'bruto'), 650);
  assert.equal(op.lucroDe(linha), 750);
});

/* ═══════════ Agregação ═══════════ */

test('agrega por usuário, ordena por lucro e separa a chefia', () => {
  zerarBase();
  const ana = op.salvarUsuario({ nome: 'Ana', email: 'ana@x.com', papel: 'user' });
  const bia = op.salvarUsuario({ nome: 'Bia', papel: 'user' });
  const chefe = op.salvarUsuario({ nome: 'Chefe', papel: 'admin' });

  op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-20', deposito: 100, saque: 400, lucro: 300, comissao: 30 });
  op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-21', deposito: 0, saque: 0, lucro: 100, comissao_contas: 10 });
  op.registrarOperacao({ user_id: bia.id, data_operacao: '2026-08-20', lucro: 50, comissao: 5 });
  op.registrarOperacao({ user_id: chefe.id, data_operacao: '2026-08-20', lucro: 900, comissao: 90 });

  const linhas = op.agregarPorUsuario({ de: '2026-08-20', ate: '2026-08-21' });
  assert.deepEqual(linhas.map((l) => l.nome), ['Chefe', 'Ana', 'Bia'], 'ordenado por lucro desc');
  const linhaAna = linhas.find((l) => l.nome === 'Ana');
  assert.equal(linhaAna.pedidos, 2);
  assert.equal(linhaAna.lucro, 400);
  assert.equal(linhaAna.total_comissao, 40);
  assert.equal(linhas.find((l) => l.nome === 'Chefe').chefia, true);

  // A chefia aparece no relatório, mas não na conta da comissão.
  const com = op.comissoes({ de: '2026-08-20', ate: '2026-08-21' });
  assert.deepEqual(com.usuarios.map((u) => u.nome).sort(), ['Ana', 'Bia']);
  assert.equal(com.total, 45);
});

test('o filtro de datas recorta, mas "blogueira hoje/semana" continua sendo de hoje', () => {
  zerarBase();
  const ana = op.salvarUsuario({ nome: 'Ana', papel: 'user' });
  const hoje = op.diaOperacional();
  op.registrarOperacao({ user_id: ana.id, data_operacao: '2020-01-05', blogueira: 999, lucro: 10 });
  op.registrarOperacao({ user_id: ana.id, data_operacao: hoje, blogueira: 40, salario_contas: 10, lucro: 20 });

  const antigo = op.agregarPorUsuario({ de: '2020-01-01', ate: '2020-01-31' })[0];
  assert.equal(antigo.pedidos, 1, 'o período recortou');
  assert.equal(antigo.blogueira, 999);
  assert.equal(antigo.blogueiraHoje, 50, 'o card de hoje não pode seguir o filtro');
  assert.equal(antigo.blogueiraSemana, 50);
});

test('as metas viram percentual nos totais', () => {
  op.salvarMetas({ metaDiariaBlogueira: 100, metaSemanalBlogueira: 500 });
  const t = op.totais({});
  assert.equal(t.metaDiaria, 100);
  assert.equal(t.pctDiaria, 50, '50 de 100');
  assert.equal(t.pctSemanal, 10);
  op.salvarMetas({ metaDiariaBlogueira: 0, metaSemanalBlogueira: 0 });
  assert.equal(op.totais({}).pctDiaria, null, 'sem meta não existe percentual');
});

/* ═══════════ Comissões: zerar e desfazer ═══════════ */

test('zerar grava o backup ANTES e só então zera', () => {
  zerarBase();
  const ana = op.salvarUsuario({ nome: 'Ana', papel: 'user' });
  const bia = op.salvarUsuario({ nome: 'Bia', papel: 'user' });
  op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-20', comissao: 30, comissao_contas: 5 });
  op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-21', comissao: 10 });
  op.registrarOperacao({ user_id: bia.id, data_operacao: '2026-08-20', comissao: 7 });

  const r = op.zerarComissoes({ de: '2026-08-20', ate: '2026-08-21', por: 'admin' });
  assert.equal(r.operacoes, 3);
  assert.equal(r.total, 52);
  assert.equal(r.backups.length, 2, 'zerar todas cria um backup POR usuário');

  assert.equal(op.comissoes({}).total, 0, 'não sobrou comissão');
  const backups = op.listarBackupsComissao();
  assert.equal(backups.length, 2);
  assert.equal(backups.every((b) => b.undone === false), true);
  const daAna = backups.find((b) => b.usuarioNome === 'Ana');
  assert.equal(daAna.total, 45);
  assert.equal(daAna.operations.length, 2);
});

test('zerar respeita o período e o usuário escolhidos', () => {
  zerarBase();
  const ana = op.salvarUsuario({ nome: 'Ana', papel: 'user' });
  const bia = op.salvarUsuario({ nome: 'Bia', papel: 'user' });
  op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-20', comissao: 30 });
  op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-25', comissao: 40 });
  op.registrarOperacao({ user_id: bia.id, data_operacao: '2026-08-20', comissao: 7 });

  op.zerarComissoes({ de: '2026-08-20', ate: '2026-08-20', userId: ana.id });
  const restante = op.comissoes({});
  assert.equal(restante.total, 47, 'só a operação da Ana no dia 20 foi zerada');
});

test('a chefia nunca é zerada — ela nem entra na conta', () => {
  zerarBase();
  const chefe = op.salvarUsuario({ nome: 'Chefe', papel: 'owner' });
  op.registrarOperacao({ user_id: chefe.id, data_operacao: '2026-08-20', comissao: 500 });
  const r = op.zerarComissoes({});
  assert.equal(r.operacoes, 0);
  assert.equal(getDb().operations[0].comissao, 500, 'o valor tem que continuar lá');
});

test('desfazer devolve o valor exato de cada operação', () => {
  zerarBase();
  const ana = op.salvarUsuario({ nome: 'Ana', papel: 'user' });
  const o1 = op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-20', comissao: 30, comissao_contas: 5 });
  const o2 = op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-21', comissao: 12 });

  const { backups } = op.zerarComissoes({});
  op.apagarOperacao(o2.id);                       // apagada depois do reset
  const r = op.desfazerReset(backups[0].id);

  assert.equal(r.restauradas, 1);
  assert.equal(r.sumiram, 1, 'operação apagada não é ressuscitada, é reportada');
  const viva = getDb().operations.find((o) => o.id === o1.id);
  assert.equal(viva.comissao, 30);
  assert.equal(viva.comissao_contas, 5);
  assert.equal(op.listarBackupsComissao()[0].undone, true);
  assert.throws(() => op.desfazerReset(backups[0].id), /já foi desfeito/);
});

/* ═══════════ Auditoria ═══════════ */

test('editar e apagar deixam o valor ANTIGO no log', () => {
  zerarBase();
  const ana = op.salvarUsuario({ nome: 'Ana', papel: 'user' });
  const o = op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-20', lucro: 100, deposito: 10 });
  op.atualizarOperacao(o.id, { lucro: 999 }, { por: 'admin' });
  op.apagarOperacao(o.id, { por: 'admin' });

  const log = op.logAlteracoes();
  assert.deepEqual(log.map((l) => l.acao), ['APAGADA', 'EDITADA'], 'mais recente primeiro');
  assert.equal(log[1].snapshot.lucro, 100, 'a edição guarda o valor de antes');
  assert.equal(log[0].snapshot.lucro, 999, 'a exclusão guarda o valor que estava valendo');
  assert.equal(log[0].usuarioNome, 'Ana');
});

/* ═══════════ CSV ═══════════ */

test('o CSV sai com BOM, cabeçalho e aspas escapadas', () => {
  zerarBase();
  const ana = op.salvarUsuario({ nome: 'Ana "A" Silva', papel: 'user' });
  op.registrarOperacao({ user_id: ana.id, data_operacao: '2026-08-20', lucro: 100, comissao: 10 });
  const csv = op.csvPorUsuario({});
  assert.ok(csv.startsWith('﻿'), 'sem BOM o Excel brasileiro come os acentos');
  assert.match(csv, /"Usuário";"E-mail"/);
  assert.match(csv, /"Lucro líquido"/, 'a coluna diz qual lucro é');
  assert.match(csv, /"Ana ""A"" Silva"/);
  assert.match(op.nomeArquivoCsv(), /^relatorio-usuarios-\d{4}-\d{2}-\d{2}\.csv$/);
});

test('painelRelatorios entrega tudo o que a aba desenha', () => {
  const p = op.painelRelatorios({ modo: 'bruto' });
  for (const chave of ['filtros', 'usuarios', 'totais', 'porUsuario', 'comissoes', 'metas', 'backups', 'auditoria']) {
    assert.ok(chave in p, `faltou ${chave}`);
  }
  assert.equal(p.filtros.modo, 'bruto');
});
