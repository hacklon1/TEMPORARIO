-- Login por USUÁRIO e SENHA.
--
-- O Supabase Auth continua autenticando por email internamente; o usuário é
-- uma camada acima, resolvida no login pela edge function "login".

ALTER TABLE public.profiles
  ADD COLUMN IF NOT EXISTS username TEXT;

-- unaccent pode não estar instalado; fallback simples para os acentos do pt-BR.
CREATE OR REPLACE FUNCTION public.unaccent_fallback(_raw TEXT)
RETURNS TEXT
LANGUAGE SQL
IMMUTABLE
AS $$
  SELECT translate(
    COALESCE(_raw, ''),
    'áàâãäéèêëíìîïóòôõöúùûüçÁÀÂÃÄÉÈÊËÍÌÎÏÓÒÔÕÖÚÙÛÜÇ',
    'aaaaaeeeeiiiiooooouuuucAAAAAEEEEIIIIOOOOOUUUUC'
  )
$$;

-- Normaliza um texto livre em um usuário válido: sem acento, só letras,
-- números, ponto, hífen e underscore. A caixa digitada é preservada — a
-- unicidade é garantida pelo índice sobre lower(username).
CREATE OR REPLACE FUNCTION public.slugify_username(_raw TEXT)
RETURNS TEXT
LANGUAGE SQL
IMMUTABLE
AS $$
  SELECT NULLIF(
    trim(both '._-' FROM
      regexp_replace(
        unaccent_fallback(_raw),
        '[^A-Za-z0-9._-]+', '', 'g'
      )
    ),
    ''
  )
$$;

-- Backfill: usuário = parte do email antes do @, com sufixo numérico em caso
-- de conflito (joao, joao2, joao3...).
DO $$
DECLARE
  r RECORD;
  base TEXT;
  candidate TEXT;
  n INT;
BEGIN
  FOR r IN SELECT id, email, nome FROM public.profiles WHERE username IS NULL ORDER BY created_at LOOP
    base := public.slugify_username(split_part(r.email, '@', 1));
    IF base IS NULL THEN
      base := public.slugify_username(r.nome);
    END IF;
    IF base IS NULL THEN
      base := 'usuario';
    END IF;

    candidate := base;
    n := 1;
    WHILE EXISTS (
      SELECT 1 FROM public.profiles
      WHERE lower(username) = lower(candidate)
    ) LOOP
      n := n + 1;
      candidate := base || n::text;
    END LOOP;

    UPDATE public.profiles SET username = candidate WHERE id = r.id;
  END LOOP;
END $$;

ALTER TABLE public.profiles
  ALTER COLUMN username SET NOT NULL;

CREATE UNIQUE INDEX IF NOT EXISTS profiles_username_lower_key
  ON public.profiles (lower(username));

-- Contas novas nascem com um usuário derivado do metadata ou do email.
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  base TEXT;
  candidate TEXT;
  n INT := 1;
BEGIN
  base := public.slugify_username(NEW.raw_user_meta_data->>'username');
  IF base IS NULL THEN
    base := public.slugify_username(split_part(NEW.email, '@', 1));
  END IF;
  IF base IS NULL THEN
    base := 'usuario';
  END IF;

  candidate := base;
  WHILE EXISTS (
    SELECT 1 FROM public.profiles WHERE lower(username) = lower(candidate)
  ) LOOP
    n := n + 1;
    candidate := base || n::text;
  END LOOP;

  INSERT INTO public.profiles (id, nome, email, username)
  VALUES (
    NEW.id,
    COALESCE(NEW.raw_user_meta_data->>'nome', split_part(NEW.email, '@', 1)),
    NEW.email,
    candidate
  );

  INSERT INTO public.user_roles (user_id, role) VALUES (NEW.id, 'user');
  RETURN NEW;
END;
$$;
