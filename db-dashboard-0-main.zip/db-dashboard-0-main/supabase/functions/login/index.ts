// Login por usuário e senha.
//
// O Supabase Auth autentica por email. Esta função resolve o usuário para o
// email correspondente usando a service role e só então autentica, devolvendo
// a sessão para o cliente.
//
// A resolução acontece aqui dentro de propósito: expor um endpoint público que
// traduz usuário -> email permitiria enumerar os emails de todo mundo.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const { username, password } = await req.json() as {
      username?: string;
      password?: string;
    };

    if (!username || !password) {
      return json({ error: "Informe usuário e senha" }, 400);
    }

    const url = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const admin = createClient(url, serviceKey);
    const identifier = username.trim();
    // Aceita tanto o nome de usuário quanto o email como identificador.
    const { data: profile, error: lookupErr } = await admin
      .from("profiles")
      .select("email")
      .or(`username.ilike.${identifier},email.ilike.${identifier}`)
      .maybeSingle();

    if (lookupErr) throw lookupErr;


    // Mensagem idêntica para usuário inexistente e senha errada: dizer qual dos
    // dois falhou entrega quais usuários existem.
    const invalid = () => json({ error: "Usuário ou senha inválidos" }, 401);

    if (!profile?.email) return invalid();

    const anon = createClient(url, anonKey);
    const { data, error } = await anon.auth.signInWithPassword({
      email: profile.email,
      password,
    });

    if (error || !data.session) return invalid();

    return json({
      access_token: data.session.access_token,
      refresh_token: data.session.refresh_token,
    });
  } catch (e) {
    console.error("login error", e);
    return json({ error: "Não foi possível entrar. Tente novamente." }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
