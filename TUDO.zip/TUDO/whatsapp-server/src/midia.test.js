// UPLOAD_DIR é apontado para um diretório temporário ANTES de importar midia.js
// — os testes escrevem arquivos e não podem tocar em uploads/ de produção.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-midia-'));
process.env.UPLOAD_DIR = DIR_TEMP;

const { caminhoMidia, normalizarMidia, ehImagemSuportada, midiaExiste, removerMidia, UPLOAD_DIR } =
  await import('./midia.js');

test('caminhoMidia resolve dentro de uploads/', () => {
  assert.equal(caminhoMidia('abc123'), path.join(UPLOAD_DIR, 'abc123'));
});

test('caminhoMidia recusa nomes que escapam do diretório', () => {
  for (const mau of ['../db.json', '../../etc/passwd', '/etc/passwd', 'sub/dir', '', '..', '.']) {
    assert.throws(() => caminhoMidia(mau), /inválido/, `deveria recusar: ${JSON.stringify(mau)}`);
  }
});

test('ehImagemSuportada aceita só os formatos que o WhatsApp renderiza', () => {
  assert.ok(ehImagemSuportada('image/jpeg'));
  assert.ok(ehImagemSuportada('IMAGE/PNG'));
  assert.ok(ehImagemSuportada('image/webp'));
  assert.ok(!ehImagemSuportada('application/pdf'));
  assert.ok(!ehImagemSuportada('video/mp4'));
  assert.ok(!ehImagemSuportada(''));
});

test('normalizarMidia devolve a forma canônica ou null', () => {
  assert.equal(normalizarMidia(null), null);
  assert.equal(normalizarMidia({}), null);
  assert.deepEqual(normalizarMidia({ file: 'x1', mime: 'image/png', nome: 'foto.png' }), {
    file: 'x1',
    mime: 'image/png',
    nome: 'foto.png',
  });
  assert.throws(() => normalizarMidia({ file: 'x1', mime: 'application/pdf' }), /não suportado/);
  assert.throws(() => normalizarMidia({ file: '../db.json', mime: 'image/png' }), /inválido/);
});

test('midiaExiste e removerMidia operam no arquivo real', () => {
  const nome = 'arquivo-teste';
  fs.writeFileSync(path.join(DIR_TEMP, nome), 'x');
  const midia = { file: nome, mime: 'image/png', nome: 'f.png' };
  assert.ok(midiaExiste(midia));
  assert.ok(removerMidia(midia));
  assert.ok(!midiaExiste(midia));
  assert.ok(!midiaExiste({ file: '../db.json' })); // nome inválido não "existe"
  assert.ok(!removerMidia({ file: '../db.json' })); // e nunca é apagado
});
