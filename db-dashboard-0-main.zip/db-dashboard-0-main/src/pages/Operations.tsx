import { memo, useCallback, useEffect, useMemo, useState, type FormEvent } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Plus,
  Trash2,
  Pencil,
  Download,
  Filter,
  X,
  ArrowDownToLine,
  ArrowUpFromLine,
  Users as UsersIcon,
  Activity,
  DollarSign,
  TrendingUp,
  Calculator as CalculatorIcon,
  Copy,
  FileText,
  ChevronLeft,
  ChevronRight,
} from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { formatBRL, formatDate } from "@/lib/format";
import { toast } from "sonner";
import { cn } from "@/lib/utils";
import { maxContasFromMontante, distribuirAleatorio } from "@/lib/contas";
import { SideCalculator } from "@/components/SideCalculator";
import { AccountsCalculator } from "@/components/AccountsCalculator";

type Op = {
  id: string;
  user_id: string;
  deposito: number;
  saque: number;
  blogueira: number;
  comissao: number;
  lucro: number;
  nome_conta: string | null;
  link_casa: string | null;
  contas_solicitadas: number;
  zerou: number;
  sacou: number;
  deposito_contas: number;
  saque_contas: number;
  salario_contas: number;
  comissao_contas: number;
  observacao: string | null;
  data_operacao: string | null;
  created_at: string;
};

type ProfileMin = { id: string; nome: string; email: string };

const toLocalInput = (d: Date) => {
  const pad = (n: number) => String(n).padStart(2, "0");
  return `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}T${pad(d.getHours())}:${pad(d.getMinutes())}`;
};

type StatTone = "destructive" | "success" | "primary" | "warning" | "info";

function MiniStat({
  title,
  value,
  icon: Icon,
  tone,
}: {
  title: string;
  value: string;
  icon: any;
  tone: StatTone;
}) {
  const toneMap: Record<StatTone, { ring: string; text: string; bg: string }> = {
    destructive: { ring: "ring-destructive/30", text: "text-destructive", bg: "bg-destructive/10" },
    success: { ring: "ring-success/30", text: "text-success", bg: "bg-success/10" },
    primary: { ring: "ring-primary/30", text: "text-primary", bg: "bg-primary/10" },
    warning: { ring: "ring-warning/30", text: "text-warning", bg: "bg-warning/10" },
    info: { ring: "ring-primary/30", text: "text-primary", bg: "bg-primary/10" },
  };
  const t = toneMap[tone];
  return (
    <div className="glass-strong rounded-2xl p-4">
      <div className="flex items-center gap-2">
        <div className={cn("flex h-7 w-7 items-center justify-center rounded-lg ring-1", t.bg, t.ring, t.text)}>
          <Icon className="h-3.5 w-3.5" />
        </div>
        <span className="text-[10px] font-semibold uppercase tracking-wider text-muted-foreground">
          {title}
        </span>
      </div>
      <p className={cn("number-tabular mt-2 text-xl font-bold", t.text)}>{value}</p>
    </div>
  );
}

type FieldTone = "destructive" | "success" | "primary" | "accent" | "warning";

// Cada valor ganha seu próprio quadro, com a cor do que ele representa:
// vermelho sai, verde entra, âmbar é comissão.
const FIELD_TONES: Record<FieldTone, { box: string; label: string; input: string }> = {
  destructive: {
    box: "border-destructive/40 bg-destructive/5 focus-within:border-destructive focus-within:bg-destructive/10 focus-within:shadow-[0_0_0_3px_hsl(var(--destructive)/0.15)]",
    label: "text-destructive",
    input: "border-destructive/30 focus-visible:ring-destructive/40",
  },
  success: {
    box: "border-success/40 bg-success/5 focus-within:border-success focus-within:bg-success/10 focus-within:shadow-[0_0_0_3px_hsl(var(--success)/0.15)]",
    label: "text-success",
    input: "border-success/30 focus-visible:ring-success/40",
  },
  primary: {
    box: "border-primary/40 bg-primary/5 focus-within:border-primary focus-within:bg-primary/10 focus-within:shadow-[0_0_0_3px_hsl(var(--primary)/0.15)]",
    label: "text-primary",
    input: "border-primary/30 focus-visible:ring-primary/40",
  },
  accent: {
    box: "border-accent/40 bg-accent/5 focus-within:border-accent focus-within:bg-accent/10 focus-within:shadow-[0_0_0_3px_hsl(var(--accent)/0.15)]",
    label: "text-accent",
    input: "border-accent/30 focus-visible:ring-accent/40",
  },
  warning: {
    box: "border-warning/40 bg-warning/5",
    label: "text-warning",
    input: "border-warning/30",
  },
};

function CampoValor({
  label,
  hint,
  tone,
  value,
  onChange,
}: {
  label: string;
  hint?: string;
  tone: FieldTone;
  value: string;
  onChange: (v: string) => void;
}) {
  const t = FIELD_TONES[tone];
  return (
    <div className={cn("space-y-1.5 rounded-xl border-2 p-3 transition-all", t.box)}>
      <Label className={cn("text-[10px] font-bold uppercase tracking-wider", t.label)}>
        {label}
        {hint && <span className="ml-1 text-[9px] font-normal text-muted-foreground">{hint}</span>}
      </Label>
      <Input
        type="number"
        step="0.01"
        inputMode="decimal"
        placeholder="0"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className={cn("h-11 bg-background text-base font-semibold", t.input)}
      />
    </div>
  );
}

// Valor calculado pelo sistema — mesmo quadro, mas sem campo editável.
function CampoCalculado({
  label,
  hint,
  valor,
}: {
  label: string;
  hint?: string;
  valor: number;
}) {
  const t = FIELD_TONES.warning;
  return (
    <div className={cn("space-y-1.5 rounded-xl border-2 p-3", t.box)}>
      <Label className={cn("text-[10px] font-bold uppercase tracking-wider", t.label)}>
        {label}
        {hint && <span className="ml-1 text-[9px] font-normal text-muted-foreground">{hint}</span>}
      </Label>
      <div className="flex h-11 items-center rounded-md border border-warning/30 bg-background px-3 text-base font-bold text-warning">
        {formatBRL(valor)}
      </div>
    </div>
  );
}

// Linha memoizada: sem isso, cada tecla digitada no formulário re-renderiza
// todas as linhas da tabela.
const OperationRow = memo(function OperationRow({
  o,
  isAdmin,
  profile,
  lucroKind,
  onEdit,
  onDelete,
}: {
  o: Op;
  isAdmin: boolean;
  profile: ProfileMin | undefined;
  lucroKind: "liquido" | "bruto";
  onEdit: (op: Op) => void;
  onDelete: (id: string) => void;
}) {
  const lucroContasOp = (o.saque_contas ?? 0) - (o.deposito_contas ?? 0) + (o.salario_contas ?? 0);
  const lucroLiqTot = o.lucro + lucroContasOp;
  const lucroBrTot = (o.saque - o.deposito) + ((o.saque_contas ?? 0) - (o.deposito_contas ?? 0));
  const lucroView = lucroKind === "bruto" ? lucroBrTot : lucroLiqTot;

  return (
    <TableRow className="border-border/60">
      {isAdmin && (
        <TableCell className="text-sm">
          <div className="font-medium">{profile?.nome ?? "—"}</div>
          <div className="text-xs text-muted-foreground">{profile?.email ?? ""}</div>
        </TableCell>
      )}
      <TableCell className="number-tabular text-right text-destructive">{formatBRL(o.deposito + (o.deposito_contas ?? 0))}</TableCell>
      <TableCell className="number-tabular text-right text-success">{formatBRL(o.saque + (o.saque_contas ?? 0))}</TableCell>
      <TableCell className="number-tabular text-right">{formatBRL(o.blogueira + (o.salario_contas ?? 0))}</TableCell>
      <TableCell className="number-tabular text-right text-warning">{formatBRL(o.comissao + (o.comissao_contas ?? 0))}</TableCell>
      <TableCell className={cn("number-tabular text-right font-bold", lucroView >= 0 ? "text-success" : "text-destructive")}>
        {formatBRL(lucroView)}
      </TableCell>
      <TableCell className="number-tabular text-right text-xs">
        <span className="text-destructive">{formatBRL(o.deposito_contas ?? 0)}</span>
        {" / "}
        <span className="text-success">{formatBRL(o.saque_contas ?? 0)}</span>
        {" / "}
        <span className="text-accent">{formatBRL(o.salario_contas ?? 0)}</span>
      </TableCell>
      <TableCell className="number-tabular text-right text-warning">{formatBRL(o.comissao_contas ?? 0)}</TableCell>
      <TableCell className="text-xs text-muted-foreground">
        {formatDate(o.data_operacao || o.created_at)}
      </TableCell>
      <TableCell className="text-right">
        <div className="flex justify-end gap-1">
          <Button size="icon" variant="ghost" onClick={() => onEdit(o)}>
            <Pencil className="h-4 w-4" />
          </Button>
          <Button
            size="icon"
            variant="ghost"
            className="text-destructive hover:text-destructive"
            onClick={() => onDelete(o.id)}
          >
            <Trash2 className="h-4 w-4" />
          </Button>
        </div>
      </TableCell>
    </TableRow>
  );
});

export default function Operations() {
  const { user, isAdmin, operatorType } = useAuth();
  const qc = useQueryClient();
  const [editingId, setEditingId] = useState<string | null>(null);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [lucroKind, setLucroKind] = useState<"liquido" | "bruto">("liquido");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState(25);
  const [activeTabPref, setActiveTab] = useState<"montante" | "contas">("montante");

  // Categoria do Operador: trava a página no escopo correspondente.
  const scopeMontante = operatorType !== "contas";
  const scopeContas = operatorType !== "montante";
  const lockedMode = operatorType === "bi" ? null : operatorType;

  const activeTab = lockedMode ?? activeTabPref;

  const [calcModePref, setCalcModePref] = useState<"montante" | "contas">(
    () => ((localStorage.getItem("ops:calcMode") as "montante" | "contas") ?? "montante"),
  );
  const calcMode = lockedMode ?? calcModePref;
  const setCalcMode = setCalcModePref;
  useEffect(() => { localStorage.setItem("ops:calcMode", calcModePref); }, [calcModePref]);





  // form state
  const [dataOperacao, setDataOperacao] = useState(toLocalInput(new Date()));
  const [nomeConta, setNomeConta] = useState("");
  const [linkCasa, setLinkCasa] = useState("");
  const [contasSolicitadas, setContasSolicitadas] = useState("");
  const [zerou, setZerou] = useState("");
  const [sacou, setSacou] = useState("");
  const [deposito, setDeposito] = useState("");
  const [saque, setSaque] = useState("");
  const [blogueira, setBlogueira] = useState("");
  const [comissao, setComissao] = useState("0");
  const [depositoContas, setDepositoContas] = useState("");
  const [saqueContas, setSaqueContas] = useState("");
  const [salarioContas, setSalarioContas] = useState("");
  const [comissaoContas, setComissaoContas] = useState("0");
  const [observacao, setObservacao] = useState("");

  // Divisor de Depósito — aleatório
  const [divTotal, setDivTotal] = useState("");
  const [divCount, setDivCount] = useState("5");
  const [divMin, setDivMin] = useState<string>(() => {
    if (typeof window === "undefined") return "60";
    return localStorage.getItem("div:min") ?? "60";
  });
  const [divValues, setDivValues] = useState<number[]>([]);

  useEffect(() => {
    try { localStorage.setItem("div:min", divMin); } catch {}
  }, [divMin]);

  const distribuir = () => {
    const total = Number(divTotal) || 0;
    const n = Math.max(1, Math.floor(Number(divCount) || 0));
    const m = Math.max(1, Math.floor(Number(divMin) || 1));
    setDivValues(distribuirAleatorio(total, n, m));
  };


  const formatDistribuicao = () =>
    divValues.map((v, i) => `Conta ${i + 1}: ${formatBRL(v)}`).join("\n");

  const copiarDistribuicao = async () => {
    if (!divValues.length) return;
    const total = divValues.reduce((a, b) => a + b, 0);
    const txt = `${formatDistribuicao()}\nTotal: ${formatBRL(total)}`;
    try {
      await navigator.clipboard.writeText(txt);
      toast.success("Copiado para a área de transferência");
    } catch {
      toast.error("Não foi possível copiar");
    }
  };

  const adicionarAosDetalhes = () => {
    if (!divValues.length) return;
    const total = divValues.reduce((a, b) => a + b, 0);
    const bloco = `Distribuição (${divValues.length} contas — ${formatBRL(total)}):\n${formatDistribuicao()}`;
    setObservacao((prev) => (prev ? `${prev}\n\n${bloco}` : bloco));
    toast.success("Adicionado aos detalhes da operação");
  };

  const usarNoDeposito = () => {
    if (!divValues.length) return;
    const total = divValues.reduce((a, b) => a + b, 0);
    setDeposito(String(total));
    setContasSolicitadas(String(divValues.length));
    toast.success("Valor aplicado ao depósito");
  };

  const resetForm = () => {
    setEditingId(null);
    setDataOperacao(toLocalInput(new Date()));
    setNomeConta("");
    setLinkCasa("");
    setContasSolicitadas("");
    setZerou("");
    setSacou("");
    setDeposito("");
    setSaque("");
    setBlogueira("");
    setComissao("0");
    setDepositoContas("");
    setSaqueContas("");
    setSalarioContas("");
    setComissaoContas("0");
    setObservacao("");
  };



  const lucroBruto = useMemo(
    () => (Number(saque) || 0) - (Number(deposito) || 0),
    [saque, deposito],
  );
  const lucroLiquido = useMemo(
    () => lucroBruto + (Number(blogueira) || 0) - (Number(comissao) || 0),
    [lucroBruto, blogueira, comissao],
  );
  const lucroContas = useMemo(
    () => (Number(saqueContas) || 0) - (Number(depositoContas) || 0) + (Number(salarioContas) || 0),
    [saqueContas, depositoContas, salarioContas],
  );
  const entradaTotal = useMemo(
    () => (Number(deposito) || 0) + (Number(saque) || 0),
    [deposito, saque],
  );

  const { data: ops = [], isLoading: loading } = useQuery({
    queryKey: ["ops", "operations"],
    queryFn: async () => {
      const { data: opsData } = await supabase
        .from("operations")
        .select("*")
        .order("created_at", { ascending: false });
      return (opsData ?? []).map((o: any) => ({
        ...o,
        deposito: Number(o.deposito),
        saque: Number(o.saque),
        blogueira: Number(o.blogueira),
        comissao: Number(o.comissao ?? 0),
        lucro: Number(o.lucro),
        contas_solicitadas: Number(o.contas_solicitadas ?? 0),
        zerou: Number(o.zerou ?? 0),
        sacou: Number(o.sacou ?? 0),
        deposito_contas: Number(o.deposito_contas ?? 0),
        saque_contas: Number(o.saque_contas ?? 0),
        salario_contas: Number(o.salario_contas ?? 0),
        comissao_contas: Number(o.comissao_contas ?? 0),
      })) as Op[];
    },
  });

  const { data: profilesList = [] } = useQuery({
    queryKey: ["profiles"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("id, nome, email");
      return (data ?? []) as ProfileMin[];
    },
  });

  const { data: myProfile } = useQuery({
    queryKey: ["my-profile-ops", user?.id],
    enabled: !!user?.id,
    queryFn: async () => {
      const { data } = await supabase
        .from("profiles")
        .select("commission_percent, commission_contas_percent")
        .eq("id", user!.id)
        .maybeSingle();
      return data as { commission_percent: number | null; commission_contas_percent: number | null } | null;
    },
  });

  const userCommissionPct = myProfile?.commission_percent;
  const hasCommissionPct = userCommissionPct != null;
  const userCommissionContasPct = myProfile?.commission_contas_percent;
  const hasCommissionContasPct = userCommissionContasPct != null;

  useEffect(() => {
    if (!hasCommissionPct) {
      setComissao("0");
      return;
    }
    const blog = Number(blogueira) || 0;
    const calc = blog * (Number(userCommissionPct) / 100);
    setComissao(calc.toFixed(2));
  }, [blogueira, userCommissionPct, hasCommissionPct]);

  // comissao_contas = lucro líquido contas (saque - dep + salário) * pct
  useEffect(() => {
    if (!hasCommissionContasPct) {
      setComissaoContas("0");
      return;
    }
    const liq = (Number(saqueContas) || 0) - (Number(depositoContas) || 0) + (Number(salarioContas) || 0);
    const calc = Math.max(0, liq) * (Number(userCommissionContasPct) / 100);
    setComissaoContas(calc.toFixed(2));
  }, [depositoContas, saqueContas, salarioContas, userCommissionContasPct, hasCommissionContasPct]);

  const profiles = useMemo(() => {
    const map: Record<string, ProfileMin> = {};
    profilesList.forEach((p) => (map[p.id] = p));
    return map;
  }, [profilesList]);

  const fetchAll = useCallback(() => qc.invalidateQueries({ queryKey: ["ops"] }), [qc]);

  useEffect(() => {
    const channel = supabase
      .channel("ops-page")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "operations" },
        () => qc.invalidateQueries({ queryKey: ["ops"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  const filtered = useMemo(() => {
    return ops.filter((o) => {
      const d = new Date(o.data_operacao || o.created_at);
      if (from && d < new Date(from)) return false;
      if (to) {
        const toD = new Date(to);
        toD.setHours(23, 59, 59, 999);
        if (d > toD) return false;
      }
      return true;
    });
  }, [ops, from, to]);

  const stats = useMemo(() => {
    const acc = filtered.reduce(
      (a, o) => {
        // Cada categoria contabiliza só o seu escopo; o Operador BI soma os dois.
        a.dep += (scopeMontante ? o.deposito : 0) + (scopeContas ? (o.deposito_contas ?? 0) : 0);
        a.saq += (scopeMontante ? o.saque : 0) + (scopeContas ? (o.saque_contas ?? 0) : 0);
        a.blog += (scopeMontante ? o.blogueira : 0) + (scopeContas ? (o.salario_contas ?? 0) : 0);
        a.com += (scopeMontante ? o.comissao : 0) + (scopeContas ? (o.comissao_contas ?? 0) : 0);
        return a;
      },
      { dep: 0, saq: 0, blog: 0, com: 0 },
    );
    const lucroBrutoTotal = acc.saq - acc.dep;
    const lucroLiquidoTotal = lucroBrutoTotal + acc.blog - acc.com;
    return { ...acc, lucroBruto: lucroBrutoTotal, lucroLiquido: lucroLiquidoTotal };
  }, [filtered, scopeMontante, scopeContas]);

  // A tabela renderiza só a página atual. Antes ela montava todas as linhas,
  // o que fazia o formulário travar a cada tecla digitada.
  const pageCount = Math.max(1, Math.ceil(filtered.length / pageSize));

  useEffect(() => {
    if (page > pageCount) setPage(1);
  }, [page, pageCount]);

  const pageItems = useMemo(() => {
    const start = (page - 1) * pageSize;
    return filtered.slice(start, start + pageSize);
  }, [filtered, page, pageSize]);

  useEffect(() => {
    setPage(1);
  }, [from, to, pageSize]);


  const startEdit = useCallback((op: Op) => {
    setEditingId(op.id);
    setDataOperacao(toLocalInput(new Date(op.data_operacao || op.created_at)));
    setNomeConta(op.nome_conta ?? "");
    setLinkCasa(op.link_casa ?? "");
    setContasSolicitadas(String(op.contas_solicitadas));
    setZerou(String(op.zerou));
    setSacou(String(op.sacou));
    setDeposito(String(op.deposito));
    setSaque(String(op.saque));
    setBlogueira(String(op.blogueira));
    setComissao(String(op.comissao));
    setDepositoContas(String(op.deposito_contas ?? 0));
    setSaqueContas(String(op.saque_contas ?? 0));
    setSalarioContas(String(op.salario_contas ?? 0));
    setComissaoContas(String(op.comissao_contas ?? 0));
    setObservacao(op.observacao ?? "");
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    if (!user) return;
    const payload = {
      deposito: Number(deposito) || 0,
      saque: Number(saque) || 0,
      blogueira: Number(blogueira) || 0,
      comissao: Number(comissao) || 0,
      contas_solicitadas: Number(contasSolicitadas) || 0,
      zerou: Number(zerou) || 0,
      sacou: Number(sacou) || 0,
      deposito_contas: Number(depositoContas) || 0,
      saque_contas: Number(saqueContas) || 0,
      salario_contas: Number(salarioContas) || 0,
      comissao_contas: Number(comissaoContas) || 0,
      nome_conta: nomeConta.trim() || null,
      link_casa: linkCasa.trim() || null,
      observacao: observacao.trim() || null,
      data_operacao: dataOperacao ? new Date(dataOperacao).toISOString() : null,
    };
    const totalNumeric =
      payload.deposito + payload.saque + payload.blogueira +
      payload.deposito_contas + payload.saque_contas + payload.salario_contas;
    if (totalNumeric === 0 && !editingId) {
      return toast.error("Preencha pelo menos um valor (depósito, saque, blogueira ou contas) antes de registrar");
    }
    if (editingId) {
      const { error } = await supabase
        .from("operations")
        .update(payload)
        .eq("id", editingId);
      if (error) return toast.error("Erro ao atualizar", { description: error.message });
      toast.success("Operação atualizada");
    } else {
      const { error } = await supabase
        .from("operations")
        .insert({ ...payload, user_id: user.id });
      if (error) return toast.error("Erro ao criar", { description: error.message });
      toast.success("Operação registrada");
    }
    resetForm();
    fetchAll();
  };

  const onDelete = useCallback(async (id: string) => {
    if (!confirm("Deletar esta operação?")) return;
    const { error } = await supabase.from("operations").delete().eq("id", id);
    if (error) return toast.error("Erro ao deletar");
    toast.success("Operação removida");
    fetchAll();
  }, [fetchAll]);

  const exportCSV = () => {
    const headers = [
      "Data", "Usuario", "Email", "Deposito", "Saque", "Blogueira", "Comissao", "Lucro",
      "Dep. Contas", "Saque Contas", "Sal. Contas", "Comissao Contas", "Lucro Contas", "Anotacao",
    ];
    const rows = filtered.map((o) => [
      new Date(o.data_operacao || o.created_at).toISOString(),
      profiles[o.user_id]?.nome ?? "",
      profiles[o.user_id]?.email ?? "",
      o.deposito.toFixed(2),
      o.saque.toFixed(2),
      o.blogueira.toFixed(2),
      o.comissao.toFixed(2),
      o.lucro.toFixed(2),
      (o.deposito_contas ?? 0).toFixed(2),
      (o.saque_contas ?? 0).toFixed(2),
      (o.salario_contas ?? 0).toFixed(2),
      (o.comissao_contas ?? 0).toFixed(2),
      ((o.saque_contas ?? 0) - (o.deposito_contas ?? 0) + (o.salario_contas ?? 0)).toFixed(2),
      (o.observacao ?? "").replace(/\n/g, " "),
    ]);
    const csv = [headers, ...rows]
      .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `operacoes-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Exportação concluída");
  };

  const investido = stats.dep;
  const retornado = stats.saq;
  const sugestaoContas = maxContasFromMontante(Number(divTotal) || 0);
  const divCountNum = Number(divCount) || 0;
  const excedeSugestao = divCountNum > sugestaoContas && (Number(divTotal) || 0) > 0;

  return (
    <div className="space-y-6 animate-fade-in">
      {/* Profit toggle */}
      <div className="flex items-center justify-end gap-2">
        <span className="text-[11px] uppercase tracking-wider text-muted-foreground">Lucro:</span>
        <div className="inline-flex rounded-full bg-background/60 p-1 ring-1 ring-border">
          <button type="button" onClick={() => setLucroKind("liquido")}
            className={cn("rounded-full px-3 py-1 text-[11px] font-semibold transition",
              lucroKind === "liquido" ? "bg-gradient-primary text-primary-foreground shadow-glow" : "text-muted-foreground")}>
            Líquido
          </button>
          <button type="button" onClick={() => setLucroKind("bruto")}
            className={cn("rounded-full px-3 py-1 text-[11px] font-semibold transition",
              lucroKind === "bruto" ? "bg-gradient-primary text-primary-foreground shadow-glow" : "text-muted-foreground")}>
            Bruto
          </button>
        </div>
      </div>

      {/* Top stat cards */}
      <div className="grid grid-cols-2 gap-3 md:grid-cols-3 xl:grid-cols-6">
        <MiniStat title="Investido" value={formatBRL(investido)} icon={ArrowDownToLine} tone="destructive" />
        <MiniStat title="Retornado" value={formatBRL(retornado)} icon={ArrowUpFromLine} tone="success" />
        <MiniStat title="Blogueiras" value={formatBRL(stats.blog)} icon={UsersIcon} tone="info" />
        <MiniStat title="Comissão" value={formatBRL(stats.com)} icon={Activity} tone="warning" />
        <MiniStat title="Lucro Bruto" value={formatBRL(stats.lucroBruto)} icon={DollarSign} tone={stats.lucroBruto >= 0 ? "primary" : "destructive"} />
        <MiniStat title="Lucro Líquido" value={formatBRL(stats.lucroLiquido)} icon={TrendingUp} tone={stats.lucroLiquido >= 0 ? "success" : "destructive"} />
      </div>


      <div className="grid gap-4 lg:grid-cols-[1fr_360px]">
        {/* LEFT: form */}
        <div className="glass-strong space-y-4 rounded-2xl border-2 border-success/40 bg-gradient-to-br from-success/5 to-transparent p-5 shadow-elegant ring-1 ring-success/20">
          <div className="flex items-center justify-between border-b-2 border-success/30 pb-3">
            <div className="flex items-center gap-3">
              <div className="flex h-11 w-11 items-center justify-center rounded-xl bg-success/15 ring-2 ring-success/30">
                <Plus className="h-5 w-5 text-success" />
              </div>
              <div>
                <h2 className="text-base font-bold uppercase tracking-wider text-success md:text-lg">
                  {editingId ? "Editar operação" : "Nova operação"}
                </h2>
                <p className="text-[11px] text-muted-foreground">
                  {editingId ? "Atualize os dados e salve" : "Preencha os campos abaixo para registrar"}
                </p>
              </div>
            </div>
            {editingId && (
              <Button type="button" variant="ghost" size="sm" onClick={resetForm}>
                <X className="h-3 w-3" /> Cancelar edição
              </Button>
            )}
          </div>

          <form onSubmit={onSubmit} className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Data</Label>
              <Input
                type="datetime-local"
                value={dataOperacao}
                onChange={(e) => setDataOperacao(e.target.value)}
                className="md:max-w-xs"
              />
            </div>

            <Tabs value={activeTab} onValueChange={(v) => setActiveTab(v as "montante" | "contas")} className="w-full">
              {!lockedMode && (
                <TabsList className="grid w-full grid-cols-2 md:w-auto">
                  <TabsTrigger value="montante">Montante</TabsTrigger>
                  <TabsTrigger value="contas">Contas</TabsTrigger>
                </TabsList>
              )}

              <TabsContent value="montante" className="mt-4 space-y-4">
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <CampoValor label="Depósito" tone="destructive" value={deposito} onChange={setDeposito} />
                  <CampoValor label="Saque" tone="success" value={saque} onChange={setSaque} />
                  <CampoValor label="Blogueiro" tone="primary" value={blogueira} onChange={setBlogueira} />
                  {hasCommissionPct && (
                    <CampoCalculado
                      label="Comissão"
                      hint={`(${userCommissionPct}% auto)`}
                      valor={Number(comissao) || 0}
                    />
                  )}
                </div>

                <div className="space-y-1.5">
                  <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">
                    Detalhes da operação
                  </Label>
                  <Textarea
                    placeholder="Anotações, observações..."
                    value={observacao}
                    onChange={(e) => setObservacao(e.target.value)}
                    rows={3}
                    maxLength={1000}
                  />
                </div>
              </TabsContent>

              <TabsContent value="contas" className="mt-4 space-y-4">
                <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-4">
                  <CampoValor label="Depósito (Contas)" tone="destructive" value={depositoContas} onChange={setDepositoContas} />
                  <CampoValor label="Saque (Contas)" tone="success" value={saqueContas} onChange={setSaqueContas} />
                  <CampoValor label="Salário (Contas)" tone="accent" value={salarioContas} onChange={setSalarioContas} />
                  {hasCommissionContasPct && (
                    <CampoCalculado
                      label="Comissão Contas"
                      hint={`(${userCommissionContasPct}% auto)`}
                      valor={Number(comissaoContas) || 0}
                    />
                  )}
                </div>
              </TabsContent>
            </Tabs>

            <div className="flex flex-wrap items-center justify-between gap-4 rounded-xl border border-border bg-background/40 p-4">
              {activeTab === "montante" ? (
                <div className="flex flex-wrap gap-6">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Entrada total</p>
                    <p className="number-tabular font-bold">{formatBRL(entradaTotal)}</p>
                  </div>
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Lucro bruto</p>
                    <p className={cn("number-tabular font-bold", lucroBruto >= 0 ? "text-foreground" : "text-destructive")}>
                      {formatBRL(lucroBruto)}
                    </p>
                  </div>
                  {hasCommissionPct && (
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Comissão</p>
                      <p className="number-tabular font-bold text-warning">−{formatBRL(Number(comissao) || 0)}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Lucro líquido</p>
                    <p className={cn("number-tabular font-bold", lucroLiquido >= 0 ? "text-success" : "text-destructive")}>
                      {formatBRL(lucroLiquido)}
                    </p>
                  </div>
                </div>
              ) : (
                <div className="flex flex-wrap gap-6">
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Entrada Contas</p>
                    <p className="number-tabular font-bold">{formatBRL((Number(depositoContas) || 0) + (Number(saqueContas) || 0))}</p>
                  </div>
                  {hasCommissionContasPct && (
                    <div>
                      <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Comissão Contas</p>
                      <p className="number-tabular font-bold text-warning">−{formatBRL(Number(comissaoContas) || 0)}</p>
                    </div>
                  )}
                  <div>
                    <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Lucro líquido Contas</p>
                    <p className={cn("number-tabular font-bold", lucroContas >= 0 ? "text-success" : "text-destructive")}>
                      {formatBRL(lucroContas)}
                    </p>
                    <p className="text-[9px] text-muted-foreground">Saque − Depósito + Salário</p>
                  </div>
                </div>
              )}
              <Button type="submit" className="bg-success text-success-foreground hover:bg-success/90">
                {editingId ? "Salvar alterações" : "Criar Operação"}
              </Button>
            </div>
          </form>
        </div>




        {/* RIGHT: Calculadora % + Divisor */}
        <aside className="space-y-4 lg:sticky lg:top-20 lg:self-start lg:max-h-[calc(100vh-6rem)] lg:overflow-y-auto lg:pr-1">
          {!lockedMode && (
            <div className="grid grid-cols-2 gap-2 rounded-xl bg-background/40 p-1 ring-1 ring-border">
              <button
                type="button"
                onClick={() => setCalcMode("montante")}
                className={`rounded-lg px-3 py-2 text-xs font-semibold transition-all ${calcMode === "montante" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"}`}
              >
                Montante
              </button>
              <button
                type="button"
                onClick={() => setCalcMode("contas")}
                className={`rounded-lg px-3 py-2 text-xs font-semibold transition-all ${calcMode === "contas" ? "bg-primary text-primary-foreground shadow" : "text-muted-foreground hover:text-foreground"}`}
              >
                Contas
              </button>
            </div>
          )}
          {calcMode === "montante" ? <SideCalculator /> : <AccountsCalculator />}

          {scopeMontante && (
          <div className="glass-strong space-y-4 rounded-2xl border border-primary/30 bg-gradient-to-br from-primary/10 to-primary/5 p-4">
            <div className="flex items-center gap-2">
              <CalculatorIcon className="h-4 w-4 text-primary" />
              <h3 className="text-xs font-bold uppercase tracking-wider text-primary">
                Divisor de depósito
              </h3>
            </div>

            <div className="space-y-3">
              <div className="space-y-1.5">
                <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Valor total</Label>
                <Input
                  type="number"
                  step="0.01"
                  inputMode="decimal"
                  placeholder="500"
                  value={divTotal}
                  onChange={(e) => setDivTotal(e.target.value)}
                />
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">Quantas contas</Label>
                <Input
                  type="number"
                  min={1}
                  value={divCount}
                  onChange={(e) => setDivCount(e.target.value)}
                />
                {(Number(divTotal) || 0) > 0 && (
                  <p className={cn("text-[10px]", excedeSugestao ? "text-warning" : "text-muted-foreground")}>
                    Sugestão para R$ {Number(divTotal) || 0}: até <span className="font-bold">{sugestaoContas}</span> {sugestaoContas === 1 ? "conta" : "contas"}
                    {excedeSugestao && " — acima do recomendado"}
                  </p>
                )}
                <div className="flex flex-wrap gap-1 pt-1">
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                    <button
                      key={n}
                      type="button"
                      onClick={() => setDivCount(String(n))}
                      className={cn(
                        "rounded-md border px-2 py-0.5 text-[10px] font-medium transition-colors",
                        divCount === String(n)
                          ? "border-primary bg-primary/20 text-primary"
                          : "border-border text-muted-foreground hover:border-primary/50",
                      )}
                    >
                      {n}
                    </button>
                  ))}
                </div>
              </div>
              <div className="space-y-1.5">
                <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">
                  Valor mínimo por conta (R$)
                </Label>
                <Input
                  type="number"
                  min={1}
                  step="1"
                  value={divMin}
                  onChange={(e) => setDivMin(e.target.value)}
                  placeholder="60"
                />
                <p className="text-[10px] text-muted-foreground">
                  Padrão sugerido: <span className="font-semibold text-foreground">R$ 60</span>. Cada conta receberá pelo menos esse valor.
                </p>
              </div>
              <p className="text-[10px] text-muted-foreground">
                Cada clique em <span className="font-bold text-foreground">Distribuir</span> gera valores aleatórios diferentes.
              </p>

            </div>

            <Button type="button" size="sm" onClick={distribuir} className="w-full">
              <CalculatorIcon className="h-3 w-3" /> Distribuir
            </Button>

            {divValues.length > 0 && (
              <div className="space-y-2 rounded-xl border border-primary/20 bg-background/60 p-3">
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold uppercase tracking-wider text-primary">Resultado</span>
                  <div className="flex gap-1">
                    <Button type="button" size="sm" variant="ghost" onClick={copiarDistribuicao} className="h-6 px-1.5">
                      <Copy className="h-3 w-3" />
                    </Button>
                    <Button type="button" size="sm" variant="ghost" onClick={adicionarAosDetalhes} className="h-6 px-1.5">
                      <FileText className="h-3 w-3" />
                    </Button>
                    <Button type="button" size="sm" variant="ghost" onClick={usarNoDeposito} className="h-6 px-1.5 text-success">
                      Usar
                    </Button>
                  </div>
                </div>
                <div className="space-y-1">
                  {divValues.map((v, i) => (
                    <div key={i} className="flex items-center justify-between rounded-lg border border-border bg-card px-2 py-1.5 text-xs">
                      <span className="inline-flex h-5 w-5 items-center justify-center rounded-full bg-primary/15 text-[10px] font-bold text-primary">
                        {i + 1}
                      </span>
                      <span className="number-tabular font-bold">{formatBRL(v)}</span>
                    </div>
                  ))}
                </div>
                <div className="flex items-center justify-between border-t border-border/50 pt-2 text-[11px]">
                  <span className="text-muted-foreground">Soma</span>
                  <span className="number-tabular font-bold">
                    {formatBRL(divValues.reduce((a, b) => a + b, 0))}
                  </span>
                </div>
              </div>
            )}
          </div>
          )}
        </aside>
      </div>

      {/* Filters + table */}
      <div className="space-y-4">
        <div className="glass-strong rounded-2xl p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="flex items-center gap-2 text-xs font-medium text-muted-foreground">
              <Filter className="h-4 w-4" /> Filtrar por período
            </div>
            <div className="ml-auto flex items-center gap-2">
              <span className="rounded-full bg-background/60 px-2.5 py-1 text-[11px] font-medium text-muted-foreground">
                {filtered.length} operação(ões)
              </span>
              <Button variant="outline" size="sm" onClick={exportCSV}>
                <Download className="mr-2 h-4 w-4" /> CSV
              </Button>
            </div>
          </div>

          <div className="mt-3 flex flex-wrap items-center gap-1.5">
            {(() => {
              const fmt = (d: Date) => {
                const y = d.getFullYear();
                const m = String(d.getMonth() + 1).padStart(2, "0");
                const da = String(d.getDate()).padStart(2, "0");
                return `${y}-${m}-${da}`;
              };
              const today = new Date();
              const yest = new Date(); yest.setDate(today.getDate() - 1);
              const d7 = new Date(); d7.setDate(today.getDate() - 6);
              const d30 = new Date(); d30.setDate(today.getDate() - 29);
              const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
              const lastMonthStart = new Date(today.getFullYear(), today.getMonth() - 1, 1);
              const lastMonthEnd = new Date(today.getFullYear(), today.getMonth(), 0);
              const presets: { label: string; from: string; to: string }[] = [
                { label: "Hoje", from: fmt(today), to: fmt(today) },
                { label: "Ontem", from: fmt(yest), to: fmt(yest) },
                { label: "7 dias", from: fmt(d7), to: fmt(today) },
                { label: "30 dias", from: fmt(d30), to: fmt(today) },
                { label: "Este mês", from: fmt(monthStart), to: fmt(today) },
                { label: "Mês passado", from: fmt(lastMonthStart), to: fmt(lastMonthEnd) },
              ];
              return presets.map((p) => {
                const active = from === p.from && to === p.to;
                return (
                  <Button
                    key={p.label}
                    type="button"
                    size="sm"
                    variant={active ? "default" : "secondary"}
                    className="h-7 rounded-full px-3 text-[11px]"
                    onClick={() => { setFrom(p.from); setTo(p.to); }}
                  >
                    {p.label}
                  </Button>
                );
              });
            })()}
            <Button
              type="button"
              size="sm"
              variant={!from && !to ? "default" : "ghost"}
              className="h-7 rounded-full px-3 text-[11px]"
              onClick={() => {
                setFrom("");
                setTo("");
                setTimeout(() => document.getElementById("from")?.focus(), 0);
              }}
            >
              Personalizar
            </Button>
          </div>

          <div className="mt-3 flex flex-wrap items-end gap-3 border-t border-border/40 pt-3">
            <div className="flex flex-col">
              <Label htmlFor="from" className="text-[10px] uppercase tracking-wider text-muted-foreground">De</Label>
              <Input id="from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="h-9 w-44" />
            </div>
            <div className="flex flex-col">
              <Label htmlFor="to" className="text-[10px] uppercase tracking-wider text-muted-foreground">Até</Label>
              <Input id="to" type="date" value={to} onChange={(e) => setTo(e.target.value)} className="h-9 w-44" />
            </div>
            {(from || to) && (
              <Button variant="ghost" size="sm" onClick={() => { setFrom(""); setTo(""); }}>
                <X className="mr-1 h-3 w-3" /> Limpar período
              </Button>
            )}
          </div>
        </div>

        <div className="glass-strong overflow-hidden rounded-2xl">
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="border-border hover:bg-transparent">
                  {isAdmin && <TableHead>Usuário</TableHead>}
                  <TableHead className="text-right">Depósito</TableHead>
                  <TableHead className="text-right">Saque</TableHead>
                  <TableHead className="text-right">Blog.</TableHead>
                  <TableHead className="text-right">Comissão</TableHead>
                  <TableHead className="text-right">Lucro ({lucroKind === "bruto" ? "Bruto" : "Líquido"})</TableHead>
                  <TableHead className="text-right">Contas (Dep/Saq/Sal)</TableHead>
                  <TableHead className="text-right">Com. Contas</TableHead>
                  <TableHead>Data</TableHead>
                  <TableHead className="text-right">Ações</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loading ? (
                  <TableRow>
                    <TableCell colSpan={isAdmin ? 10 : 9} className="text-center text-muted-foreground">
                      Carregando...
                    </TableCell>
                  </TableRow>
                ) : filtered.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={isAdmin ? 10 : 9} className="py-12 text-center text-muted-foreground">
                      Nenhuma operação encontrada.
                    </TableCell>
                  </TableRow>
                ) : (
                  pageItems.map((o) => (
                    <OperationRow
                      key={o.id}
                      o={o}
                      isAdmin={isAdmin}
                      profile={profiles[o.user_id]}
                      lucroKind={lucroKind}
                      onEdit={startEdit}
                      onDelete={onDelete}
                    />
                  ))
                )}
              </TableBody>
            </Table>
          </div>

          {filtered.length > 0 && (
            <div className="flex flex-wrap items-center justify-between gap-3 border-t border-border/40 px-4 py-3">
              <div className="flex items-center gap-2 text-xs text-muted-foreground">
                <span>
                  {(page - 1) * pageSize + 1}–{Math.min(page * pageSize, filtered.length)} de {filtered.length}
                </span>
                <select
                  value={pageSize}
                  onChange={(e) => setPageSize(Number(e.target.value))}
                  className="h-8 rounded-md border border-border bg-background px-2 text-xs"
                  aria-label="Operações por página"
                >
                  {[25, 50, 100, 200].map((n) => (
                    <option key={n} value={n}>
                      {n} por página
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex items-center gap-2">
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  disabled={page <= 1}
                  onClick={() => setPage((p) => Math.max(1, p - 1))}
                >
                  <ChevronLeft className="h-4 w-4" /> Anterior
                </Button>
                <span className="text-xs text-muted-foreground">
                  {page} / {pageCount}
                </span>
                <Button
                  type="button"
                  size="sm"
                  variant="ghost"
                  disabled={page >= pageCount}
                  onClick={() => setPage((p) => Math.min(pageCount, p + 1))}
                >
                  Próxima <ChevronRight className="h-4 w-4" />
                </Button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
