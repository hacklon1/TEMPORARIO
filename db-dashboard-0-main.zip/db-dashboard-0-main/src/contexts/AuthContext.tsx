import { createContext, useContext, useEffect, useState, type ReactNode } from "react";
import type { Session, User } from "@supabase/supabase-js";
import { supabase } from "@/integrations/supabase/client";

// "owner" é o valor gravado no banco; na tela ele aparece como "Dono".
type Role = "owner" | "admin" | "user" | null;

/** Categoria do Operador. Admin e DONO enxergam tudo, como o "bi". */
export type OperatorType = "bi" | "montante" | "contas";

type AuthContextValue = {
  user: User | null;
  session: Session | null;
  role: Role;
  loading: boolean;
  /** DONO herda todos os poderes de admin. */
  isAdmin: boolean;
  isDono: boolean;
  operatorType: OperatorType;
  /** Usuário de login. É o que aparece nas telas, no lugar do email. */
  username: string;
  signIn: (username: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
};

const AuthContext = createContext<AuthContextValue | undefined>(undefined);

async function readFunctionError(error: unknown): Promise<string> {
  try {
    const resp = (error as any)?.context?.response;
    if (resp && typeof resp.json === "function") {
      const body = await resp.clone().json();
      if (body?.error) return String(body.error);
    }
  } catch { /* ignore */ }
  return "Não foi possível entrar. Tente novamente.";
}

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<User | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [role, setRole] = useState<Role>(null);
  const [operatorType, setOperatorType] = useState<OperatorType>("bi");
  const [username, setUsername] = useState("");
  const [loading, setLoading] = useState(true);

  const loadProfile = async (uid: string) => {
    const { data } = await supabase
      .from("profiles")
      .select("operator_type, username")
      .eq("id", uid)
      .maybeSingle();
    setOperatorType((data?.operator_type as OperatorType) ?? "bi");
    setUsername(data?.username ?? "");
  };

  const loadRole = async (uid: string) => {
    const { data } = await supabase
      .from("user_roles")
      .select("role")
      .eq("user_id", uid)
      .order("role", { ascending: true })
      .limit(5);
    if (data?.some((r) => r.role === "owner")) setRole("owner");
    else if (data?.some((r) => r.role === "admin")) setRole("admin");
    else if (data && data.length > 0) setRole("user");
    else setRole(null);
  };

  useEffect(() => {
    // Subscribe FIRST, then check existing session
    const { data: sub } = supabase.auth.onAuthStateChange((_event, sess) => {
      setSession(sess);
      setUser(sess?.user ?? null);
      if (sess?.user) {
        // defer to avoid deadlock
        setTimeout(() => {
          loadRole(sess.user.id);
          loadProfile(sess.user.id);
        }, 0);
      } else {
        setRole(null);
        setOperatorType("bi");
        setUsername("");
      }
    });

    supabase.auth.getSession().then(({ data: { session: sess } }) => {
      setSession(sess);
      setUser(sess?.user ?? null);
      if (sess?.user) {
        Promise.all([loadRole(sess.user.id), loadProfile(sess.user.id)])
          .finally(() => setLoading(false));
      } else setLoading(false);
    });

    return () => sub.subscription.unsubscribe();
  }, []);

  // O Supabase Auth autentica por email. A edge function "login" traduz o
  // usuário para o email correspondente e devolve a sessão já autenticada.
  const signIn = async (username: string, password: string) => {
    const { data, error } = await supabase.functions.invoke("login", {
      body: { username, password },
    });

    if (data?.error) return { error: String(data.error) };
    if (error) {
      // Em respostas 4xx o supabase-js não entrega o corpo em `data`;
      // ele fica no contexto do erro.
      return { error: await readFunctionError(error) };
    }
    if (!data?.access_token || !data?.refresh_token) {
      return { error: "Usuário ou senha inválidos" };
    }

    const { error: sessionError } = await supabase.auth.setSession({
      access_token: data.access_token,
      refresh_token: data.refresh_token,
    });
    return { error: sessionError?.message ?? null };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
    setRole(null);
    setOperatorType("bi");
    setUsername("");
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        session,
        role,
        loading,
        isAdmin: role === "admin" || role === "owner",
        isDono: role === "owner",
        // Admin e DONO nunca são limitados por categoria.
        operatorType: role === "admin" || role === "owner" ? "bi" : operatorType,
        username,
        signIn,
        signOut,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used within AuthProvider");
  return ctx;
}
