import { useEffect, useMemo, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { Download, Filter, X, BarChart3, Target, TrendingUp, ChevronDown, ChevronRight, Heart, Save, History, Eraser, Undo2, Archive } from "lucide-react";

import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { RelatoriosExternos } from "@/components/RelatoriosExternos";
import { formatBRL, formatDate } from "@/lib/format";
import { toast } from "sonner";
import { Navigate } from "react-router-dom";

type Op = {
  id: string;
  user_id: string;
  deposito: number;
  saque: number;
  blogueira: number;
  comissao: number;
  comissao_contas: number;
  lucro: number;
  deposito_contas: number;
  saque_contas: number;
  salario_contas: number;
  nome_conta: string | null;
  data_operacao: string | null;
  created_at: string;
};


type ProfileMin = { id: string; nome: string; email: string };

type Aggregate = {
  user_id: string;
  nome: string;
  email: string;
  pedidos: number;
  deposito: number;
  saque: number;
  blogueira: number;
  lucro: number;
  lucroBruto: number;
  blogDia: number;
  blogSemana: number;
  comissaoBlog: number;
  comissaoContas: number;
};


const startOfDay = (d: Date) => {
  const x = new Date(d);
  if (x.getHours() < 5) x.setDate(x.getDate() - 1);
  x.setHours(5, 0, 0, 0);
  return x;
};
const startOfWeek = (d: Date) => {
  const x = startOfDay(d);
  const diff = (x.getDay() + 6) % 7;
  x.setDate(x.getDate() - diff);
  return x;
};

type ResetSnapshotItem = {
  operation_id: string;
  comissao: number;
  comissao_contas: number;
};

type CommissionReset = {
  id: string;
  user_id: string;
  reset_by: string | null;
  operations: ResetSnapshotItem[];
  total_comissao: number;
  total_comissao_contas: number;
  undone: boolean;
  undone_at: string | null;
  created_at: string;
};

export default function Reports() {
  const { isAdmin, loading: authLoading, user } = useAuth();
  const qc = useQueryClient();
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");
  const [userFilter, setUserFilter] = useState<string>("all");
  const [expanded, setExpanded] = useState<string | null>(null);
  const [lucroKind, setLucroKind] = useState<"liquido" | "bruto">("liquido");


  const { data: settings } = useQuery({
    queryKey: ["app-settings"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("meta_diaria_blogueira, meta_semanal_blogueira")
        .eq("id", 1)
        .maybeSingle();
      return data as { meta_diaria_blogueira: number; meta_semanal_blogueira: number } | null;
    },
  });

  const [metaDia, setMetaDia] = useState<string>("");
  const [metaSem, setMetaSem] = useState<string>("");
  useEffect(() => {
    if (settings) {
      setMetaDia(String(settings.meta_diaria_blogueira ?? 0));
      setMetaSem(String(settings.meta_semanal_blogueira ?? 0));
    }
  }, [settings]);

  const saveMetas = async () => {
    const { error } = await supabase
      .from("app_settings")
      .update({
        meta_diaria_blogueira: Number(metaDia) || 0,
        meta_semanal_blogueira: Number(metaSem) || 0,
      })
      .eq("id", 1);
    if (error) return toast.error("Erro ao salvar metas", { description: error.message });
    toast.success("Metas atualizadas");
    qc.invalidateQueries({ queryKey: ["app-settings"] });
  };

  const { data: ops = [], isLoading: loadingOps } = useQuery({
    queryKey: ["ops", "reports"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data } = await supabase
        .from("operations")
        .select("id, user_id, deposito, saque, blogueira, comissao, comissao_contas, lucro, deposito_contas, saque_contas, salario_contas, nome_conta, data_operacao, created_at")
        .order("created_at", { ascending: false });
      return (data ?? []).map((o: any) => ({
        ...o,
        deposito: Number(o.deposito),
        saque: Number(o.saque),
        blogueira: Number(o.blogueira),
        comissao: Number(o.comissao ?? 0),
        comissao_contas: Number(o.comissao_contas ?? 0),
        lucro: Number(o.lucro),
        deposito_contas: Number(o.deposito_contas ?? 0),
        saque_contas: Number(o.saque_contas ?? 0),
        salario_contas: Number(o.salario_contas ?? 0),
      })) as Op[];
    },

  });

  const { data: profiles = [], isLoading: loadingProfiles } = useQuery({
    queryKey: ["profiles"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data } = await supabase.from("profiles").select("id, nome, email");
      return (data ?? []) as ProfileMin[];
    },
  });

  // Admins e donos não recebem comissão — ficam fora do relatório de comissões.
  const { data: adminIds = [] } = useQuery({
    queryKey: ["admin-role-ids"],
    enabled: isAdmin,
    queryFn: async () => {
      const { data } = await supabase.from("user_roles").select("user_id, role");
      return (data ?? [])
        .filter((r: any) => r.role === "admin" || r.role === "owner")
        .map((r: any) => r.user_id as string);
    },
  });
  const adminIdSet = useMemo(() => new Set(adminIds), [adminIds]);

  const loading = loadingOps || loadingProfiles;

  useEffect(() => {
    if (!isAdmin) return;
    const channel = supabase
      .channel("reports-page")
      .on("postgres_changes", { event: "*", schema: "public", table: "operations" },
        () => qc.invalidateQueries({ queryKey: ["ops"] }))
      .subscribe();
    return () => { supabase.removeChannel(channel); };
  }, [isAdmin, qc]);

  const filteredOps = useMemo(() => {
    return ops.filter((o) => {
      const d = new Date(o.created_at);
      if (from && d < new Date(from)) return false;
      if (to) {
        const toD = new Date(to);
        toD.setHours(23, 59, 59, 999);
        if (d > toD) return false;
      }
      if (userFilter !== "all" && o.user_id !== userFilter) return false;
      return true;
    });
  }, [ops, from, to, userFilter]);

  const aggregates: Aggregate[] = useMemo(() => {
    const now = new Date();
    const sod = startOfDay(now);
    const sow = startOfWeek(now);
    const map = new Map<string, Aggregate>();
    const profMap: Record<string, ProfileMin> = {};
    profiles.forEach((p) => (profMap[p.id] = p));

    for (const o of filteredOps) {
      const cur = map.get(o.user_id) ?? {
        user_id: o.user_id,
        nome: profMap[o.user_id]?.nome ?? "—",
        email: profMap[o.user_id]?.email ?? "",
        pedidos: 0, deposito: 0, saque: 0, blogueira: 0, lucro: 0, lucroBruto: 0,
        blogDia: 0, blogSemana: 0, comissaoBlog: 0, comissaoContas: 0,
      };
      cur.pedidos += 1;
      cur.deposito += o.deposito + (o.deposito_contas || 0);
      cur.saque += o.saque + (o.saque_contas || 0);
      cur.blogueira += o.blogueira + (o.salario_contas || 0);
      const lucroContasOp = (o.saque_contas || 0) - (o.deposito_contas || 0) + (o.salario_contas || 0);
      cur.lucro += o.lucro + lucroContasOp;
      cur.lucroBruto += (o.saque - o.deposito) + ((o.saque_contas || 0) - (o.deposito_contas || 0));
      cur.comissaoBlog += o.comissao;
      cur.comissaoContas += o.comissao_contas;
      const d = new Date(o.created_at);
      if (d >= sod) cur.blogDia += o.blogueira + (o.salario_contas || 0);
      if (d >= sow) cur.blogSemana += o.blogueira + (o.salario_contas || 0);

      map.set(o.user_id, cur);
    }
    return Array.from(map.values()).sort((a, b) => (lucroKind === "bruto" ? b.lucroBruto - a.lucroBruto : b.lucro - a.lucro));
  }, [filteredOps, profiles, lucroKind]);


  const totals = useMemo(() => {
    return aggregates.reduce(
      (acc, a) => {
        acc.pedidos += a.pedidos;
        acc.deposito += a.deposito;
        acc.saque += a.saque;
        acc.blogueira += a.blogueira;
        acc.lucro += a.lucro;
        acc.lucroBruto += a.lucroBruto;
        acc.blogDia += a.blogDia;
        acc.blogSemana += a.blogSemana;
        acc.comissaoBlog += a.comissaoBlog;
        acc.comissaoContas += a.comissaoContas;
        return acc;
      },
      { pedidos: 0, deposito: 0, saque: 0, blogueira: 0, lucro: 0, lucroBruto: 0, blogDia: 0, blogSemana: 0, comissaoBlog: 0, comissaoContas: 0 },
    );
  }, [aggregates]);

  const md = Number(metaDia) || 0;
  const ms = Number(metaSem) || 0;

  // null = ocioso; user_id = zerando aquele usuário; "all" = zerando todos
  const [zeroing, setZeroing] = useState<string | null>(null);
  const opsComComissao = useMemo(
    () => filteredOps.filter((o) => !adminIdSet.has(o.user_id) && (o.comissao !== 0 || o.comissao_contas !== 0)),
    [filteredOps, adminIdSet],
  );

  const comissaoAggregates = useMemo(
    () => aggregates.filter((a) => !adminIdSet.has(a.user_id)),
    [aggregates, adminIdSet],
  );
  const comissaoTotals = useMemo(
    () =>
      comissaoAggregates.reduce(
        (acc, a) => {
          acc.blog += a.comissaoBlog;
          acc.contas += a.comissaoContas;
          return acc;
        },
        { blog: 0, contas: 0 },
      ),
    [comissaoAggregates],
  );

  // Cria o backup primeiro; só zera se o backup foi gravado com sucesso.
  const zerarComissoesDe = async (userId: string): Promise<number> => {
    const ops = opsComComissao.filter((o) => o.user_id === userId);
    if (ops.length === 0) return 0;

    const snapshot: ResetSnapshotItem[] = ops.map((o) => ({
      operation_id: o.id,
      comissao: o.comissao,
      comissao_contas: o.comissao_contas,
    }));
    const { error: bkErr } = await (supabase as any).from("commission_resets").insert({
      user_id: userId,
      reset_by: user?.id ?? null,
      operations: snapshot,
      total_comissao: ops.reduce((s, o) => s + o.comissao, 0),
      total_comissao_contas: ops.reduce((s, o) => s + o.comissao_contas, 0),
    });
    if (bkErr) throw new Error(`Falha ao criar backup — nada foi zerado. ${bkErr.message}`);

    const ids = ops.map((o) => o.id);
    const CHUNK = 200;
    for (let i = 0; i < ids.length; i += CHUNK) {
      const { error } = await supabase
        .from("operations")
        .update({ comissao: 0, comissao_contas: 0 })
        .in("id", ids.slice(i, i + CHUNK));
      if (error) throw new Error(`Backup criado, mas o zeramento falhou no meio: ${error.message}`);
    }
    return ids.length;
  };

  const zerarUsuario = async (userId: string, nome: string) => {
    setZeroing(userId);
    try {
      const n = await zerarComissoesDe(userId);
      if (n === 0) {
        toast.info(`Nenhuma comissão a zerar para ${nome} no período filtrado.`);
      } else {
        toast.success(`Comissões de ${nome} zeradas`, {
          description: `${n} operação(ões). Backup salvo — dá para desfazer abaixo.`,
        });
      }
      qc.invalidateQueries({ queryKey: ["ops"] });
      qc.invalidateQueries({ queryKey: ["commission_resets"] });
    } catch (e: any) {
      toast.error("Erro ao zerar comissões", { description: e.message });
    } finally {
      setZeroing(null);
    }
  };

  const zerarTodos = async () => {
    setZeroing("all");
    try {
      const userIds = Array.from(new Set(opsComComissao.map((o) => o.user_id)));
      let total = 0;
      for (const uid of userIds) total += await zerarComissoesDe(uid);
      toast.success("Comissões zeradas", {
        description: `${total} operação(ões) de ${userIds.length} usuário(s). Um backup por usuário foi salvo.`,
      });
      qc.invalidateQueries({ queryKey: ["ops"] });
      qc.invalidateQueries({ queryKey: ["commission_resets"] });
    } catch (e: any) {
      toast.error("Erro ao zerar comissões", { description: e.message });
      qc.invalidateQueries({ queryKey: ["ops"] });
      qc.invalidateQueries({ queryKey: ["commission_resets"] });
    } finally {
      setZeroing(null);
    }
  };

  const exportCSV = () => {
    const headers = ["Usuário","Email","Pedidos","Depósito","Saque","Blogueira","Lucro","Blog. Hoje","Blog. Semana"];
    const rows = aggregates.map((a) => [
      a.nome, a.email, a.pedidos,
      a.deposito.toFixed(2), a.saque.toFixed(2), a.blogueira.toFixed(2), a.lucro.toFixed(2),
      a.blogDia.toFixed(2), a.blogSemana.toFixed(2),
    ]);
    const csv = [headers, ...rows]
      .map((r) => r.map((c) => `"${String(c).replace(/"/g, '""')}"`).join(","))
      .join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `relatorio-usuarios-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast.success("Relatório exportado");
  };

  if (!authLoading && !isAdmin) return <Navigate to="/" replace />;

  return (
    <div className="space-y-6 animate-fade-in">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold md:text-3xl">Relatórios por usuário</h1>
          <p className="text-sm text-muted-foreground">
            Salário arrecadado das blogueiras, lucro e progresso de metas.
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="inline-flex rounded-full bg-background/60 p-1 ring-1 ring-border">
            <button type="button" onClick={() => setLucroKind("liquido")}
              className={`rounded-full px-3 py-1 text-[11px] font-semibold transition ${lucroKind === "liquido" ? "bg-gradient-primary text-primary-foreground shadow-glow" : "text-muted-foreground"}`}>
              Líquido
            </button>
            <button type="button" onClick={() => setLucroKind("bruto")}
              className={`rounded-full px-3 py-1 text-[11px] font-semibold transition ${lucroKind === "bruto" ? "bg-gradient-primary text-primary-foreground shadow-glow" : "text-muted-foreground"}`}>
              Bruto
            </button>
          </div>
          <Button variant="outline" size="sm" onClick={exportCSV}>
            <Download className="mr-2 h-4 w-4" /> Exportar CSV
          </Button>
        </div>
      </div>


      {/* Relatórios do coletor externo */}
      <RelatoriosExternos />

      {/* Metas blogueiras */}
      <div className="glass-strong rounded-2xl p-4">
        <div className="mb-3 flex items-center gap-2">
          <Heart className="h-4 w-4 text-destructive" />
          <h2 className="text-sm font-bold uppercase tracking-wider">Metas — Salário das blogueiras</h2>
        </div>
        <div className="flex flex-wrap items-end gap-3">
          <div className="flex flex-col">
            <Label className="text-xs">Meta diária (R$)</Label>
            <Input type="number" value={metaDia} onChange={(e) => setMetaDia(e.target.value)} className="h-9 w-40" />
          </div>
          <div className="flex flex-col">
            <Label className="text-xs">Meta semanal (R$)</Label>
            <Input type="number" value={metaSem} onChange={(e) => setMetaSem(e.target.value)} className="h-9 w-40" />
          </div>
          <Button size="sm" onClick={saveMetas} className="bg-gradient-primary shadow-glow">
            <Save className="h-4 w-4" /> Salvar metas
          </Button>
        </div>
      </div>

      {/* Filtros */}
      <div className="glass-strong flex flex-wrap items-end gap-3 rounded-2xl p-4">
        <Filter className="h-4 w-4 text-muted-foreground" />
        <div className="flex flex-col">
          <Label htmlFor="from" className="text-xs">De</Label>
          <Input id="from" type="date" value={from} onChange={(e) => setFrom(e.target.value)} className="h-9 w-40" />
        </div>
        <div className="flex flex-col">
          <Label htmlFor="to" className="text-xs">Até</Label>
          <Input id="to" type="date" value={to} onChange={(e) => setTo(e.target.value)} className="h-9 w-40" />
        </div>
        <div className="flex flex-col">
          <Label className="text-xs">Usuário</Label>
          <Select value={userFilter} onValueChange={setUserFilter}>
            <SelectTrigger className="h-9 w-56"><SelectValue placeholder="Todos" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Todos os usuários</SelectItem>
              {profiles.map((p) => (
                <SelectItem key={p.id} value={p.id}>{p.nome} — {p.email}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        {(from || to || userFilter !== "all") && (
          <Button variant="ghost" size="sm" onClick={() => { setFrom(""); setTo(""); setUserFilter("all"); }}>
            <X className="mr-1 h-3 w-3" /> Limpar
          </Button>
        )}
      </div>

      {/* Totais */}
      <div className="grid gap-4 md:grid-cols-4">
        <div className="glass-strong rounded-2xl p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><BarChart3 className="h-3 w-3" /> Pedidos</div>
          <div className="mt-1 text-2xl font-bold number-tabular">{totals.pedidos}</div>
        </div>
        <div className="glass-strong rounded-2xl p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><TrendingUp className="h-3 w-3" /> Lucro total ({lucroKind === "bruto" ? "Bruto" : "Líquido"})</div>
          {(() => { const v = lucroKind === "bruto" ? totals.lucroBruto : totals.lucro; return (
            <div className={`mt-1 text-2xl font-bold number-tabular ${v >= 0 ? "text-success" : "text-destructive"}`}>{formatBRL(v)}</div>
          ); })()}
        </div>
        <div className="glass-strong rounded-2xl p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><Target className="h-3 w-3" /> Blogueiras hoje</div>
          <div className="mt-1 text-2xl font-bold number-tabular">{formatBRL(totals.blogDia)}</div>
          {md > 0 && (
            <div className="mt-2 space-y-1">
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-background/60">
                <div className="h-full bg-gradient-primary" style={{ width: `${Math.min(100, (totals.blogDia / md) * 100)}%` }} />
              </div>
              <div className="text-[11px] text-muted-foreground">
                {((totals.blogDia / md) * 100).toFixed(1)}% de {formatBRL(md)}
              </div>
            </div>
          )}
        </div>
        <div className="glass-strong rounded-2xl p-4">
          <div className="flex items-center gap-2 text-xs text-muted-foreground"><Target className="h-3 w-3" /> Blogueiras semana</div>
          <div className="mt-1 text-2xl font-bold number-tabular">{formatBRL(totals.blogSemana)}</div>
          {ms > 0 && (
            <div className="mt-2 space-y-1">
              <div className="h-1.5 w-full overflow-hidden rounded-full bg-background/60">
                <div className="h-full bg-gradient-primary" style={{ width: `${Math.min(100, (totals.blogSemana / ms) * 100)}%` }} />
              </div>
              <div className="text-[11px] text-muted-foreground">
                {((totals.blogSemana / ms) * 100).toFixed(1)}% de {formatBRL(ms)}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Comissão a pagar */}
      <div className="glass-strong space-y-3 rounded-2xl border border-warning/30 bg-gradient-to-br from-warning/5 to-transparent p-4">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <TrendingUp className="h-4 w-4 text-warning" />
            <h2 className="text-sm font-bold uppercase tracking-wider text-warning">Comissão a pagar (período filtrado)</h2>
          </div>
          <div className="flex flex-wrap items-center gap-1.5">
            {(() => {
              const fmt = (d: Date) => `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`;
              const today = new Date();
              const d7 = new Date(); d7.setDate(today.getDate()-6);
              const monthStart = new Date(today.getFullYear(), today.getMonth(), 1);
              const presets = [
                { label: "Hoje", from: fmt(today), to: fmt(today) },
                { label: "7 dias", from: fmt(d7), to: fmt(today) },
                { label: "Mês", from: fmt(monthStart), to: fmt(today) },
              ];
              return presets.map(p => (
                <Button key={p.label} size="sm" variant={from === p.from && to === p.to ? "default" : "secondary"}
                  className="h-7 rounded-full px-3 text-[11px]"
                  onClick={() => { setFrom(p.from); setTo(p.to); }}>
                  {p.label}
                </Button>
              ));
            })()}
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button size="sm" variant="destructive" className="h-7 rounded-full px-3 text-[11px]"
                  disabled={zeroing !== null || opsComComissao.length === 0}>
                  <Eraser className="mr-1 h-3 w-3" /> {zeroing === "all" ? "Zerando..." : "Zerar todas"}
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Zerar as comissões de todos os operadores?</AlertDialogTitle>
                  <AlertDialogDescription>
                    Isso vai zerar a Comissão Blogueira e a Comissão Contas de{" "}
                    <strong>{opsComComissao.length} operação(ões)</strong> do período filtrado,
                    totalizando <strong>{formatBRL(comissaoTotals.blog + comissaoTotals.contas)}</strong>.
                    Um backup por usuário será salvo e você poderá desfazer na seção
                    "Backups de comissões zeradas".
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancelar</AlertDialogCancel>
                  <AlertDialogAction onClick={zerarTodos} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                    Zerar todas
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
          </div>
        </div>
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="rounded-xl border border-border bg-background/40 p-3">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Comissão Blogueira</p>
            <p className="number-tabular mt-1 text-xl font-bold text-warning">{formatBRL(comissaoTotals.blog)}</p>
          </div>
          <div className="rounded-xl border border-border bg-background/40 p-3">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Comissão Contas</p>
            <p className="number-tabular mt-1 text-xl font-bold text-warning">{formatBRL(comissaoTotals.contas)}</p>
          </div>
          <div className="rounded-xl border border-warning/40 bg-warning/10 p-3">
            <p className="text-[10px] uppercase tracking-wider text-muted-foreground">Total a pagar</p>
            <p className="number-tabular mt-1 text-xl font-bold text-warning">{formatBRL(comissaoTotals.blog + comissaoTotals.contas)}</p>
          </div>
        </div>
        <div className="overflow-x-auto rounded-xl border border-border/40">
          <Table>
            <TableHeader>
              <TableRow className="border-border bg-background/40">
                <TableHead>Usuário</TableHead>
                <TableHead className="text-right">Com. Blogueira</TableHead>
                <TableHead className="text-right">Com. Contas</TableHead>
                <TableHead className="text-right">Total</TableHead>
                <TableHead className="w-24 text-right">Ações</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {comissaoAggregates.length === 0 ? (
                <TableRow><TableCell colSpan={5} className="py-6 text-center text-muted-foreground">Sem dados no período.</TableCell></TableRow>
              ) : comissaoAggregates.map(a => {
                const nOps = opsComComissao.filter((o) => o.user_id === a.user_id).length;
                return (
                <TableRow key={`com-${a.user_id}`} className="border-border/40">
                  <TableCell className="text-sm">
                    <div className="font-medium">{a.nome}</div>
                    <div className="text-xs text-muted-foreground">{a.email}</div>
                  </TableCell>
                  <TableCell className="number-tabular text-right text-warning">{formatBRL(a.comissaoBlog)}</TableCell>
                  <TableCell className="number-tabular text-right text-warning">{formatBRL(a.comissaoContas)}</TableCell>
                  <TableCell className="number-tabular text-right font-bold">{formatBRL(a.comissaoBlog + a.comissaoContas)}</TableCell>
                  <TableCell className="text-right">
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button size="sm" variant="destructive" className="h-7 rounded-full px-3 text-[11px]"
                          disabled={zeroing !== null || nOps === 0}>
                          <Eraser className="mr-1 h-3 w-3" /> {zeroing === a.user_id ? "Zerando..." : "Zerar"}
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Zerar as comissões de {a.nome}?</AlertDialogTitle>
                          <AlertDialogDescription>
                            Isso vai zerar a Comissão Blogueira ({formatBRL(a.comissaoBlog)}) e a
                            Comissão Contas ({formatBRL(a.comissaoContas)}) de{" "}
                            <strong>{nOps} operação(ões)</strong> de {a.nome} no período filtrado —
                            total de <strong>{formatBRL(a.comissaoBlog + a.comissaoContas)}</strong>.
                            Um backup será salvo e você poderá desfazer na seção
                            "Backups de comissões zeradas".
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancelar</AlertDialogCancel>
                          <AlertDialogAction onClick={() => zerarUsuario(a.user_id, a.nome)} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
                            Zerar comissões
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
                );
              })}
            </TableBody>
          </Table>
        </div>
      </div>

      <CommissionBackupsSection profiles={profiles} busy={zeroing !== null} />

      {/* Tabela por usuário */}
      <div className="glass-strong overflow-hidden rounded-2xl">
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead></TableHead>
                <TableHead>Usuário</TableHead>
                <TableHead className="text-right">Pedidos</TableHead>
                <TableHead className="text-right">Depósito</TableHead>
                <TableHead className="text-right">Saque</TableHead>
                <TableHead className="text-right">Blogueira</TableHead>
                <TableHead className="text-right">Lucro</TableHead>
                <TableHead className="text-right">Blog. Hoje</TableHead>
                <TableHead className="text-right">Blog. Semana</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {loading ? (
                <TableRow><TableCell colSpan={9} className="text-center text-muted-foreground">Carregando...</TableCell></TableRow>
              ) : aggregates.length === 0 ? (
                <TableRow><TableCell colSpan={9} className="py-12 text-center text-muted-foreground">Nenhum dado encontrado.</TableCell></TableRow>
              ) : (
                aggregates.map((a) => {
                  const isOpen = expanded === a.user_id;
                  const userOps = filteredOps.filter((o) => o.user_id === a.user_id);
                  return (
                    <>
                      <TableRow
                        key={a.user_id}
                        className="cursor-pointer border-border/60 hover:bg-muted/30"
                        onClick={() => setExpanded(isOpen ? null : a.user_id)}
                      >
                        <TableCell className="w-8">
                          {isOpen ? <ChevronDown className="h-4 w-4 text-primary" /> : <ChevronRight className="h-4 w-4 text-muted-foreground" />}
                        </TableCell>
                        <TableCell className="text-sm">
                          <div className="font-medium">{a.nome}</div>
                          <div className="text-xs text-muted-foreground">{a.email}</div>
                        </TableCell>
                        <TableCell className="number-tabular text-right">{a.pedidos}</TableCell>
                        <TableCell className="number-tabular text-right text-warning">{formatBRL(a.deposito)}</TableCell>
                        <TableCell className="number-tabular text-right">{formatBRL(a.saque)}</TableCell>
                        <TableCell className="number-tabular text-right">{formatBRL(a.blogueira)}</TableCell>
                        {(() => { const v = lucroKind === "bruto" ? a.lucroBruto : a.lucro; return (
                          <TableCell className={`number-tabular text-right font-bold ${v >= 0 ? "text-success" : "text-destructive"}`}>
                            {formatBRL(v)}
                          </TableCell>
                        ); })()}
                        <TableCell className="number-tabular text-right">{formatBRL(a.blogDia)}</TableCell>
                        <TableCell className="number-tabular text-right">{formatBRL(a.blogSemana)}</TableCell>
                      </TableRow>
                      {isOpen && (
                        <TableRow key={`${a.user_id}-detail`} className="bg-muted/20 hover:bg-muted/20">
                          <TableCell colSpan={9} className="p-4">
                            <div className="space-y-2">
                              <div className="flex items-center justify-between">
                                <h3 className="text-sm font-bold">
                                  Histórico de operações — {a.nome}
                                </h3>
                                <span className="text-[11px] text-muted-foreground">
                                  {userOps.length} operação(ões)
                                </span>
                              </div>
                              <div className="max-h-96 overflow-auto rounded-lg border border-border/40">
                                <Table>
                                  <TableHeader>
                                    <TableRow className="border-border bg-background/40">
                                      <TableHead>Data</TableHead>
                                      <TableHead>Conta</TableHead>
                                      <TableHead className="text-right">Depósito</TableHead>
                                      <TableHead className="text-right">Saque</TableHead>
                                      <TableHead className="text-right">Blog.</TableHead>
                                      <TableHead className="text-right">Comissão</TableHead>
                                      <TableHead className="text-right">Lucro</TableHead>
                                    </TableRow>
                                  </TableHeader>
                                  <TableBody>
                                    {userOps.length === 0 ? (
                                      <TableRow>
                                        <TableCell colSpan={7} className="py-6 text-center text-muted-foreground">
                                          Sem operações no período.
                                        </TableCell>
                                      </TableRow>
                                    ) : (
                                      userOps.map((o) => {
                                        const depTot = o.deposito + (o.deposito_contas || 0);
                                        const saqTot = o.saque + (o.saque_contas || 0);
                                        const blogTot = o.blogueira + (o.salario_contas || 0);
                                        const comTot = o.comissao + (o.comissao_contas || 0);
                                        const lucroContas = (o.saque_contas || 0) - (o.deposito_contas || 0) + (o.salario_contas || 0);
                                        const lucroTotLiq = o.lucro + lucroContas;
                                        const lucroTotBr = (o.saque - o.deposito) + ((o.saque_contas || 0) - (o.deposito_contas || 0));
                                        const v = lucroKind === "bruto" ? lucroTotBr : lucroTotLiq;
                                        return (
                                          <TableRow key={o.id} className="border-border/40">
                                            <TableCell className="text-xs text-muted-foreground">
                                              {formatDate(o.data_operacao || o.created_at)}
                                            </TableCell>
                                            <TableCell className="text-xs">{o.nome_conta ?? "—"}</TableCell>
                                            <TableCell className="number-tabular text-right text-xs text-warning">{formatBRL(depTot)}</TableCell>
                                            <TableCell className="number-tabular text-right text-xs text-success">{formatBRL(saqTot)}</TableCell>
                                            <TableCell className="number-tabular text-right text-xs">{formatBRL(blogTot)}</TableCell>
                                            <TableCell className="number-tabular text-right text-xs text-warning">{formatBRL(comTot)}</TableCell>
                                            <TableCell className={`number-tabular text-right text-xs font-bold ${v >= 0 ? "text-success" : "text-destructive"}`}>
                                              {formatBRL(v)}
                                            </TableCell>
                                          </TableRow>
                                        );
                                      })

                                    )}
                                  </TableBody>
                                </Table>
                              </div>
                            </div>
                          </TableCell>
                        </TableRow>
                      )}
                    </>
                  );
                })
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      <AuditLogSection profiles={profiles} />
    </div>
  );
}

function CommissionBackupsSection({ profiles, busy }: { profiles: ProfileMin[]; busy: boolean }) {
  const qc = useQueryClient();
  const [undoing, setUndoing] = useState<string | null>(null);

  const { data: resets = [], isLoading } = useQuery({
    queryKey: ["commission_resets"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("commission_resets")
        .select("id, user_id, reset_by, operations, total_comissao, total_comissao_contas, undone, undone_at, created_at")
        .order("created_at", { ascending: false })
        .limit(100);
      if (error) throw error;
      return (data ?? []).map((r: any) => ({
        ...r,
        total_comissao: Number(r.total_comissao),
        total_comissao_contas: Number(r.total_comissao_contas),
        operations: (r.operations ?? []) as ResetSnapshotItem[],
      })) as CommissionReset[];
    },
  });

  const nameOf = (id: string | null) => {
    if (!id) return "—";
    const p = profiles.find((x) => x.id === id);
    return p ? p.nome : id.slice(0, 8);
  };

  const desfazer = async (r: CommissionReset) => {
    setUndoing(r.id);
    try {
      let restored = 0;
      let missing = 0;
      for (const item of r.operations) {
        const { data, error } = await supabase
          .from("operations")
          .update({ comissao: item.comissao, comissao_contas: item.comissao_contas })
          .eq("id", item.operation_id)
          .select("id");
        if (error) throw new Error(`Restauração interrompida: ${error.message}`);
        if (data && data.length > 0) restored += 1;
        else missing += 1;
      }
      const { error: mkErr } = await (supabase as any)
        .from("commission_resets")
        .update({ undone: true, undone_at: new Date().toISOString() })
        .eq("id", r.id);
      if (mkErr) throw new Error(`Comissões restauradas, mas falhou ao marcar o backup: ${mkErr.message}`);
      toast.success(`Comissões de ${nameOf(r.user_id)} restauradas`, {
        description: `${restored} operação(ões) restaurada(s)${missing > 0 ? `; ${missing} não encontrada(s) (apagadas depois do zeramento)` : ""}.`,
      });
      qc.invalidateQueries({ queryKey: ["ops"] });
      qc.invalidateQueries({ queryKey: ["commission_resets"] });
    } catch (e: any) {
      toast.error("Erro ao desfazer", { description: e.message });
      qc.invalidateQueries({ queryKey: ["ops"] });
    } finally {
      setUndoing(null);
    }
  };

  return (
    <div className="glass-strong space-y-3 rounded-2xl p-4">
      <div className="flex items-center gap-2">
        <Archive className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-bold uppercase tracking-wider">Backups de comissões zeradas</h2>
        <span className="ml-auto text-[11px] text-muted-foreground">somente admin</span>
      </div>
      <div className="overflow-x-auto rounded-xl border border-border/40">
        <Table>
          <TableHeader>
            <TableRow className="border-border bg-background/40">
              <TableHead>Quando</TableHead>
              <TableHead>Usuário</TableHead>
              <TableHead>Zerado por</TableHead>
              <TableHead className="text-right">Com. Blogueira</TableHead>
              <TableHead className="text-right">Com. Contas</TableHead>
              <TableHead className="text-right">Total</TableHead>
              <TableHead>Status</TableHead>
              <TableHead className="w-28 text-right">Ação</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={8} className="py-6 text-center text-muted-foreground">Carregando...</TableCell></TableRow>
            ) : resets.length === 0 ? (
              <TableRow><TableCell colSpan={8} className="py-6 text-center text-muted-foreground">Nenhum zeramento registrado ainda.</TableCell></TableRow>
            ) : (
              resets.map((r) => (
                <TableRow key={r.id} className="border-border/40">
                  <TableCell className="text-xs text-muted-foreground">{formatDate(r.created_at)}</TableCell>
                  <TableCell className="text-xs font-medium">{nameOf(r.user_id)}</TableCell>
                  <TableCell className="text-xs">{nameOf(r.reset_by)}</TableCell>
                  <TableCell className="number-tabular text-right text-xs text-warning">{formatBRL(r.total_comissao)}</TableCell>
                  <TableCell className="number-tabular text-right text-xs text-warning">{formatBRL(r.total_comissao_contas)}</TableCell>
                  <TableCell className="number-tabular text-right text-xs font-bold">{formatBRL(r.total_comissao + r.total_comissao_contas)}</TableCell>
                  <TableCell>
                    <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${r.undone ? "bg-success/15 text-success" : "bg-warning/15 text-warning"}`}>
                      {r.undone ? "DESFEITO" : "ATIVO"}
                    </span>
                  </TableCell>
                  <TableCell className="text-right">
                    {!r.undone && (
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button size="sm" variant="outline" className="h-7 rounded-full px-3 text-[11px]"
                            disabled={busy || undoing !== null}>
                            <Undo2 className="mr-1 h-3 w-3" /> {undoing === r.id ? "Desfazendo..." : "Desfazer"}
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Desfazer o zeramento de {nameOf(r.user_id)}?</AlertDialogTitle>
                            <AlertDialogDescription>
                              As comissões de <strong>{r.operations.length} operação(ões)</strong> voltarão
                              aos valores de antes do zeramento de {formatDate(r.created_at)} —
                              total de <strong>{formatBRL(r.total_comissao + r.total_comissao_contas)}</strong>.
                              Se alguma operação foi editada depois, o valor dela também volta ao do backup.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancelar</AlertDialogCancel>
                            <AlertDialogAction onClick={() => desfazer(r)}>
                              Restaurar comissões
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    )}
                  </TableCell>
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

function AuditLogSection({ profiles }: { profiles: ProfileMin[] }) {
  const { data: audits = [], isLoading } = useQuery({
    queryKey: ["operation_audit"],
    queryFn: async () => {
      const { data, error } = await (supabase as any)
        .from("operation_audit")
        .select("id, operation_id, user_id, acao, snapshot, changed_by, changed_at")
        .order("changed_at", { ascending: false })
        .limit(200);
      if (error) throw error;
      return data ?? [];
    },
  });
  const nameOf = (id: string | null) => {
    if (!id) return "—";
    const p = profiles.find((x) => x.id === id);
    return p ? p.nome : id.slice(0, 8);
  };
  return (
    <div className="glass-strong space-y-3 rounded-2xl p-4">
      <div className="flex items-center gap-2">
        <History className="h-4 w-4 text-primary" />
        <h2 className="text-sm font-bold uppercase tracking-wider">Log de alterações</h2>
        <span className="ml-auto text-[11px] text-muted-foreground">somente admin</span>
      </div>
      <div className="overflow-x-auto rounded-xl border border-border/40">
        <Table>
          <TableHeader>
            <TableRow className="border-border bg-background/40">
              <TableHead>Quando</TableHead>
              <TableHead>Ação</TableHead>
              <TableHead>Operação de</TableHead>
              <TableHead>Por</TableHead>
              <TableHead className="text-right">Lucro</TableHead>
              <TableHead className="text-right">Depósito</TableHead>
              <TableHead className="text-right">Saque</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody>
            {isLoading ? (
              <TableRow><TableCell colSpan={7} className="py-6 text-center text-muted-foreground">Carregando...</TableCell></TableRow>
            ) : audits.length === 0 ? (
              <TableRow><TableCell colSpan={7} className="py-6 text-center text-muted-foreground">Nenhuma alteração registrada.</TableCell></TableRow>
            ) : (
              audits.map((a: any) => {
                const s = a.snapshot ?? {};
                return (
                  <TableRow key={a.id} className="border-border/40">
                    <TableCell className="text-xs text-muted-foreground">{formatDate(a.changed_at)}</TableCell>
                    <TableCell>
                      <span className={`rounded-full px-2 py-0.5 text-[10px] font-semibold ${a.acao === "APAGADA" ? "bg-destructive/15 text-destructive" : "bg-warning/15 text-warning"}`}>
                        {a.acao}
                      </span>
                    </TableCell>
                    <TableCell className="text-xs">{nameOf(a.user_id)}</TableCell>
                    <TableCell className="text-xs">{nameOf(a.changed_by)}</TableCell>
                    <TableCell className="number-tabular text-right text-xs">{formatBRL(Number(s.lucro ?? 0))}</TableCell>
                    <TableCell className="number-tabular text-right text-xs">{formatBRL(Number(s.deposito ?? 0))}</TableCell>
                    <TableCell className="number-tabular text-right text-xs">{formatBRL(Number(s.saque ?? 0))}</TableCell>
                  </TableRow>
                );
              })
            )}
          </TableBody>
        </Table>
      </div>
    </div>
  );
}

