-- Cria a conta DONO inicial: ELIOT.
--
-- Como o login agora é por usuário, o email é só encanamento interno do
-- Supabase Auth e nunca aparece na tela.
--
-- Idempotente: se a conta já existir, só garante o papel de DONO.

DO $$
DECLARE
  uid UUID;
  senha TEXT := 'SENHAHACKAVEL';
  login_email TEXT := 'eliot@db.local';
BEGIN
  SELECT id INTO uid FROM auth.users WHERE email = login_email;

  IF uid IS NULL THEN
    uid := gen_random_uuid();

    INSERT INTO auth.users (
      instance_id,
      id,
      aud,
      role,
      email,
      encrypted_password,
      email_confirmed_at,
      raw_app_meta_data,
      raw_user_meta_data,
      created_at,
      updated_at
    ) VALUES (
      '00000000-0000-0000-0000-000000000000',
      uid,
      'authenticated',
      'authenticated',
      login_email,
      extensions.crypt(senha, extensions.gen_salt('bf')),
      now(),
      '{"provider":"email","providers":["email"]}'::jsonb,
      '{"nome":"ELIOT","username":"eliot"}'::jsonb,
      now(),
      now()
    );
    -- O trigger on_auth_user_created já criou o profile e o papel 'user'.
  END IF;

  UPDATE public.profiles
     SET nome = 'ELIOT',
         username = 'eliot'
   WHERE id = uid;

  DELETE FROM public.user_roles WHERE user_id = uid;
  INSERT INTO public.user_roles (user_id, role) VALUES (uid, 'owner');
END $$;
