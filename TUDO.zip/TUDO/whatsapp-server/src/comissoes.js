/* Comissão COBRADA dos Operadores.
 *
 * O que é: o Operador recebe da Brogueira um salário por serviço — é o
 * `💸 Valor: R$ x` da mensagem que ele manda para ela:
 *
 *     ━━━━━━━━━━━━━━━
 *     🔸 Montante: 500
 *     💸 Valor: R$ 100,00
 *     📊 Até 1 conta
 *     ━━━━━━━━━━━━━━━
 *     ⚡ Envio após confirmação do pagamento
 *     📩 Envie o comprovante para dar continuidade
 *
 * A casa cobra dele uma porcentagem desse salário — escolhida por Operador
 * (15% sobre R$ 100 = R$ 15). O parser já separa esse `Valor` do `Montante` e
 * o guarda no serviço como `atendimento.contasTotal`; aqui ele só é somado.
 *
 * ── As duas regras que definem tudo ─────────────────────────────────────
 * 1. SÓ SERVIÇO VALIDADO É COBRADO. Enquanto a Brogueira não manda o
 *    comprovante (passo 3), o Operador não recebeu — cobrar comissão de um
 *    serviço que pode expirar seria cobrar do que não existe.
 * 2. A BASE É O SALÁRIO, NÃO O MONTANTE. O montante é o dinheiro do jogo, que
 *    passa pelo Operador; o `Valor` é o que fica com ele. A porcentagem incide
 *    sobre o que ele ganhou.
 *
 * O que já foi cobrado vira um registro em `comissoesCobradas` com a lista de
 * serviços — é o que impede a mesma validação de ser cobrada duas vezes e o
 * que o "Desfazer" usa para voltar atrás.
 */
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';
import timezone from 'dayjs/plugin/timezone.js';
import { getDb, saveDb } from './db.js';
import { filtrarServicos, dayKey, salarioDoAtendimento } from './store.js';
import { metas } from './operacoes.js';
import { STATUS, ROTULO_STATUS } from './servicos.js';

dayjs.extend(utc);
dayjs.extend(timezone);

const num = (v, padrao = 0) => (Number.isFinite(Number(v)) ? Number(v) : padrao);
const cent = (v) => Math.round(num(v) * 100) / 100;

/**
 * O salário do Operador naquele serviço: o que ele cobrou na mensagem dele —
 * o "Valor: R$ x" quando existe, senão o "💸 R$ x" solto do template mais
 * usado. Ver salarioDoAtendimento()/extractSalario().
 */
export const salarioDoServico = (sv) => cent(salarioDoAtendimento(sv?.atendimento));

/**
 * O MONTANTE que o Operador pegou naquele serviço — o `🔸 Montante` da mesma
 * mensagem. É o dinheiro do jogo, que passa por ele; não é a base da comissão
 * (essa é o salário), mas é o volume da operação: quanto foi movimentado e
 * confirmado no dia.
 */
export const montanteDoServico = (sv) => cent(sv?.atendimento?.montante);

/** Só o que fechou os 3 passos entra na cobrança. */
export const cobravel = (sv) => sv?.status === (STATUS?.VALIDADO ?? 'validado') && Boolean(sv?.atendimento);

/* ═══════════ Configuração da porcentagem ═══════════ */

export function configComissoes() {
  const c = getDb().comissoesConfig ?? {};
  return {
    padraoPct: num(c.padraoPct),
    porOperador: { ...(c.porOperador ?? {}) },
    // Apelido: o nome que o WhatsApp entrega é o pushName da pessoa ("🥷🏻",
    // ".", "Jota$") — ilegível num relatório. O apelido é só de exibição:
    // nada é reescrito no histórico, e limpar devolve o nome original.
    apelidos: { ...(c.apelidos ?? {}) },
    // Isento: não é cobrado e não aparece no quadro. Some do relatório, mas
    // continua no histórico e na tela de ajuste (senão não teria como voltar).
    isentos: { ...(c.isentos ?? {}) },
  };
}

function garantirConfig() {
  const db = getDb();
  if (!db.comissoesConfig || typeof db.comissoesConfig !== 'object') db.comissoesConfig = {};
  const c = db.comissoesConfig;
  if (!c.porOperador || typeof c.porOperador !== 'object') c.porOperador = {};
  if (!c.apelidos || typeof c.apelidos !== 'object') c.apelidos = {};
  if (!c.isentos || typeof c.isentos !== 'object') c.isentos = {};
  return c;
}

/** O nome que vai para a tela: o apelido escolhido, ou o que veio do WhatsApp. */
export function nomeDeExibicao(operadorId, nomeOriginal) {
  const apelido = configComissoes().apelidos[operadorId];
  return (apelido && String(apelido).trim()) || nomeOriginal || 'desconhecido';
}

export function definirApelido({ operadorId, apelido }) {
  if (!operadorId) throw new Error('informe o operador');
  const c = garantirConfig();
  const limpo = String(apelido ?? '').trim().slice(0, 40);
  if (limpo) c.apelidos[operadorId] = limpo;
  else delete c.apelidos[operadorId];   // vazio = volta ao nome do WhatsApp
  saveDb();
  return configComissoes();
}

export const isento = (operadorId) => configComissoes().isentos[operadorId] === true;

export function definirIsento({ operadorId, isento: valor }) {
  if (!operadorId) throw new Error('informe o operador');
  const c = garantirConfig();
  if (valor) c.isentos[operadorId] = true;
  else delete c.isentos[operadorId];
  saveDb();
  return configComissoes();
}

/** A porcentagem de um Operador: a dele, ou o padrão da casa. */
export function pctDoOperador(operadorId) {
  const c = configComissoes();
  const propria = c.porOperador[operadorId];
  return propria === undefined || propria === null ? c.padraoPct : num(propria);
}

export function definirPct({ operadorId = null, pct }) {
  const valor = Math.min(100, Math.max(0, num(pct)));
  const c = garantirConfig();
  if (operadorId) c.porOperador[operadorId] = valor;
  else c.padraoPct = valor;   // sem operador = o padrão da casa
  saveDb();
  return configComissoes();
}

/** Zera a regra própria: o Operador volta a seguir o padrão da casa. */
export function limparPct(operadorId) {
  delete garantirConfig().porOperador[operadorId];
  saveDb();
  return configComissoes();
}

/* ═══════════ Cálculo ═══════════ */

const periodoDe = (de, ate) => (de || ate ? { de: de ?? '0000-01-01', ate: ate ?? '9999-12-31' } : 'all');

/**
 * Serviços já cobrados → a PORCENTAGEM com que foram cobrados.
 *
 * Guardar a % (e não só "foi cobrado") é o que faz a coluna "já cobrado"
 * mostrar o que realmente saiu. Recalcular com a porcentagem de hoje
 * reescreveria o passado: mudar a % de um Operador mudaria o valor de uma
 * cobrança fechada semanas atrás.
 */
function jaCobrados() {
  const mapa = new Map();
  for (const c of getDb().comissoesCobradas ?? []) {
    if (c.desfeita) continue;
    for (const id of c.servicoIds ?? []) mapa.set(id, num(c.pct));
  }
  return mapa;
}

/**
 * Quanto cada Operador deve no período.
 *
 * `aberto` = validado no período e ainda não cobrado. `cobrado` = o que já
 * saiu numa cobrança. Os dois aparecem na tela: o primeiro é o que se cobra
 * agora, o segundo é o histórico daquele mesmo recorte.
 */
export function comissoesOperadores({ de = null, ate = null, sessao = null, incluirIsentos = false } = {}) {
  const cobrados = jaCobrados();
  const servicos = filtrarServicos(periodoDe(de, ate), sessao).filter(cobravel);

  const porOperador = new Map();
  for (const sv of servicos) {
    const a = sv.atendimento;
    const id = a.operatorId || a.operatorPn || a.operatorName || 'desconhecido';
    // Isento sai antes de somar: não é cobrado nem aparece no quadro.
    if (!incluirIsentos && isento(id)) continue;
    const linha = porOperador.get(id) ?? {
      operadorId: id, operadorPn: a.operatorPn ?? null, nomeOriginal: a.operatorName || 'desconhecido',
      servicos: 0, salario: 0, montante: 0,
      servicosCobrados: 0, salarioCobrado: 0, comissaoCobrada: 0,
      servicoIds: [],
      // Quanto ele pegou em cada dia — é o que a navegação por dia da semana lê.
      porDia: {},
    };
    const salario = salarioDoServico(sv);
    const montante = montanteDoServico(sv);
    linha.montante += montante;
    const dia = sv.day;
    // O dia guarda DUAS medidas: tudo o que ele pegou (é o que a faixa da
    // semana mostra) e o que ainda não foi cobrado. Misturar as duas fazia a
    // soma dos dias não bater com o total a cobrar do card.
    const noDia = linha.porDia[dia] ?? { servicos: 0, salario: 0, montante: 0, servicosAbertos: 0, salarioAberto: 0 };
    noDia.servicos += 1;
    noDia.salario += salario;
    noDia.montante += montante;
    if (!cobrados.has(sv.id)) {
      noDia.servicosAbertos += 1;
      noDia.salarioAberto += salario;
    }
    linha.porDia[dia] = noDia;

    if (cobrados.has(sv.id)) {
      linha.servicosCobrados += 1;
      linha.salarioCobrado += salario;
      // A comissão cobrada usa a % do dia da cobrança, não a de agora.
      linha.comissaoCobrada += salario * cobrados.get(sv.id) / 100;
    } else {
      linha.servicos += 1;
      linha.salario += salario;
      linha.servicoIds.push(sv.id);
    }
    linha.nomeOriginal = a.operatorName || linha.nomeOriginal;
    porOperador.set(id, linha);
  }

  const cfg = configComissoes();
  const linhas = [...porOperador.values()].map((l) => {
    const pct = pctDoOperador(l.operadorId);
    return {
      ...l,
      nome: nomeDeExibicao(l.operadorId, l.nomeOriginal),
      apelido: cfg.apelidos[l.operadorId] ?? null,
      isento: isento(l.operadorId),
      salario: cent(l.salario),
      montante: cent(l.montante),
      salarioCobrado: cent(l.salarioCobrado),
      porDia: Object.fromEntries(Object.entries(l.porDia).map(([dia, v]) => [dia, {
        servicos: v.servicos, salario: cent(v.salario), montante: cent(v.montante),
        comissao: cent(v.salario * pct / 100),
        servicosAbertos: v.servicosAbertos, salarioAberto: cent(v.salarioAberto),
        comissaoAberta: cent(v.salarioAberto * pct / 100),
      }])),
      pct,
      pctPropria: cfg.porOperador[l.operadorId] !== undefined,  // false = segue o padrão
      comissao: cent(l.salario * pct / 100),
      comissaoCobrada: cent(l.comissaoCobrada),
    };
  }).sort((a, b) => b.comissao - a.comissao || b.salario - a.salario);

  const soma = (campo) => cent(linhas.reduce((s, l) => s + l[campo], 0));
  return {
    periodo: { de, ate },
    padraoPct: configComissoes().padraoPct,
    operadores: linhas,
    resumo: {
      operadores: linhas.filter((l) => l.servicos > 0).length,
      // "Em aberto" = ainda não cobrado. É o que os botões de cobrança usam.
      servicos: linhas.reduce((s, l) => s + l.servicos, 0),
      salario: soma('salario'),
      comissao: soma('comissao'),
      // "Total" = tudo o que foi pego no período, cobrado ou não. É o número
      // que responde "quanto rolou nesta semana".
      servicosTotal: linhas.reduce((s, l) => s + l.servicos + l.servicosCobrados, 0),
      // Montante validado: o volume que passou pelos Operadores e fechou os 3
      // passos. Conta o serviço todo (cobrado ou não) — é medida de operação,
      // não de cobrança.
      montante: soma('montante'),
      salarioTotal: cent(soma('salario') + soma('salarioCobrado')),
      comissaoTotal: cent(soma('comissao') + soma('comissaoCobrada')),
      comissaoCobrada: soma('comissaoCobrada'),
    },
  };
}

/**
 * TODOS os serviços que um Operador pegou no recorte — não só os cobráveis.
 *
 * A tabela de comissão só fala de dinheiro cobrável (serviço validado), então
 * o que ele atendeu e não fechou some dela. Este "Ver mais" mostra o dia
 * inteiro do Operador: o que ele pegou, o que virou comprovante e o que ficou
 * pelo caminho — é a lista que se lê na frente dele quando ele contesta a
 * cobrança.
 *
 * `pego` = tem atendimento (ele respondeu o pedido). O status do serviço
 * continua sendo o do funil (aguardando/validado/expirado); `validado` é o
 * único que entra na comissão, e é o que a tela pinta de verde.
 */
export function servicosDoOperador(operadorId, { de = null, ate = null, sessao = null } = {}) {
  const alvo = String(operadorId ?? '');
  const cobrados = jaCobrados();
  const pct = pctDoOperador(alvo);

  const meu = (sv) => {
    const a = sv?.atendimento;
    if (!a) return false;
    return String(a.operatorId || a.operatorPn || a.operatorName || 'desconhecido') === alvo;
  };

  let nomeOriginal = 'desconhecido';
  const lista = filtrarServicos(periodoDe(de, ate), sessao).filter(meu).map((sv) => {
    nomeOriginal = sv.atendimento?.operatorName || nomeOriginal;
    const validado = cobravel(sv);
    const salario = salarioDoServico(sv);
    return {
      id: sv.id,
      day: sv.day,
      // Quando ele atendeu — é a hora que ele reconhece, não a do pedido.
      ts: sv.atendimento?.ts || sv.ts,
      pedidoTs: sv.pedidoTs ?? null,
      validadoEm: sv.validadoEm ?? null,
      tipo: sv.tipo ?? null,
      status: sv.status,
      statusRotulo: ROTULO_STATUS[sv.status] ?? sv.status,
      validado,
      brogueira: sv.brogueiraNome || 'sem nome',
      grupo: sv.groupName || null,
      contasPedidas: num(sv.contasPedidas),
      montante: cent(sv.atendimento?.montante),
      salario: cent(salario),
      casamento: sv.atendimento?.casamento ?? null,
      comprovante: sv.comprovante ? { tipo: sv.comprovante.tipo ?? null, ts: sv.comprovante.ts ?? null } : null,
      // Só serviço validado gera comissão; e só o não cobrado ainda está em aberto.
      cobrado: cobrados.has(sv.id),
      comissao: validado && !isento(alvo) ? cent(salario * pct / 100) : 0,
    };
  }).sort((a, b) => String(b.ts).localeCompare(String(a.ts)));

  const somar = (filtro, campo) => cent(lista.filter(filtro).reduce((s, sv) => s + sv[campo], 0));
  const validados = lista.filter((sv) => sv.validado);

  return {
    operadorId: alvo,
    nome: nomeDeExibicao(alvo, nomeOriginal),
    periodo: { de, ate },
    pct,
    isento: isento(alvo),
    resumo: {
      pegos: lista.length,
      validados: validados.length,
      // Taxa de fechamento: quantos dos que ele pegou viraram comprovante.
      taxa: lista.length ? Math.round((validados.length / lista.length) * 100) : 0,
      // O salário dos que fecharam é o que a comissão enxerga; o dos pegos é
      // o que ele teria recebido se todos tivessem fechado.
      salarioPego: somar(() => true, 'salario'),
      salarioValidado: somar((sv) => sv.validado, 'salario'),
      montanteValidado: somar((sv) => sv.validado, 'montante'),
      comissao: somar(() => true, 'comissao'),
    },
    servicos: lista,
  };
}

/**
 * Lista de Operadores conhecidos (para a tela de porcentagens).
 * Vem do histórico inteiro, não do período: dá para combinar a porcentagem de
 * alguém que ainda não validou nada nesta semana.
 */
export function operadoresConhecidos() {
  const vistos = new Map();
  for (const sv of getDb().servicos ?? []) {
    const a = sv.atendimento;
    if (!a) continue;
    const id = a.operatorId || a.operatorPn || a.operatorName || 'desconhecido';
    const linha = vistos.get(id) ?? { operadorId: id, operadorPn: a.operatorPn ?? null, nomeOriginal: a.operatorName || 'desconhecido', validados: 0, salarioTotal: 0 };
    if (cobravel(sv)) {
      linha.validados += 1;
      linha.salarioTotal += salarioDoServico(sv);
    }
    linha.nomeOriginal = a.operatorName || linha.nomeOriginal;
    vistos.set(id, linha);
  }
  const cfg = configComissoes();
  return [...vistos.values()]
    .map((l) => ({
      ...l,
      nome: nomeDeExibicao(l.operadorId, l.nomeOriginal),
      apelido: cfg.apelidos[l.operadorId] ?? null,
      isento: isento(l.operadorId),
      salarioTotal: cent(l.salarioTotal),
      pct: pctDoOperador(l.operadorId),
      pctPropria: cfg.porOperador[l.operadorId] !== undefined,
    }))
    .sort((a, b) => b.salarioTotal - a.salarioTotal || String(a.nome).localeCompare(String(b.nome), 'pt-BR'));
}

/* ═══════════ A semana e os seus dias ═══════════
   A comissão é fechada por SEMANA — é o ciclo em que a casa acerta com o
   Operador. A semana é de calendário (segunda a domingo), o mesmo corte que
   todo o resto do painel usa; e dentro dela dá para abrir dia a dia, porque a
   conferência com o Operador é sempre "no dia tal você pegou tanto".  */

const DIAS_CURTOS = ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'];

const somaDias = (iso, n) => {
  const [a, m, d] = String(iso).split('-').map(Number);
  const base = new Date(Date.UTC(a, m - 1, d));
  base.setUTCDate(base.getUTCDate() + n);
  return base.toISOString().slice(0, 10);
};

/** Segunda-feira da semana de `dia` (que já vem no fuso do bot). */
export function semanaDe(dia = dayKey()) {
  const [a, m, d] = String(dia).split('-').map(Number);
  const recuo = (new Date(Date.UTC(a, m - 1, d)).getUTCDay() + 6) % 7;
  const de = somaDias(dia, -recuo);
  return { de, ate: somaDias(de, 6) };
}

/**
 * O quadro da semana: o total de cada dia, o total de cada Operador e o que
 * cada um pegou em cada dia.
 *
 * `referencia` é qualquer dia dentro da semana desejada — é assim que as setas
 * de navegação funcionam (‹ manda a segunda anterior, › a seguinte). Não há
 * navegação para o futuro: a semana que ainda não começou não tem o que somar.
 */
export function resumoSemana({ referencia = null, sessao = null } = {}) {
  const hoje = dayKey();
  const alvo = /^\d{4}-\d{2}-\d{2}$/.test(String(referencia ?? '')) ? String(referencia) : hoje;
  const semana = semanaDe(alvo);
  const { operadores, resumo, padraoPct } = comissoesOperadores({ de: semana.de, ate: semana.ate, sessao });

  const dias = [];
  for (let i = 0; i < 7; i += 1) {
    const day = somaDias(semana.de, i);
    const [a, m, d] = day.split('-').map(Number);
    const totalDia = operadores.reduce((acc, o) => {
      const x = o.porDia[day];
      if (!x) return acc;
      return {
        servicos: acc.servicos + x.servicos,
        salario: acc.salario + x.salario,
        montante: acc.montante + x.montante,
        comissao: acc.comissao + x.comissao,
        comissaoAberta: acc.comissaoAberta + x.comissaoAberta,
      };
    }, { servicos: 0, salario: 0, montante: 0, comissao: 0, comissaoAberta: 0 });
    dias.push({
      day,
      rotulo: DIAS_CURTOS[new Date(Date.UTC(a, m - 1, d)).getUTCDay()],
      dataCurta: `${String(d).padStart(2, '0')}/${String(m).padStart(2, '0')}`,
      futuro: day > hoje,
      hoje: day === hoje,
      servicos: totalDia.servicos,
      salario: cent(totalDia.salario),
      montante: cent(totalDia.montante),
      comissao: cent(totalDia.comissao),
      comissaoAberta: cent(totalDia.comissaoAberta),
    });
  }

  const semanaAnterior = somaDias(semana.de, -7);
  const semanaSeguinte = somaDias(semana.de, 7);
  return {
    semana: { ...semana, rotulo: `${semana.de.slice(8)}/${semana.de.slice(5, 7)} a ${semana.ate.slice(8)}/${semana.ate.slice(5, 7)}` },
    anterior: semanaAnterior,
    // Sem semana futura: navegar para frente só até a semana corrente.
    proxima: semanaSeguinte <= hoje ? semanaSeguinte : null,
    atual: semana.de === semanaDe(hoje).de,
    dias,
    operadores,
    resumo,
    padraoPct,
  };
}

/* ═══════════ A semana da casa: sábado 05h → sábado 05h ═══════════
   O ciclo do negócio não é o da folhinha: ele vira **sábado às 5 da manhã**,
   quando o turno da noite acaba. Um serviço validado às 03h de sábado ainda é
   da semana que está fechando — por isso a janela é medida no RELÓGIO
   (timestamp), não no campo `day`, que vira à meia-noite.
   Os quadros do topo da aba Relatórios contam por esta janela.  */

const CORTE_SEMANA = { diaSemana: 6, hora: 5 };   // 6 = sábado

/** Quando aquele serviço foi confirmado — é isso que o coloca numa semana. */
export function validadoEm(sv) {
  return sv?.validadoEm || sv?.comprovante?.ts || sv?.atendimento?.ts || sv?.ts || null;
}

/**
 * A janela da semana da casa que contém `agora`.
 * Devolve os limites em ISO e o rótulo pronto para a tela.
 */
export function semanaDaCasa(agora = undefined) {
  const fuso = getDb().config?.timezone || 'America/Sao_Paulo';
  const ref = dayjs(agora).tz(fuso);
  // Quantos dias voltar até o último sábado (contando que antes das 5h de
  // sábado a semana ainda é a anterior).
  let recuo = (ref.day() - CORTE_SEMANA.diaSemana + 7) % 7;
  if (recuo === 0 && ref.hour() < CORTE_SEMANA.hora) recuo = 7;
  const inicio = ref.subtract(recuo, 'day').hour(CORTE_SEMANA.hora).minute(0).second(0).millisecond(0);
  const fim = inicio.add(7, 'day');
  const curto = (d) => d.format('DD/MM');
  return {
    de: inicio.toISOString(),
    ate: fim.toISOString(),
    diaDe: inicio.format('YYYY-MM-DD'),
    diaAte: fim.subtract(1, 'day').format('YYYY-MM-DD'),
    rotulo: `sáb ${curto(inicio)} 05h → sáb ${curto(fim)} 05h`,
  };
}

/**
 * O que a semana da casa fechou: quantos montantes foram validados, quanto
 * somaram e quanto de salário as Brogueiras pagaram aos Operadores.
 *
 * "Salário pago pelas Brogueiras" é o `💸 Valor` das mensagens dos Operadores —
 * o mesmo número que serve de base para a comissão. Aqui ele aparece pelo outro
 * lado do balcão: o que saiu do bolso delas na semana.
 *
 * Operador isento fica de fora, como no resto da aba.
 */
export function resumoSemanaDaCasa({ agora = undefined, sessao = null } = {}) {
  const janela = semanaDaCasa(agora);
  const de = new Date(janela.de).getTime();
  const ate = new Date(janela.ate).getTime();

  let montantes = 0;
  let montante = 0;
  let salario = 0;
  const operadores = new Set();
  for (const sv of getDb().servicos ?? []) {
    if (!cobravel(sv)) continue;
    const a = sv.atendimento;
    const id = a.operatorId || a.operatorPn || a.operatorName || 'desconhecido';
    if (isento(id)) continue;
    if (sessao && (sv.sessaoId ?? 'n1') !== sessao) continue;
    const quando = new Date(validadoEm(sv) || 0).getTime();
    if (!(quando >= de && quando < ate)) continue;
    montantes += 1;
    montante += montanteDoServico(sv);
    salario += salarioDoServico(sv);
    operadores.add(id);
  }
  return {
    ...janela,
    montantes,
    montante: cent(montante),
    salario: cent(salario),
    operadores: operadores.size,
  };
}

/**
 * Montante validado de HOJE e da SEMANA — os dois quadros do topo da aba.
 *
 * "Validado" é o que fechou os 3 passos: a Brogueira pediu, o Operador
 * respondeu e ela mandou o comprovante. Montante em aberto (sem comprovante)
 * fica de fora de propósito: o quadro responde "quanto foi confirmado", não
 * "quanto foi prometido".
 *
 * Operador isento não entra, como no resto da aba — senão o número do topo não
 * fecharia com a tabela logo abaixo, que é a primeira conferência que se faz.
 */
export function montanteValidado({ sessao = null, agora = undefined } = {}) {
  const hoje = dayKey();
  const cfg = metas();

  const doDia = comissoesOperadores({ de: hoje, ate: hoje, sessao }).resumo;
  // A semana dos quadros do topo é a da casa (sábado 05h), não a da folhinha.
  const daSemana = resumoSemanaDaCasa({ agora, sessao });
  const pct = (v, meta) => (meta > 0 ? Math.round((v / meta) * 1000) / 10 : null);

  return {
    hoje: {
      dia: hoje,
      servicos: doDia.servicosTotal,
      montante: doDia.montante,
      meta: cfg.metaDiariaBlogueira,
      pct: pct(doDia.montante, cfg.metaDiariaBlogueira),
    },
    semana: {
      de: daSemana.diaDe,
      ate: daSemana.diaAte,
      rotulo: daSemana.rotulo,
      servicos: daSemana.montantes,
      montante: daSemana.montante,
      // Quantos montantes validados saíram e quanto as Brogueiras pagaram de
      // salário — os dois primeiros quadros da linha.
      montantes: daSemana.montantes,
      salario: daSemana.salario,
      operadores: daSemana.operadores,
      meta: cfg.metaSemanalBlogueira,
      pct: pct(daSemana.montante, cfg.metaSemanalBlogueira),
    },
  };
}

/* ═══════════ A cobrança pelo WhatsApp ═══════════
   "Cobrar" na linha do Operador manda uma mensagem PARA ELE. O texto é escrito
   pelo dono em Configurações; aqui só entram os números daquele Operador
   naquele recorte. Nada é gravado por este caminho: mandar a mensagem é
   cobrar, não dar baixa — a baixa é o "Zerar comissão", que tem backup. */

const CAMPOS_MENSAGEM = ['operador', 'valor', 'salario', 'servicos', 'pct', 'periodo'];

const dinheiro = (n) => Number(n || 0).toLocaleString('pt-BR', { style: 'currency', currency: 'BRL' });

/**
 * Troca os campos entre chaves pelo dado do Operador.
 * Campo desconhecido fica como está — é melhor o dono ver `{fulano}` cru na
 * prévia e corrigir do que a mensagem sair com um buraco silencioso.
 */
export function montarMensagemCobranca(modelo, dados) {
  return String(modelo ?? '').replace(/\{(\w+)\}/g, (bruto, campo) => (
    CAMPOS_MENSAGEM.includes(campo) ? String(dados[campo] ?? '') : bruto
  ));
}

/**
 * A cobrança de um Operador: para quem vai, quanto é e o texto pronto.
 * `recorte` é o mesmo da tela ({de, ate}); sem ele, a semana da casa.
 */
export function cobrancaDoOperador(operadorId, { de = null, ate = null, agora = undefined } = {}) {
  /* Sem recorte explícito, vale a MESMA semana do card de comissão (segunda a
     domingo) — é o que a tabela ao lado está mostrando. Cobrar por uma janela
     diferente da que está na tela faria a mensagem dizer um valor e a linha
     outro, que é o pior erro possível numa cobrança. */
  const janela = (de || ate) ? { de, ate } : semanaDe();
  // A isenção vem antes da busca: o isento já sai da lista, e sem esta guarda
  // o erro sairia como "não tem serviço" — que manda o dono procurar no lugar
  // errado. É a única coisa que impede a cobrança.
  if (isento(operadorId)) throw new Error('este Operador está isento de comissão');

  const { operadores } = comissoesOperadores({ de: janela.de, ate: janela.ate });
  // Sem linha no período (nenhum serviço validado) a cobrança ainda sai: o dono
  // pode querer cobrar uma semana que já foi zerada, ou mandar o recado mesmo
  // sem movimento. O que falta vira zero, e o texto é editável na hora.
  const conhecido = operadoresConhecidos().find((o) => o.operadorId === operadorId);
  const linha = operadores.find((o) => o.operadorId === operadorId) ?? {
    operadorId,
    nome: conhecido?.nome ?? nomeDeExibicao(operadorId, 'Operador'),
    operadorPn: conhecido?.operadorPn ?? null,
    servicos: 0, salario: 0, comissao: 0, comissaoCobrada: 0,
    servicosCobrados: 0, salarioCobrado: 0,
    pct: pctDoOperador(operadorId),
  };

  const periodo = janela.rotulo
    || (janela.de === janela.ate ? janela.de.split('-').reverse().join('/')
      : `${String(janela.de).split('-').reverse().join('/')} a ${String(janela.ate).split('-').reverse().join('/')}`);

  /* O valor cobrado é a comissão DO PERÍODO: o que está em aberto mais o que já
     foi apurado no "Zerar comissão". Depois da baixa o painel mostra zero em
     aberto — mas a pessoa continua devendo, e é justamente aí que se cobra.
     Antes de qualquer baixa os dois números são o mesmo, então nada muda no
     caso comum. */
  const aberta = num(linha.comissao);
  const apurada = num(linha.comissaoCobrada);
  const total = cent(aberta + apurada);

  /* Salário e nº de serviços do PERÍODO, não só o que está em aberto. Eles
     têm de descrever o mesmo conjunto que `total`, senão depois de um "Zerar
     comissão" a mensagem sai dizendo "Salário recebido: R$ 0,00 / Comissão
     (10%): R$ 20,00" — e o Operador, com razão, contesta a conta. */
  const salarioPeriodo = cent(num(linha.salario) + num(linha.salarioCobrado));
  const servicosPeriodo = num(linha.servicos) + num(linha.servicosCobrados);

  const mensagem = montarMensagemCobranca(getDb().config?.comissaoMensagem, {
    operador: linha.nome,
    valor: dinheiro(total),
    salario: dinheiro(salarioPeriodo),
    servicos: servicosPeriodo,
    pct: linha.pct,
    periodo,
  });

  return {
    operadorId: linha.operadorId,
    nome: linha.nome,
    // O número só existe quando o WhatsApp expôs o telefone (alguns contatos
    // chegam só com o @lid). Sem ele não há para quem mandar.
    para: linha.operadorPn || null,
    servicos: servicosPeriodo,
    salario: salarioPeriodo,
    pct: linha.pct,
    comissao: total,
    comissaoAberta: cent(aberta),
    comissaoApurada: cent(apurada),
    periodo,
    mensagem,
  };
}

/* ═══════════ Cobrança ═══════════ */

/**
 * Registra a cobrança do que está aberto — com a lista de serviços cobrados.
 *
 * A lista é o que garante as duas coisas que importam: a mesma validação não
 * é cobrada de novo, e o "Desfazer" devolve exatamente aquele conjunto. A
 * porcentagem também fica gravada: se ela mudar depois, a cobrança antiga
 * continua contando a história do dia em que foi feita.
 */
export function cobrar({ operadorId = null, de = null, ate = null, por = 'admin' } = {}) {
  const { operadores } = comissoesOperadores({ de, ate });
  const alvo = operadores
    .filter((l) => !isento(l.operadorId))
    .filter((l) => l.servicos > 0 && (!operadorId || l.operadorId === operadorId));
  if (!alvo.length) return { cobrancas: [], servicos: 0, total: 0 };

  const db = getDb();
  if (!Array.isArray(db.comissoesCobradas)) db.comissoesCobradas = [];
  const agora = new Date().toISOString();
  const cobrancas = alvo.map((l) => ({
    id: `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    operadorId: l.operadorId,
    operadorNome: l.nome,
    operadorPn: l.operadorPn,
    periodo: { de, ate },
    pct: l.pct,
    servicoIds: [...l.servicoIds],
    servicos: l.servicos,
    salario: l.salario,
    valor: l.comissao,
    por: String(por ?? 'admin').slice(0, 80),
    criadaEm: agora,
    desfeita: false,
    desfeitaEm: null,
  }));
  db.comissoesCobradas.push(...cobrancas);
  saveDb();

  return {
    cobrancas,
    servicos: cobrancas.reduce((s, c) => s + c.servicos, 0),
    total: cent(cobrancas.reduce((s, c) => s + c.valor, 0)),
  };
}

export function listarCobrancas(limite = 100) {
  return [...(getDb().comissoesCobradas ?? [])]
    .map((c, i) => ({ c, i }))
    .sort((a, b) => String(b.c.criadaEm).localeCompare(String(a.c.criadaEm)) || (b.i - a.i))
    .slice(0, limite)
    .map(({ c }) => ({ ...c }));
}

/** Desfaz: os serviços daquela cobrança voltam a contar como em aberto. */
export function desfazerCobranca(id) {
  const db = getDb();
  const cobranca = (db.comissoesCobradas ?? []).find((c) => c.id === id);
  if (!cobranca) throw new Error('cobrança não encontrada');
  if (cobranca.desfeita) throw new Error('esta cobrança já foi desfeita');
  cobranca.desfeita = true;
  cobranca.desfeitaEm = new Date().toISOString();
  saveDb();
  return { servicos: cobranca.servicos, valor: cobranca.valor, operador: cobranca.operadorNome };
}
