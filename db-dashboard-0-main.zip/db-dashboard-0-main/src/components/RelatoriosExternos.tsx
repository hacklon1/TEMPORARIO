import { useMemo, useState } from "react";
import {
  AlertTriangle,
  Banknote,
  CheckCircle2,
  ClipboardList,
  Coins,
  RefreshCw,
  Satellite,
  TrendingUp,
  Users as UsersIcon,
  Wallet,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import {
  Table,
  TableBody,
  TableCell,
  TableFooter,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { StatCard } from "@/components/StatCard";
import { useRelatoriosExternos } from "@/hooks/useRelatoriosExternos";
import {
  diaOperacional,
  NOME_OPERADOR_REMOVIDO,
  RelatorioError,
  type OperadorExterno,
} from "@/lib/relatoriosExternos";
import { formatBRL, formatDate } from "@/lib/format";

const statusLabel: Record<string, { texto: string; classe: string }> = {
  aberta: { texto: "Aberta", classe: "text-warning" },
  zerou: { texto: "Zerou", classe: "text-destructive" },
  sacou: { texto: "Sacou", classe: "text-success" },
};

/** Os timestamps do coletor vêm em ISO com offset -03:00 (não em UTC/Z) e
 *  `ultima_operacao` pode ser null. `formatDate` cospe "Invalid Date" se algo
 *  chegar torto — aqui um traço é melhor do que ruído na tabela. */
function quando(valor?: string | null): string {
  if (!valor) return "—";
  const d = new Date(valor);
  return Number.isNaN(d.getTime()) ? "—" : formatDate(d);
}

function temMovimento(o: OperadorExterno): boolean {
  return (
    o.pedidos !== 0 ||
    o.validados !== 0 ||
    o.montante !== 0 ||
    o.blogueira !== 0 ||
    o.comissao !== 0 ||
    o.lucro !== 0
  );
}

export function RelatoriosExternos() {
  const [data, setData] = useState<string>(() => diaOperacional());
  // O coletor manda TODOS os cadastrados, inclusive quem não operou. A lista
  // completa é a que fecha com o Montante, então ela é o padrão; o filtro existe
  // para quando a tela fica poluída.
  const [soComMovimento, setSoComMovimento] = useState(false);
  const { data: rel, isFetching, isError, error, refetch } = useRelatoriosExternos(data);

  const montante = rel?.montante;
  const contas = rel?.contas;
  const todosOperadores = rel?.operadores?.operadores ?? [];

  const operadores = useMemo(() => {
    const lista = soComMovimento ? todosOperadores.filter(temMovimento) : todosOperadores;
    return [...lista].sort((a, b) => b.lucro - a.lucro);
  }, [todosOperadores, soComMovimento]);

  // Somamos a lista inteira, não a filtrada: este total é o que precisa bater
  // com o Montante, e operadores de cadastro apagado entram nele.
  const totalOperadores = useMemo(
    () =>
      todosOperadores.reduce(
        (acc, o) => ({
          pedidos: acc.pedidos + o.pedidos,
          validados: acc.validados + o.validados,
          montante: acc.montante + o.montante,
          blogueira: acc.blogueira + o.blogueira,
          comissao: acc.comissao + o.comissao,
          lucro: acc.lucro + o.lucro,
        }),
        { pedidos: 0, validados: 0, montante: 0, blogueira: 0, comissao: 0, lucro: 0 },
      ),
    [todosOperadores],
  );

  const porHora = montante?.por_hora ?? [];
  const picoHora = Math.max(1, ...porHora.map((h) => Math.abs(h.montante)));

  // O motivo vem da Edge Function (código + status + trecho do corpo). A tela
  // repassa o motivo em vez de esconder tudo atrás de uma frase genérica.
  const erro = error as RelatorioError | Error | undefined;
  const codigo = erro instanceof RelatorioError ? erro.codigo : undefined;
  const statusErro = erro instanceof RelatorioError ? erro.status : undefined;
  const detalheBruto = erro instanceof RelatorioError ? erro.detalhe : undefined;
  const { tituloErro, detalheErro } = (() => {
    const http = statusErro ? ` (HTTP ${statusErro})` : "";
    const comDetalhe = `${erro?.message ?? ""}${detalheBruto ? ` — ${detalheBruto}` : ""}`.trim();
    switch (codigo) {
      case "token_coletor":
        return {
          tituloErro: "O token do coletor foi recusado",
          detalheErro: `O WhatsApp Server recusou a autenticação${http}. Confira o secret RELATORIOS_TOKEN da Edge Function relatorios-externos.`,
        };
      case "data_invalida":
        return {
          tituloErro: "Data inválida",
          detalheErro: `${erro?.message ?? "O WhatsApp Server recusou esta data"}${http}. Escolha um dia no formato AAAA-MM-DD que exista no calendário — o Dash não troca de dia sozinho.`,
        };
      case "coletor_offline":
        return {
          tituloErro: "O WhatsApp Server não respondeu",
          detalheErro: comDetalhe || "Timeout, falha de rede ou erro 5xx do servidor. A Edge Function já tentou duas vezes.",
        };
      case "proxy":
        return { tituloErro: "A Edge Function não respondeu", detalheErro: comDetalhe };
      case "contrato":
        return { tituloErro: "Resposta fora do contrato", detalheErro: erro?.message };
      default:
        return { tituloErro: "Não foi possível ler o coletor", detalheErro: erro?.message };
    }
  })();

  // O servidor devolve o dia operacional que de fato usou. Se ele diferir do
  // pedido, a tela avisa em vez de mostrar números de outro dia como se fossem
  // os certos.
  const diaDevolvido = montante?.data;
  const diaDiferente = !!diaDevolvido && diaDevolvido !== data;

  return (
    <section className="space-y-4">
      <div className="glass-strong flex flex-wrap items-end justify-between gap-3 rounded-2xl p-4">
        <div className="flex items-center gap-2">
          <Satellite className="h-4 w-4 text-primary" />
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider">Relatórios do coletor</h2>
            <p className="text-[11px] text-muted-foreground">
              WhatsApp Server
              {diaDevolvido && ` — dia ${diaDevolvido}`}
              {montante?.gerado_em && ` — gerado em ${quando(montante.gerado_em)}`}
            </p>
          </div>
        </div>
        <div className="flex items-end gap-3">
          <div className="flex flex-col">
            <Label htmlFor="rel-data" className="text-xs">Dia</Label>
            <Input
              id="rel-data"
              type="date"
              value={data}
              onChange={(e) => setData(e.target.value)}
              className="h-9 w-40"
            />
          </div>
          <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isFetching}>
            <RefreshCw className={`mr-2 h-4 w-4 ${isFetching ? "animate-spin" : ""}`} />
            Atualizar
          </Button>
        </div>
      </div>

      {diaDiferente && !isError && (
        <div className="flex items-start gap-2 rounded-2xl border border-warning/40 bg-warning/5 p-4 text-sm">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-warning" />
          <div>
            <p className="font-semibold text-warning">O servidor devolveu outro dia</p>
            <p className="text-xs text-muted-foreground">
              Pedido {data}, recebido {diaDevolvido}. Os números abaixo são do dia {diaDevolvido}.
            </p>
          </div>
        </div>
      )}

      {isError && (
        <div className="flex items-start gap-2 rounded-2xl border border-destructive/40 bg-destructive/5 p-4 text-sm">
          <AlertTriangle className="mt-0.5 h-4 w-4 shrink-0 text-destructive" />
          <div>
            <p className="font-semibold text-destructive">{tituloErro}</p>
            <p className="text-xs text-muted-foreground">{detalheErro}</p>
          </div>
        </div>
      )}

      {/* Montante */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Montante</h3>
        <div className="grid gap-4 md:grid-cols-4">
          <StatCard
            title="Montante"
            value={formatBRL(montante?.totais.montante ?? 0)}
            icon={Banknote}
            tone="primary"
            hint={`${montante?.totais.validados ?? 0} validados de ${montante?.totais.pedidos ?? 0} pedidos`}
          />
          <StatCard
            title="Blogueira"
            value={formatBRL(montante?.totais.blogueira ?? 0)}
            icon={Coins}
            tone="warning"
            hint="salário pago ao operador"
          />
          <StatCard
            title="Comissão"
            value={formatBRL(montante?.totais.comissao ?? 0)}
            icon={Wallet}
            tone="success"
          />
          <StatCard
            title="Lucro"
            value={formatBRL(montante?.totais.lucro ?? 0)}
            icon={TrendingUp}
            tone="success"
            hint="o que fica com a casa"
          />
        </div>

        {/* Montante por hora do dia operacional. O coletor manda as 24 horas na
            ordem 05:00 → 04:00, zeradas inclusive — desenhamos na ordem que veio. */}
        {porHora.length > 0 && (
          <div className="glass-strong rounded-2xl p-4">
            <p className="mb-3 text-[11px] font-medium uppercase tracking-wider text-muted-foreground">
              Montante por hora
            </p>
            <div className="flex items-end gap-1 overflow-x-auto">
              {porHora.map((h) => (
                <div key={h.hora} className="flex min-w-[18px] flex-1 flex-col items-center gap-1">
                  <div
                    className="w-full rounded-sm bg-primary/60"
                    style={{ height: `${Math.max(2, (Math.abs(h.montante) / picoHora) * 56)}px` }}
                    title={`${h.hora} — montante ${formatBRL(h.montante)} · blogueira ${formatBRL(h.blogueira)} · lucro ${formatBRL(h.lucro)}`}
                  />
                  <span className="text-[9px] text-muted-foreground">{h.hora.slice(0, 2)}</span>
                </div>
              ))}
            </div>
          </div>
        )}
      </div>

      {/* Contas */}
      <div className="space-y-3">
        <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">Contas</h3>
        <div className="grid gap-4 md:grid-cols-4">
          <StatCard
            title="Contas solicitadas"
            value={String(contas?.totais.contas_solicitadas ?? 0)}
            icon={ClipboardList}
            tone="primary"
            hint={`${contas?.totais.sacou ?? 0} sacaram · ${contas?.totais.zerou ?? 0} zeraram · ${contas?.totais.aberta ?? 0} abertas`}
          />
          <StatCard
            title="Pedidos"
            value={String(contas?.totais.pedidos ?? 0)}
            icon={CheckCircle2}
            tone="muted"
            hint={`montante ${formatBRL(contas?.totais.montante ?? 0)}`}
          />
          <StatCard title="Salário" value={formatBRL(contas?.totais.salario ?? 0)} icon={Coins} tone="warning" />
          <StatCard
            title="Lucro"
            value={formatBRL(contas?.totais.lucro ?? 0)}
            icon={TrendingUp}
            tone="success"
            hint={`comissão ${formatBRL(contas?.totais.comissao ?? 0)}`}
          />
        </div>
        <div className="glass-strong overflow-x-auto rounded-2xl">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead>Blogueira</TableHead>
                <TableHead className="text-right">Contas</TableHead>
                <TableHead className="text-right">Montante</TableHead>
                <TableHead className="text-right">Salário</TableHead>
                <TableHead>Operador</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Atualizado</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {contas?.itens.length ? (
                // Uma linha por pedido: a mesma blogueira aparece várias vezes,
                // então o nome não serve de key.
                contas.itens.map((c, i) => (
                  <TableRow key={`${i}-${c.nome_conta}-${c.atualizado_em ?? ""}`} className="border-border">
                    <TableCell className="font-medium">{c.nome_conta}</TableCell>
                    <TableCell className="number-tabular text-right">{c.contas}</TableCell>
                    <TableCell className="number-tabular text-right">{formatBRL(c.montante)}</TableCell>
                    <TableCell className="number-tabular text-right">{formatBRL(c.salario)}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{c.operador || "—"}</TableCell>
                    <TableCell className={`text-xs font-semibold ${statusLabel[c.status].classe}`}>
                      {statusLabel[c.status].texto}
                    </TableCell>
                    <TableCell className="text-xs text-muted-foreground">{quando(c.atualizado_em)}</TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={7} className="py-8 text-center text-sm text-muted-foreground">
                    {isFetching ? "Carregando…" : "Nenhum pedido no relatório deste dia."}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </div>
      </div>

      {/* Operadores */}
      <div className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <UsersIcon className="h-4 w-4 text-primary" />
            <h3 className="text-xs font-bold uppercase tracking-wider text-muted-foreground">
              Operadores
            </h3>
            <span className="text-[11px] text-muted-foreground">
              {operadores.length} de {todosOperadores.length}
            </span>
          </div>
          <div className="flex items-center gap-2">
            <Switch
              id="rel-mov"
              checked={soComMovimento}
              onCheckedChange={setSoComMovimento}
            />
            <Label htmlFor="rel-mov" className="text-xs text-muted-foreground">
              Somente com movimento
            </Label>
          </div>
        </div>
        <div className="glass-strong overflow-x-auto rounded-2xl">
          <Table>
            <TableHeader>
              <TableRow className="border-border hover:bg-transparent">
                <TableHead>Operador</TableHead>
                <TableHead>Categoria</TableHead>
                <TableHead className="text-right">Pedidos</TableHead>
                <TableHead className="text-right">Validados</TableHead>
                <TableHead className="text-right">Montante</TableHead>
                <TableHead className="text-right">Blogueira</TableHead>
                <TableHead className="text-right">Comissão</TableHead>
                <TableHead className="text-right">Lucro</TableHead>
                <TableHead className="text-right">%</TableHead>
                <TableHead>Última operação</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {operadores.length ? (
                operadores.map((o) => {
                  const removido = o.nome === NOME_OPERADOR_REMOVIDO;
                  return (
                    <TableRow key={o.id} className="border-border">
                      <TableCell className="font-medium">
                        <span className="flex items-center gap-2">
                          <span className={`h-2 w-2 rounded-full ${o.online ? "bg-success" : "bg-muted-foreground/40"}`} />
                          {/* Cadastro apagado no coletor: o id continua estável e o
                              dinheiro da linha é necessário para fechar com o Montante. */}
                          {removido ? (
                            <span className="italic text-muted-foreground">Usuário removido</span>
                          ) : (
                            o.nome
                          )}
                          {o.usuario && <span className="text-xs text-muted-foreground">@{o.usuario}</span>}
                        </span>
                      </TableCell>
                      <TableCell className="text-xs uppercase text-muted-foreground">
                        {o.categoria || "—"}
                      </TableCell>
                      <TableCell className="number-tabular text-right">{o.pedidos}</TableCell>
                      <TableCell className="number-tabular text-right">{o.validados}</TableCell>
                      <TableCell className="number-tabular text-right">{formatBRL(o.montante)}</TableCell>
                      <TableCell className="number-tabular text-right">{formatBRL(o.blogueira)}</TableCell>
                      <TableCell className="number-tabular text-right">{formatBRL(o.comissao)}</TableCell>
                      <TableCell className="number-tabular text-right">{formatBRL(o.lucro)}</TableCell>
                      <TableCell className="number-tabular text-right text-xs">
                        {o.isento ? (
                          <span className="rounded-full bg-muted/60 px-2 py-0.5 text-[10px] uppercase text-muted-foreground">
                            isento
                          </span>
                        ) : (
                          `${o.pct}%`
                        )}
                      </TableCell>
                      <TableCell className="text-xs text-muted-foreground">{quando(o.ultima_operacao)}</TableCell>
                    </TableRow>
                  );
                })
              ) : (
                <TableRow>
                  <TableCell colSpan={10} className="py-8 text-center text-sm text-muted-foreground">
                    {isFetching
                      ? "Carregando…"
                      : soComMovimento && todosOperadores.length
                        ? "Nenhum operador com movimento neste dia."
                        : "Nenhum operador no relatório deste dia."}
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
            {todosOperadores.length > 0 && (
              <TableFooter>
                <TableRow className="border-border hover:bg-transparent">
                  <TableCell colSpan={2} className="text-xs uppercase text-muted-foreground">
                    Total (todos os operadores)
                  </TableCell>
                  <TableCell className="number-tabular text-right">{totalOperadores.pedidos}</TableCell>
                  <TableCell className="number-tabular text-right">{totalOperadores.validados}</TableCell>
                  <TableCell className="number-tabular text-right">{formatBRL(totalOperadores.montante)}</TableCell>
                  <TableCell className="number-tabular text-right">{formatBRL(totalOperadores.blogueira)}</TableCell>
                  <TableCell className="number-tabular text-right">{formatBRL(totalOperadores.comissao)}</TableCell>
                  <TableCell className="number-tabular text-right">{formatBRL(totalOperadores.lucro)}</TableCell>
                  <TableCell colSpan={2} />
                </TableRow>
              </TableFooter>
            )}
          </Table>
        </div>
      </div>
    </section>
  );
}
