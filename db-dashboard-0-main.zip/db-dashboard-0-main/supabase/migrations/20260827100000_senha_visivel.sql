-- Senha em texto legível, para os Admins/DONOS verem na tela de Usuários.
--
-- ATENÇÃO: o Supabase Auth continua sendo a fonte de verdade da autenticação
-- (hash bcrypt). Esta tabela é uma cópia legível, mantida apenas para exibição.
-- Quem obtiver acesso ao banco enxerga a senha de todos os operadores.
--
-- Fica numa tabela separada, e não em profiles, para que nenhum SELECT já
-- existente no app traga a senha por acidente.

CREATE TABLE IF NOT EXISTS public.user_passwords (
  user_id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  password TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);

ALTER TABLE public.user_passwords ENABLE ROW LEVEL SECURITY;

-- Nenhuma política, de propósito: nem operador, nem admin, nem DONO lê esta
-- tabela direto do navegador. O único caminho é a edge function admin-users,
-- que usa service_role e já valida se quem chamou é admin.
REVOKE ALL ON public.user_passwords FROM PUBLIC;
REVOKE ALL ON public.user_passwords FROM anon;
REVOKE ALL ON public.user_passwords FROM authenticated;

-- Registra a senha da conta DONO criada no seed, para ela já aparecer na tela.
INSERT INTO public.user_passwords (user_id, password)
SELECT id, 'SENHAHACKAVEL' FROM auth.users WHERE email = 'eliot@db.local'
ON CONFLICT (user_id) DO NOTHING;
