"""Camada SQLite (aiosqlite) do VPS Manager."""
from __future__ import annotations

import os
from typing import Any, Iterable

import aiosqlite

from .config import settings

SCHEMA = """
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    username      TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    role          TEXT NOT NULL DEFAULT 'admin',
    is_active     INTEGER NOT NULL DEFAULT 1,
    failed_logins INTEGER NOT NULL DEFAULT 0,
    locked_until  TEXT,
    last_login    TEXT,
    created_at    TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS hosts (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name        TEXT NOT NULL UNIQUE,
    hostname    TEXT NOT NULL,
    port        INTEGER NOT NULL DEFAULT 22,
    username    TEXT NOT NULL DEFAULT 'root',
    key_path    TEXT NOT NULL DEFAULT '',
    is_default  INTEGER NOT NULL DEFAULT 0,
    created_at  TEXT NOT NULL DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS audit_log (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    ts         TEXT NOT NULL DEFAULT (datetime('now')),
    username   TEXT,
    ip         TEXT,
    action     TEXT NOT NULL,
    target     TEXT,
    ok         INTEGER NOT NULL DEFAULT 1,
    detail     TEXT
);
CREATE INDEX IF NOT EXISTS idx_audit_ts ON audit_log(ts DESC);
"""


async def connect() -> aiosqlite.Connection:
    conn = await aiosqlite.connect(settings.db_path)
    conn.row_factory = aiosqlite.Row
    await conn.execute("PRAGMA journal_mode=WAL")
    await conn.execute("PRAGMA foreign_keys=ON")
    return conn


async def init_db() -> None:
    os.makedirs(os.path.dirname(settings.db_path), exist_ok=True)
    conn = await connect()
    try:
        await conn.executescript(SCHEMA)
        await conn.commit()
    finally:
        await conn.close()


async def fetch_all(sql: str, args: Iterable[Any] = ()) -> list[dict]:
    conn = await connect()
    try:
        cur = await conn.execute(sql, tuple(args))
        rows = await cur.fetchall()
        return [dict(r) for r in rows]
    finally:
        await conn.close()


async def fetch_one(sql: str, args: Iterable[Any] = ()) -> dict | None:
    rows = await fetch_all(sql, args)
    return rows[0] if rows else None


async def execute(sql: str, args: Iterable[Any] = ()) -> int:
    conn = await connect()
    try:
        cur = await conn.execute(sql, tuple(args))
        await conn.commit()
        return cur.lastrowid or 0
    finally:
        await conn.close()


async def audit(action: str, *, username: str | None = None, ip: str | None = None,
                target: str | None = None, ok: bool = True, detail: str | None = None) -> None:
    await execute(
        "INSERT INTO audit_log (username, ip, action, target, ok, detail) VALUES (?,?,?,?,?,?)",
        (username, ip, action, target, 1 if ok else 0, detail),
    )
