export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      admin_tables: {
        Row: {
          content_text: string | null
          content_type: string
          created_at: string
          created_by: string | null
          descricao: string | null
          file_url: string | null
          id: string
          ordem: number
          titulo: string
          updated_at: string
        }
        Insert: {
          content_text?: string | null
          content_type?: string
          created_at?: string
          created_by?: string | null
          descricao?: string | null
          file_url?: string | null
          id?: string
          ordem?: number
          titulo: string
          updated_at?: string
        }
        Update: {
          content_text?: string | null
          content_type?: string
          created_at?: string
          created_by?: string | null
          descricao?: string | null
          file_url?: string | null
          id?: string
          ordem?: number
          titulo?: string
          updated_at?: string
        }
        Relationships: []
      }
      app_settings: {
        Row: {
          aviso_dashboard: string | null
          id: number
          meta_diaria_blogueira: number
          meta_semanal_blogueira: number
          pix_template_contas_global: string | null
          pix_template_global: string | null
          promo_ativa: boolean
          promo_percentual: number
          promo_valor_minimo: number
          updated_at: string
        }
        Insert: {
          aviso_dashboard?: string | null
          id?: number
          meta_diaria_blogueira?: number
          meta_semanal_blogueira?: number
          pix_template_contas_global?: string | null
          pix_template_global?: string | null
          promo_ativa?: boolean
          promo_percentual?: number
          promo_valor_minimo?: number
          updated_at?: string
        }
        Update: {
          aviso_dashboard?: string | null
          id?: number
          meta_diaria_blogueira?: number
          meta_semanal_blogueira?: number
          pix_template_contas_global?: string | null
          pix_template_global?: string | null
          promo_ativa?: boolean
          promo_percentual?: number
          promo_valor_minimo?: number
          updated_at?: string
        }
        Relationships: []
      }
      image_shortcuts: {
        Row: {
          created_at: string
          created_by: string | null
          id: string
          image_url: string
          ordem: number
          titulo: string
          updated_at: string
        }
        Insert: {
          created_at?: string
          created_by?: string | null
          id?: string
          image_url: string
          ordem?: number
          titulo: string
          updated_at?: string
        }
        Update: {
          created_at?: string
          created_by?: string | null
          id?: string
          image_url?: string
          ordem?: number
          titulo?: string
          updated_at?: string
        }
        Relationships: []
      }
      operation_audit: {
        Row: {
          acao: string
          changed_at: string
          changed_by: string | null
          id: string
          operation_id: string
          snapshot: Json
          user_id: string
        }
        Insert: {
          acao: string
          changed_at?: string
          changed_by?: string | null
          id?: string
          operation_id: string
          snapshot: Json
          user_id: string
        }
        Update: {
          acao?: string
          changed_at?: string
          changed_by?: string | null
          id?: string
          operation_id?: string
          snapshot?: Json
          user_id?: string
        }
        Relationships: []
      }
      operations: {
        Row: {
          blogueira: number
          comissao: number
          comissao_contas: number
          contas_solicitadas: number
          created_at: string
          data_operacao: string | null
          deposito: number
          deposito_contas: number
          id: string
          link_casa: string | null
          lucro: number
          lucro_contas: number | null
          nome_conta: string | null
          observacao: string | null
          sacou: number
          salario_contas: number
          saque: number
          saque_contas: number
          updated_at: string
          user_id: string
          zerou: number
        }
        Insert: {
          blogueira?: number
          comissao?: number
          comissao_contas?: number
          contas_solicitadas?: number
          created_at?: string
          data_operacao?: string | null
          deposito?: number
          deposito_contas?: number
          id?: string
          link_casa?: string | null
          lucro?: number
          lucro_contas?: number | null
          nome_conta?: string | null
          observacao?: string | null
          sacou?: number
          salario_contas?: number
          saque?: number
          saque_contas?: number
          updated_at?: string
          user_id: string
          zerou?: number
        }
        Update: {
          blogueira?: number
          comissao?: number
          comissao_contas?: number
          contas_solicitadas?: number
          created_at?: string
          data_operacao?: string | null
          deposito?: number
          deposito_contas?: number
          id?: string
          link_casa?: string | null
          lucro?: number
          lucro_contas?: number | null
          nome_conta?: string | null
          observacao?: string | null
          sacou?: number
          salario_contas?: number
          saque?: number
          saque_contas?: number
          updated_at?: string
          user_id?: string
          zerou?: number
        }
        Relationships: []
      }
      profiles: {
        Row: {
          accumulated_debt: number
          blocked: boolean
          commission_contas_percent: number | null
          commission_percent: number | null
          created_at: string
          daily_goal: number
          debt_reset_at: string | null
          email: string
          id: string
          nome: string
          operator_type: string
          updated_at: string
          username: string | null
        }
        Insert: {
          accumulated_debt?: number
          blocked?: boolean
          commission_contas_percent?: number | null
          commission_percent?: number | null
          created_at?: string
          daily_goal?: number
          debt_reset_at?: string | null
          email: string
          id: string
          nome?: string
          operator_type?: string
          updated_at?: string
          username?: string | null
        }
        Update: {
          accumulated_debt?: number
          blocked?: boolean
          commission_contas_percent?: number | null
          commission_percent?: number | null
          created_at?: string
          daily_goal?: number
          debt_reset_at?: string | null
          email?: string
          id?: string
          nome?: string
          operator_type?: string
          updated_at?: string
          username?: string | null
        }
        Relationships: []
      }
      user_passwords: {
        Row: {
          created_at: string
          password: string
          updated_at: string
          user_id: string
        }
        Insert: {
          created_at?: string
          password: string
          updated_at?: string
          user_id: string
        }
        Update: {
          created_at?: string
          password?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      dono_exists: { Args: never; Returns: boolean }
      get_user_ranking: {
        Args: never
        Returns: {
          deposito: number
          lucro: number
          nome: string
          pedidos: number
          saque: number
          user_id: string
        }[]
      }
      get_user_ranking_weekly: {
        Args: never
        Returns: {
          lucro: number
          nome: string
          pedidos: number
          user_id: string
        }[]
      }
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
      is_dono: { Args: { _user_id: string }; Returns: boolean }
    }
    Enums: {
      app_role: "admin" | "user" | "owner"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "user", "owner"],
    },
  },
} as const
