import { memo, useEffect, useMemo, useState } from "react";
import { Calculator, Percent, Copy, Pencil, Check, Tag } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { formatBRL } from "@/lib/format";
import { toast } from "sonner";
import { maxContasFromMontante } from "@/lib/contas";
import { supabase } from "@/integrations/supabase/client";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { DEFAULT_MONTANTE_TEMPLATE, renderTemplate } from "@/lib/pixTemplates";

const DEFAULT_HEADER = `📌 PIX CELULAR

💠 CHAVE

🏷️ NOME - INTER`;

function SideCalculatorImpl() {
  const qc = useQueryClient();
  const [valor, setValor] = useState("");
  const [percentStr, setPercentStr] = useState<string>(() => {
    if (typeof window === "undefined") return "20";
    return localStorage.getItem("calc:percent") ?? "20";
  });

  // Cabeçalho local do usuário (PIX pessoal) — fallback localStorage
  const [pixHeader, setPixHeader] = useState<string>(() => {
    if (typeof window === "undefined") return DEFAULT_HEADER;
    return localStorage.getItem("pix:header") ?? DEFAULT_HEADER;
  });
  const [editingHeader, setEditingHeader] = useState(false);

  // Template global (ADM) — editável apenas em /tabelas
  const { data: globalTemplate } = useQuery({
    queryKey: ["pix-template-global"],
    queryFn: async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("pix_template_global")
        .eq("id", 1)
        .maybeSingle();
      return (data?.pix_template_global as string | null) ?? null;
    },
  });

  // Promoção definida pelos admins em /tabelas. Vale para todos os usuários.
  const { data: promo } = useQuery({
    queryKey: ["promo-calculadora"],
    queryFn: async () => {
      const { data } = await supabase
        .from("app_settings")
        .select("promo_ativa, promo_valor_minimo, promo_percentual")
        .eq("id", 1)
        .maybeSingle();
      return data ?? null;
    },
  });

  const [copied, setCopied] = useState(false);

  const percentEscolhido = Number(percentStr) || 0;
  const valorNum = Number(valor) || 0;

  const promoMin = Number(promo?.promo_valor_minimo ?? 0);
  const promoPct = Number(promo?.promo_percentual ?? 0);
  const promoAtiva = Boolean(promo?.promo_ativa) && promoMin > 0 && promoPct > 0;
  const promoAplicada = promoAtiva && valorNum >= promoMin;

  // Enquanto a promoção vale, ela manda na porcentagem. A escolha manual do
  // usuário fica guardada e volta assim que o montante cai abaixo do mínimo.
  const percent = promoAplicada ? promoPct : percentEscolhido;

  useEffect(() => {
    try {
      localStorage.setItem("calc:percent", String(percentEscolhido));
      window.dispatchEvent(new CustomEvent("calc:percent-changed", { detail: percent }));
    } catch {}
  }, [percent, percentEscolhido]);

  useEffect(() => {
    try { localStorage.setItem("pix:header", pixHeader); } catch {}
  }, [pixHeader]);

  // Quando o admin liga, desliga ou ajusta a promoção, quem já está com a
  // página aberta recebe a mudança sem precisar recarregar.
  useEffect(() => {
    const channel = supabase
      .channel("promo-calc")
      .on(
        "postgres_changes",
        { event: "UPDATE", schema: "public", table: "app_settings" },
        () => qc.invalidateQueries({ queryKey: ["promo-calculadora"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(channel);
    };
  }, [qc]);

  const valorPercentual = useMemo(() => valorNum * (percent / 100), [valorNum, percent]);
  const valorRestante = useMemo(() => valorNum - valorPercentual, [valorNum, valorPercentual]);
  const nContas = useMemo(() => maxContasFromMontante(valorNum), [valorNum]);

  const pixMessage = useMemo(() => {
    const template = (globalTemplate ?? DEFAULT_MONTANTE_TEMPLATE);
    const avisoAlto =
      nContas === 1 && valorNum > 150
        ? "\n\n⚠️ Montante alto feito em apenas uma conta, será feito vários depósitos até atingir o valor total!"
        : "";
    return renderTemplate(template, {
      header: pixHeader.trim(),
      montante: valorNum > 0 ? valorNum.toLocaleString("pt-BR") : "—",
      valor: formatBRL(valorPercentual),
      contas: String(nContas),
      contas_label: nContas === 1 ? "conta" : "contas",
      aviso_alto: avisoAlto,
    });
  }, [globalTemplate, pixHeader, valorNum, valorPercentual, nContas]);

  const copiarPix = async () => {
    try {
      await navigator.clipboard.writeText(pixMessage);
      setCopied(true);
      toast.success("Mensagem PIX copiada");
      setTimeout(() => setCopied(false), 1800);
    } catch {
      toast.error("Não foi possível copiar");
    }
  };

  return (
    <div className="glass-strong space-y-5 rounded-2xl p-5">
      <div className="flex items-center gap-2">
        <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-primary/15 text-primary ring-1 ring-primary/30">
          <Calculator className="h-4 w-4" />
        </div>
        <div>
          <h3 className="font-semibold leading-tight">Calculadora de %</h3>
          <p className="text-xs text-muted-foreground">Quanto vale X% de um valor</p>
        </div>
      </div>

      <div className="space-y-3">
        <div className="space-y-1.5">
          <Label htmlFor="calc-valor" className="text-xs">Montante (R$)</Label>
          <Input
            id="calc-valor"
            type="number"
            inputMode="decimal"
            placeholder="0,00"
            value={valor}
            onChange={(e) => setValor(e.target.value)}
          />
        </div>
        <div className="space-y-1.5">
          <div className="flex items-center justify-between">
            <Label htmlFor="calc-pct" className="text-xs">Porcentagem (%)</Label>
            {promoAplicada && (
              <span className="flex items-center gap-1 rounded-full bg-accent/15 px-2 py-0.5 text-[10px] font-bold uppercase tracking-wider text-accent ring-1 ring-accent/30">
                <Tag className="h-3 w-3" /> Promoção
              </span>
            )}
          </div>
          <Input
            id="calc-pct"
            type="number"
            inputMode="decimal"
            min={0}
            max={100}
            step="0.01"
            placeholder="ex: 20"
            value={promoAplicada ? String(promoPct) : percentStr}
            onChange={(e) => setPercentStr(e.target.value)}
            disabled={promoAplicada}
            className={promoAplicada ? "border-accent/50 font-bold text-accent" : undefined}
          />
          {promoAtiva && !promoAplicada && (
            <p className="text-[10px] text-muted-foreground">
              Montantes a partir de {formatBRL(promoMin)} usam {promoPct}% automaticamente.
            </p>
          )}
          {promoAplicada && (
            <p className="text-[10px] text-accent">
              Promoção aplicada: montante de {formatBRL(promoMin)} ou mais.
            </p>
          )}
        </div>
      </div>

      <div className="space-y-2 rounded-xl border border-border bg-background/40 p-4">
        <div className="flex items-center justify-between text-sm">
          <span className="flex items-center gap-1 text-muted-foreground">
            <Percent className="h-3 w-3" /> {percent}% de {formatBRL(valorNum)}
          </span>
          <span className="number-tabular font-bold text-accent">
            {formatBRL(valorPercentual)}
          </span>
        </div>
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Valor restante</span>
          <span className="number-tabular font-semibold">{formatBRL(valorRestante)}</span>
        </div>
        <div className="flex items-center justify-between text-xs text-muted-foreground">
          <span>Divisão sugerida</span>
          <span className="font-semibold text-foreground">Até {nContas} {nContas === 1 ? "conta" : "contas"}</span>
        </div>
      </div>

      {/* Mensagem PIX pronta */}
      <div className="space-y-2 rounded-xl border border-primary/30 bg-gradient-to-br from-primary/5 to-transparent p-3">
        <div className="flex items-center justify-between">
          <p className="text-[10px] font-bold uppercase tracking-wider text-primary">Mensagem PIX</p>
          <div className="flex gap-1">
            <Button
              type="button"
              size="sm"
              variant="ghost"
              className="h-7 px-2"
              onClick={() => setEditingHeader((v) => !v)}
              title="Editar sua chave PIX"
            >
              <Pencil className="h-3 w-3" />
            </Button>
            <Button
              type="button"
              size="sm"
              variant="ghost"
              className="h-7 px-2"
              onClick={copiarPix}
              title="Copiar mensagem"
            >
              {copied ? <Check className="h-3 w-3 text-success" /> : <Copy className="h-3 w-3" />}
            </Button>
          </div>
        </div>

        {editingHeader && (
          <div className="space-y-1.5">
            <Label className="text-[10px] uppercase tracking-wider text-muted-foreground">
              Sua chave PIX (fica salva neste navegador)
            </Label>
            <Textarea
              value={pixHeader}
              onChange={(e) => setPixHeader(e.target.value)}
              rows={5}
              className="text-xs"
            />
            <div className="flex justify-end">
              <Button type="button" size="sm" variant="ghost" className="h-7 text-[10px]" onClick={() => setPixHeader(DEFAULT_HEADER)}>
                Restaurar padrão
              </Button>
            </div>
          </div>
        )}

        <pre className="max-h-72 overflow-auto whitespace-pre-wrap rounded-lg bg-background/60 p-3 text-[11px] leading-relaxed text-foreground">
{pixMessage}
        </pre>
      </div>
    </div>
  );
}

export const SideCalculator = memo(SideCalculatorImpl);
