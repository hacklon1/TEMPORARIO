// Admin-only CRUD over auth users + profiles + roles.
// Requires a JWT belonging to a user with role = 'admin'.
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
};

// "owner" é o valor no banco; "Dono" é só o rótulo da interface.
type AppRole = "admin" | "user" | "owner";
type OperatorType = "bi" | "montante" | "contas";

type Action =
  | { action: "list" }
  | {
    action: "create";
    email?: string;
    username: string;
    operator_type?: OperatorType;
    password: string;
    nome?: string;
    role: AppRole;
    commission_percent?: number | null;
    commission_contas_percent?: number | null;
    daily_goal?: number | null;
  }
  | {
    action: "update";
    user_id: string;
    nome?: string;
    username?: string;
    operator_type?: OperatorType;
    email?: string;
    password?: string;
    role?: AppRole;
    commission_percent?: number | null;
    commission_contas_percent?: number | null;
    daily_goal?: number | null;
  }
  | { action: "delete"; user_id: string };

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const jwt = authHeader.replace("Bearer ", "");
    if (!jwt) {
      return json({ error: "missing auth" }, 401);
    }

    const url = Deno.env.get("SUPABASE_URL")!;
    const serviceKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    // Verify caller
    const userClient = createClient(url, anonKey, {
      global: { headers: { Authorization: `Bearer ${jwt}` } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) return json({ error: "unauthorized" }, 401);

    const admin = createClient(url, serviceKey);
    // has_role já trata DONO como superconjunto de admin.
    const { data: isAdmin, error: roleErr } = await admin.rpc("has_role", {
      _user_id: userData.user.id,
      _role: "admin",
    });
    if (roleErr) throw roleErr;
    if (!isAdmin) return json({ error: "forbidden" }, 403);

    // Esta função roda com service_role, que passa por cima do RLS. Por isso a
    // proteção do DONO precisa ser aplicada aqui explicitamente.
    const callerIsDono = await isDono(admin, userData.user.id);

    const targetIsDono = (userId: string) => isDono(admin, userId);

    const body = (await req.json()) as Action;

    if (body.action === "list") {
      const { data: profiles, error: pErr } = await admin
        .from("profiles")
        .select("id, nome, email, username, operator_type, created_at, commission_percent, commission_contas_percent, daily_goal")
        .order("created_at", { ascending: false });
      if (pErr) throw pErr;
      const { data: roles, error: rErr } = await admin
        .from("user_roles")
        .select("user_id, role");
      if (rErr) throw rErr;
      const map = new Map(roles.map((r) => [r.user_id, r.role]));

      // Cópia legível da senha. Só sai daqui porque o chamador já foi
      // validado como admin/DONO logo acima.
      const { data: senhas, error: sErr } = await admin
        .from("user_passwords")
        .select("user_id, password");
      if (sErr) throw sErr;
      const senhaMap = new Map((senhas ?? []).map((s) => [s.user_id, s.password]));

      return json({
        users: (profiles ?? []).map((p) => ({
          ...p,
          role: map.get(p.id) ?? "user",
          password: senhaMap.get(p.id) ?? "",
        })),
      });
    }

    if (body.action === "create") {
      if (body.role === "owner" && !callerIsDono) {
        const { data: existe } = await admin.rpc("dono_exists");
        if (existe) {
          return json({ error: "Apenas um DONO pode criar outro DONO" }, 403);
        }
      }
      const username = normalizeUsername(body.username);
      if (!username) {
        return json({ error: "Informe um usuário válido (letras, números, ponto, hífen ou underscore)" }, 400);
      }
      if (await usernameTaken(admin, username)) {
        return json({ error: `O usuário "${username}" já existe. Escolha outro nome de login.` }, 400);
      }

      // O login é por usuário; o email é só encanamento do Supabase Auth.
      // Se a tela não mandar um, derivamos do próprio usuário.
      const email = body.email?.trim() || `${username}@db.local`;
      // Nome e usuário são equivalentes.
      const nome = body.nome?.trim() || username;

      const { data: created, error } = await admin.auth.admin.createUser({
        email,
        password: body.password,
        email_confirm: true,
        user_metadata: { nome, username },
      });
      if (error) {
        const msg = String(error.message ?? error);
        const friendly = /known to be weak|easy to guess/i.test(msg)
          ? "Esta senha é muito comum. Escolha uma senha mais forte."
          : /weak|should be at least|short/i.test(msg)
          ? "A senha é muito fraca. Use ao menos 6 caracteres."
          : msg;
        return json({ error: friendly }, 400);
      }
      const uid = created.user!.id;
      // Ensure correct nome + extras
      const profPayload: Record<string, unknown> = { nome, username, email };
      // Categoria só se aplica a Operador; admin e dono enxergam tudo.
      profPayload.operator_type = body.role === "user" ? (body.operator_type ?? "bi") : "bi";
      if (body.commission_percent !== undefined) profPayload.commission_percent = body.commission_percent;
      if (body.commission_contas_percent !== undefined) profPayload.commission_contas_percent = body.commission_contas_percent;
      if (body.daily_goal !== undefined) profPayload.daily_goal = body.daily_goal ?? 0;
      await admin.from("profiles").update(profPayload).eq("id", uid);
      // O trigger do banco já semeia 'user'. Troca se pediram outro papel.
      if (body.role && body.role !== "user") {
        await admin.from("user_roles").delete().eq("user_id", uid);
        await admin.from("user_roles").insert({ user_id: uid, role: body.role });
      }
      await savePassword(admin, uid, body.password);
      return json({ ok: true, user_id: uid });
    }

    if (body.action === "update") {
      if (!callerIsDono && await targetIsDono(body.user_id)) {
        return json({ error: "Apenas um DONO pode alterar a conta de um DONO" }, 403);
      }
      if (body.role === "owner" && !callerIsDono) {
        const { data: existe } = await admin.rpc("dono_exists");
        if (existe) {
          return json({ error: "Apenas um DONO pode conceder o papel de DONO" }, 403);
        }
      }
      const updates: Record<string, unknown> = {};
      if (body.email) updates.email = body.email;
      if (body.password) updates.password = body.password;
      if (Object.keys(updates).length) {
        const { error } = await admin.auth.admin.updateUserById(
          body.user_id,
          updates,
        );
        if (error) {
          const msg = String(error.message ?? error);
          const friendly = /same.*password|different from the old/i.test(msg)
            ? "A nova senha deve ser diferente da senha atual."
            : /weak.password|should be at least|short/i.test(msg)
            ? "A senha é muito fraca. Use ao menos 6 caracteres."
            : /email/i.test(msg) && /exist|registered|already/i.test(msg)
            ? "Este email já está em uso."
            : msg;
          return json({ error: friendly }, 400);
        }
      }
      const profileUpdate: Record<string, unknown> = {};
      if (body.username !== undefined) {
        const username = normalizeUsername(body.username);
        if (!username) {
          return json({ error: "Informe um usuário válido (letras, números, ponto, hífen ou underscore)" }, 400);
        }
        if (await usernameTaken(admin, username, body.user_id)) {
          return json({ error: `O usuário "${username}" já existe. Escolha outro nome de login.` }, 400);
        }
        profileUpdate.username = username;
      }
      if (body.operator_type !== undefined) {
        profileUpdate.operator_type = body.role === "user" ? body.operator_type : "bi";
      }
      if (body.nome !== undefined) profileUpdate.nome = body.nome;
      if (body.email !== undefined) profileUpdate.email = body.email;
      if (body.commission_percent !== undefined) profileUpdate.commission_percent = body.commission_percent;
      if (body.commission_contas_percent !== undefined) profileUpdate.commission_contas_percent = body.commission_contas_percent;
      if (body.daily_goal !== undefined) profileUpdate.daily_goal = body.daily_goal ?? 0;
      if (Object.keys(profileUpdate).length) {
        await admin.from("profiles").update(profileUpdate).eq(
          "id",
          body.user_id,
        );
      }
      if (body.role) {
        await admin.from("user_roles").delete().eq("user_id", body.user_id);
        await admin.from("user_roles").insert({
          user_id: body.user_id,
          role: body.role,
        });
      }
      await savePassword(admin, body.user_id, body.password);
      return json({ ok: true });
    }

    if (body.action === "delete") {
      if (!callerIsDono && await targetIsDono(body.user_id)) {
        return json({ error: "Apenas um DONO pode remover um DONO" }, 403);
      }
      const { error } = await admin.auth.admin.deleteUser(body.user_id);
      if (error) throw error;
      return json({ ok: true });
    }

    return json({ error: "invalid action" }, 400);
  } catch (e) {
    console.error("admin-users error", e);
    return json({ error: String(e?.message ?? e) }, 500);
  }
});

// Guarda a cópia legível da senha, para os Admins/DONOS verem na tela.
// O Supabase Auth segue com o hash — esta tabela é só espelho de exibição.
async function savePassword(
  admin: ReturnType<typeof createClient>,
  userId: string,
  password: string | undefined,
) {
  if (!password) return;
  const { error } = await admin
    .from("user_passwords")
    .upsert(
      { user_id: userId, password, updated_at: new Date().toISOString() },
      { onConflict: "user_id" },
    );
  if (error) console.error("savePassword", error);
}

// Preserva a caixa digitada: "JoaoSilva" continua "JoaoSilva".
// A unicidade e o login seguem sem diferenciar maiúsculas de minúsculas.
function normalizeUsername(raw: string | undefined): string | null {
  if (!raw) return null;
  const clean = raw
    .trim()
    .normalize("NFD")
    .replace(/[̀-ͯ]/g, "")
    .replace(/[^A-Za-z0-9._-]+/g, "")
    .replace(/^[._-]+|[._-]+$/g, "");
  return clean.length >= 3 ? clean : null;
}

async function usernameTaken(
  admin: ReturnType<typeof createClient>,
  username: string,
  exceptUserId?: string,
) {
  let q = admin.from("profiles").select("id").ilike("username", username);
  if (exceptUserId) q = q.neq("id", exceptUserId);
  const { data, error } = await q.maybeSingle();
  if (error) throw error;
  return Boolean(data);
}

async function isDono(admin: ReturnType<typeof createClient>, userId: string) {
  const { data, error } = await admin.rpc("is_dono", { _user_id: userId });
  if (error) throw error;
  return Boolean(data);
}

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
