// Análise de texto e extração de dados financeiros das mensagens.
//
// Regras de negócio (build do zero a partir da spec — ajuste aqui se necessário):
//  - "Montante" = valor ao lado da palavra montante ("🔸 Montante: 233").
//  - "Conta"    = valor rotulado pela palavra "Valor" ("💸 Valor R$ 6,00").
//                 "R$ x" solto NÃO é conta — é o valor a pagar do montante.
//  - parseBrazilianNumber entende os formatos brasileiros de moeda.

// Converte as fontes "estilizadas" que o WhatsApp/os bots usam para ASCII.
//   "𝐌𝐨𝐧𝐭𝐚𝐧𝐭𝐞" / "𝗠𝗼𝗻𝘁𝗮𝗻𝘁𝗲" / "ｍｏｎｔａｎｔｅ"  ->  "Montante"
// Sem isto, /montante/i NÃO casa (são pontos de código do bloco Mathematical
// Alphanumeric Symbols, U+1D400+) e o montante da mensagem era ignorado.
export function desestilizar(str) {
  return String(str ?? '').normalize('NFKC');
}

// Remove acentos, baixa a caixa e colapsa espaços — usado para casar palavras-chave.
export function normalizeText(str) {
  return desestilizar(str)
    .normalize('NFD')
    .replace(/[̀-ͯ]/g, '') // remove diacríticos
    .toLowerCase()
    .replace(/\s+/g, ' ')
    .trim();
}

// Normaliza especificamente linhas de "montante" (remove emojis/símbolos, mantém dígitos e separadores).
export function normalizeMontanteText(str) {
  return normalizeText(str).replace(/[^\w\s.,:$rR-]/g, ' ').replace(/\s+/g, ' ').trim();
}

// Extrai o texto de qualquer tipo de mensagem do Baileys.
export function extractText(message) {
  if (!message) return '';
  const m = message.message ?? message;
  return (
    m?.conversation ??
    m?.extendedTextMessage?.text ??
    m?.imageMessage?.caption ??
    m?.videoMessage?.caption ??
    m?.documentMessage?.caption ??
    m?.buttonsResponseMessage?.selectedDisplayText ??
    m?.listResponseMessage?.title ??
    ''
  );
}

// Converte um número no formato brasileiro para Number.
//  "100" -> 100 | "100,50" -> 100.5 | "1.000" -> 1000
//  "1.500,99" -> 1500.99 | "R$ 500" -> 500 | "350,00" -> 350
// Retorna null se não houver dígitos.
export function parseBrazilianNumber(raw) {
  if (raw == null) return null;
  let s = String(raw).trim();
  // remove tudo que não é dígito, ponto, vírgula ou sinal
  s = s.replace(/[^\d.,-]/g, '');
  if (!/\d/.test(s)) return null;

  const hasDot = s.includes('.');
  const hasComma = s.includes(',');

  if (hasDot && hasComma) {
    // o último separador é o decimal; o outro é milhar
    if (s.lastIndexOf(',') > s.lastIndexOf('.')) {
      // vírgula é decimal: 1.500,99
      s = s.replace(/\./g, '').replace(',', '.');
    } else {
      // ponto é decimal: 1,500.99 (formato US ocasional)
      s = s.replace(/,/g, '');
    }
  } else if (hasComma) {
    // só vírgula -> decimal
    s = s.replace(',', '.');
  } else if (hasDot) {
    // só ponto: pode ser milhar (1.000 / 1.500.000) ou decimal (100.50)
    const parts = s.split('.');
    const allThousandGroups = parts.slice(1).every((p) => p.length === 3);
    if (parts.length > 1 && allThousandGroups && parts[0].length <= 3) {
      // padrão de milhar -> remove os pontos
      s = s.replace(/\./g, '');
    }
    // caso contrário mantém o ponto como decimal
  }

  const n = Number(s);
  return Number.isFinite(n) ? n : null;
}

// --- padrões de montante -------------------------------------------------
// Só olhamos a MESMA linha da palavra "montante" ([^\S\n] = espaço que não é
// quebra de linha), para não capturar o "💸 R$ ..." da linha de baixo.
const RE_MONTANTE_PALAVRA = /montantes?/gi;
// 1ª opção: valor DEPOIS da palavra, com separador explícito (":", "-", "=" ou "R$").
//   "Montante: 233" | "Montante: R$ 350,00" | "Montante final - 1.000"
const RE_APOS_SEPARADOR =
  /^[^\S\n]*(?:total|final|liquido|liquida)?[^\S\n]*(?:[:\-=]+[^\S\n]*(?:r\$|rs)?|(?:r\$|rs))[^\S\n]*(\d[\d.,]*)/i;
// 2ª opção: valor ANTES da palavra — "300 de montante", "600 montante".
const RE_ANTES = /(\d[\d.,]*)[^\S\n]*(?:reais[^\S\n]*)?(?:(?:de|em|no|d[eo]s)[^\S\n]+)?$/i;
// 3ª opção: valor logo depois, sem separador — "Montante 300".
const RE_APOS_SOLTO = /^[^\S\n]*(\d[\d.,]*)/i;

const JANELA = 40; // caracteres examinados de cada lado da palavra

// Extrai TODOS os montantes de um texto. Retorna { total, valores, spans }.
// Casa "Montante: 200", "Montante: R$200", "🔸 𝐌𝐨𝐧𝐭𝐚𝐧𝐭𝐞: 233" e "300 de montante".
// `spans` são os trechos [ini, fim) ocupados por cada montante no texto já
// desestilizado — extractContas usa isso para não recontar o montante.
export function extractMontante(text) {
  const t = desestilizar(text);
  const valores = [];
  const spans = [];

  RE_MONTANTE_PALAVRA.lastIndex = 0;
  let w;
  while ((w = RE_MONTANTE_PALAVRA.exec(t)) !== null) {
    const ini = w.index;
    const fim = ini + w[0].length;
    const depois = t.slice(fim, fim + JANELA);
    const antes = t.slice(Math.max(0, ini - JANELA), ini);

    // 1) "Montante: X" — o separador torna a leitura inequívoca, vence sempre.
    const comSep = RE_APOS_SEPARADOR.exec(depois);
    if (comSep && registrar(comSep[1], ini, fim + comSep[0].length)) continue;

    // 2) sem separador os dois lados competem ("500 montante 3 contas" x
    //    "1 montante 500"): o montante é um valor em reais, quase sempre maior
    //    que a quantidade de contas / o multiplicador ao lado — fica com o maior.
    const anterior = RE_ANTES.exec(antes);
    const solto = RE_APOS_SOLTO.exec(depois);
    const vAntes = anterior ? parseBrazilianNumber(anterior[1]) : null;
    const vSolto = solto ? parseBrazilianNumber(solto[1]) : null;

    if (vAntes != null && (vSolto == null || vAntes >= vSolto)) {
      registrar(anterior[1], ini - (antes.length - anterior.index), fim);
    } else if (vSolto != null) {
      registrar(solto[1], ini, fim + solto[0].length);
    }
  }

  function registrar(bruto, ini, fim) {
    const n = parseBrazilianNumber(bruto);
    if (n == null) return false;
    valores.push(n);
    spans.push([ini, fim]);
    return true;
  }

  const total = valores.reduce((a, b) => a + b, 0);
  return { total, valores, spans };
}

// Substitui por espaços os trechos já contabilizados como montante.
function mascarar(t, spans) {
  if (!spans.length) return t;
  let out = t;
  for (const [ini, fim] of spans) {
    out = out.slice(0, ini) + ' '.repeat(fim - ini) + out.slice(fim);
  }
  return out;
}

// Valor de conta: SÓ com a palavra "Valor" rotulando a quantia, na mesma linha.
//   "💸 𝗩𝗮𝗹𝗼𝗿 R$ 6,00" | "Valor: R$ 25" | "Valor final: R$ 28,50"
const RE_VALOR_CONTA =
  /valor(?:[^\S\n]*(?:final|total))?[^\S\n]*[:\-=]?[^\S\n]*(?:r\$|rs)?[^\S\n]*(\d[\d.,]*)/gi;

// Extrai "contas" (entradas de valor/pagamento). Retorna { qtd, total, entradas: [] }.
// Um "R$ x" SOLTO (sem a palavra "Valor") NÃO conta: nas mensagens de montante
// esse é o valor a pagar pelo montante, não uma conta.
export function extractContas(text, spansMontante) {
  // mascara o que já foi contabilizado como montante, para não contar duas vezes
  const spans = spansMontante ?? extractMontante(text).spans;
  const t = mascarar(desestilizar(text), spans);
  const entradas = [];

  RE_VALOR_CONTA.lastIndex = 0;
  let m;
  while ((m = RE_VALOR_CONTA.exec(t)) !== null) {
    const n = parseBrazilianNumber(m[1]);
    if (n != null) entradas.push({ tipo: 'valor', valor: n });
  }

  const total = entradas.reduce((a, e) => a + e.valor, 0);
  return { qtd: entradas.length, total, entradas };
}

/* ═══════════ SALÁRIO DO OPERADOR ═══════════
   O que a Brogueira paga ao Operador por aquele atendimento — é a base da
   comissão que a casa cobra dele (ver src/comissoes.js).

   NÃO é a mesma coisa que "conta". Conta continua exigindo a palavra "Valor"
   (regra endurecida a pedido do usuário em 02/08); o salário aceita também o
   "R$ x" solto, porque o template mais usado no grupo escreve o preço sem
   rótulo nenhum, logo abaixo do montante:

       🔸 Montante: 100
       💸 R$ 20,00        ← o salário
       📊 Até 1 conta

   Confundir os dois foi o que zerou a comissão de 167 dos 315 serviços do
   histórico: `salarioDoServico` lia `contasTotal`, que nesse template é 0.

   O montante já vem mascarado, então "Montante: R$ 100" não é lido como preço.
   Medido nas mensagens reais: toda mensagem de Operador tem NO MÁXIMO um "R$",
   e nas 142 que trazem os dois formatos o "Valor" e o "R$" solto sempre batem. */
const RE_RS_SOLTO = /(?:r\$|rs)[^\S\n]*(\d[\d.,]*)/gi;
// Último recurso: o 💸 seguido direto do número, sem "R$" nenhum ("💸 20").
// O emoji só aparece na linha do preço nesses templates, então ele é o rótulo.
// Não colide com "💸 R$ 20" (ali o que vem depois do emoji é a letra R).
const RE_EMOJI_PRECO = /💸[^\S\n]*[:\-=]?[^\S\n]*(\d[\d.,]*)/;

export function extractSalario(text, spansMontante) {
  const spans = spansMontante ?? extractMontante(text).spans;
  const t = mascarar(desestilizar(text), spans);

  // 1º o rotulado — é o mais explícito, e quando existe é o mesmo número.
  const rotulado = extractContas(text, spans);
  if (rotulado.total > 0) return rotulado.total;

  // 2º o "R$" solto. Só o PRIMEIRO: é a linha do preço, logo abaixo do
  // montante. Somar todos faria um texto promocional com vários "R$" virar um
  // salário inventado.
  RE_RS_SOLTO.lastIndex = 0;
  const comMoeda = RE_RS_SOLTO.exec(t);
  const n = comMoeda ? parseBrazilianNumber(comMoeda[1]) : null;
  if (n != null && n > 0) return n;

  // 3º o preço marcado só pelo emoji.
  const soEmoji = RE_EMOJI_PRECO.exec(t);
  const e = soEmoji ? parseBrazilianNumber(soEmoji[1]) : null;
  return e != null && e > 0 ? e : 0;
}

// Quantas contas o Operador diz que aquele montante rende: "📊 Até 2 contas".
// É o ÚNICO lugar da mensagem dele que fala em QUANTIDADE de contas — o
// "Valor: R$ x" é preço, não quantidade. Aparece em 89% das mensagens reais de
// Operador, e é por ele que um pedido de "2 contas" casa por valor (antes só o
// montante casava, e todo pedido de conta caía no elo fraco da proximidade).
const RE_ATE_CONTAS = /\bate[^\S\n]*(\d[\d.,]*)[^\S\n]*contas?\b/i;

export function contasOferecidas(text) {
  const m = RE_ATE_CONTAS.exec(normalizeText(text));
  const n = m ? parseBrazilianNumber(m[1]) : null;
  return n != null && n > 0 ? n : 0;
}

// Analisa uma mensagem inteira e devolve o resumo financeiro (ou null se não houver nada).
export function analisarMensagem(text) {
  const montante = extractMontante(text);
  const contas = extractContas(text, montante.spans);
  if (montante.valores.length === 0 && contas.qtd === 0) return null;
  return {
    montante: montante.total,
    montanteValores: montante.valores,
    contasQtd: contas.qtd,
    contasTotal: contas.total,
    contasEntradas: contas.entradas,
    // O que o Operador cobrou por este atendimento — base da comissão.
    salario: extractSalario(text, montante.spans),
    // quantidade anunciada ("Até 2 contas") — usada no casamento do passo 2
    contasOferecidas: contasOferecidas(text),
  };
}
