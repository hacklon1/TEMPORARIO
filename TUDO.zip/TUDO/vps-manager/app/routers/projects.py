"""Listagem e download dos projetos em /opt."""
from __future__ import annotations

import asyncio
import datetime as dt
import os

from fastapi import APIRouter, Depends, HTTPException, Query, Request
from fastapi.responses import StreamingResponse

from .. import db
from ..config import settings
from ..deps import admin_user, client_ip, current_user
from ..services import archiver

router = APIRouter(prefix="/api/projects", tags=["projects"])


@router.get("")
async def list_projects(user: dict = Depends(admin_user)):
    items = archiver.list_projects()
    sizes = await asyncio.gather(*[archiver.dir_size(i["path"]) for i in items])
    for item, size in zip(items, sizes):
        item.update(size)
    return {"roots": settings.roots, "excludes": settings.excludes, "projects": items}


@router.get("/{name}/info")
async def project_info(name: str, root: str = "/opt", user: dict = Depends(admin_user)):
    try:
        path = archiver.resolve_project(root, name)
    except archiver.ArchiveError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    size, files = await asyncio.gather(archiver.dir_size(path), archiver.file_count(path))
    return {"name": name, "path": path, "files": files, **size}


def _stamp() -> str:
    return dt.datetime.now().strftime("%Y%m%d-%H%M")


@router.get("/{name}/download")
async def download_project(
    name: str,
    request: Request,
    root: str = "/opt",
    fmt: str = Query("tar.gz", pattern="^(tar\\.gz|zip)$"),
    full: bool = False,
    user: dict = Depends(admin_user),
):
    try:
        path = archiver.resolve_project(root, name)
    except archiver.ArchiveError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    base_dir = os.path.dirname(path)
    suffix = "completo" if full else "enxuto"
    filename = f"{name}-{suffix}-{_stamp()}.{'zip' if fmt == 'zip' else 'tar.gz'}"
    media = "application/zip" if fmt == "zip" else "application/gzip"

    await db.audit("project.download", username=user["username"], ip=client_ip(request),
                   target=path, detail=f"fmt={fmt} full={full}")

    return StreamingResponse(
        archiver.stream_archive([path], base_dir, "zip" if fmt == "zip" else "tar.gz", full),
        media_type=media,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-Accel-Buffering": "no",
            "Cache-Control": "no-store",
        },
    )


@router.get("/download-all")
async def download_all(
    request: Request,
    root: str = "/opt",
    fmt: str = Query("tar.gz", pattern="^(tar\\.gz|zip)$"),
    full: bool = False,
    user: dict = Depends(admin_user),
):
    """Baixa TODOS os projetos da raiz em um unico arquivo."""
    if root not in settings.roots:
        raise HTTPException(status_code=400, detail="raiz nao permitida")
    paths = [i["path"] for i in archiver.list_projects() if i["root"] == root]
    if not paths:
        raise HTTPException(status_code=404, detail="nenhum projeto encontrado")

    label = os.path.basename(root.rstrip("/")) or "raiz"
    suffix = "completo" if full else "enxuto"
    filename = f"{label}-todos-{suffix}-{_stamp()}.{'zip' if fmt == 'zip' else 'tar.gz'}"
    media = "application/zip" if fmt == "zip" else "application/gzip"

    await db.audit("project.download_all", username=user["username"], ip=client_ip(request),
                   target=root, detail=f"fmt={fmt} full={full} n={len(paths)}")

    return StreamingResponse(
        archiver.stream_archive(paths, root, "zip" if fmt == "zip" else "tar.gz", full),
        media_type=media,
        headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "X-Accel-Buffering": "no",
            "Cache-Control": "no-store",
        },
    )
