-- Papel DONO (gravado como 'owner' no enum).
-- Precisa ficar sozinho nesta migração: o Postgres não permite usar um valor
-- de enum na mesma transação em que ele é criado.
ALTER TYPE public.app_role ADD VALUE IF NOT EXISTS 'owner';
