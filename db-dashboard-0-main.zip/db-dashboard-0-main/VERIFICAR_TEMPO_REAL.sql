-- Verifica e garante que a tabela de operações emite eventos de tempo real.
--
-- Cole no SQL Editor do Supabase. Pode rodar mais de uma vez.

-- 1. A tabela está publicada no Realtime?
--    Se vier vazio, o painel nunca recebe eventos e depende só da recarga.
SELECT tablename AS tabelas_publicadas_no_realtime
  FROM pg_publication_tables
 WHERE pubname = 'supabase_realtime'
   AND schemaname = 'public';

-- 2. Garante a publicação (ignora o erro se já estiver publicada).
DO $$
BEGIN
  ALTER PUBLICATION supabase_realtime ADD TABLE public.operations;
EXCEPTION
  WHEN duplicate_object THEN NULL;
END $$;

-- 3. REPLICA IDENTITY FULL faz os eventos de UPDATE e DELETE virem completos.
--    Sem isso, editar ou apagar uma operação não atualiza o painel direito.
ALTER TABLE public.operations REPLICA IDENTITY FULL;

-- 4. Confirmação final — 'operations' deve aparecer na lista.
SELECT tablename AS agora_publicadas
  FROM pg_publication_tables
 WHERE pubname = 'supabase_realtime'
   AND schemaname = 'public';
