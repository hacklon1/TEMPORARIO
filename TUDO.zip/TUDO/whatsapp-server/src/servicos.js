// Validação de SERVIÇO em 3 passos — a correlação entre quem pede, quem atende
// e quem comprova.
//
//   PASSO 1  a Brogueira pede no grupo          → db.pedidos (pedidos.js)
//   PASSO 2  o Operador responde a ela          → db.messages (parser.js)
//   PASSO 3  a Brogueira manda o comprovante    → imagem ou PDF
//            PIX depois de um tempo
//
// Só quando os três passos se ligam à MESMA pessoa, no MESMO grupo e dentro do
// prazo é que existe um "serviço validado". É esse recorte — e só ele — que
// alimenta o quadro DESEMPENHO DOS OPERADORES; o quadro antigo continua
// contando toda mensagem financeira, validada ou não.
//
// Este módulo é PURO: recebe listas e devolve escolhas. Quem grava é o
// store.js — assim a regra de casamento pode ser testada sem tocar em disco.

import { contasOferecidas } from './parser.js';

// ── Prazos (padrão; ajustáveis em Configurações) ─────────────────────────
// Escolha do usuário: 1h do pedido até a resposta, 2h da resposta até o
// comprovante. Passou disso, o serviço não valida — casar coisas de horas
// diferentes seria pior do que não casar.
export const JANELA_ATENDIMENTO_PADRAO = 60; // minutos (passo 1 → passo 2)
export const JANELA_COMPROVANTE_PADRAO = 120; // minutos (passo 2 → passo 3)

// Como o passo 2 é reconhecido:
//   'cascata' → citação, senão valor, senão o pedido em aberto mais recente
//   'valor'   → citação, senão valor (nunca casa só por proximidade)
//   'citacao' → só quando o Operador usa "responder" na mensagem dela
export const MODOS_CASAMENTO = ['cascata', 'valor', 'citacao'];
export const MODO_CASAMENTO_PADRAO = 'cascata';

// Como um serviço foi casado, da prova mais forte para a mais fraca. Vai
// gravado no serviço e aparece no painel — dá para desconfiar dos 'tempo'.
export const CASAMENTOS = ['citacao', 'valor', 'tempo'];

export const STATUS = {
  AGUARDANDO_ATENDIMENTO: 'aguardando_atendimento',
  AGUARDANDO_COMPROVANTE: 'aguardando_comprovante',
  VALIDADO: 'validado',
  SEM_ATENDIMENTO: 'expirado_sem_atendimento',
  SEM_COMPROVANTE: 'expirado_sem_comprovante',
};

const MIN_MS = 60_000;

function inteiroPositivo(v, padrao) {
  const n = Number(v);
  return Number.isFinite(n) && n > 0 ? Math.round(n) : padrao;
}

// Lê os prazos e o modo da config global, já em milissegundos.
export function configServicos(config = {}) {
  const modo = MODOS_CASAMENTO.includes(config?.servicosModoCasamento)
    ? config.servicosModoCasamento
    : MODO_CASAMENTO_PADRAO;
  return {
    ligado: config?.servicosEnabled !== false,
    modo,
    janelaAtendimentoMin: inteiroPositivo(config?.servicosJanelaAtendimentoMin, JANELA_ATENDIMENTO_PADRAO),
    janelaComprovanteMin: inteiroPositivo(config?.servicosJanelaComprovanteMin, JANELA_COMPROVANTE_PADRAO),
    get janelaAtendimentoMs() { return this.janelaAtendimentoMin * MIN_MS; },
    get janelaComprovanteMs() { return this.janelaComprovanteMin * MIN_MS; },
  };
}

/* ═══════════ Leitura da mensagem crua do Baileys ═══════════ */

// O Baileys embrulha a mensagem em camadas (mensagem temporária, ver-uma-vez,
// documento com legenda). Sem descascar, um comprovante que veio como
// `documentWithCaptionMessage` não seria visto como PDF nenhum.
const EMBRULHOS = [
  'ephemeralMessage',
  'viewOnceMessage',
  'viewOnceMessageV2',
  'viewOnceMessageV2Extension',
  'documentWithCaptionMessage',
  'editedMessage',
];

export function conteudo(msg) {
  let m = msg?.message ?? msg ?? {};
  for (let i = 0; i < 5; i++) {
    const embrulho = EMBRULHOS.find((k) => m?.[k]?.message);
    if (!embrulho) break;
    m = m[embrulho].message;
  }
  return m ?? {};
}

const ehPdf = (mime, nome) =>
  /pdf/i.test(String(mime ?? '')) || /\.pdf$/i.test(String(nome ?? ''));

/**
 * A mensagem é um comprovante (passo 3)?
 *
 * Escolha do usuário: vale QUALQUER imagem ou PDF — o bot não lê o conteúdo do
 * arquivo (não há OCR aqui), e exigir a palavra "pix" na legenda derrubaria a
 * maioria dos comprovantes, que vêm sem legenda nenhuma.
 *
 * Figurinha, áudio e vídeo ficam de fora: ninguém comprova PIX com eles.
 */
export function detectarComprovante(msg) {
  const m = conteudo(msg);
  const img = m.imageMessage;
  if (img) {
    return { tipo: 'imagem', mime: img.mimetype ?? null, nome: null, legenda: img.caption ?? '' };
  }
  const doc = m.documentMessage;
  if (doc) {
    const mime = doc.mimetype ?? null;
    const nome = doc.fileName ?? doc.title ?? null;
    if (ehPdf(mime, nome)) return { tipo: 'pdf', mime, nome, legenda: doc.caption ?? '' };
    // Comprovante mandado como arquivo de imagem (acontece quando ela anexa da
    // galeria pelo botão de documento).
    if (/^image\//i.test(String(mime))) return { tipo: 'imagem', mime, nome, legenda: doc.caption ?? '' };
  }
  return null;
}

/**
 * A mensagem cita outra? Devolve { stanzaId, participant } ou null.
 * `stanzaId` é o id da mensagem citada — o mesmo `msg.key.id` que gravamos no
 * pedido e no lançamento, e é o que torna a prova do passo 2 inequívoca.
 */
export function citacaoDe(msg) {
  const m = conteudo(msg);
  for (const valor of Object.values(m)) {
    const ctx = valor?.contextInfo;
    if (ctx?.stanzaId) {
      return { stanzaId: ctx.stanzaId, participant: ctx.participant ?? null };
    }
  }
  return null;
}

/* ═══════════ Casamento do passo 2 (Operador responde) ═══════════ */

const ts = (v) => (typeof v === 'number' ? v : Date.parse(v ?? '') || 0);

// Quantas contas a mensagem do Operador oferece. Duas fontes, nessa ordem:
// o "Até N contas" anunciado (gravado no lançamento desde 29/08; para o
// histórico antigo é relido do texto) e, na falta dele, o nº de rótulos
// "Valor:" — cada rótulo é uma conta cotada.
export function contasDaResposta(entrada) {
  const anunciadas = Number(
    entrada?.contasOferecidas ?? contasOferecidas(entrada?.text ?? ''),
  );
  if (Number.isFinite(anunciadas) && anunciadas > 0) return anunciadas;
  const rotulos = Number(entrada?.contasQtd ?? 0);
  return Number.isFinite(rotulos) && rotulos > 0 ? rotulos : 0;
}

// A mensagem do Operador é uma oferta de MONTANTE ou de CONTA? O montante manda:
// "Montante: 200 / Até 2 contas" é oferta de montante (o "até 2" só diz em
// quantas contas ele parte). Sem montante, "Valor: R$ 25" sozinho é conta.
// Devolve null quando não dá para dizer — aí o casamento não usa o tipo.
export function tipoDaResposta(entrada) {
  if (Number(entrada?.montante ?? 0) > 0) return 'montante';
  return contasDaResposta(entrada) > 0 ? 'conta' : null;
}

// Os valores batem? O pedido "400 montante 2 contas" e a mensagem do Operador
// com "Montante: 400" são o mesmo serviço; o pedido "2 contas" casa com o
// "Até 2 contas" que ele anunciou. Comparação exata — arredondar aproximaria
// serviços diferentes.
export function valoresBatem(servico, entrada) {
  const montantePedido = Number(servico?.montantePedido ?? 0);
  const montanteFeito = Number(entrada?.montante ?? 0);
  if (montantePedido > 0 && montanteFeito > 0 && montantePedido === montanteFeito) return true;

  const contasPedidas = Number(servico?.contasPedidas ?? 0);
  return servico?.tipo === 'conta' && contasPedidas > 0 && contasPedidas === contasDaResposta(entrada);
}

/**
 * Escolhe qual pedido em aberto a mensagem do Operador está atendendo.
 *
 * `abertos` são os serviços do MESMO grupo ainda sem atendimento (o chamador
 * filtra). Devolve { servico, casamento } ou null.
 *
 * A cascata (escolha do usuário):
 *   1. citação  — o Operador usou "responder" na mensagem dela. Prova direta.
 *   2. valor    — o montante/qtd de contas da mensagem dele bate com o pedido.
 *   3. tempo    — o pedido em aberto mais recente do grupo dentro do prazo,
 *                 preferindo os do MESMO tipo da mensagem (oferta de montante
 *                 fecha pedido de montante; oferta de conta fecha pedido de
 *                 conta). Sem nenhum do tipo, vale o mais recente de qualquer
 *                 tipo. É o elo mais fraco; fica marcado como tal no painel.
 */
export function escolherAtendimento(abertos, { entrada, citacao = null, agora = Date.now(), cfg }) {
  const janela = cfg.janelaAtendimentoMs;
  const operador = entrada?.operatorId ?? null;

  // Ninguém atende o próprio pedido: se o Operador também tinha pedido algo, o
  // serviço dele não pode ser fechado pela própria mensagem.
  const candidatos = abertos
    .filter((s) => !operador || s.brogueiraId !== operador)
    .filter((s) => {
      const idade = agora - ts(s.pedidoTs);
      return idade >= 0 && idade <= janela;
    })
    .sort((a, b) => ts(b.pedidoTs) - ts(a.pedidoTs)); // mais recente primeiro

  if (citacao?.stanzaId) {
    const citado = candidatos.find((s) => s.pedidoMsgId && s.pedidoMsgId === citacao.stanzaId);
    if (citado) return { servico: citado, casamento: 'citacao' };
  }
  if (cfg.modo === 'citacao') return null;

  const porValor = candidatos.find((s) => valoresBatem(s, entrada));
  if (porValor) return { servico: porValor, casamento: 'valor' };
  if (cfg.modo === 'valor') return null;

  // Desempate por tipo: sem isso a oferta de montante levava o pedido de conta
  // que por acaso era o mais recente — e o pedido de conta expirava "sem
  // atendimento" mesmo com o Operador tendo respondido. Preferir o mesmo tipo
  // não inventa casamento nenhum: só escolhe melhor entre os que já cabiam.
  const tipo = tipoDaResposta(entrada);
  const doTipo = tipo ? candidatos.filter((s) => s.tipo === tipo) : [];
  const escolhidos = doTipo.length ? doTipo : candidatos;
  return escolhidos.length ? { servico: escolhidos[0], casamento: 'tempo' } : null;
}

/* ═══════════ Casamento do passo 3 (comprovante) ═══════════ */

/**
 * Escolhe a qual atendimento o comprovante se refere.
 *
 * `pendentes` são os serviços do mesmo grupo, da MESMA Brogueira, aguardando
 * comprovante (o chamador filtra). A citação vence; senão, o atendimento mais
 * recente dentro do prazo — o comprovante costuma seguir o último serviço.
 */
export function escolherComprovante(pendentes, { citacao = null, agora = Date.now(), cfg }) {
  const janela = cfg.janelaComprovanteMs;
  const candidatos = pendentes
    .filter((s) => {
      const idade = agora - ts(s.atendimento?.ts);
      return idade >= 0 && idade <= janela;
    })
    .sort((a, b) => ts(b.atendimento?.ts) - ts(a.atendimento?.ts));

  if (citacao?.stanzaId) {
    const citado = candidatos.find((s) => s.atendimento?.msgId === citacao.stanzaId);
    if (citado) return { servico: citado, casamento: 'citacao' };
  }
  return candidatos.length ? { servico: candidatos[0], casamento: 'tempo' } : null;
}

// Rótulos usados no painel e nos relatórios de texto.
export const ROTULO_CASAMENTO = {
  citacao: 'respondeu citando',
  valor: 'valor confere',
  tempo: 'por proximidade',
};

export const ROTULO_STATUS = {
  [STATUS.AGUARDANDO_ATENDIMENTO]: 'aguardando operador',
  [STATUS.AGUARDANDO_COMPROVANTE]: 'aguardando comprovante',
  [STATUS.VALIDADO]: 'validado',
  [STATUS.SEM_ATENDIMENTO]: 'ninguém atendeu',
  [STATUS.SEM_COMPROVANTE]: 'sem comprovante',
};
