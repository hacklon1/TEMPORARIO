// O contrato com o Dash: nomes de campo, o corte das 5h, o mapeamento dos
// status e a comissão do isento. O Dash rejeita a resposta inteira se um campo
// mudar de nome — estes testes são o que segura isso.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-relext-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb, saveDb } = await import('./db.js');
const rel = await import('./relatorios-externos.js');

loadDb();

const DIA = '2026-08-30';

// Um serviço como o bot grava: pedido → atendimento → comprovante.
function servico({ id, ts, tipo = 'montante', status = 'validado', brogueira = 'Brogueira X',
  operador = 'op-a', operadorNome = 'Fulano', montante = 100, salario = 20, contasPedidas = 0 }) {
  const atendido = status !== 'expirado_sem_atendimento';
  return {
    id, ts, pedidoTs: ts, day: ts.slice(0, 10), sessaoId: 'n1',
    groupId: 'g1@g.us', groupName: 'Grupo', status,
    brogueiraId: 'b1@lid', brogueiraNome: brogueira,
    tipo, montantePedido: montante, contasPedidas,
    atendimento: atendido ? {
      ts, sessaoId: 'n1', operatorId: operador, operatorPn: '5511999999999@s.whatsapp.net',
      operatorName: operadorNome, montante, contasQtd: contasPedidas || 1,
      contasTotal: salario, salario,
    } : null,
    comprovante: status === 'validado' ? { ts, tipo: 'imagem' } : null,
    validadoEm: status === 'validado' ? ts : null,
  };
}

function base() {
  const db = getDb();
  db.config.timezone = 'America/Sao_Paulo';
  db.appSettings = { metaDiariaBlogueira: 1000, metaSemanalBlogueira: 5000 };
  db.comissoesConfig = {
    padraoPct: 10,
    porOperador: { 'op-b': 20 },
    apelidos: { 'op-a': 'Fulano da Silva' },
    isentos: { 'op-c': true },
  };
  db.comissoesCobradas = [];
  db.servicos = [
    // 30/08 15h em SP — montante validado do op-a (10% de 20 = 2).
    servico({ id: 's1', ts: '2026-08-30T18:00:00.000Z', montante: 500, salario: 20 }),
    // 31/08 01h em SP (= 04h UTC): ainda é o dia 30 pelo corte das 5h, mas o
    // campo `day` do serviço já diz 31 — é justamente o que não pode escorregar.
    servico({ id: 's2', ts: '2026-08-31T04:00:00.000Z', tipo: 'conta', contasPedidas: 3,
      brogueira: 'Lorraine', operador: 'op-b', operadorNome: 'Ciclana', montante: 300, salario: 60 }),
    // Conta que expirou sem comprovante → "zerou", e não paga comissão.
    servico({ id: 's3', ts: '2026-08-30T20:00:00.000Z', tipo: 'conta', contasPedidas: 2,
      status: 'expirado_sem_comprovante', brogueira: 'Ruth', salario: 40 }),
    // Isento: opera, aparece, mas comissão é 0.
    servico({ id: 's4', ts: '2026-08-30T19:00:00.000Z', operador: 'op-c',
      operadorNome: 'Isentão', montante: 200, salario: 50 }),
    // Dia seguinte: não pode aparecer em nada.
    servico({ id: 's5', ts: '2026-08-31T18:00:00.000Z', montante: 999, salario: 99 }),
  ];
  saveDb();
}
base();

/* ═══════════ Dia pedido ═══════════ */

test('o dia vem de ?data=; sem ela, sai do início da janela ISO', () => {
  assert.equal(rel.diaDaConsulta({ data: DIA }), DIA);
  // 05h de 30/08 em SP = 08h UTC — é o começo do dia operacional 30.
  assert.equal(rel.diaDaConsulta({ inicio: '2026-08-30T08:00:00.000Z' }), DIA);
  assert.equal(rel.diaDaConsulta({ data: '', inicio: '2026-08-30T08:00:00.000Z' }), DIA);
});

test('data ilegível vira null (a rota responde 400), nunca "hoje" em silêncio', () => {
  // Cair de volta em hoje faria o Dash mostrar um dia achando que pediu outro.
  assert.equal(rel.diaDaConsulta({ data: 'abacaxi', inicio: '2026-08-30T08:00:00.000Z' }), null);
  assert.equal(rel.diaDaConsulta({ data: '2026-13-45' }), null);  // passa no formato, não existe
  assert.equal(rel.diaDaConsulta({ data: '2026-02-30' }), null);
});

test('o corte das 5h manda, não o campo `day` do serviço', () => {
  // s2 tem day='2026-08-31' e mesmo assim pertence ao dia operacional 30.
  const ids = rel.servicosDoDia(DIA).map((s) => s.id).sort();
  assert.deepEqual(ids, ['s1', 's2', 's3', 's4']);
  assert.deepEqual(rel.servicosDoDia('2026-08-31').map((s) => s.id), ['s5']);
});

/* ═══════════ Montante ═══════════ */

test('montante soma o salário e a comissão dos serviços validados', () => {
  const m = rel.montante(DIA);
  assert.equal(m.data, DIA);
  assert.equal(m.moeda, 'BRL');
  assert.equal(m.totais.pedidos, 4);      // tudo que foi pedido no dia
  assert.equal(m.totais.validados, 3);    // s3 expirou
  assert.equal(m.totais.blogueira, 130);  // 20 + 60 + 50
  // s1: 10% de 20 = 2 · s2: 20% de 60 = 12 · s4: isento = 0
  assert.equal(m.totais.comissao, 14);
  assert.equal(m.totais.lucro, 14);       // o que fica com a casa é a comissão
  assert.equal(m.totais.montante, 1000);  // 500 + 300 + 200
});

test('depósito e saque não existem nesta fonte: vão como 0, nunca inventados', () => {
  const m = rel.montante(DIA);
  assert.equal(m.totais.deposito, 0);
  assert.equal(m.totais.saque, 0);
  assert.ok(m.por_hora.every((h) => h.deposito === 0 && h.saque === 0));
});

test('por_hora cobre as 24 horas do dia operacional, começando às 05:00', () => {
  const { por_hora: horas } = rel.montante(DIA);
  assert.equal(horas.length, 24);
  assert.equal(horas[0].hora, '05:00');
  assert.equal(horas[23].hora, '04:00');
  assert.equal(horas.find((h) => h.hora === '15:00').montante, 500); // s1, 15h em SP
  assert.equal(horas.find((h) => h.hora === '01:00').montante, 300); // s2, já de madrugada
});

/* ═══════════ Contas ═══════════ */

test('contas mapeia o destino do serviço para o vocabulário do Dash', () => {
  const c = rel.contas(DIA);
  assert.equal(c.itens.length, 2);
  const lorraine = c.itens.find((i) => i.nome_conta === 'Lorraine');
  assert.equal(lorraine.status, 'sacou');   // validado
  assert.equal(lorraine.salario, 60);
  assert.equal(lorraine.lucro, 12);         // 20% de 60
  assert.equal(lorraine.contas, 3);
  const ruth = c.itens.find((i) => i.nome_conta === 'Ruth');
  assert.equal(ruth.status, 'zerou');       // expirou
  assert.equal(ruth.salario, 0);            // não validou: ninguém recebeu
  assert.equal(ruth.lucro, 0);
  for (const i of c.itens) assert.ok(['aberta', 'zerou', 'sacou'].includes(i.status));
});

test('contas_solicitadas conta CONTAS pedidas; zerou/sacou contam linhas', () => {
  const t = rel.contas(DIA).totais;
  assert.equal(t.contas_solicitadas, 5); // 3 da Lorraine + 2 da Ruth
  assert.equal(t.pedidos, 2);            // duas linhas
  assert.equal(t.sacou, 1);
  assert.equal(t.zerou, 1);
  assert.equal(t.salario, 60);
  assert.equal(t.lucro, 12);
});

/* ═══════════ Operadores ═══════════ */

test('operadores traz id estável, apelido, categoria e o que sobra para cada um', () => {
  const ops = rel.operadores(DIA).operadores;
  assert.deepEqual(ops.map((o) => o.id).sort(), ['op-a', 'op-b', 'op-c']);

  const a = ops.find((o) => o.id === 'op-a');
  assert.equal(a.nome, 'Fulano da Silva');  // o apelido configurado vence
  assert.equal(a.usuario, '5511999999999'); // telefone sem o sufixo do WhatsApp
  assert.equal(a.categoria, 'montante');
  assert.equal(a.pedidos, 2);               // s1 (validado) + s3 (expirado)
  assert.equal(a.blogueira, 20);
  assert.equal(a.comissao, 2);
  assert.equal(a.lucro, 18);                // o que sobra para ele
  assert.equal(a.meta_diaria, 1000);

  const b = ops.find((o) => o.id === 'op-b');
  assert.equal(b.categoria, 'contas');      // o dia dele foi só de conta
  for (const o of ops) assert.ok(['bi', 'montante', 'contas'].includes(o.categoria));
});

test('operador isento aparece no relatório, mas com comissão zero', () => {
  const c = rel.operadores(DIA).operadores.find((o) => o.id === 'op-c');
  assert.equal(c.isento, true);
  assert.equal(c.comissao, 0);
  assert.equal(c.pct, 0);
  assert.equal(c.blogueira, 50);  // o volume dele continua contando
  assert.equal(c.lucro, 50);
});

test('um dia sem movimento devolve zeros e listas vazias — nunca erro', () => {
  const m = rel.montante('2020-01-01');
  assert.equal(m.totais.pedidos, 0);
  assert.equal(m.totais.lucro, 0);
  assert.equal(m.por_hora.length, 24);
  assert.deepEqual(rel.contas('2020-01-01').itens, []);
  assert.equal(rel.contas('2020-01-01').totais.contas_solicitadas, 0);
  assert.deepEqual(rel.operadores('2020-01-01').operadores, []);
});
