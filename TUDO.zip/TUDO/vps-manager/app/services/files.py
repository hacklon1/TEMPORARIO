"""Navegacao segura no sistema de arquivos."""
from __future__ import annotations

import grp
import os
import pwd
import stat as statmod

from ..config import settings

TEXT_EXT = {
    ".txt", ".md", ".py", ".js", ".mjs", ".ts", ".json", ".yml", ".yaml", ".toml", ".ini",
    ".cfg", ".conf", ".sh", ".bash", ".env", ".sql", ".html", ".css", ".xml", ".service",
    ".log", ".csv", ".example", ".gitignore", ".rules",
}
MAX_VIEW_BYTES = 512 * 1024


class PathError(Exception):
    pass


def safe_path(raw: str) -> str:
    """Normaliza e garante que o caminho esta dentro de browse_root."""
    root = os.path.realpath(settings.browse_root)
    p = os.path.realpath(os.path.join(root, raw.lstrip("/"))) if not os.path.isabs(raw) else os.path.realpath(raw)
    if not (p == root or p.startswith(root.rstrip("/") + "/")):
        raise PathError("caminho fora da raiz permitida")
    return p


def _owner(uid: int) -> str:
    try:
        return pwd.getpwuid(uid).pw_name
    except Exception:
        return str(uid)


def _group(gid: int) -> str:
    try:
        return grp.getgrgid(gid).gr_name
    except Exception:
        return str(gid)


def listdir(path: str, show_hidden: bool = True) -> dict:
    p = safe_path(path)
    if not os.path.isdir(p):
        raise PathError("nao e um diretorio")
    entries = []
    try:
        it = os.scandir(p)
    except PermissionError as exc:
        raise PathError("sem permissao de leitura") from exc
    with it:
        for entry in it:
            if not show_hidden and entry.name.startswith("."):
                continue
            try:
                st = entry.stat(follow_symlinks=False)
            except OSError:
                continue
            is_link = entry.is_symlink()
            is_dir = entry.is_dir(follow_symlinks=False) or (is_link and os.path.isdir(entry.path))
            entries.append({
                "name": entry.name,
                "path": entry.path,
                "is_dir": is_dir,
                "is_link": is_link,
                "link_target": os.readlink(entry.path) if is_link else None,
                "size": st.st_size,
                "modified": st.st_mtime,
                "mode": oct(st.st_mode & 0o777)[2:],
                "owner": _owner(st.st_uid),
                "group": _group(st.st_gid),
                "viewable": _viewable(entry.name, st),
            })
    entries.sort(key=lambda e: (not e["is_dir"], e["name"].lower()))
    parent = os.path.dirname(p) if p != os.path.realpath(settings.browse_root) else None
    return {"path": p, "parent": parent, "entries": entries}


def _viewable(name: str, st: os.stat_result) -> bool:
    if not statmod.S_ISREG(st.st_mode) or st.st_size > MAX_VIEW_BYTES:
        return False
    ext = os.path.splitext(name)[1].lower()
    return ext in TEXT_EXT or "." not in name


def read_text(path: str) -> dict:
    p = safe_path(path)
    if not os.path.isfile(p):
        raise PathError("arquivo nao encontrado")
    size = os.path.getsize(p)
    if size > MAX_VIEW_BYTES:
        raise PathError(f"arquivo grande demais para visualizar ({size} bytes)")
    with open(p, "rb") as fh:
        raw = fh.read()
    if b"\0" in raw[:4096]:
        raise PathError("arquivo binario")
    return {"path": p, "size": size, "content": raw.decode("utf-8", errors="replace")}


def stat_path(path: str) -> dict:
    p = safe_path(path)
    st = os.stat(p, follow_symlinks=False)
    return {
        "path": p, "size": st.st_size, "is_dir": os.path.isdir(p),
        "mode": oct(st.st_mode & 0o777)[2:], "owner": _owner(st.st_uid),
        "group": _group(st.st_gid), "modified": st.st_mtime,
    }
