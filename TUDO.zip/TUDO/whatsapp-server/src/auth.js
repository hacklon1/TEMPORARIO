// Autenticação com papéis: 'admin' (acesso total) e 'viewer' (só monitoramento do Painel).
// - admin: autentica com a senha == API_TOKEN (compatível com o login por token de antes).
// - viewer: usuário/senha de VIEWER_USER/VIEWER_PASS no .env → recebe um token de sessão.
import crypto from 'node:crypto';

const sessions = new Map(); // token de sessão -> { role, user, exp }
const TTL_MS = 30 * 24 * 3600 * 1000; // sessões duram 30 dias

function adminToken() {
  return process.env.API_TOKEN || '';
}
function viewerCreds() {
  return { user: process.env.VIEWER_USER || '', pass: process.env.VIEWER_PASS || '' };
}

// Compara em tempo constante (evita timing attacks).
function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  if (ba.length !== bb.length) return false;
  return crypto.timingSafeEqual(ba, bb);
}

// Tenta autenticar. Retorna { token, role, user } ou null.
export function login(username, password) {
  const admin = adminToken();
  if (admin && password && safeEqual(password, admin)) {
    return { token: admin, role: 'admin', user: 'admin' };
  }
  const v = viewerCreds();
  if (v.user && v.pass && username === v.user && safeEqual(password, v.pass)) {
    const token = crypto.randomBytes(24).toString('hex');
    sessions.set(token, { role: 'viewer', user: username, exp: Date.now() + TTL_MS });
    return { token, role: 'viewer', user: username };
  }
  return null;
}

// Resolve um token para { role, user } ou null.
export function resolveToken(token) {
  if (!token) return null;
  const admin = adminToken();
  if (admin && safeEqual(token, admin)) return { role: 'admin', user: 'admin' };
  const s = sessions.get(token);
  if (!s) return null;
  if (s.exp && s.exp < Date.now()) {
    sessions.delete(token);
    return null;
  }
  return { role: s.role, user: s.user };
}

export function logout(token) {
  sessions.delete(token);
}
