"""VPS Manager — painel web de download de projetos e controle da VPS."""
from __future__ import annotations

import os
import secrets
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.responses import FileResponse, JSONResponse, ORJSONResponse
from fastapi.staticfiles import StaticFiles

from . import db
from .config import settings
from .routers import auth, files, hosts, projects, system, terminal
from .security import hash_password

WEB_DIR = "/opt/vps-manager/web"
BOOTSTRAP_PW_FILE = "/etc/vps-manager/.admin_bootstrap_pw"


async def _ensure_admin() -> None:
    """Cria o admin inicial. Seguro contra corrida entre workers do gunicorn."""
    conn = await db.connect()
    try:
        pw = secrets.token_urlsafe(18)
        cur = await conn.execute(
            "INSERT OR IGNORE INTO users (username, password_hash, role) VALUES (?,?,?)",
            ("admin", hash_password(pw), "superadmin"),
        )
        await conn.commit()
        if cur.rowcount != 1:
            return  # outro worker ja criou
    finally:
        await conn.close()

    os.makedirs(os.path.dirname(BOOTSTRAP_PW_FILE), exist_ok=True)
    with open(BOOTSTRAP_PW_FILE, "w", encoding="utf-8") as fh:
        fh.write(pw + "\n")
    os.chmod(BOOTSTRAP_PW_FILE, 0o600)


@asynccontextmanager
async def lifespan(app: FastAPI):
    os.makedirs(settings.tmp_dir, exist_ok=True)
    os.makedirs(settings.upload_dir, exist_ok=True)
    await db.init_db()
    await _ensure_admin()
    yield


app = FastAPI(
    title=settings.app_name,
    version="1.0.0",
    default_response_class=ORJSONResponse,
    docs_url="/api/docs" if settings.debug else None,
    redoc_url=None,
    openapi_url="/api/openapi.json" if settings.debug else None,
    lifespan=lifespan,
)

app.include_router(auth.router)
app.include_router(system.router)
app.include_router(projects.router)
app.include_router(files.router)
app.include_router(hosts.router)
app.include_router(terminal.router)


@app.middleware("http")
async def security_headers(request: Request, call_next):
    response = await call_next(request)
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "SAMEORIGIN")
    response.headers.setdefault("Referrer-Policy", "same-origin")
    return response


@app.get("/api/health")
async def health():
    return {"ok": True, "app": settings.app_name, "version": app.version}


@app.get("/")
async def index():
    return FileResponse(os.path.join(WEB_DIR, "index.html"))


@app.get("/favicon.ico", include_in_schema=False)
async def favicon():
    return FileResponse(os.path.join(WEB_DIR, "favicon.ico"), media_type="image/x-icon")


@app.get("/favicon.svg", include_in_schema=False)
async def favicon_svg():
    return FileResponse(os.path.join(WEB_DIR, "favicon.svg"), media_type="image/svg+xml")


@app.get("/apple-touch-icon.png", include_in_schema=False)
@app.get("/apple-touch-icon-precomposed.png", include_in_schema=False)
async def touch_icon():
    return FileResponse(os.path.join(WEB_DIR, "apple-touch-icon.png"), media_type="image/png")


@app.get("/login")
async def login_page():
    return FileResponse(os.path.join(WEB_DIR, "login.html"))


app.mount("/static", StaticFiles(directory=WEB_DIR), name="static")


@app.exception_handler(404)
async def not_found(request: Request, exc):
    if request.url.path.startswith(("/api", "/ws", "/static")):
        return JSONResponse({"detail": "nao encontrado"}, status_code=404)
    return FileResponse(os.path.join(WEB_DIR, "index.html"))
