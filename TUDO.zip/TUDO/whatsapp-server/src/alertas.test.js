// Alerta de link repetido: quando dispara, o que a mensagem diz e o que
// impede o mesmo caso de virar spam.
// DATA_DIR aponta para um diretório temporário ANTES de importar db.js.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-alerta-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb, getConfigSessao } = await import('./db.js');
const { registrarPedido } = await import('./store.js');
const { analisarPedido } = await import('./pedidos.js');
const {
  configAlertas, avaliarAlerta, marcarAlertado, enviarAlerta, processarAlertaRepetido,
  contarReenviosDoDia, MAX_LINKS_ALERTADOS,
} = await import('./alertas.js');

loadDb();

const GRUPO_ALERTA = '999@g.us';

function preparar(config = {}) {
  const db = getDb();
  db.pedidos = [];
  db.alertas = { links: {}, dias: {}, ultimo: null };
  // A config do alerta agora é de CADA número — aqui, a do Número 1.
  Object.assign(getConfigSessao(), {
    alertaRepetidosEnabled: true,
    alertaRepetidosGrupo: GRUPO_ALERTA,
    alertaRepetidosMensagem: 'Alerta, link repetido',
    alertaRepetidosPorLink: 3,
    alertaRepetidosPorDia: 0,
    alertaRepetidosMarcarTodos: true,
    ...config,
  });
  return db;
}

function receber(autor, texto, { papel = 'brogueira' } = {}) {
  const pedido = analisarPedido(texto);
  assert.ok(pedido, `texto sem link: ${texto}`);
  return registrarPedido({
    groupId: 'g1@g.us',
    groupName: 'DB Contas e Montantes',
    autorId: `${autor}@lid`,
    autorNome: autor,
    papel,
    pedido,
    text: texto,
  });
}

// Um "WhatsApp" de mentira: guarda o que teria sido enviado.
function fakeDeps({ falharMembros = false } = {}) {
  const enviadas = [];
  return {
    enviadas,
    reply: async (to, texto, opts) => { enviadas.push({ to, texto, mentions: opts?.mentions }); },
    getGroupParticipants: async (jid) => {
      if (falharMembros) throw new Error('sem conexão');
      return [`a@lid`, `b@lid`, jid];
    },
  };
}

const LINK = 'https://okok.com/?id=5';

/* ── limite por link ── */

test('nada acontece antes do limite', async () => {
  preparar({ alertaRepetidosPorLink: 3 });
  const deps = fakeDeps();

  await processarAlertaRepetido(receber('Ana', `${LINK}\n7 contas`), deps); // 1ª
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps); // 2ª
  assert.equal(deps.enviadas.length, 0, '2 envios ainda não chegam ao limite 3');

  await processarAlertaRepetido(receber('Ana', `${LINK}\n2 contas`), deps); // 3ª
  assert.equal(deps.enviadas.length, 1);
  assert.equal(deps.enviadas[0].to, GRUPO_ALERTA, 'vai para o grupo configurado, não para o grupo de origem');
});

test('a mensagem traz o texto configurado e o caso concreto', async () => {
  preparar({ alertaRepetidosPorLink: 2, alertaRepetidosMensagem: '🚨 Alerta, link repetido' });
  const deps = fakeDeps();
  await processarAlertaRepetido(receber('Ana', `${LINK}\n7 contas`), deps);
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps);

  const { texto } = deps.enviadas[0];
  assert.match(texto, /^🚨 Alerta, link repetido/);
  assert.match(texto, /Bia/);
  assert.match(texto, /2ª vez/);
  assert.match(texto, /okok\.com\/\?id=5/);
  assert.match(texto, /1ª vez foi de \*Ana\*/);
  assert.match(texto, /Grupo: DB Contas e Montantes/);
});

test('marcar todos usa a lista de participantes do grupo de destino', async () => {
  preparar({ alertaRepetidosPorLink: 2 });
  const deps = fakeDeps();
  receber('Ana', `${LINK}\n7 contas`);
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps);
  assert.deepEqual(deps.enviadas[0].mentions, ['a@lid', 'b@lid', GRUPO_ALERTA]);
});

test('sem "marcar todos" a mensagem vai sem mentions', async () => {
  preparar({ alertaRepetidosPorLink: 2, alertaRepetidosMarcarTodos: false });
  const deps = fakeDeps();
  receber('Ana', `${LINK}\n7 contas`);
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps);
  assert.equal(deps.enviadas[0].mentions, undefined);
});

test('falha ao listar os membros não cancela o alerta', async () => {
  preparar({ alertaRepetidosPorLink: 2 });
  const deps = fakeDeps({ falharMembros: true });
  receber('Ana', `${LINK}\n7 contas`);
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps);
  assert.equal(deps.enviadas.length, 1, 'avisa mesmo sem conseguir marcar todos');
  assert.equal(deps.enviadas[0].mentions, undefined);
});

test('cada link avisa uma vez só', async () => {
  preparar({ alertaRepetidosPorLink: 2 });
  const deps = fakeDeps();
  receber('Ana', `${LINK}\n7 contas`);
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps); // 2ª → alerta
  await processarAlertaRepetido(receber('Ana', `${LINK}\n1 conta`), deps); // 3ª → calado
  await processarAlertaRepetido(receber('Bia', `${LINK}\n2 contas`), deps); // 4ª → calado
  assert.equal(deps.enviadas.length, 1);

  // Outro link, porém, avisa normalmente.
  receber('Ana', 'https://outro.com/?id=9\n1 conta');
  await processarAlertaRepetido(receber('Bia', 'https://outro.com/?id=9\n2 contas'), deps);
  assert.equal(deps.enviadas.length, 2);
});

test('envio que falha não consome o alerta', async () => {
  preparar({ alertaRepetidosPorLink: 2 });
  const quebrado = { reply: async () => { throw new Error('sem conexão'); }, getGroupParticipants: async () => [] };
  receber('Ana', `${LINK}\n7 contas`);
  const r = await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), quebrado);
  assert.equal(r, null, 'não lança, só devolve null');
  assert.deepEqual(getDb().alertas.links, {}, 'nada marcado — a próxima repetição tenta de novo');

  const deps = fakeDeps();
  await processarAlertaRepetido(receber('Ana', `${LINK}\n1 conta`), deps);
  assert.equal(deps.enviadas.length, 1);
});

/* ── limite por dia ── */

test('o limite por dia soma reenvios de links diferentes', async () => {
  preparar({ alertaRepetidosPorLink: 0, alertaRepetidosPorDia: 3 });
  const deps = fakeDeps();

  receber('Ana', 'https://a.com/?id=1\n1 conta');
  await processarAlertaRepetido(receber('Bia', 'https://a.com/?id=1\n2 contas'), deps); // reenvio 1
  receber('Ana', 'https://b.com/?id=2\n1 conta');
  await processarAlertaRepetido(receber('Bia', 'https://b.com/?id=2\n2 contas'), deps); // reenvio 2
  assert.equal(deps.enviadas.length, 0);

  receber('Ana', 'https://c.com/?id=3\n1 conta');
  await processarAlertaRepetido(receber('Bia', 'https://c.com/?id=3\n2 contas'), deps); // reenvio 3
  assert.equal(deps.enviadas.length, 1);
  assert.match(deps.enviadas[0].texto, /3 reenvios de link hoje/);

  // O dia já avisou: os próximos reenvios ficam calados.
  receber('Ana', 'https://d.com/?id=4\n1 conta');
  await processarAlertaRepetido(receber('Bia', 'https://d.com/?id=4\n2 contas'), deps);
  assert.equal(deps.enviadas.length, 1);
});

test('os dois limites no mesmo pedido viram uma mensagem só', async () => {
  preparar({ alertaRepetidosPorLink: 2, alertaRepetidosPorDia: 1 });
  const deps = fakeDeps();
  receber('Ana', `${LINK}\n7 contas`);
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps);

  assert.equal(deps.enviadas.length, 1, 'um alerta, não dois');
  assert.match(deps.enviadas[0].texto, /2ª vez/);
  assert.match(deps.enviadas[0].texto, /1 reenvios de link hoje/);
});

test('contarReenviosDoDia conta mensagens, não links', () => {
  const db = preparar();
  const hoje = receber('Ana', `${LINK}\n7 contas`).day;
  assert.equal(contarReenviosDoDia(db, hoje), 0);
  receber('Bia', `${LINK}\n300`);
  assert.equal(contarReenviosDoDia(db, hoje), 1);
});

/* ── desligamentos e recortes ── */

test('desligado, sem grupo ou sem repetição não dispara nada', async () => {
  const deps = fakeDeps();

  preparar({ alertaRepetidosEnabled: false, alertaRepetidosPorLink: 2 });
  receber('Ana', `${LINK}\n7 contas`);
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps);
  assert.equal(deps.enviadas.length, 0, 'desligado');

  preparar({ alertaRepetidosGrupo: '', alertaRepetidosPorLink: 2 });
  receber('Ana', `${LINK}\n7 contas`);
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps);
  assert.equal(deps.enviadas.length, 0, 'sem grupo de destino');

  preparar({ alertaRepetidosPorLink: 2 });
  await processarAlertaRepetido(receber('Ana', `${LINK}\n7 contas`), deps);
  assert.equal(deps.enviadas.length, 0, 'primeiro envio não é repetição');

  preparar({ alertaRepetidosPorLink: 0, alertaRepetidosPorDia: 0 });
  receber('Ana', `${LINK}\n7 contas`);
  await processarAlertaRepetido(receber('Bia', `${LINK}\n300`), deps);
  assert.equal(deps.enviadas.length, 0, 'os dois limites em 0 = alerta desligado');
});

test('pedido de Operador não dispara alerta', async () => {
  preparar({ alertaRepetidosPorLink: 2 });
  const deps = fakeDeps();
  const primeiro = receber('Chefe', `${LINK}\ndivulgação`, { papel: 'operador' });
  const segundo = receber('Chefe', `${LINK}\ndivulgação`, { papel: 'operador' });
  assert.equal(segundo.repetido, true, 'entre Operadores a marca existe');
  await processarAlertaRepetido(primeiro, deps);
  await processarAlertaRepetido(segundo, deps);
  assert.equal(deps.enviadas.length, 0, 'mas o alerta é sobre as Brogueiras');
});

test('configAlertas normaliza o que vem do painel', () => {
  const c = configAlertas({});
  assert.equal(c.ativo, false);
  assert.equal(c.mensagem, 'Alerta, link repetido', 'nunca manda mensagem vazia');
  assert.equal(c.marcarTodos, true, 'padrão é marcar');
  assert.equal(configAlertas({ alertaRepetidosPorLink: -5 }).porLink, 0);
  assert.equal(configAlertas({ alertaRepetidosPorLink: '4' }).porLink, 4);
  assert.equal(configAlertas({ alertaRepetidosPorLink: 'x' }).porLink, 0);
  assert.equal(configAlertas({ alertaRepetidosMensagem: '   ' }).mensagem, 'Alerta, link repetido');
});

test('o índice do que já foi alertado não cresce sem limite', () => {
  const db = preparar();
  for (let i = 0; i < MAX_LINKS_ALERTADOS + 50; i++) {
    marcarAlertado(db, {
      motivos: ['link'],
      chave: `link${String(i).padStart(5, '0')}.com`,
      ts: new Date(1700000000000 + i * 1000).toISOString(),
      grupo: GRUPO_ALERTA,
      day: '2026-08-11',
    });
  }
  const chaves = Object.keys(db.alertas.links);
  const nome = (i) => `link${String(i).padStart(5, '0')}.com`;
  assert.equal(chaves.length, MAX_LINKS_ALERTADOS);
  assert.ok(!chaves.includes(nome(0)), 'os mais antigos saem primeiro');
  assert.ok(chaves.includes(nome(MAX_LINKS_ALERTADOS + 49)), 'o mais recente fica');
});

test('enviarAlerta num destino privado não tenta marcar todos', async () => {
  const deps = fakeDeps();
  await enviarAlerta(
    { grupo: '5511999999999@s.whatsapp.net', marcarTodos: true, texto: 'oi' },
    deps,
  );
  assert.equal(deps.enviadas[0].mentions, undefined, 'num DM não há quem marcar');
});

test('avaliarAlerta é puro: não marca nada por conta própria', () => {
  const db = preparar({ alertaRepetidosPorLink: 2 });
  receber('Ana', `${LINK}\n7 contas`);
  const entry = receber('Bia', `${LINK}\n300`);
  const alerta = avaliarAlerta({ entry, db });
  assert.ok(alerta);
  assert.deepEqual(db.alertas.links, {}, 'só marcarAlertado() escreve');
  marcarAlertado(db, alerta);
  assert.equal(avaliarAlerta({ entry, db }), null, 'depois de marcado, silêncio');
});
