// A camada visual: tipografia local, a linha viva e o piso de acessibilidade.
//
// Aparência costuma não ter teste — e é justamente por isso que ela quebra sem
// ninguém ver. Aqui ficam só as decisões que, se sumirem, mudam o painel: as
// fontes servidas do próprio servidor, os números em mono, o foco visível e o
// traço de atividade que diz que o bot está ouvindo.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const PUBLIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');
const CSS = fs.readFileSync(path.join(PUBLIC, 'style.css'), 'utf8');

test('as fontes são servidas pelo próprio painel, nunca por CDN', () => {
  const arquivos = [...CSS.matchAll(/url\('(\/fonts\/[^']+)'\)/g)].map((m) => m[1]);
  assert.ok(arquivos.length >= 4, 'deveria haver @font-face apontando para /fonts');
  for (const arq of arquivos) {
    assert.ok(fs.existsSync(path.join(PUBLIC, arq)), `${arq} não está no disco`);
  }
  // Um IP puro sem CDN: nenhuma fonte pode vir de fora, senão a cara do painel
  // depende de o Google abrir.
  assert.equal(/@font-face[^}]*https?:/.test(CSS), false, 'há @font-face apontando para fora');
});

test('dinheiro e contagem usam a família de dados (mono tabular)', () => {
  for (const seletor of ['.stat .value', '.tbl .num', '.mini .v']) {
    const i = CSS.indexOf(seletor + ' ');
    assert.ok(i >= 0, `${seletor} sumiu`);
    const bloco = CSS.slice(i, CSS.indexOf('}', i));
    assert.match(bloco, /var\(--font-dados\)/, `${seletor} deixou de usar a fonte de dados`);
  }
  assert.match(CSS, /--font-dados:\s*'IBM Plex Mono'/);
});

test('o piso de acessibilidade continua de pé', () => {
  assert.match(CSS, /:focus-visible\s*\{[^}]*outline:\s*2px solid var\(--accent\)/, 'foco visível');
  assert.match(CSS, /prefers-reduced-motion/, 'quem pede menos movimento tem que ser atendido');
  assert.match(CSS, /\.tbl th\s*\{[^}]*position:\s*sticky/, 'cabeçalho de tabela fixo');
});

async function montar() {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;
  window.Element.prototype.getBoundingClientRect = () => ({ left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0 });
  window.Element.prototype.scrollIntoView = () => {};
  window.fetch = async () => ({ ok: true, status: 200, json: async () => ({ ok: true, recursos: [], sessoes: [], conflitos: [] }) });
  for (const arquivo of ['app.js', 'relatorios.js']) {
    const tag = window.document.createElement('script');
    tag.textContent = fs.readFileSync(path.join(PUBLIC, arquivo), 'utf8');
    window.document.body.appendChild(tag);
  }
  return { window, doc: window.document, fechar: async () => { await new Promise((r) => setTimeout(r, 20)); dom.window.close(); } };
}

test('a linha viva desenha 24 horas, marca a hora corrente e mede o volume', async () => {
  const { window, doc, fechar } = await montar();
  try {
    const horas = Array(24).fill(0);
    const agora = new Date().getHours();
    horas[agora] = 10;
    const anterior = (agora + 23) % 24;
    horas[anterior] = 5;

    window.linhaViva(horas);
    const barras = [...doc.querySelectorAll('#linha-viva i')];
    assert.equal(barras.length, 24, 'um traço por hora');
    assert.equal(barras[agora].className, 'agora');
    assert.match(barras[agora].title, new RegExp(`${String(agora).padStart(2, '0')}h · 10`));

    // A altura acompanha o volume: a hora cheia é mais alta que a de metade.
    const alt = (el) => Number(String(el.style.height).replace('px', ''));
    if (anterior < agora) assert.ok(alt(barras[agora]) > alt(barras[anterior]), 'volume maior, traço maior');
    // Hora futura fica apagada, e nenhuma some da linha.
    const futura = barras.find((b) => b.className === 'futura');
    if (futura) assert.equal(alt(futura), 2, 'hora que ainda não chegou continua visível, no mínimo');
  } finally { await fechar(); }
});

test('mensagem nova pisca o traço da hora corrente e a piscada passa', async () => {
  const { window, doc, fechar } = await montar();
  try {
    window.linhaViva(Array(24).fill(1));
    const agora = new Date().getHours();
    const barra = doc.querySelectorAll('#linha-viva i')[agora];

    window.pulsarLinhaViva();
    assert.equal(barra.classList.contains('bateu'), true);
    await new Promise((r) => setTimeout(r, 1000));
    assert.equal(barra.classList.contains('bateu'), false, 'a piscada não pode ficar acesa');
  } finally { await fechar(); }
});

test('dado ausente não quebra a linha (nasce com 24 traços zerados)', async () => {
  const { window, doc, fechar } = await montar();
  try {
    window.linhaViva(undefined);
    assert.equal(doc.querySelectorAll('#linha-viva i').length, 24);
    window.linhaViva([1, 2, 3]);   // série de tamanho errado
    assert.equal(doc.querySelectorAll('#linha-viva i').length, 24);
  } finally { await fechar(); }
});
