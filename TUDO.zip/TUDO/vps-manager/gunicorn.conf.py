"""Configuracao do gunicorn para o VPS Manager."""
bind = "127.0.0.1:8200"
workers = 2
worker_class = "uvicorn.workers.UvicornWorker"
timeout = 0            # 0 = sem timeout: downloads longos e sessoes SSH persistentes
graceful_timeout = 30
keepalive = 15
accesslog = "/opt/vps-manager/logs/access.log"
errorlog = "/opt/vps-manager/logs/error.log"
loglevel = "info"
proc_name = "vps-manager"
forwarded_allow_ips = "127.0.0.1"
