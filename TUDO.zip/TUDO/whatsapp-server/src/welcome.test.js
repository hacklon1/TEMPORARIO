import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

// DATA_DIR num diretório temporário ANTES de importar db.js — nenhum teste pode
// tocar no db.json de produção.
process.env.DATA_DIR = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-welcome-'));

const { deveDarBoasVindas, montarMensagem, processarEntradaGrupo, _limparDedupe } = await import('./welcome.js');
const { getDb, loadDb, getConfigSessao } = await import('./db.js');


loadDb();

// Aplica uma config de boas-vindas ao db em memória e devolve o objeto config.
function configurar(extra = {}) {
  const config = getConfigSessao();
  Object.assign(config, {
    welcomeEnabled: true,
    welcomeMode: 'all',
    welcomeGroups: [],
    welcomeMessage: 'Bem-vindo {mencao} ao {grupo}!',
    ...extra,
  });
  return config;
}

// Coleta os envios em vez de ir à rede.
function deps({ falhar = false } = {}) {
  const enviados = [];
  return {
    enviados,
    reply: async (jid, texto, opts) => {
      if (falhar) throw new Error('envio falhou');
      enviados.push({ jid, texto, mentions: opts?.mentions ?? [] });
    },
    getGroupInfo: async () => ({ nome: 'Equipe Alpha', total: 7 }),
    souEu: (jid) => jid === '5511000000000@s.whatsapp.net',
  };
}

const entrada = (participants) => ({ id: 'grupo1@g.us', action: 'add', participants, author: 'x@s.whatsapp.net' });

test('deveDarBoasVindas respeita o modo configurado', () => {
  assert.equal(deveDarBoasVindas({ welcomeEnabled: false, welcomeMode: 'all' }, 'g@g.us'), false);
  assert.equal(deveDarBoasVindas({ welcomeEnabled: true, welcomeMode: 'all' }, 'g@g.us'), true);

  const especifico = { welcomeEnabled: true, welcomeMode: 'specific', welcomeGroups: ['a@g.us'] };
  assert.equal(deveDarBoasVindas(especifico, 'a@g.us'), true);
  assert.equal(deveDarBoasVindas(especifico, 'b@g.us'), false);
});

test('montarMensagem substitui as variáveis', () => {
  const { texto } = montarMensagem('Oi {nome}, bem-vindo ao {grupo}! Somos {total}. Fone: {numero}', {
    participante: '5511987654321@s.whatsapp.net',
    grupo: 'Equipe Alpha',
    total: 7,
  });
  assert.equal(texto, 'Oi 5511987654321, bem-vindo ao Equipe Alpha! Somos 7. Fone: 5511987654321');
});

test('montarMensagem só popula mentions quando o template usa {mencao}', () => {
  const jid = '5511987654321@s.whatsapp.net';

  const com = montarMensagem('Olá {mencao}!', { participante: jid });
  assert.equal(com.texto, 'Olá @5511987654321!');
  assert.deepEqual(com.mentions, [jid]);

  const sem = montarMensagem('Olá {nome}!', { participante: jid });
  assert.deepEqual(sem.mentions, []);
});

test('montarMensagem funciona com JID @lid', () => {
  const { texto, mentions } = montarMensagem('Oi {mencao}', { participante: '277945201520675@lid' });
  assert.equal(texto, 'Oi @277945201520675');
  assert.deepEqual(mentions, ['277945201520675@lid']);
});

test('processarEntradaGrupo envia uma saudação por participante', async () => {
  _limparDedupe();
  configurar();
  const d = deps();
  await processarEntradaGrupo(entrada(['5511111111111@s.whatsapp.net', '5522222222222@s.whatsapp.net']), d);

  assert.equal(d.enviados.length, 2);
  assert.equal(d.enviados[0].jid, 'grupo1@g.us');
  assert.equal(d.enviados[0].texto, 'Bem-vindo @5511111111111 ao Equipe Alpha!');
  assert.deepEqual(d.enviados[0].mentions, ['5511111111111@s.whatsapp.net']);
});

test('processarEntradaGrupo ignora ações que não são "add"', async () => {
  _limparDedupe();
  configurar();
  const d = deps();
  for (const action of ['remove', 'promote', 'demote']) {
    await processarEntradaGrupo({ ...entrada(['5511111111111@s.whatsapp.net']), action }, d);
  }
  assert.equal(d.enviados.length, 0);
});

test('processarEntradaGrupo não saúda o próprio bot', async () => {
  _limparDedupe();
  configurar();
  const d = deps();
  await processarEntradaGrupo(entrada(['5511000000000@s.whatsapp.net']), d);
  assert.equal(d.enviados.length, 0);
});

test('processarEntradaGrupo não repete a saudação para o mesmo participante', async () => {
  _limparDedupe();
  configurar();
  const d = deps();
  await processarEntradaGrupo(entrada(['5511111111111@s.whatsapp.net']), d);
  await processarEntradaGrupo(entrada(['5511111111111@s.whatsapp.net']), d);
  assert.equal(d.enviados.length, 1);
});

test('processarEntradaGrupo respeita welcomeEnabled e mensagem vazia', async () => {
  _limparDedupe();
  configurar({ welcomeEnabled: false });
  const desligado = deps();
  await processarEntradaGrupo(entrada(['5511111111111@s.whatsapp.net']), desligado);
  assert.equal(desligado.enviados.length, 0);

  _limparDedupe();
  configurar({ welcomeMessage: '   ' });
  const vazio = deps();
  await processarEntradaGrupo(entrada(['5511111111111@s.whatsapp.net']), vazio);
  assert.equal(vazio.enviados.length, 0);
});

test('processarEntradaGrupo segue para o próximo participante se um envio falhar', async () => {
  _limparDedupe();
  configurar();
  const d = deps({ falhar: true });
  // Não deve lançar: a falha é registrada e o lote continua.
  await processarEntradaGrupo(entrada(['5511111111111@s.whatsapp.net', '5522222222222@s.whatsapp.net']), d);
  assert.equal(d.enviados.length, 0);
});
