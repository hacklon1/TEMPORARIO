-- CORREÇÃO: dar ao cargo DONO ('owner') os poderes de Admin.
--
-- Todas as políticas RLS do sistema checam has_role(auth.uid(), 'admin').
-- Redefinindo essa função, o DONO passa a valer em todas elas de uma vez,
-- sem precisar reescrever política por política.
--
-- Cole isto no SQL Editor do Supabase e execute.

CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE SQL
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id
      AND (
        role = _role
        OR (_role::text = 'admin' AND role::text = 'owner')
      )
  )
$$;

-- Conferência: deve voltar true para quem é DONO.
SELECT p.nome,
       p.email,
       r.role,
       public.has_role(p.id, 'admin') AS tem_poder_de_admin
FROM public.profiles p
JOIN public.user_roles r ON r.user_id = p.id
WHERE r.role::text = 'owner';
