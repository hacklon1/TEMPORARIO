# Integração — Dash ⇄ WhatsApp Server

O Dash **puxa** (pull) os relatórios do dia do WhatsApp Server (o "coletor"). O
servidor só expõe três endpoints `GET` que devolvem JSON. Ele nunca escreve no
Dash.

```
Navegador (Dash)  →  Edge Function `relatorios-externos`  →  $WHATSAPP_SERVER_URL/api/v1/relatorios/...
      JWT do Dash                    Bearer RELATORIOS_TOKEN
```

O proxy é obrigatório: o WhatsApp Server **não manda cabeçalhos de CORS**, então
o navegador não pode chamá-lo direto. Toda chamada sai da Edge Function; o
front-end fala só com ela. A Edge Function responde ao preflight `OPTIONS` com
`Access-Control-Allow-Origin` / `-Headers` / `-Methods` — sem isso o supabase-js
devolve "Failed to send a request to the Edge Function" mesmo com a URL certa.

## Configuração

A URL do servidor fica em **um único lugar**: o secret `WHATSAPP_SERVER_URL` da
Edge Function. Ela é provisória (túnel Cloudflare) e vai trocar por um domínio
fixo — quando trocar, muda-se o secret e mais nada. Nenhum arquivo do
repositório escreve essa URL à mão; o front-end nem fica sabendo dela (o painel
de conexão mostra a que a Edge Function informou).

```bash
supabase secrets set WHATSAPP_SERVER_URL=https://objective-gzip-trademark-bra.trycloudflare.com
supabase secrets set RELATORIOS_TOKEN=<token-compartilhado>   # o mesmo de sempre
supabase functions deploy relatorios-externos
```

`RELATORIOS_URL` continua aceito como nome antigo do mesmo secret (se os dois
existirem, `WHATSAPP_SERVER_URL` vence). O secret `RELATORIOS_CA_CERT` e o
pinning de certificado **não existem mais**: o túnel tem certificado válido e o
`fetch` do Deno funciona sem nenhuma flag. O endereço antigo
(`https://179.197.231.192:8080`, certificado autoassinado) não funciona a
partir de uma Edge Function e não deve voltar.

O token nunca vai para o bundle do front-end: só a Edge Function lê
`RELATORIOS_TOKEN`.

## As três rotas

```
GET /api/v1/relatorios/montante?data=YYYY-MM-DD
GET /api/v1/relatorios/contas?data=YYYY-MM-DD
GET /api/v1/relatorios/operadores?data=YYYY-MM-DD
Authorization: Bearer <RELATORIOS_TOKEN>
```

O parâmetro chama-se **`data`** — não `dia`, `date` nem `day`. Nome errado não
dá erro: o servidor cai no dia corrente em silêncio. Por isso a tela compara o
`data` da resposta com o pedido e avisa quando diferem.

Sem `data` o servidor devolve o dia corrente. Data inválida devolve **400** e o
Dash mostra o erro parado no dia pedido, sem trocar para hoje.

## Dia operacional

Começa às **05:00 (America/Sao_Paulo)** e vai até 04:59 do dia seguinte. Um
serviço das 2h da madrugada pertence ao dia **anterior**. O Dash não faz conta
de fuso no cliente: `diaOperacional()` só escolhe o dia padrão do seletor (em
America/Sao_Paulo, não no fuso do navegador) e a verdade sobre o dia devolvido é
o campo `data` da resposta. O Dash manda apenas `data` — não manda mais
`inicio`/`fim`.

## Formato das respostas

Todas trazem `{ data, gerado_em (ISO-8601 com offset), moeda: "BRL", ... }`.

- **`/montante`** — `totais: { pedidos, deposito, saque, blogueira, comissao,
  lucro, montante, validados }` e `por_hora` com 24 itens **em ordem
  operacional** (`05:00` → `04:00`): `{ hora, deposito, saque, lucro, montante,
  blogueira }`. O gráfico desenha na ordem do array e nunca reordena por string.
- **`/contas`** — `totais: { contas_solicitadas, deposito, saque, salario,
  comissao, lucro, zerou, sacou, aberta, pedidos, montante }` e `itens[]`
  `{ nome_conta, deposito, saque, salario, lucro, status, atualizado_em, contas,
  montante, operador }`. `status` ∈ `sacou` | `zerou` | `aberta`. `contas` é
  quantas contas o pedido tinha; `pedidos` conta **linhas** e
  `contas_solicitadas` soma **contas** — grandezas diferentes de propósito.
- **`/operadores`** — `operadores[]` `{ id, nome, usuario, categoria, pedidos,
  deposito, saque, blogueira, comissao, lucro, meta_dia, online,
  ultima_operacao, validados, montante, pct, isento }`. `id` (`"1234@lid"`) é a
  chave estável entre dias — nunca o nome, que é apelido. `blogueira` = o que
  ele recebe; `comissao` = o que deve à casa; `lucro = blogueira - comissao`.
  `online` = operou nos últimos 15 min. Já vem ordenado por lucro decrescente.

`deposito` e `saque` vêm **sempre 0** nas três rotas: essa fonte não tem esses
conceitos. O Dash não os exibe. O número que importa é `montante`.

O validador do Dash ignora chave desconhecida e aceita número como string. Os
nomes de campo acima não são renomeados. `meta_diaria` (nome da especificação
antiga) ainda é aceito como sinônimo de `meta_dia`. O guarda desse contrato é
[relatoriosExternos.test.ts](src/test/relatoriosExternos.test.ts).

## Erros

A Edge Function repassa o motivo para a tela (código, status HTTP e um trecho
do corpo), e registra status e corpo no log da função:

| Servidor | Código no Dash | O que a tela mostra |
| --- | --- | --- |
| 401 / 403 | `token_coletor` | "O token do coletor foi recusado" |
| 400 | `data_invalida` | "Data inválida" + motivo do servidor |
| 5xx, timeout, falha de rede | `coletor_offline` | "O WhatsApp Server não respondeu" |
| Edge Function inacessível (rede/CORS/não-2xx) | `proxy` | motivo real, lido do corpo da resposta |
| JSON fora do contrato | `contrato` | campo que falhou |

Timeout de **20 s** por chamada, com **1 nova tentativa** (em timeout, falha de
rede ou 5xx) antes de desistir. Falhas do servidor voltam com HTTP 200 e `error`
no corpo de propósito: o supabase-js esconde o corpo de respostas não-2xx.

## Como conferir se funcionou

```bash
curl -s -H "Authorization: Bearer $RELATORIOS_TOKEN" \
  "$WHATSAPP_SERVER_URL/api/v1/relatorios/montante?data=2026-09-01" | jq .totais.pedidos
# → 91  (200)

curl -s -o /dev/null -w '%{http_code}\n' "$WHATSAPP_SERVER_URL/api/v1/relatorios/montante?data=2026-09-01"
# → 401 (sem token)
```

No Dash: Dashboard (admin) → "Conexão com o coletor" → dia `2026-09-01` →
"Testar conexão". As três rotas devem responder 200 e a URL mostrada deve ser a
do secret.

## Onde isso aparece no Dash

**Página Relatórios** (`/reports`, somente admin), bloco "Relatórios do coletor":
cartões de Montante, cartões + tabela de Contas e tabela de Operadores, com
seletor de dia e botão de atualizar. Revalida sozinho a cada 5 minutos. Mostra
o dia que o servidor devolveu e avisa se for diferente do pedido.

**Dashboard** (`/`, somente admin), bloco "Conexão com o coletor": testa as três
rotas de uma vez (status HTTP, tempo e tamanho), mostra o log de todas as
chamadas da sessão e guarda o último JSON cru de cada rota, com botões de
copiar e baixar. Usa a ação `{acao:"diagnostico", data}` da Edge Function.

### Reaproveitando o dado em outras telas

```ts
import { ultimaResposta } from "@/lib/coletorStore";
const montante = ultimaResposta("montante");   // { ts, ms, bytes, bruto } | undefined
```

É leitura oportunista — some no F5. Quem precisa do dado garantido chama
`buscarRelatorio` (ou o hook `useRelatoriosExternos`).

Arquivos: [relatoriosExternos.ts](src/lib/relatoriosExternos.ts),
[coletorStore.ts](src/lib/coletorStore.ts),
[coletorDiagnostico.ts](src/lib/coletorDiagnostico.ts),
[useRelatoriosExternos.ts](src/hooks/useRelatoriosExternos.ts),
[useColetor.ts](src/hooks/useColetor.ts),
[RelatoriosExternos.tsx](src/components/RelatoriosExternos.tsx),
[ConexaoColetor.tsx](src/components/ConexaoColetor.tsx),
[index.ts](supabase/functions/relatorios-externos/index.ts).
