// Teste de conexão com o WhatsApp Server.
//
// Diferente de `buscarRelatorio`, aqui o objetivo não é a tela de relatórios: é
// saber se o caminho até o servidor está de pé e por quê, quando não está. Bate
// nas três rotas de uma vez e devolve status, tempo e o payload de cada uma —
// que fica guardado no store para outras partes do Dash reaproveitarem.

import { FunctionsFetchError, FunctionsHttpError } from "@supabase/supabase-js";

import { supabase } from "@/integrations/supabase/client";
import { guardarResposta, registrarLog, tamanhoJson } from "@/lib/coletorStore";
import {
  diaOperacional,
  MSG_OFFLINE,
  MSG_PROXY,
  MSG_TOKEN,
  RELATORIOS_BASE_URL,
  RELATORIOS_MODO,
  RELATORIOS_PATH,
  type RelatorioTipo,
} from "@/lib/relatoriosExternos";

export type RotaDiagnostico = {
  tipo: RelatorioTipo;
  ok: boolean;
  status?: number;
  ms: number;
  bytes?: number;
  codigo?: string;
  erro?: string;
  /** Pedaço do corpo quando ele não é o JSON esperado (HTML de erro, etc.). */
  amostra?: string;
};

export type Diagnostico = {
  modo: "proxy" | "direto";
  /** Base do servidor. Em modo proxy vem da Edge Function (é ela que guarda a URL). */
  base: string;
  caminho: string;
  data: string;
  ms_total: number;
  token_configurado?: boolean;
  timeout_ms?: number;
  tentativas?: number;
  rotas: RotaDiagnostico[];
};

const TIPOS: RelatorioTipo[] = ["montante", "contas", "operadores"];

/** Roda o teste e registra tudo no log do coletor. Nunca lança: uma falha de
 *  conexão é justamente o resultado que o painel precisa mostrar. */
export async function testarConexao(data: string = diaOperacional()): Promise<Diagnostico> {
  const comeco = performance.now();

  const diagnostico =
    RELATORIOS_MODO === "direto"
      ? await testarDireto(data)
      : await testarViaProxy(data, comeco);

  for (const r of diagnostico.rotas) {
    registrarLog({
      origem: "diagnostico",
      rota: r.tipo,
      nivel: r.ok ? "ok" : "erro",
      ms: r.ms,
      status: r.status,
      bytes: r.bytes,
      codigo: r.codigo,
      mensagem: r.ok ? `${data} — ${r.bytes ?? 0} bytes` : (r.erro ?? "falha"),
    });
  }

  const oks = diagnostico.rotas.filter((r) => r.ok).length;
  registrarLog({
    origem: "diagnostico",
    rota: "*",
    nivel: oks === diagnostico.rotas.length ? "ok" : oks === 0 ? "erro" : "info",
    ms: diagnostico.ms_total,
    mensagem: `Teste de conexão: ${oks}/${diagnostico.rotas.length} rotas responderam (${diagnostico.modo})`,
  });

  return diagnostico;
}

/** Mensagem legível para um erro do supabase-js ao invocar a Edge Function. */
async function motivoDoProxy(error: unknown): Promise<string> {
  if (error instanceof FunctionsHttpError) {
    const res = error.context as Response | undefined;
    try {
      const corpo = await res?.clone().json();
      const detalhe = corpo?.error ?? corpo?.message;
      if (detalhe) return `Edge Function respondeu ${res?.status}: ${detalhe}`;
    } catch { /* sem JSON */ }
    return `Edge Function respondeu ${res?.status ?? "erro"}`;
  }
  if (error instanceof FunctionsFetchError) return `${MSG_PROXY} (rede ou CORS)`;
  return (error as Error)?.message ?? MSG_PROXY;
}

async function testarViaProxy(data: string, comeco: number): Promise<Diagnostico> {
  const base: Diagnostico = {
    modo: "proxy",
    base: "",
    caminho: RELATORIOS_PATH,
    data,
    ms_total: 0,
    rotas: [],
  };

  try {
    const { data: body, error } = await supabase.functions.invoke("relatorios-externos", {
      body: { acao: "diagnostico", data },
    });
    const ms_total = Math.round(performance.now() - comeco);

    if (error || body?.error) {
      // A Edge Function não respondeu: o servidor nem chegou a ser chamado.
      const mensagem = error ? await motivoDoProxy(error) : String(body?.error);
      return {
        ...base,
        ms_total,
        rotas: TIPOS.map((tipo) => ({ tipo, ok: false, ms: 0, codigo: "proxy", erro: mensagem })),
      };
    }

    const d = body?.diagnostico ?? {};
    const rotas: RotaDiagnostico[] = (d.rotas ?? []).map((r: Record<string, unknown>) => {
      const tipo = r.tipo as RelatorioTipo;
      if (r.ok && r.relatorio !== undefined) {
        guardarResposta(tipo, r.relatorio, Number(r.ms ?? 0), Number(r.bytes ?? tamanhoJson(r.relatorio)));
      }
      return {
        tipo,
        ok: !!r.ok,
        status: r.status as number | undefined,
        ms: Number(r.ms ?? 0),
        bytes: r.bytes as number | undefined,
        codigo: r.codigo as string | undefined,
        erro: r.erro as string | undefined,
        amostra: r.amostra as string | undefined,
      };
    });

    return {
      ...base,
      base: (d.base as string) ?? base.base,
      caminho: (d.caminho as string) ?? base.caminho,
      ms_total: Number(d.ms_total ?? ms_total),
      token_configurado: d.token_configurado as boolean | undefined,
      timeout_ms: d.timeout_ms as number | undefined,
      tentativas: d.tentativas as number | undefined,
      rotas,
    };
  } catch (e) {
    return {
      ...base,
      ms_total: Math.round(performance.now() - comeco),
      rotas: TIPOS.map((tipo) => ({
        tipo,
        ok: false,
        ms: 0,
        codigo: "proxy",
        erro: (e as Error)?.message ?? MSG_PROXY,
      })),
    };
  }
}

/** Modo de desenvolvimento: navegador falando direto com o servidor. Só funciona
 *  onde o CORS não atrapalha. */
async function testarDireto(data: string): Promise<Diagnostico> {
  const token = import.meta.env.VITE_RELATORIOS_TOKEN ?? "";
  const comeco = performance.now();

  const rotas = await Promise.all(
    TIPOS.map(async (tipo): Promise<RotaDiagnostico> => {
      const t0 = performance.now();
      if (!RELATORIOS_BASE_URL) {
        return { tipo, ok: false, ms: 0, codigo: "proxy", erro: "VITE_RELATORIOS_URL não configurada para o modo direto" };
      }
      const url = new URL(`${RELATORIOS_PATH}/${tipo}`, RELATORIOS_BASE_URL);
      url.searchParams.set("data", data);
      try {
        const res = await fetch(url, {
          headers: {
            Accept: "application/json",
            ...(token ? { Authorization: `Bearer ${token}` } : {}),
            "X-Dash-Client": "dash-web",
          },
        });
        const corpo = await res.text();
        const ms = Math.round(performance.now() - t0);

        if (res.status === 401 || res.status === 403) {
          return { tipo, ok: false, status: res.status, ms, codigo: "token_coletor", erro: MSG_TOKEN };
        }
        if (res.status === 400) {
          return { tipo, ok: false, status: 400, ms, codigo: "data_invalida", erro: "Data inválida", amostra: corpo.slice(0, 300) };
        }
        if (!res.ok) {
          return { tipo, ok: false, status: res.status, ms, codigo: "coletor_offline", erro: `${MSG_OFFLINE} (HTTP ${res.status})`, amostra: corpo.slice(0, 300) };
        }
        const bruto = JSON.parse(corpo);
        guardarResposta(tipo, bruto, ms, corpo.length);
        return { tipo, ok: true, status: res.status, ms, bytes: corpo.length };
      } catch (e) {
        return {
          tipo,
          ok: false,
          ms: Math.round(performance.now() - t0),
          codigo: "coletor_offline",
          erro: MSG_OFFLINE,
          amostra: (e as Error)?.message,
        };
      }
    }),
  );

  return {
    modo: "direto",
    base: RELATORIOS_BASE_URL,
    caminho: RELATORIOS_PATH,
    data,
    ms_total: Math.round(performance.now() - comeco),
    rotas,
  };
}
