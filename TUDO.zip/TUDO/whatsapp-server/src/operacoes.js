/* Relatórios por usuário — o livro-caixa dos operadores.
 *
 * Uma operação é uma linha do dia de um operador: o que entrou (depósito), o
 * que saiu (saque), o que foi pago à Brogueira e a comissão dele. A aba
 * Relatórios soma isso por pessoa e por período, calcula o que há para pagar
 * de comissão e guarda o rastro de tudo que for editado, apagado ou zerado.
 *
 * ── As três regras que não podem escorregar ─────────────────────────────
 * 1. O DIA OPERACIONAL COMEÇA ÀS 5H. Uma operação registrada às 02h da
 *    madrugada pertence ao dia anterior — é o mesmo turno de quem trabalhou a
 *    noite inteira. A semana também usa esse corte (segunda 5h → segunda 5h).
 * 2. LÍQUIDO ≠ BRUTO. O líquido parte do lucro informado e soma o resultado
 *    das contas; o bruto ignora o lucro informado e olha só o dinheiro que se
 *    mexeu. Os dois convivem na tela porque respondem perguntas diferentes.
 * 3. ADMIN E OWNER NÃO ENTRAM NA COMISSÃO. Eles aparecem no resto dos
 *    relatórios (o dinheiro passou por eles), mas ninguém paga comissão para
 *    o dono da operação — somá-los inflaria o total a pagar.
 */
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';
import timezone from 'dayjs/plugin/timezone.js';
import { getDb, saveDb } from './db.js';

dayjs.extend(utc);
dayjs.extend(timezone);

// Hora em que o dia operacional vira. Não é configurável de propósito: mudar
// isso reescreveria o passado (as mesmas operações cairiam em outros dias).
export const CORTE_HORA = 5;

const num = (v, padrao = 0) => (Number.isFinite(Number(v)) ? Number(v) : padrao);
const cent = (v) => Math.round(num(v) * 100) / 100;

function tz() {
  const configurado = getDb().config?.timezone || 'America/Sao_Paulo';
  try {
    dayjs().tz(configurado);
    return configurado;
  } catch {
    return 'America/Sao_Paulo';
  }
}

/** O dia operacional (YYYY-MM-DD) de um instante: antes das 5h, é o dia anterior. */
export function diaOperacional(ts = undefined) {
  return dayjs(ts).tz(tz()).subtract(CORTE_HORA, 'hour').format('YYYY-MM-DD');
}

/** Segunda-feira do dia operacional de `ts` — o começo da semana operacional. */
export function inicioSemanaOperacional(ts = undefined) {
  const d = dayjs(dayjs(ts).tz(tz()).subtract(CORTE_HORA, 'hour').format('YYYY-MM-DD'));
  return d.subtract((d.day() + 6) % 7, 'day').format('YYYY-MM-DD');
}

/* ═══════════ Dinheiro ═══════════ */

/** Lucro líquido: o lucro informado mais o resultado das contas. */
export function lucroLiquido(op) {
  return cent(num(op.lucro) + (num(op.saque_contas) - num(op.deposito_contas) + num(op.salario_contas)));
}

/** Lucro bruto: só o dinheiro que se mexeu, sem o lucro informado. */
export function lucroBruto(op) {
  return cent((num(op.saque) - num(op.deposito)) + (num(op.saque_contas) - num(op.deposito_contas)));
}

export const depositoTotal = (op) => cent(num(op.deposito) + num(op.deposito_contas));
export const saqueTotal = (op) => cent(num(op.saque) + num(op.saque_contas));
export const blogueiraTotal = (op) => cent(num(op.blogueira) + num(op.salario_contas));
export const lucroDe = (op, modo = 'liquido') => (modo === 'bruto' ? lucroBruto(op) : lucroLiquido(op));

/* ═══════════ Usuários (perfis + papel) ═══════════
   O papel decide só uma coisa aqui: quem entra na conta da comissão. */

export const PAPEIS = ['owner', 'admin', 'user'];
export const isChefia = (u) => u?.papel === 'admin' || u?.papel === 'owner';

export function listarUsuarios() {
  return [...(getDb().usuarios ?? [])].sort((a, b) => String(a.nome).localeCompare(String(b.nome), 'pt-BR'));
}

export function usuarioPorId(id) {
  return (getDb().usuarios ?? []).find((u) => u.id === id) ?? null;
}

export function salvarUsuario({ id, nome, email, papel }) {
  const db = getDb();
  if (!Array.isArray(db.usuarios)) db.usuarios = [];
  const limpo = {
    nome: String(nome ?? '').trim().slice(0, 80),
    email: String(email ?? '').trim().slice(0, 120) || null,
    papel: PAPEIS.includes(papel) ? papel : 'user',
  };
  if (!limpo.nome) throw new Error('informe o nome do usuário');

  const existente = id ? db.usuarios.find((u) => u.id === id) : null;
  if (id && !existente) throw new Error('usuário não encontrado');
  if (existente) {
    Object.assign(existente, limpo);
    saveDb();
    return existente;
  }
  const novo = { id: `u${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`, ...limpo, criadoEm: new Date().toISOString() };
  db.usuarios.push(novo);
  saveDb();
  return novo;
}

export function apagarUsuario(id) {
  const db = getDb();
  const antes = db.usuarios.length;
  // As operações ficam: apagar o histórico junto esconderia dinheiro que já
  // aconteceu. Elas passam a aparecer como "usuário removido".
  db.usuarios = (db.usuarios ?? []).filter((u) => u.id !== id);
  saveDb();
  return antes - db.usuarios.length;
}

/* ═══════════ Operações ═══════════ */

const CAMPOS_VALOR = [
  'deposito', 'saque', 'blogueira', 'comissao', 'comissao_contas', 'lucro',
  'deposito_contas', 'saque_contas', 'salario_contas',
];

function normalizarOperacao(entrada, base = {}) {
  const op = { ...base };
  for (const campo of CAMPOS_VALOR) {
    if (entrada[campo] !== undefined) op[campo] = cent(entrada[campo]);
    else if (op[campo] === undefined) op[campo] = 0;
  }
  if (entrada.nome_conta !== undefined) op.nome_conta = String(entrada.nome_conta ?? '').trim().slice(0, 80) || null;
  if (entrada.data_operacao !== undefined) {
    const d = String(entrada.data_operacao ?? '').slice(0, 10);
    op.data_operacao = /^\d{4}-\d{2}-\d{2}$/.test(d) ? d : null;
  }
  return op;
}

/**
 * O dia que vale para os relatórios.
 * `data_operacao` (quando o admin informa) manda; senão, o dia operacional do
 * registro. É o que permite lançar hoje uma operação de ontem.
 */
export const diaDaOperacao = (op) => op.data_operacao || op.dia || diaOperacional(op.created_at);

export function registrarOperacao(entrada = {}) {
  const db = getDb();
  if (!Array.isArray(db.operations)) db.operations = [];
  const user = usuarioPorId(entrada.user_id);
  if (!user) throw new Error('escolha um usuário para a operação');

  const agora = new Date().toISOString();
  const op = normalizarOperacao(entrada, {
    id: `o${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    user_id: user.id,
    created_at: agora,
  });
  op.dia = op.data_operacao || diaOperacional(agora);
  db.operations.push(op);
  saveDb();
  return op;
}

export function atualizarOperacao(id, mudancas = {}, { por = 'admin' } = {}) {
  const db = getDb();
  const atual = (db.operations ?? []).find((o) => o.id === id);
  if (!atual) throw new Error('operação não encontrada');

  registrarAuditoria(atual, 'EDITADA', por);
  const novo = normalizarOperacao(mudancas, atual);
  if (mudancas.user_id && usuarioPorId(mudancas.user_id)) novo.user_id = mudancas.user_id;
  novo.dia = novo.data_operacao || diaOperacional(novo.created_at);
  Object.assign(atual, novo);
  saveDb();
  return atual;
}

export function apagarOperacao(id, { por = 'admin' } = {}) {
  const db = getDb();
  const atual = (db.operations ?? []).find((o) => o.id === id);
  if (!atual) return 0;
  registrarAuditoria(atual, 'APAGADA', por);
  db.operations = db.operations.filter((o) => o.id !== id);
  saveDb();
  return 1;
}

/* ═══════════ Log de alterações ═══════════
   O gatilho do Postgres virou uma função chamada por quem edita/apaga: o
   snapshot guarda o valor ANTIGO, que é o que se quer conferir depois. */

const MAX_AUDITORIA = 2000;

function registrarAuditoria(op, acao, por) {
  const db = getDb();
  if (!Array.isArray(db.operationAudit)) db.operationAudit = [];
  db.operationAudit.push({
    id: `a${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
    operation_id: op.id,
    user_id: op.user_id,
    acao,
    snapshot: { ...op },
    changed_by: String(por ?? 'admin').slice(0, 80),
    changed_at: new Date().toISOString(),
  });
  if (db.operationAudit.length > MAX_AUDITORIA) {
    db.operationAudit.splice(0, db.operationAudit.length - MAX_AUDITORIA);
  }
}

export function logAlteracoes(limite = 200) {
  const nomes = Object.fromEntries((getDb().usuarios ?? []).map((u) => [u.id, u.nome]));
  // Editar e apagar a mesma operação acontece no mesmo milissegundo: com o
  // timestamp sozinho a ordem sairia embaralhada. A posição na lista é a ordem
  // real dos fatos, e desempata.
  return (getDb().operationAudit ?? [])
    .map((r, i) => ({ r, i }))
    .sort((a, b) => String(b.r.changed_at).localeCompare(String(a.r.changed_at)) || (b.i - a.i))
    .slice(0, limite)
    .map(({ r }) => ({ ...r, usuarioNome: nomes[r.user_id] ?? 'usuário removido' }));
}

/* ═══════════ Consulta e agregação ═══════════ */

export function filtrarOperacoes({ de = null, ate = null, userId = null } = {}) {
  return (getDb().operations ?? [])
    .filter((op) => {
      const dia = diaDaOperacao(op);
      if (de && dia < de) return false;
      if (ate && dia > ate) return false;
      if (userId && op.user_id !== userId) return false;
      return true;
    })
    .sort((a, b) => String(diaDaOperacao(b)).localeCompare(String(diaDaOperacao(a)))
      || String(b.created_at).localeCompare(String(a.created_at)));
}

const zeros = () => ({
  pedidos: 0, deposito: 0, saque: 0, blogueira: 0, comissao: 0, comissao_contas: 0,
  lucroLiquido: 0, lucroBruto: 0, blogueiraHoje: 0, blogueiraSemana: 0,
});

/**
 * Agrega por usuário. "Blog. hoje/semana" usam o corte das 5h e NÃO dependem
 * do filtro de datas: a meta é do dia corrente, não do período em análise —
 * senão a barra de progresso mentiria sempre que alguém filtrasse o mês.
 */
export function agregarPorUsuario({ de = null, ate = null, userId = null, modo = 'liquido' } = {}) {
  const hoje = diaOperacional();
  const semana = inicioSemanaOperacional();
  const porUsuario = new Map();
  const usuarios = Object.fromEntries((getDb().usuarios ?? []).map((u) => [u.id, u]));

  // O recorte de hoje/semana varre TODAS as operações do usuário, não só as do
  // filtro — por isso duas passagens.
  for (const op of getDb().operations ?? []) {
    if (userId && op.user_id !== userId) continue;
    const linha = porUsuario.get(op.user_id) ?? { ...zeros(), user_id: op.user_id };
    const dia = diaDaOperacao(op);
    if (dia === hoje) linha.blogueiraHoje += blogueiraTotal(op);
    if (dia >= semana) linha.blogueiraSemana += blogueiraTotal(op);
    porUsuario.set(op.user_id, linha);
  }

  for (const op of filtrarOperacoes({ de, ate, userId })) {
    const linha = porUsuario.get(op.user_id) ?? { ...zeros(), user_id: op.user_id };
    linha.pedidos += 1;
    linha.deposito += depositoTotal(op);
    linha.saque += saqueTotal(op);
    linha.blogueira += blogueiraTotal(op);
    linha.comissao += num(op.comissao);
    linha.comissao_contas += num(op.comissao_contas);
    linha.lucroLiquido += lucroLiquido(op);
    linha.lucroBruto += lucroBruto(op);
    porUsuario.set(op.user_id, linha);
  }

  return [...porUsuario.values()]
    .map((l) => {
      const u = usuarios[l.user_id];
      return {
        ...l,
        nome: u?.nome ?? 'usuário removido',
        email: u?.email ?? null,
        papel: u?.papel ?? 'user',
        chefia: isChefia(u),
        lucro: cent(modo === 'bruto' ? l.lucroBruto : l.lucroLiquido),
        deposito: cent(l.deposito), saque: cent(l.saque), blogueira: cent(l.blogueira),
        comissao: cent(l.comissao), comissao_contas: cent(l.comissao_contas),
        lucroLiquido: cent(l.lucroLiquido), lucroBruto: cent(l.lucroBruto),
        blogueiraHoje: cent(l.blogueiraHoje), blogueiraSemana: cent(l.blogueiraSemana),
        total_comissao: cent(l.comissao + l.comissao_contas),
      };
    })
    .sort((a, b) => b.lucro - a.lucro);
}

/** Totais dos cards do topo. */
export function totais({ de = null, ate = null, userId = null, modo = 'liquido' } = {}) {
  const linhas = agregarPorUsuario({ de, ate, userId, modo });
  const soma = (campo) => cent(linhas.reduce((s, l) => s + l[campo], 0));
  const cfg = metas();
  const blogueiraHoje = soma('blogueiraHoje');
  const blogueiraSemana = soma('blogueiraSemana');
  const pct = (v, meta) => (meta > 0 ? Math.round((v / meta) * 1000) / 10 : null);
  return {
    pedidos: linhas.reduce((s, l) => s + l.pedidos, 0),
    lucro: soma('lucro'),
    lucroLiquido: soma('lucroLiquido'),
    lucroBruto: soma('lucroBruto'),
    deposito: soma('deposito'),
    saque: soma('saque'),
    blogueira: soma('blogueira'),
    blogueiraHoje,
    blogueiraSemana,
    metaDiaria: cfg.metaDiariaBlogueira,
    metaSemanal: cfg.metaSemanalBlogueira,
    pctDiaria: pct(blogueiraHoje, cfg.metaDiariaBlogueira),
    pctSemanal: pct(blogueiraSemana, cfg.metaSemanalBlogueira),
    dia: diaOperacional(),
    semanaDe: inicioSemanaOperacional(),
  };
}

/* ═══════════ Metas ═══════════ */

export function metas() {
  const s = getDb().appSettings ?? {};
  return {
    metaDiariaBlogueira: num(s.metaDiariaBlogueira),
    metaSemanalBlogueira: num(s.metaSemanalBlogueira),
  };
}

export function salvarMetas({ metaDiariaBlogueira, metaSemanalBlogueira } = {}) {
  const db = getDb();
  db.appSettings = {
    metaDiariaBlogueira: Math.max(0, cent(metaDiariaBlogueira)),
    metaSemanalBlogueira: Math.max(0, cent(metaSemanalBlogueira)),
  };
  saveDb();
  return metas();
}

/* ═══════════ Comissões ═══════════ */

/** O que há a pagar no período, por usuário. Admin e owner ficam de fora. */
export function comissoes({ de = null, ate = null, userId = null } = {}) {
  const porUsuario = agregarPorUsuario({ de, ate, userId })
    .filter((l) => !l.chefia && (l.comissao !== 0 || l.comissao_contas !== 0));
  const soma = (campo) => cent(porUsuario.reduce((s, l) => s + l[campo], 0));
  return {
    usuarios: porUsuario.map((l) => ({
      user_id: l.user_id, nome: l.nome, email: l.email,
      comissao: l.comissao, comissao_contas: l.comissao_contas, total: l.total_comissao,
    })),
    comissao: soma('comissao'),
    comissao_contas: soma('comissao_contas'),
    total: cent(soma('comissao') + soma('comissao_contas')),
  };
}

/**
 * Zera comissões — SEMPRE com backup gravado antes.
 *
 * A ordem importa e é o coração desta função: primeiro grava o snapshot com o
 * valor exato de cada operação, e só se o backup ficou salvo é que zera. Se o
 * processo morrer no meio, sobra um backup a mais (inofensivo) em vez de
 * dinheiro apagado sem rastro.
 *
 * `userId` nulo zera todo mundo do período — e nesse caso sai UM BACKUP POR
 * USUÁRIO, para o "Desfazer" poder devolver a comissão de uma pessoa só.
 */
export function zerarComissoes({ de = null, ate = null, userId = null, por = 'admin' } = {}) {
  const db = getDb();
  const alvo = filtrarOperacoes({ de, ate, userId })
    .filter((op) => !isChefia(usuarioPorId(op.user_id)))
    .filter((op) => num(op.comissao) !== 0 || num(op.comissao_contas) !== 0);
  if (!alvo.length) return { backups: [], operacoes: 0, total: 0 };

  const porUsuario = new Map();
  for (const op of alvo) {
    if (!porUsuario.has(op.user_id)) porUsuario.set(op.user_id, []);
    porUsuario.get(op.user_id).push(op);
  }

  if (!Array.isArray(db.commissionResets)) db.commissionResets = [];
  const backups = [];
  for (const [uid, ops] of porUsuario) {
    const backup = {
      id: `r${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`,
      user_id: uid,
      reset_by: String(por ?? 'admin').slice(0, 80),
      operations: ops.map((op) => ({
        operation_id: op.id, comissao: num(op.comissao), comissao_contas: num(op.comissao_contas),
      })),
      total_comissao: cent(ops.reduce((s, op) => s + num(op.comissao), 0)),
      total_comissao_contas: cent(ops.reduce((s, op) => s + num(op.comissao_contas), 0)),
      periodo: { de, ate },
      undone: false,
      undone_at: null,
      created_at: new Date().toISOString(),
    };
    db.commissionResets.push(backup);
    backups.push(backup);
  }
  saveDb();                      // ── o backup está no disco a partir daqui ──

  // Só agora o dinheiro sai da tela. Em lotes, como no original: com milhares
  // de operações, um save por linha travaria o servidor.
  const LOTE = 200;
  for (let i = 0; i < alvo.length; i += LOTE) {
    for (const op of alvo.slice(i, i + LOTE)) {
      op.comissao = 0;
      op.comissao_contas = 0;
    }
    saveDb();
  }

  return {
    backups,
    operacoes: alvo.length,
    total: cent(backups.reduce((s, b) => s + b.total_comissao + b.total_comissao_contas, 0)),
  };
}

export function listarBackupsComissao(limite = 100) {
  const nomes = Object.fromEntries((getDb().usuarios ?? []).map((u) => [u.id, u.nome]));
  return [...(getDb().commissionResets ?? [])]
    .sort((a, b) => String(b.created_at).localeCompare(String(a.created_at)))
    .slice(0, limite)
    .map((b) => ({
      ...b,
      usuarioNome: nomes[b.user_id] ?? 'usuário removido',
      operacoes: b.operations.length,
      total: cent(num(b.total_comissao) + num(b.total_comissao_contas)),
    }));
}

/**
 * Desfaz um backup: devolve a cada operação o valor exato do snapshot.
 * Operação que não existe mais (foi apagada depois do reset) é contada à
 * parte em vez de recriada — ressuscitar uma linha apagada seria pior.
 */
export function desfazerReset(id) {
  const db = getDb();
  const backup = (db.commissionResets ?? []).find((b) => b.id === id);
  if (!backup) throw new Error('backup não encontrado');
  if (backup.undone) throw new Error('este backup já foi desfeito');

  let restauradas = 0;
  let sumiram = 0;
  for (const item of backup.operations ?? []) {
    const op = (db.operations ?? []).find((o) => o.id === item.operation_id);
    if (!op) { sumiram += 1; continue; }
    op.comissao = cent(item.comissao);
    op.comissao_contas = cent(item.comissao_contas);
    restauradas += 1;
  }
  backup.undone = true;
  backup.undone_at = new Date().toISOString();
  saveDb();
  return { restauradas, sumiram, total: cent(num(backup.total_comissao) + num(backup.total_comissao_contas)) };
}

/* ═══════════ CSV ═══════════ */

const csvCampo = (v) => `"${String(v ?? '').replace(/"/g, '""')}"`;

/** Agregados por usuário em CSV — com BOM, que é o que o Excel brasileiro espera. */
export function csvPorUsuario({ de = null, ate = null, userId = null, modo = 'liquido' } = {}) {
  const linhas = agregarPorUsuario({ de, ate, userId, modo });
  const cab = ['Usuário', 'E-mail', 'Papel', 'Pedidos', 'Depósito', 'Saque', 'Blogueira',
    'Comissão', 'Comissão contas', modo === 'bruto' ? 'Lucro bruto' : 'Lucro líquido',
    'Blog. hoje', 'Blog. semana'];
  const corpo = linhas.map((l) => [
    l.nome, l.email ?? '', l.papel, l.pedidos, l.deposito, l.saque, l.blogueira,
    l.comissao, l.comissao_contas, l.lucro, l.blogueiraHoje, l.blogueiraSemana,
  ].map(csvCampo).join(';'));
  return '﻿' + [cab.map(csvCampo).join(';'), ...corpo].join('\r\n') + '\r\n';
}

export function nomeArquivoCsv() {
  return `relatorio-usuarios-${diaOperacional()}.csv`;
}

/** Tudo o que a aba precisa numa chamada só. */
export function painelRelatorios({ de = null, ate = null, userId = null, modo = 'liquido' } = {}) {
  return {
    filtros: { de, ate, userId, modo },
    usuarios: listarUsuarios(),
    totais: totais({ de, ate, userId, modo }),
    porUsuario: agregarPorUsuario({ de, ate, userId, modo }),
    comissoes: comissoes({ de, ate, userId }),
    metas: metas(),
    backups: listarBackupsComissao(100),
    auditoria: logAlteracoes(200),
  };
}
