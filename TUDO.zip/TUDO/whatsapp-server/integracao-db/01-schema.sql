-- DB Dashboard × Whatsap Server — o lado que RECEBE.
--
-- Duas tabelas, prefixo `wa_` para não esbarrar no que o site já tem:
--   wa_operadores_dia  → uma linha por Operador por dia (o ranking)
--   wa_servicos        → uma linha por serviço (os 3 passos, um a um)
--
-- As duas são idempotentes por construção: a chave primária é o que identifica
-- o registro do lado do bot, então reenviar o mesmo lote atualiza em vez de
-- duplicar. É isso que deixa a retentativa do bot ser burra e segura.

create table if not exists public.wa_operadores_dia (
  dia                     date        not null,
  operador_id             text        not null,
  operador_pn             text,
  operador_nome           text,

  -- serviços dos 3 passos
  servicos                integer     not null default 0,   -- pedidos que ele atendeu
  validados               integer     not null default 0,   -- fecharam com comprovante
  aguardando              integer     not null default 0,
  sem_comprovante         integer     not null default 0,
  taxa                    numeric(5,3) not null default 0,  -- validados / serviços

  -- dinheiro
  montante_validado       numeric(14,2) not null default 0,
  montante_atendido       numeric(14,2) not null default 0,
  montante_lancado        numeric(14,2) not null default 0,
  lancamentos             integer     not null default 0,

  -- contas nos três recortes que o painel usa (não são o mesmo número)
  contas_pegas_qtd        integer     not null default 0,
  contas_pegas_valor      numeric(14,2) not null default 0,
  contas_validadas_qtd    integer     not null default 0,
  contas_validadas_valor  numeric(14,2) not null default 0,
  contas_lancadas_qtd     integer     not null default 0,
  contas_lancadas_valor   numeric(14,2) not null default 0,

  -- como os serviços dele casaram (a prova de cada um)
  casamento_citacao       integer     not null default 0,
  casamento_valor         integer     not null default 0,
  casamento_tempo         integer     not null default 0,
  brogueiras              integer     not null default 0,

  atualizado_em           timestamptz not null default now(),
  primary key (dia, operador_id)
);

create index if not exists wa_operadores_dia_dia_idx on public.wa_operadores_dia (dia desc);
create index if not exists wa_operadores_dia_operador_idx on public.wa_operadores_dia (operador_id);

create table if not exists public.wa_servicos (
  id               text        primary key,   -- id do serviço no bot
  dia              date        not null,
  status           text        not null,      -- aguardando_atendimento | aguardando_comprovante | validado | expirado_*
  tipo             text,                      -- montante | conta | indefinido
  sessao_id        text,                      -- qual número do bot viu
  grupo_id         text,
  grupo_nome       text,

  -- passo 1: a Brogueira pediu
  brogueira_nome   text,
  brogueira_pn     text,
  pedido_texto     text,
  pedido_ts        timestamptz,
  montante_pedido  numeric(14,2) not null default 0,
  contas_pedidas   integer       not null default 0,

  -- passo 2: o Operador respondeu
  operador_id      text,
  operador_pn      text,
  operador_nome    text,
  atendimento_ts   timestamptz,
  montante         numeric(14,2) not null default 0,
  contas_qtd       integer       not null default 0,
  contas_valor     numeric(14,2) not null default 0,
  casamento        text,                      -- citacao | valor | tempo

  -- passo 3: o comprovante PIX dela
  comprovante_ts   timestamptz,
  comprovante_tipo text,                      -- imagem | pdf

  atualizado_em    timestamptz not null default now()
);

create index if not exists wa_servicos_dia_idx on public.wa_servicos (dia desc);
create index if not exists wa_servicos_operador_idx on public.wa_servicos (operador_id, dia desc);
create index if not exists wa_servicos_status_idx on public.wa_servicos (status);

-- ── Acesso ────────────────────────────────────────────────────────────
-- RLS ligada e SEM política de escrita: só a `service_role` (a edge function
-- de ingestão) grava. Quem entra no site pelo login lê.
alter table public.wa_operadores_dia enable row level security;
alter table public.wa_servicos       enable row level security;

drop policy if exists "wa_operadores_dia leitura autenticada" on public.wa_operadores_dia;
create policy "wa_operadores_dia leitura autenticada"
  on public.wa_operadores_dia for select
  to authenticated using (true);

drop policy if exists "wa_servicos leitura autenticada" on public.wa_servicos;
create policy "wa_servicos leitura autenticada"
  on public.wa_servicos for select
  to authenticated using (true);

-- ── Visões de conveniência para o dashboard ───────────────────────────
-- O site pode consultar direto as tabelas; estas são só os dois cortes que a
-- tela de Operações/Relatórios pede sempre.

create or replace view public.wa_ranking_hoje as
  select *
    from public.wa_operadores_dia
   where dia = (now() at time zone 'America/Sao_Paulo')::date
   order by validados desc, montante_validado desc;

create or replace view public.wa_totais_dia as
  select dia,
         count(*)                        as operadores,
         sum(servicos)                   as servicos,
         sum(validados)                  as validados,
         sum(montante_validado)          as montante_validado,
         sum(montante_lancado)           as montante_lancado,
         sum(contas_validadas_qtd)       as contas_validadas_qtd,
         sum(contas_lancadas_valor)      as contas_lancadas_valor
    from public.wa_operadores_dia
   group by dia
   order by dia desc;
