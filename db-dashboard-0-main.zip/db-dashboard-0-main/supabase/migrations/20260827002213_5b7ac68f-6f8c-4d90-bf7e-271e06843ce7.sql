CREATE OR REPLACE FUNCTION public.is_dono(_user_id uuid)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = 'owner'::public.app_role
  )
$$;

CREATE OR REPLACE FUNCTION public.dono_exists()
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles WHERE role = 'owner'::public.app_role
  )
$$;

REVOKE ALL ON FUNCTION public.is_dono(uuid) FROM PUBLIC, anon;
REVOKE ALL ON FUNCTION public.dono_exists() FROM PUBLIC, anon;
GRANT EXECUTE ON FUNCTION public.is_dono(uuid) TO authenticated, service_role;
GRANT EXECUTE ON FUNCTION public.dono_exists() TO authenticated, service_role;