// Múltiplos números: migração do db antigo, isolamento entre as sessões e o
// detector de sobreposição (dois números fazendo a mesma coisa no mesmo grupo).
//
// DATA_DIR aponta para um diretório temporário ANTES de importar db.js.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-sessoes-'));
process.env.DATA_DIR = DIR_TEMP;

const {
  IDS_SESSOES, MAX_SESSOES, CHAVES_RECURSOS, normalizarSessoes, sessoesIniciais, sessaoNova,
  normalizarConfigSessao, conflitos, recursosCompletos,
} = await import('./sessoes.js');
const { loadDb, getDb, getSessao, getConfig, getConfigSessao } = await import('./db.js');

// db.json no formato antigo (um número só), como o de produção antes desta versão.
const DB_ANTIGO = {
  config: {
    monitorMode: 'specific',
    monitoredGroups: ['120363000000000000@g.us'],
    welcomeEnabled: true,
    welcomeMessage: 'Bem-vinda!',
    commandAuthorizedNumbers: ['5573981810457'],
    alertaRepetidosEnabled: true,
    alertaRepetidosGrupo: '999@g.us',
    repetidosJanelaHoras: 24,
    timezone: 'America/Bahia',
  },
  stats: { totalMessages: 7, totalMontante: 300, totalContasValor: 0, totalContasQtd: 0, startedAt: null },
  messages: [{ id: 'm1', day: '2026-08-01', montante: 300, contasQtd: 0, contasTotal: 0 }],
  schedules: [{ id: 'sch_1', name: 'antigo', cron: '0 9 * * *', to: '1@g.us', message: 'oi', enabled: true }],
  meta: { version: 3 },
};

fs.writeFileSync(path.join(DIR_TEMP, 'db.json'), JSON.stringify(DB_ANTIGO));
loadDb();

test('migração: a config do número único vira a do Número 1, com tudo ligado', () => {
  const n1 = getSessao('n1');
  assert.equal(n1.ativa, true, 'o Número 1 continua no ar');
  assert.deepEqual(n1.recursos, recursosCompletos(), 'herda todos os recursos que já executava');
  assert.equal(n1.config.monitorMode, 'specific');
  assert.deepEqual(n1.config.monitoredGroups, ['120363000000000000@g.us']);
  assert.equal(n1.config.welcomeMessage, 'Bem-vinda!');
  assert.deepEqual(n1.config.commandAuthorizedNumbers, ['5573981810457']);
  assert.equal(n1.config.alertaRepetidosGrupo, '999@g.us');
});

test('migração: o que é do servidor fica global e o histórico é preservado', () => {
  const db = getDb();
  assert.equal(db.config.timezone, 'America/Bahia');
  assert.equal(db.config.repetidosJanelaHoras, 24);
  // Config de comportamento não fica duplicada na global — fonte única.
  assert.equal(db.config.welcomeMessage, undefined);
  assert.equal(db.messages.length, 1, 'lançamentos preservados');
  assert.equal(db.stats.totalMontante, 300);
  assert.equal(db.schedules[0].sessaoId, 'n1', 'agendamento antigo dispara pelo Número 1');
});

test('getConfig junta o global com o do número; getConfigSessao é o objeto gravável', () => {
  const vista = getConfig('n1');
  assert.equal(vista.timezone, 'America/Bahia', 'o fuso global entra na visão do número');
  assert.equal(vista.welcomeMessage, 'Bem-vinda!');

  const viva = getConfigSessao('n2');
  viva.welcomeMessage = 'só do número 2';
  assert.equal(getSessao('n2').config.welcomeMessage, 'só do número 2');
  assert.equal(getSessao('n1').config.welcomeMessage, 'Bem-vinda!', 'o Número 1 não foi afetado');
});

test('números 2 e 3 nascem parados, sem recursos e sem monitorar nada', () => {
  for (const id of ['n2', 'n3']) {
    const s = getSessao(id);
    assert.equal(s.ativa, false, `${id} não conecta sozinho`);
    assert.equal(Object.values(s.recursos).some(Boolean), false, `${id} não faz nada até alguém escolher`);
    assert.equal(s.config.monitorMode, 'specific');
    assert.deepEqual(s.config.monitoredGroups, []);
    assert.equal(s.config.monitorPrivate, false);
  }
});

test('normalizarSessoes devolve sempre os 3 lugares, na ordem, sem duplicar id', () => {
  const s = normalizarSessoes([{ id: 'n2', nome: 'B' }, { id: 'n2', nome: 'repetido' }]);
  assert.equal(s.length, MAX_SESSOES);
  assert.deepEqual(s.map((x) => x.id), IDS_SESSOES);
  assert.equal(s[1].nome, 'B');
});

test('config de sessão descarta chave desconhecida e conserta tipo errado', () => {
  const c = normalizarConfigSessao({
    monitoredGroups: 'não é lista',
    monitorMode: 'inventado',
    alertaRepetidosPorLink: 'x',
    inventadoAqui: true,
  });
  assert.deepEqual(c.monitoredGroups, []);
  assert.equal(c.monitorMode, 'all');
  assert.equal(c.alertaRepetidosPorLink, 3);
  assert.equal('inventadoAqui' in c, false);
});

test('recursos só aceitam as chaves conhecidas', () => {
  const s = normalizarSessoes([{ id: 'n1', recursos: { monitorar: 1, inventado: true } }])[0];
  assert.equal(s.recursos.monitorar, true);
  assert.equal('inventado' in s.recursos, false);
  assert.deepEqual(Object.keys(s.recursos).sort(), [...CHAVES_RECURSOS].sort());
});

/* ── Sobreposição entre números ─────────────────────────────────── */

// Fixture: monitorPrivate desligado por padrão, senão TODO caso acusaria também
// a sobreposição em conversa privada (que é testada à parte).
function dbCom(sessoes) {
  return {
    sessoes: normalizarSessoes(
      sessoes.map((s) => ({ ...s, config: { monitorPrivate: false, ...(s.config ?? {}) } })),
    ),
  };
}

test('dois números monitorando o MESMO grupo é apontado como conflito', () => {
  const db = dbCom([
    { id: 'n1', ativa: true, recursos: { monitorar: true }, config: { monitorMode: 'specific', monitoredGroups: ['A@g.us'] } },
    { id: 'n2', ativa: true, recursos: { monitorar: true }, config: { monitorMode: 'specific', monitoredGroups: ['A@g.us'] } },
  ]);
  const achados = conflitos(db, { 'A@g.us': 'Grupo A' });
  const c = achados.find((x) => x.recurso === 'monitorar');
  assert.ok(c, 'o painel precisa avisar antes de a contagem dobrar');
  assert.equal(c.nome, 'Grupo A');
  assert.deepEqual(c.sessoes.sort(), ['n1', 'n2']);
  assert.equal(c.certeza, 'confirmado');
});

test('grupos diferentes (ou recursos diferentes) não geram conflito', () => {
  const separados = dbCom([
    { id: 'n1', ativa: true, recursos: { monitorar: true }, config: { monitorMode: 'specific', monitoredGroups: ['A@g.us'] } },
    { id: 'n2', ativa: true, recursos: { monitorar: true }, config: { monitorMode: 'specific', monitoredGroups: ['B@g.us'] } },
  ]);
  assert.deepEqual(conflitos(separados), []);

  const papeisDiferentes = dbCom([
    { id: 'n1', ativa: true, recursos: { monitorar: true }, config: { monitorMode: 'all' } },
    { id: 'n2', ativa: true, recursos: { pedidos: true }, config: { monitorMode: 'all' } },
  ]);
  assert.deepEqual(conflitos(papeisDiferentes), [], 'funções separadas é justamente o arranjo desejado');
});

test('"todos os grupos" em dois números conflita, e cobre o grupo específico do outro', () => {
  const db = dbCom([
    { id: 'n1', ativa: true, recursos: { pedidos: true }, config: { monitorMode: 'all' } },
    { id: 'n2', ativa: true, recursos: { pedidos: true }, config: { monitorMode: 'specific', monitoredGroups: ['A@g.us'] } },
  ]);
  const achados = conflitos(db);
  assert.equal(achados.length, 1);
  assert.equal(achados[0].alvo, 'A@g.us');
  assert.deepEqual(achados[0].sessoes.sort(), ['n1', 'n2']);
});

test('"monitorar privado" nos dois números sai como conflito possível', () => {
  const db = dbCom([
    { id: 'n1', ativa: true, recursos: { monitorar: true }, config: { monitorMode: 'none', monitorPrivate: true } },
    { id: 'n2', ativa: true, recursos: { monitorar: true }, config: { monitorMode: 'none', monitorPrivate: true } },
  ]);
  const achados = conflitos(db);
  assert.equal(achados.length, 1);
  assert.equal(achados[0].alvo, 'privado');
  assert.equal(achados[0].certeza, 'possivel');
});

test('número desligado não conflita com ninguém', () => {
  const db = dbCom([
    { id: 'n1', ativa: true, recursos: { monitorar: true }, config: { monitorMode: 'all' } },
    { id: 'n2', ativa: false, recursos: { monitorar: true }, config: { monitorMode: 'all' } },
  ]);
  assert.deepEqual(conflitos(db), []);
});

test('boas-vindas nos mesmos grupos avisa; resposta automática avisa como "possível"', () => {
  const db = dbCom([
    { id: 'n1', ativa: true, recursos: { boasVindas: true, autoResposta: true }, config: { welcomeMode: 'all', autoReplyEnabled: true } },
    { id: 'n2', ativa: true, recursos: { boasVindas: true, autoResposta: true }, config: { welcomeMode: 'all', autoReplyEnabled: true } },
  ]);
  const achados = conflitos(db);
  const boas = achados.find((x) => x.recurso === 'boasVindas');
  const auto = achados.find((x) => x.recurso === 'autoResposta');
  assert.equal(boas?.certeza, 'confirmado');
  assert.equal(auto?.certeza, 'possivel');
});

test('sessaoNova não liga nada por engano', () => {
  const s = sessaoNova('n3', 2);
  assert.equal(s.ativa, false);
  assert.equal(Object.values(s.recursos).some(Boolean), false);
});
