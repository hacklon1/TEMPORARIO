# Whatsap Server — Bot de gestão de operações (BOT-ULTIMATE)

Bot de **gerenciamento de WhatsApp** em Node.js + [Baileys](https://github.com/WhiskeySockets/Baileys),
com painel web em tempo real (Express + Socket.IO), extração de dados financeiros
(montantes/contas), relatórios por operador, agendamentos e controle de acesso.
Opera **até 3 números** ao mesmo tempo, cada um com funções e configuração próprias
(ver [Vários números](#vários-números-até-3)).
Roda **ao lado do Server Delta** (`/opt/delta-cpa`) como serviço independente.

- **Local:** `/opt/whatsapp-server`  ·  **Porta:** `8080` em `0.0.0.0` (HTTPS)
- **Serviço:** `systemctl {start,stop,restart,status} whatsapp-server`
- **Usuário:** `whatsapp` (system user)  ·  **Node:** 22

## Arquitetura

```
Navegador ── Socket.IO ──┐
                         ▼
              server.js (Express + API + tempo real)
                 │        │            │
             Baileys   node-cron   data/db.json
                 │
              WhatsApp
```

Módulos em `src/`:

| Arquivo | Responsabilidade |
|---------|------------------|
| `sessoes.js`  | Modelo dos até 3 números: recursos, config por número e detecção de sobreposição |
| `whatsapp.js` | Conexões Baileys (uma por número), QR, reconexão, `messages.upsert`, cache de grupos |
| `handler.js`  | Orquestra cada mensagem: monitoramento → comando → extração → auto-resposta |
| `welcome.js`  | Boas-vindas a quem entra num grupo (`group-participants.update`) |
| `jid.js`      | Identidade do remetente sob endereçamento LID (`@lid` × telefone) |
| `parser.js`   | `normalizeText`, `parseBrazilianNumber`, `extractMontante`, `extractContas`, `contasOferecidas` |
| `store.js`    | Registra lançamentos, pedidos e indicações; agrega totais, por operador e por Brogueira; guarda o "quem é quem" |
| `pedidos.js`  | Filtro dos pedidos de link das Brogueiras (contas × montante) |
| `repetidos.js`| Link repetido: chave normalizada, detecção no ato e agrupamento para o painel |
| `alertas.js`  | Alerta de link repetido: limites, texto do aviso e disparo no grupo de operação |
| `indicacoes.js`| Leitura de "Vim por @fulana" — quem indicou quem |
| `membros.js`  | Papel no grupo: Operador (admin) × Brogueira (membro comum) |
| `reports.js`  | `!RELATORIO`, `!OPERADORES` e `!INDICACOES` (texto e dados) |
| `commands.js` | Comandos `!...`, autorização por número + senha |
| `scheduler.js`| Agendamentos (node-cron) |
| `db.js`       | Persistência JSON (`data/db.json`) |
| `realtime.js` | Snapshot + `emitUpdate()` via Socket.IO |

## Uso

1. Suba: `systemctl enable --now whatsapp-server`
2. Painel: `https://<host>:8080` (informe o `API_TOKEN` do `.env`).
   Porta/host vêm de `PORT`/`HOST` no `.env` — hoje `0.0.0.0:8080`, ou seja,
   **exposto em todas as interfaces** (liberado no ufw). O HTTPS usa o par
   `TLS_CERT`/`TLS_KEY` em `certs/`, que é **self-signed** — o navegador avisa.
3. Autentique escaneando o QR (aba Painel, terminal via `journalctl -u whatsapp-server`,
   ou `GET /api/qr`).

### Token

```bash
grep API_TOKEN /opt/whatsapp-server/.env
```
Todas as rotas `/api/*` e o Socket.IO exigem `Authorization: Bearer <API_TOKEN>`
(ou `?token=` na querystring, usado pelo `<img>` do QR).

## Vários números (até 3)

O servidor mantém **três sessões independentes** de WhatsApp — `n1`, `n2` e `n3`.
Cada uma tem:

- **conexão própria** (pasta `auth/<id>`, QR próprio, reconexão própria);
- **configuração completa própria** — grupos monitorados, mensagens, autorizados,
  limites de alerta. Mexer num número **não** mexe nos outros;
- **recursos** — o que aquele número faz. É aqui que as funções ficam separadas.

| Recurso | O que liga |
|---------|------------|
| `monitorar`    | lançamentos dos Operadores (montante/contas) que alimentam o Painel |
| `pedidos`      | pedidos de link das Brogueiras + detecção de link repetido |
| `indicacoes`   | "vim por @fulana" |
| `alertas`      | aviso automático de link repetido (depende de `pedidos`) |
| `comandos`     | `!RELATORIO`, `!OPERADORES`, `!STATUS`… |
| `autoResposta` | resposta automática |
| `boasVindas`   | saudação a quem entra no grupo |
| `agendamentos` | pode disparar os agendamentos marcados com este número |
| `envios`       | envio manual pela aba Enviar e por `POST /api/send` |

Tudo isso se opera na aba **Números** do painel: ligar/desligar o número, dar nome,
ler o QR, marcar os recursos, reconectar e desvincular (apaga a sessão e pede QR novo).

**Os dados são somados** entre os três (é uma operação só) e cada registro guarda o
número que o coletou; o seletor **Número** no cabeçalho filtra Painel, Brogueiras e
Indicações. Registros anteriores a esta versão contam como do Número 1.

### Contra a contagem dobrada

Dois números no mesmo grupo com o mesmo recurso ligado trabalhariam a mesma
mensagem duas vezes. Três defesas, nesta ordem:

1. números novos nascem **desligados, sem recurso nenhum** e sem grupo monitorado;
2. o painel **avisa** a sobreposição (`conflitos()` em `src/sessoes.js`): diz qual
   recurso, quais números e qual grupo;
3. o registro é recusado quando o **id da mensagem do WhatsApp** já foi gravado
   (`jaRegistrado()` em `src/store.js`) — vale mesmo se o aviso for ignorado, e
   também pega a reentrega da mesma mensagem numa reconexão.

Boas-vindas têm deduplicação própria por `grupo+participante` (60 s), então dois
números no mesmo grupo ainda mandam **uma** saudação.

### Migração da versão de um número só

Na primeira subida com este código, ao carregar o `db.json`:

- a `config` que existia vira a **config do Número 1**, que herda **todos** os
  recursos ligados — o bot continua fazendo exatamente o que fazia;
- só `timezone` e `repetidosJanelaHoras` continuam **globais** (em `db.config`);
- os agendamentos existentes passam a apontar para `sessaoId: 'n1'`;
- as credenciais soltas em `auth/` são movidas para `auth/n1/` (sem novo pareamento);
- nada do histórico é tocado (lançamentos, pedidos, indicações, pessoas, alertas).

## Painel

Shell com **sidebar** (navegação) + **topbar** (status da conexão, tema, sair) e
grid de cards. Responsivo: a sidebar vira uma barra de ícones abaixo de 900px.
Arquivos em `public/` (`index.html`, `style.css`, `app.js`, `relatorios.js`) —
sem build, sem dependência externa.

### A cara do painel

**Duas famílias, hospedadas aqui** (`public/fonts/`, ~105 KB no caso comum):
**IBM Plex Sans** para texto e **IBM Plex Mono** para todo número que se compara
em coluna — dinheiro, contagem, hora. O mono não é enfeite: é a voz do
livro-caixa, e é o que faz os valores alinharem dígito com dígito. Nada vem de
CDN de propósito: o painel roda num IP puro, e a cara dele não pode depender de
o Google abrir (um teste garante que nenhum `@font-face` aponte para fora).

**A linha viva** é o elemento de assinatura: 24 traços na barra de cima, um por
hora do dia, com a altura contando o volume de mensagens e a hora corrente
pulsando. Quando chega mensagem nova, o traço de agora pisca em verde. Ela
responde sem texto a pergunta que se faz o dia inteiro — *o bot está
recebendo?* — que nenhum número da tela responde.

Outras decisões: rótulos em versalete com espacejamento (as etiquetas recuam,
os dados avançam); item ativo do menu com uma barra na lateral em vez do bloco
pintado (são 14 itens — 14 blocos de cor competiriam com os dados); cabeçalho de
card com fio e o ícone num quadrado tingido, ancorando a coluna; cabeçalho de
tabela fixo ao rolar; foco visível em tudo que recebe teclado; e
`prefers-reduced-motion` respeitado. O único movimento que sobrou é o da linha
viva — a entrada em cascata dos cards foi cortada por cansar quem troca de aba
cinquenta vezes por dia.

### Temas (5)

O seletor fica no ícone de paleta da topbar; a escolha é lembrada em
`localStorage` (`ws_theme`) e aplicada como `data-theme` no `<html>`:

| Tema | `data-theme` | Cara |
|------|--------------|------|
| Escuro (padrão) | `dark` | azul-petróleo sobre quase-preto — o de sempre |
| Claro | `light` | cinza-azulado claro |
| Preto & Dourado | `noir` | preto com acento azul e dourado |
| Branco & Dourado | `dourado` | branco com acento dourado |
| Azul & Vermelho | `azul` | azul profundo com acento vermelho |

**Toda cor da interface vem de token** (`--page`, `--surface*`, `--ink*`,
`--line*`, `--accent`, `--good/--warning/--critical`, `--gradient-*`, `--glow`,
`--shadow*`): nenhum componente conhece cor fixa, então trocar o tema recolore
o painel inteiro — cards, tabelas, selos, sidebar e gráficos — sem recarregar.
Cada tema também declara `color-scheme`, para os controles nativos do navegador
acompanharem.

Duas regras que os temas **não** podem quebrar:

* **As séries dos gráficos não seguem o acento do tema.** `--s1/--s2/--s3` e a
  rampa `--seq-*` são a paleta categórica validada (contraste + daltonismo); o
  que muda entre temas é qual variação dela entra — a de superfície escura ou a
  de superfície clara. Repintar as séries com a cor da marca do tema faria a
  cor decorar em vez de identificar o dado. As três superfícies novas foram
  passadas no validador: tudo PASS, com o verde em 2,8:1 no tema branco (o
  mesmo aviso do tema claro de sempre — os valores estão escritos ao lado das
  barras, que é o alívio exigido).
* **As cores de status são reservadas.** `--good/--warning/--critical` não
  viram cor de marca; um tema só as redefine quando precisa de contraste (o
  Branco & Dourado escurece o âmbar, que sobre branco ficaria em ~1,8:1).

Utilitárias que acompanham: `.glass`, `.glass-strong`, `.text-gradient`,
`.number-tabular`, `.anim-fade`, `.anim-slide`, `.anim-glow` e a barra de
rolagem no tom do tema.

A paleta de dados é validada, não escolhida no olho:

| Papel | Cor | Onde |
|-------|-----|------|
| Série 1 | azul `#3987e5` / `#2a78d6` | montante |
| Série 2 | laranja `#d95926` / `#eb6834` | contas (R$) |
| Parte-do-todo | verde `--sv-ok` + hachura | serviço validado x sem comprovante |
| Sequencial | rampa azul 100→700 | heatmap de atividade |
| Status | `good` / `warning` / `critical` | conexão e zona de risco |

Regras que o painel segue (e que valem manter em qualquer gráfico novo):

- **Um eixo por gráfico.** Nada de dois eixos Y — a correlação seria inventada.
- **Cor segue a métrica, nunca a posição.** Um ranking não repinta ninguém.
- **Magnitude usa uma hue só**, clara→escura. Arco-íris não codifica ordem.
- **Operadores são categorias** → barras, não linha (linha sugere continuidade
  entre pessoas, que não existe). **Dias são contínuos** → aí a linha é o
  desenho certo, e é por isso que a onda da semana é uma área suave enquanto o
  quadro ao lado é de colunas. Os dois ficam **lado a lado** (a onda à
  esquerda, os validados à direita, cada um com o seu card de apoio embaixo
  numa `.col-quadro`); o da direita é de **colunas verticais, uma por Operador**
  (`colunaV()`/`gradeV()`/`rotuloEixo()` em app.js). A **área de plotagem tem a
  mesma altura nos dois** — é isso que faz a comparação lado a lado valer:
  coluna do mesmo tamanho, valor do mesmo tamanho. Caixa de 520×206 e 520×220
  (proporção < 0,45), baixas de propósito: a leitura aqui é comparar pessoas,
  não medir no eixo:
  o quadro antigo agrupa montante e contas lado a lado (medidas independentes —
  empilhar sugeriria um total que ninguém soma), o quadro dos serviços **empilha**
  validado + sem comprovante (é a mesma medida partida pelo desfecho, e aí a
  pilha É o total dele). O nome vai embaixo da coluna, cortado por
  **caractere e não por unidade UTF-16** — os nomes do grupo vêm em fonte
  estilizada (𝐀𝐒𝐒𝐈𝐒𝐓𝐄𝐍𝐓𝐄, U+1D400) e um `slice()` cru parte o par substituto
  e imprime "�".
- **Rótulo só no extremo**; o resto vem do eixo, do tooltip e da tabela ao lado.
- **Grade em hairline sólida**, recessiva; barra fina (≤24px) com ponta
  arredondada de 4px e base quadrada no zero.
- Todo gráfico tem **hover e foco por teclado** com o mesmo conteúdo, e os
  valores também são alcançáveis fora do tooltip.

## Comandos no WhatsApp

| Comando | Efeito |
|---------|--------|
| `!RELATORIO` | Resumo de hoje |
| `!OPERADORES` | Desempenho por operador |
| `!INDICACOES` | Ranking de quem mais indicou |
| `!STATUS` | Estado do bot |
| `!AJUDA` | Lista de comandos |

Os três relatórios aceitam o **período** no primeiro argumento — é como se pede
um dia anterior pelo próprio grupo:

```
!RELATORIO ontem        !OPERADORES 28/08        !INDICACOES semana
!RELATORIO 28/08/2026   !OPERADORES mes          !RELATORIO geral
```

Sem argumento é hoje. O título do relatório sempre diz de qual recorte ele é
(`📊 RELATÓRIO — 28/08/2026`), então ninguém lê um número do dia 28 achando que
é de hoje. Argumento que não bate com nada cai em **hoje**, nunca em "tudo".

Só **números autorizados** executam comandos (config `commandAuthorizedNumbers` /
`reportAuthorizedNumbers`). Se `commandPassword` estiver definida, envie
`!COMANDO senha=SUA_SENHA`.

## Boas-vindas em grupo

Quando alguém entra num grupo, o bot pode mandar uma saudação. Configure na aba
**Configurações → Boas-vindas** do painel:

| Config | Efeito |
|--------|--------|
| `welcomeEnabled` | Liga/desliga a saudação |
| `welcomeMode` | `all` (todos os grupos) ou `specific` |
| `welcomeGroups` | JIDs quando `welcomeMode === 'specific'` (aba **Grupos**) |
| `welcomeMessage` | O texto, com as variáveis abaixo |

Variáveis do template:

| Variável | Vira |
|----------|------|
| `{mencao}` | `@numero` **marcando** a pessoa (menção real) |
| `{numero}` | Só os dígitos |
| `{nome}` | Nome se conhecido, senão o número |
| `{grupo}` | Nome do grupo |
| `{total}` | Total de participantes após a entrada |

Padrão: `Olá {mencao}, seja bem-vindo(a) ao {grupo}! 👋`

Detalhes de comportamento:

- Só reage a `action: 'add'` — sair, promover e rebaixar são ignorados.
- **Não saúda o próprio bot** quando ele é adicionado a um grupo.
- Entradas repetidas do mesmo participante são ignoradas por **60s** (o WhatsApp
  reemite o evento em reconexão/sync, o que geraria saudação duplicada).
- Entrada em lote gera uma mensagem por pessoa, com **uma** consulta de
  metadados do grupo; se um envio falhar, os demais continuam.

## Apagar dados coletados

Painel → **Configurações → Zona de risco**, ou via API. Antes de qualquer
escrita o servidor grava um **backup completo** em `data/backup-<ISO>.json`
(os 10 mais recentes são mantidos; os anteriores são podados).

| Escopo | Efeito |
|--------|--------|
| `historico` | Remove lançamentos; os totais são **recalculados** a partir do que sobrou |
| `estatisticas` | Zera os totais acumulados; o histórico fica intacto |
| `tudo` | Remove os lançamentos **e** zera os totais |

`antesDe` (`YYYY-MM-DD`, opcional) restringe a remoção a lançamentos anteriores
à data — a entrada exatamente na data de corte é **mantida**. `confirmar: true`
é obrigatório; sem ele a rota devolve 400 e nada é tocado.

**Config e agendamentos nunca são apagados por essa operação.**

```bash
TOKEN=$(grep -oP '^API_TOKEN=\K.*' /opt/whatsapp-server/.env)

# apagar tudo
curl -sk -X POST https://127.0.0.1:8080/api/dados/limpar \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"escopo":"tudo","confirmar":true}'

# apagar só o histórico anterior a julho/2026
curl -sk -X POST https://127.0.0.1:8080/api/dados/limpar \
  -H "Authorization: Bearer $TOKEN" -H 'Content-Type: application/json' \
  -d '{"escopo":"historico","antesDe":"2026-07-01","confirmar":true}'

# listar os backups disponíveis
curl -sk https://127.0.0.1:8080/api/dados/backups -H "Authorization: Bearer $TOKEN"
```

Para **restaurar** um backup (não há rota — é manual, de propósito):

```bash
systemctl stop whatsapp-server
cp /opt/whatsapp-server/data/backup-<ISO>.json /opt/whatsapp-server/data/db.json
chown whatsapp:whatsapp /opt/whatsapp-server/data/db.json
systemctl start whatsapp-server
```

## Regras de extração (build do zero — ajuste em `src/parser.js`)

- **Fonte estilizada:** todo texto passa por `NFKC` antes da extração — as mensagens
  chegam em negrito unicode (`🔸 𝐌𝐨𝐧𝐭𝐚𝐧𝐭𝐞:`), que **não** é a palavra "Montante"
  para um regex comum.
- **Montante:** o valor ao lado da palavra, na mesma linha. `Montante: 233`,
  `🔸 Montante: R$ 350,00` e também **antes** dela (`300 de montante 2 contas` → 300).
  Com separador (`:`) o valor de depois vence; sem separador, vence o **maior** dos dois
  lados (desempata `1 montante 500` × `500 montante 3 contas`).
- **Contas anunciadas:** `contasOferecidas` lê o `📊 Até N contas` da mensagem do
  Operador — quantidade, não valor; não entra em total nenhum, serve ao passo 2
  da validação (é por ela que um pedido de "2 contas" casa por valor).
- **Contas:** **só** o valor rotulado com a palavra **"Valor"** na mesma linha —
  `💸 𝗩𝗮𝗹𝗼𝗿 R$ 6,00`, `Valor: R$ 25`, `Valor final: R$ 28,50`. Um `R$ x` **solto não
  conta**: nas mensagens de montante ele é o preço do montante, não uma conta.
- **Números BR:** `100`, `100,50`, `1.000`, `1.500,99`, `R$ 500` → `Number`.
- **Operador:** quem enviou a mensagem no grupo monitorado (`pushName` + número).
- **Só de administrador:** em grupo, a telemetria (montante e contas) só é gravada
  se o remetente for **admin do grupo** (Operador). A mesma frase vinda de uma
  Brogueira é *pedido*, não produção — vai para a aba Brogueiras (`db.pedidos`) e
  **não** entra no relatório financeiro. Se o papel não puder ser confirmado
  (`desconhecido`, falha ao ler os membros), a mensagem **não** é gravada e fica
  um `warn` no log. Em conversa **privada** não existe "admin de grupo": o que
  chega continua sendo gravado se `monitorPrivate` estiver ligado.
- **Relatórios:** agregados por **dia** (fuso `America/Sao_Paulo`, configurável).

## Períodos (vale para todos os relatórios)

Todo relatório fala o mesmo vocabulário — `?period=` na API, botões no painel:

| Valor | O que é |
|-------|---------|
| `hoje` | o dia corrente |
| `semana` | **esta semana**, a partir da segunda-feira |
| `mes` | **este mês**, do dia 1º |
| `ano` | **este ano**, de 1º de janeiro |
| `ontem` | o dia anterior |
| `geral` | tudo o que está guardado |
| `2026-08-27` | um dia exato (ISO) |
| `28/08` · `28/08/2026` | um dia exato, escrito como as pessoas escrevem |

Semana, mês e ano são de **calendário**, não janelas móveis: "no mês" no grupo
quer dizer o mês corrente, não os últimos 30 dias. Um `period` desconhecido cai
em **hoje** — nunca em "tudo", que exageraria todo número do painel. A conversão
está em `intervaloPeriodo()` (`src/store.js`) e a comparação é textual sobre o
campo `day` (`YYYY-MM-DD`), que já é cronológica. Quem traduz o texto ("ontem",
"28/08") é `periodoDoTexto()`, usada tanto pela query string quanto pelos
comandos do WhatsApp — é o mesmo vocabulário nas duas pontas. Sem ano, `28/12`
lido em janeiro é o dezembro passado, não um dia no futuro.

## Ver dias anteriores (modo histórico do painel)

O painel abre **ao vivo, em hoje**. O seletor de dia no topo (`‹ [data] ›`, com
o botão **hoje** ao lado) coloca **Painel, Brogueiras, Operadores e Indicações**
no mesmo dia do passado — um recorte só, para nunca existir a dúvida de qual aba
está mostrando o quê.

Enquanto um dia anterior está na tela:

* um aviso no topo do Painel diz **qual dia** está aberto e **o que aquele dia
  tem** (lançamentos, pedidos, serviços), com o botão *Voltar para hoje*;
* os rótulos dos KPIs deixam de dizer "hoje" e passam a dizer a data;
* **o que chega pelo socket é ignorado nos números.** O servidor continua
  empurrando o dia corrente a cada mensagem nova; se o painel aceitasse, a tela
  voltaria para hoje sozinha no meio de uma conferência. O estado das conexões
  (isso é sempre "agora") continua atualizando;
* a série de 7 dias e as "últimas mensagens" passam a terminar **no dia
  escolhido** — comparar com "ontem" só quer dizer alguma coisa se "ontem" for o
  dia anterior ao que está na tela;
* os botões `Hoje/Semana/Mês/Ano/Geral` das abas ficam apagados: o dia global
  manda. Voltar para hoje devolve o controle a eles.

Os acumulados de "desde sempre" (`stats`) continuam sendo do servidor inteiro —
não são recortados pelo dia.

**Como o painel sabe até onde voltar:** `GET /api/dias` devolve o primeiro dia
gravado, o último e o que cada dia tem (`diasComDados()` em `src/store.js`).
O `<input type=date>` usa isso como `min`/`max` e o aviso usa para contar o
movimento do dia. Um dia sem nada aparece **zerado** — nunca como se fosse hoje.

O bloco de números do snapshot continua se chamando `hoje` mesmo olhando para
ontem: é o contrato que o painel já consumia, e renomeá-lo quebraria a tela de
quem estivesse com a página aberta durante o deploy. O que ele está mostrando
vai em `periodo: { valor, rotulo, de, ate, historico }`.

## Aba **Operadores** — quem pegou quanto

Ranking do período: **quantos serviços cada Operador pegou** e quanto isso deu.

- **Pegos** = pedidos de Brogueira que ele atendeu (passo 2 da validação).
- **Validados** = os que fecharam com comprovante PIX (passo 3).
- **Taxa** = validados ÷ pegos, com selo verde a partir de 70% e âmbar abaixo de 40%.
- **Lançado** = toda mensagem financeira dele, tenha casado com um pedido ou não
  (valor + nº de lançamentos + contas). Quem só lançou **continua no ranking** —
  sumir da lista por não ter pedido casado esconderia trabalho de verdade.

**Contas aparecem em três recortes**, e eles não são o mesmo número:

| Recorte | O que conta | Onde |
|---------|-------------|------|
| **Contas pegas** | contas dos serviços de conta que ele atendeu, tenham fechado ou não | coluna e KPI no modo "Todos" |
| **Contas validadas** | só as dos serviços de conta com comprovante PIX | coluna e KPI no modo "Só validados" |
| **Contas lançadas** | os rótulos "Valor:" de toda mensagem financeira dele | sub-linha da coluna *Lançado* |

A quantidade dos dois primeiros recortes vem do **PEDIDO** ("12 contas de 10" =
12 contas), e o valor, do que o Operador cobrou. Pedido de **montante** não conta
contas: em "400 montante 2 contas" o 2 diz em quantas contas o montante foi
dividido — não é um pedido de 2 contas. (Até 29/08 os dois recortes somavam o nº
de rótulos "Valor:" da resposta, quase sempre 1, e o painel mostrava 1 conta por
serviço no lugar das 12 pedidas.)

A coluna e o KPI trocam de recorte junto com o filtro (o cabeçalho muda de
"Contas pegas" para "Contas validadas"), e o detalhe do Operador mostra os três
lado a lado, com a contagem do dia no dia a dia.

Clicar numa linha abre o dia a dia do Operador e os serviços que ele pegou, com a
hora do pedido, a do atendimento, a do comprovante e **como o casamento foi feito**.
`GET /api/operadores/ranking?period=&sessao=` (`rankingOperadores()` no store).

### O filtro Todos x Só validados

O botão **Contar** decide o que o ranking mede — e são dois rankings diferentes,
não o mesmo com linhas escondidas:

| | Todos os serviços pegos | Só os validados |
|---|---|---|
| Quem entra | todo Operador do período, **inclusive quem só lançou** sem pedido casado | só quem fechou ao menos um serviço com comprovante |
| Ordem | serviços pegos → montante validado → montante lançado | serviços validados → montante validado |
| Posição (`#`) | do ranking inteiro | **recalculada** — é outro ranking |
| Detalhe do Operador | todos os serviços dele | só os que fecharam |

A seta `▾` no cabeçalho marca a coluna que está mandando na ordem, e a linha ao
lado dos botões diz em palavras o que está sendo contado (`6 de 9 serviços
fecharam com comprovante`). A troca **não vai ao servidor**: pegos e validados já
vêm juntos na mesma resposta.

A **busca por nome ou número** vale nos dois modos e, ao contrário do filtro, ela
**não mexe na posição** de quem sobrou — procurar alguém não pode promovê-lo a 1º.

### Filtro por um dia específico (pedido do usuário, 30/08)

Ao lado dos botões de período há um **seletor de dia**: `‹` dia anterior,
calendário, `›` dia seguinte. Escolher um dia manda `period=AAAA-MM-DD` — o
servidor já entendia esse formato (`periodoDaReq`), faltava o controle no painel.

- Os dois controles são **exclusivos**: com um dia escolhido nenhum botão de
  período fica aceso e a moldura do seletor acende; clicar num botão limpa o dia.
- A seta de avançar **trava em hoje** (não existe ranking de amanhã) e limpar o
  campo devolve o recorte para *hoje* — sem período a aba ficaria sem dado.
- As datas andam com `somarDias()`, que monta o `Date` com ano/mês/dia locais:
  `new Date('2026-08-30')` seria lido como UTC e voltaria um dia para quem está
  a oeste de Greenwich.
- No detalhe do Operador, **cada dia do dia a dia é um botão** que filtra a aba
  inteira por aquele dia — o caminho curto entre "esse dia foi estranho" e "quem
  mais trabalhou nele".

### Leitura visual do ranking

Os números continuam escritos; o desenho é reforço, nunca substituto:

| Onde | O quê |
|------|-------|
| KPI **Validados** | medidor (`.meter`) com a taxa do período |
| KPI **Montante validado** | sparkline do montante validado dia a dia (soma dos `dias[]` de todos os Operadores). **Some** quando o recorte é de um dia só — linha reta não informa nada |
| Tabela, coluna *Montante validado* | barra com a **fatia do líder** do período |
| Tabela, coluna `#` | disco nos **3 primeiros**; o resto fica só no número (medalha colorida traria uma hue nova e brigaria com as séries) |
| Tabela | cabeçalho **grudado no topo** enquanto a lista rola |
| Pódio | barra proporcional ao 1º colocado |
| Detalhe | dia a dia em linhas com barra, ordenadas do mais recente |

## Aba **Relatórios** — o livro-caixa dos operadores (admin)

Fica **logo abaixo do Painel** no menu. É a única tela do bot que fala de
dinheiro da operação (depósito, saque, comissão) em vez de mensagem do
WhatsApp, e é **adminOnly nas duas pontas**: `aplicarRole()` esconde a aba do
viewer e todas as rotas `/api/relatorios*` e `/api/operations*` exigem admin.

> **De onde vêm os números.** Esta aba tem o seu próprio livro-caixa em
> `data/db.json` (coleções `operations`, `usuarios`, `appSettings`,
> `commissionResets`, `operationAudit`) — ele **não** deriva dos lançamentos
> lidos nos grupos: depósito, saque e comissão não existem nas mensagens. As
> operações entram **pela API** (`POST /api/operations`), que é o caminho para
> outro sistema despejar aqui; na tela só dá para editar ou apagar o que já
> existe. O card principal da aba — a **comissão dos Operadores** — não depende
> disso: ele lê os serviços validados que o próprio bot registrou.

### As regras que a tela obedece

| Regra | Como é |
|---|---|
| **Dia operacional** | começa às **05:00** — antes disso, conta como o dia anterior |
| **Semana** | começa na **segunda**, com o mesmo corte das 5h |
| **Lucro líquido** | `lucro + (saque_contas − deposito_contas + salario_contas)` |
| **Lucro bruto** | `(saque − deposito) + (saque_contas − deposito_contas)` |
| **Depósito / Saque / Blogueira** | sempre o total: o valor "normal" + o de contas |
| **Comissão** | **admin e owner ficam de fora** — aparecem no resto do relatório, mas ninguém paga comissão para a chefia |

O corte das 5h não é configurável de propósito: mudá-lo reescreveria o passado,
jogando as mesmas operações em outros dias.

### O que tem na tela, de cima para baixo

1. **Cabeçalho** — **Exportar CSV** (agregados por usuário, com BOM UTF-8 e
   aspas escapadas: `relatorio-usuarios-AAAA-MM-DD.csv`). O lucro da tela é
   sempre o **líquido**; o alternador Líquido/Bruto foi removido a pedido do
   dono (a API ainda aceita `?modo=bruto`, mas a tela não usa).
2. **Metas — montante validado**: meta diária e semanal em R$ (as chaves no
   banco continuam `metaDiariaBlogueira`/`metaSemanalBlogueira`, para não
   migrar dado por causa de um rótulo).
3. **Filtros**: De, Até e usuário. Tudo abaixo respeita o recorte; **Limpar**
   aparece só quando há filtro.
4. **Totais** — os quatro quadros olham a **semana da casa**, que vira
   **sábado às 05:00** (o ciclo do negócio acaba quando o turno da noite acaba,
   não à meia-noite):
   - **Montantes validados**: quantos serviços fecharam os 3 passos na semana.
   - **Salário pago na semana**: o que as Brogueiras pagaram aos Operadores —
     a soma do `💸 Valor` das mensagens deles nos serviços validados.
   - **Montante validado hoje** e **na semana**.
   Esses dois vêm dos **serviços do bot**, não do livro-caixa: somam o
   `🔸 Montante` que o Operador pegou **e** que fechou os 3 passos. Montante
   sem comprovante fica de fora: o quadro responde *quanto foi confirmado*, não
   *quanto foi prometido*. **Operador isento não entra** — assim o número do
   topo fecha com a tabela de comissão logo abaixo, que já não mostra os
   isentos (decisão do dono, 30/08). Quando há meta definida, a barra mostra o
   percentual; sem meta, o rodapé conta quantos serviços entraram — mais útil
   que um "0%". Os dois **ignoram o filtro de data de propósito**: são o dia e a
   semana correntes, senão a barra mentiria toda vez que alguém olhasse o mês
   passado.
5. **Comissão a pagar**: atalhos Hoje / 7 dias / Mês (que mexem nos mesmos
   filtros de cima, para não existirem dois recortes disputando a tela), os
   três tiles e a tabela por usuário com **Zerar** individual e **Zerar todas**.

Na tabela dos Operadores, cada linha tem **três ações, e elas fazem coisas
diferentes de propósito**:

| Botão | O que faz |
|---|---|
| **Cobrar** | O bot manda a cobrança **no WhatsApp do Operador**. Abre a mensagem já preenchida (modelo em *Configurações › Cobrança de comissão*), com o valor, o salário, a porcentagem e o período — dá para ajustar o texto só para aquele envio. **Não mexe no dinheiro**, e continua disponível **mesmo com a comissão zerada no painel**. |
| **Isentar** | Tira a pessoa da cobrança e do quadro. |
| **Zerar comissão** *(destacado)* | **Dá baixa**: registra a cobrança com a lista de serviços e zera o que estava em aberto. É o que dá para desfazer no histórico. |

**Cobrar vale mesmo depois de zerar.** O valor da mensagem é a comissão **do
período**: o que está em aberto **mais** o que já foi apurado no *Zerar
comissão*. Dar baixa não é receber — a pessoa continua devendo, e é justamente
aí que se cobra. Antes de qualquer baixa os dois números são o mesmo, então o
caso comum não muda; depois dela, a prévia mostra a composição ("R$ 123,80 já
apurado — a cobrança continua valendo até ele pagar"). Recorte sem movimento
nenhum também não é erro: a mensagem sai zerada e o texto é editável. A **única**
recusa é o Operador isento.

A prévia e o envio usam **o mesmo recorte que está na tela** (a semana ou o dia
aberto no card de comissão) — se falassem de janelas diferentes, a linha diria
um valor e a mensagem outro, o pior erro possível numa cobrança.

Mandar mensagem e dar baixa são dois botões porque são dois fatos: um fala com
a pessoa, o outro mexe na conta. Quem manda a mensagem é o número conectado com
**Envio manual** ligado; se o WhatsApp não expôs o telefone do Operador (só o
`@lid`), a tela avisa em vez de tentar mandar.
6. **Backups de comissões zeradas**: quem zerou, quanto, status ATIVO/DESFEITO
   e o botão **Desfazer**.

O **histórico de cobranças** (card "Cobranças de comissão") nasce **fechado** —
é consulta, não operação do dia. Abre pelo botão **Ver histórico de comissões**,
no cabeçalho do card de comissão, que já mostra entre parênteses quantas
cobranças existem; o botão vira *Ocultar histórico*, e o card tem o seu próprio
*Ocultar*. A escolha não é lembrada de propósito: a tela sempre abre limpa.
7. **Por usuário**: linha expansível — abrindo, o histórico de operações do
   período, com editar e apagar. **Criar** operação e **cadastrar usuário** não
   existem mais na tela (saíram a pedido do dono): entram pela API
   (`POST /api/operations`, `POST /api/relatorios/usuarios`), que continua de pé.
8. **Log de alterações**: os últimos 200 EDITADA/APAGADA, guardando o valor
   **de antes** da mudança.

### Comissão cobrada dos Operadores (o card principal)

A casa cobra do Operador uma **porcentagem do salário que ele recebe das
Brogueiras** — o `💸 Valor` da mensagem que ele manda para elas:

```
━━━━━━━━━━━━━━━
🔸 Montante: 500
💸 Valor: R$ 100,00
📊 Até 1 conta
━━━━━━━━━━━━━━━
⚡ Envio após confirmação do pagamento
📩 Envie o comprovante para dar continuidade
```

Nessa mensagem, **o montante é o dinheiro do jogo** (que só passa pelo
Operador) e **o `Valor` é o que fica com ele**. A porcentagem incide sobre o
`Valor`: 15% de R$ 100 = **R$ 15**. O parser já separava os dois desde a
correção de 02/08 (`extractMontante` × `extractContas`), e o serviço guarda o
`Valor` em `atendimento.contasTotal` — a comissão só soma esse campo.

**Só serviço validado é cobrado.** Enquanto a Brogueira não manda o comprovante
(passo 3), o Operador não recebeu: cobrar de um serviço que ainda pode expirar
seria cobrar do que não existe. Pedido sem atendimento, atendimento sem
comprovante e expirados ficam de fora.

Na tela (`Relatórios` → *Comissão dos Operadores*):

* **% por Operador**, editável na própria linha, e um **padrão da casa** para
  quem não tem regra própria (a linha mostra o selo `padrão`). Ninguém nasce
  sendo cobrado: o padrão começa em 0%.
* **Salário validado (em aberto)**, **comissão a cobrar** e **já cobrado no
  período**.
* **Cobrar** por Operador ou **Cobrar todas** — respeitando o filtro de datas.

> **Duas semanas, de propósito.** Os quadros do topo usam a semana da casa
> (sábado 05h → sábado 05h), medida no **relógio**: um serviço validado às 03h
> de sábado ainda pertence à semana que está fechando, mesmo o campo `day` já
> sendo sábado (`semanaDaCasa()` / `resumoSemanaDaCasa()` em `comissoes.js`). Já
> o card de comissão logo abaixo navega por **semana de calendário**
> (segunda a domingo), porque as cobranças foram registradas assim — cada um diz
> na tela qual janela está mostrando. Alinhar os dois é uma troca de função.

#### O fechamento é semanal, com o dia a dia aberto

A comissão soma **tudo o que o Operador pegou na semana** (segunda a domingo —
o mesmo corte de calendário do resto do painel). As setas `‹ ›` do card andam de
semana em semana (nunca para uma semana que não começou; clicar no rótulo volta
para a semana corrente), e abaixo delas a faixa dos **7 dias** mostra quanto foi
pego em cada um. Clicar num dia recorta o quadro para aquele dia — inclusive a
cobrança, que passa a valer só para ele; clicar de novo volta para a semana.

Esse card **não segue** os filtros de data do topo da aba, de propósito: o
acerto com o Operador é semanal, e dois recortes disputando a mesma tela é
exatamente o tipo de ambiguidade que faz alguém cobrar o período errado.

Duas medidas convivem e não podem ser confundidas: **salário da semana** é tudo
o que foi pego (cobrado ou não — é o que a soma dos dias fecha), enquanto
**comissão a cobrar** é só o que ainda está em aberto. A coluna *já cobrado* usa
a **porcentagem gravada na cobrança**, não a de hoje: mudar a % de alguém não
pode reescrever o valor de uma cobrança fechada semanas atrás.

#### Nome na tela e Operadores isentos

O WhatsApp entrega o nome que a própria pessoa escolheu (`🥷🏻`, `.`, `Jota$`) —
ilegível num relatório. O botão ✎ ao lado do nome grava um **apelido**, que vale
**só na exibição**: o histórico continua com o `pushName` original (mostrado
embaixo, para conferência), e apagar o apelido devolve o nome de origem.

**Isento** (botão na linha, ou a chave na tela *Operadores*) tira a pessoa da
cobrança: ela deixa de ser cobrada, some do quadro e não entra em nenhum total —
nem por "Cobrar todas", nem cobrando-a diretamente. As cobranças já feitas
continuam no histórico, e ela continua aparecendo na tela *Operadores*, que é
por onde se desfaz a isenção.

A tela **Operadores** (botão no cabeçalho do card) lista todos os conhecidos —
inclusive os isentos — com apelido, porcentagem e isenção num lugar só.

**A cobrança guarda a lista de serviços** (`servicoIds`) e a porcentagem do dia.
É isso que garante as três coisas: a mesma validação não é cobrada duas vezes,
mudar a % depois não reescreve o passado, e **Desfazer** devolve exatamente
aquele conjunto para "em aberto".

> O card **"Comissão lançada nas operações"**, logo abaixo, é outra coisa: são
> os campos `comissao`/`comissao_contas` digitados no livro-caixa manual. Os
> dois convivem — um vem do que o bot viu no grupo, o outro do que foi lançado
> à mão.

### Zerar comissão: a ordem importa

O `POST /api/relatorios/comissoes/zerar` **grava o backup primeiro** (snapshot
com o valor exato de cada operação + quem mandou zerar) e só então zera, em
lotes de 200. Se o processo morrer no meio, sobra um backup a mais — inofensivo
— em vez de dinheiro apagado sem rastro. "Zerar todas" cria **um backup por
usuário**, para o Desfazer conseguir devolver a comissão de uma pessoa só.

**Desfazer** devolve a cada operação o valor exato do snapshot. Operação que foi
apagada depois do reset não é ressuscitada: ela é contada à parte e reportada
("3 restauradas · 1 não existe mais").

### API

`GET /api/relatorios?de&ate&user&modo` (desenha a aba inteira) ·
`GET /api/relatorios/export.csv` · `POST /api/relatorios/metas` ·
`GET|POST /api/relatorios/usuarios` · `PATCH|DELETE /api/relatorios/usuarios/:id` ·
`GET|POST /api/operations` · `PATCH|DELETE /api/operations/:id` ·
`POST /api/relatorios/comissoes/zerar` · `GET /api/relatorios/backups` ·
`POST /api/relatorios/backups/:id/desfazer` · `GET /api/relatorios/auditoria`.

**Comissão dos Operadores:** `GET /api/relatorios/operadores?semana=|dia=|de&ate`
(em aberto, já cobrado, a semana e a lista de conhecidos) ·
`GET /api/relatorios/semana?ref=` (os 7 dias) ·
`POST /api/relatorios/operadores/apelido` (`{operadorId, apelido}`; vazio limpa) ·
`POST /api/relatorios/operadores/isento` (`{operadorId, isento}`) ·
`POST /api/relatorios/operadores/pct`
(`{operadorId, pct}` — sem `operadorId` grava o padrão da casa) ·
`DELETE /api/relatorios/operadores/:id/pct` (volta ao padrão) ·
`POST /api/relatorios/operadores/cobrar` (`{operadorId?, dia|semana|de&ate}` — dá baixa) ·
`GET /api/relatorios/operadores/:id/cobranca` (prévia: destino, valores e texto) ·
`POST /api/relatorios/operadores/:id/cobrar-whatsapp` (manda a mensagem) ·
`POST /api/relatorios/cobrancas/:id/desfazer`.

Mexer numa operação emite o evento `operacoes` **só para a sala admin** do
Socket.IO — quem não pode ver os números também não precisa saber que mudaram;
o painel aberto recarrega a aba sozinho (é o "invalidate" do Realtime).

Regras em `src/operacoes.js` (livro-caixa) e `src/comissoes.js` (comissão dos
Operadores), tela em `public/relatorios.js`; testes em `src/operacoes.test.js`
(13), `src/comissoes.test.js` (17) e `src/relatorios-ui.test.js` (25).

## Brogueiras x Operadores (aba **Brogueiras**)

Os membros de um grupo são lidos direto do WhatsApp e caem em duas categorias:

| Categoria     | Quem é                                    |
|---------------|-------------------------------------------|
| **Operador**  | administrador do grupo (`admin`/`superadmin`) |
| **Brogueira** | membro comum                              |

A lista vem do `groupMetadata` e fica em cache por 10 min (`src/membros.js`) —
sem isso cada mensagem viraria uma consulta de rede. O cache é invalidado quando
alguém entra, sai ou muda de cargo. Se a consulta falhar, o papel fica
`desconhecido` em vez de chutar "Brogueira" e sujar o relatório.

### Buscar uma Brogueira

O campo acima da tabela filtra **por nome ou por número**, sem ir ao servidor (o
relatório do período já veio inteiro, então responde na tecla):

- nome casa **sem acento e sem maiúscula** — "claudia" acha "Cláudia";
- número casa por pedaço e **em qualquer formatação** — `91234`,
  `(11) 91234-5678` e `5511912345678` acham a mesma pessoa, porque só os dígitos
  são comparados, contra o telefone **e** contra o identificador interno;
- o contador ao lado mostra `3 de 47`, para não parecer que o resto sumiu.

A tabela passou a mostrar o telefone embaixo do nome (quando o WhatsApp o
entrega — em grupo o remetente costuma vir como `@lid`, e aí não há número a
mostrar). O mesmo campo existe na aba **Operadores**.

### O filtro de pedidos (`src/pedidos.js`)

Um **pedido** é um link mais uma linha curta dizendo o que ela quer:

```
https://670win.me/?id=357497224     https://www.okokathena.win/?id=393339299
7 contas variadas                   520 em 4
→ CONTA, qtd 7                      → MONTANTE, R$ 520 em 4 contas
```

O que separa os dois é **estrutural**, não o tamanho do número:

- `7 contas variadas` → o 7 é a **quantidade**: nada vem antes dele.
- `200 2 contas` → o 200 vem **antes** da quantidade; número antes da quantidade
  só pode ser valor → montante de R$ 200 em 2 contas.
- Sem a palavra "contas": `520 em 4`, `200/2` → valor e divisão. `Quero 400` → só valor.

Detalhes que o filtro trata:

- **Os links saem do texto antes de olhar os números** — `?id=357497224` tem 9
  dígitos e viraria um montante absurdo.
- **Fonte estilizada** (`𝟳 𝗰𝗼𝗻𝘁𝗮𝘀`) é normalizada com NFKC, como no parser financeiro.
- `1mil` / `2 mil` viram 1000 / 2000.
- Havendo dois números antes da quantidade (`1 montante 500 / 5 contas`), o
  montante é o **maior** — o outro é contagem.
- **Textão com link é divulgação, não pedido** (máx. 10 palavras). Sem esse
  limite, o "10" de `*PAGO 10 NA DE 50*` virava um montante de R$ 10.
- Link sem pedido legível é gravado como **indefinido** — visível no painel,
  nunca descartado em silêncio.

### O relatório

`GET /api/brogueiras?period=today|geral` (`&operadores=1` inclui os admins).
Por Brogueira: total de pedidos, **soma dos montantes**, **soma das contas**,
lista de links e os pedidos **agrupados por dia**. `montanteTotal` soma só
pedidos de montante e `contasTotal` só pedidos de conta — em `200 2 contas` o 2
diz em quantas contas dividir, não é um pedido de 2 contas.

Os pedidos ficam em `data/db.json` → `pedidos` (últimos 5000), separados do
histórico financeiro (`messages`), que é outra coisa: quem **pede** o link x quem
**atende** com o comprovante.

### Links repetidos (`src/repetidos.js`)

O mesmo link pedido mais de uma vez aparece no card **Links repetidos** da aba,
no KPI e como selo na linha do pedido. Dois casos, marcados com cor **e** com
palavra (a cor nunca carrega o sentido sozinha):

| Selo    | O que aconteceu                                                     |
|---------|---------------------------------------------------------------------|
| `mesma` | ela reenviou o **próprio** link (insistência/cobrança)               |
| `outra` | o link de uma Brogueira reapareceu na mão de **outra** — duas pessoas pedindo pela mesma conta |

- **Comparação por chave normalizada**: `https://`, `www.`, barra final,
  fragmento e maiúsculas não separam o que é o mesmo link. O `?id=` **faz** parte
  da chave — é ele que identifica a conta.
- **Convite de grupo do WhatsApp e link de Telegram ficam de fora**
  (`DOMINIOS_IGNORADOS`): é divulgação, e no histórico real era o link mais
  repetido do grupo (17× por 8 pessoas), escondendo os repetidos de verdade.
- **Pedido de Operador não entra na comparação** — ele reposta link de divulgação
  o tempo todo, e o relatório das Brogueiras já o deixa de fora.
- **Janela configurável** (Configurações → Monitoramento): quantas horas para trás
  um link ainda conta como "já mandado" (`repetidosJanelaHoras`).
  **0 = todo o histórico guardado** (padrão).
- **O período filtra o que aparece, não o que é comparado**: um link mandado
  ontem e repetido hoje aparece em "Hoje", com o envio de ontem esmaecido como
  contexto da repetição.
- **Vale para o histórico antigo**: o relatório é recalculado na leitura, então os
  pedidos gravados antes desta funcionalidade entram também (nos 866 pedidos do
  histórico real: 159 links repetidos, 42 deles de uma Brogueira para outra).
- **Ao vivo**: o registro do pedido já nasce com `repetido`/`repeticoes`, o
  servidor emite o evento Socket.IO `repetido` e o painel mostra um aviso
  flutuante em qualquer aba (só para `admin`) — clicar nele abre a aba
  Brogueiras. Fica também um `warn` no log.

### Alerta automático (`src/alertas.js`)

Passando do limite, o bot manda um aviso **em outro grupo** (o de operação),
marcando todo mundo. Tudo configurável em **Configurações → Alerta de link
repetido**:

| Campo | O que faz |
|---|---|
| `alertaRepetidosEnabled` | liga/desliga |
| `alertaRepetidosGrupo` | grupo que **recebe** o aviso (lista vem do WhatsApp) |
| `alertaRepetidosMensagem` | o texto (padrão `Alerta, link repetido`) |
| `alertaRepetidosPorLink` | avisa quando o **mesmo link** chegar a N envios (padrão 3) |
| `alertaRepetidosPorDia` | avisa quando o **dia** juntar N reenvios, de links quaisquer (padrão 0) |
| `alertaRepetidosMarcarTodos` | marca todos os participantes (padrão sim) |

Os dois limites são independentes: **0 desliga** cada um. Se os dois baterem na
mesma mensagem, sai **um** aviso só, com as duas informações.

```
Alerta, link repetido

🔁 *Bia* mandou pela 3ª vez:
https://okok.com/?id=5
1ª vez foi de *Ana* em 11/08 12:00
Grupo: DB Contas e Montantes

📊 10 reenvios de link hoje.
```

- **Cada link avisa uma vez; cada dia avisa uma vez.** O aviso marca o grupo
  inteiro — repetir isso a cada mensagem nova do mesmo caso seria o spam que se
  está tentando denunciar. O que já foi avisado fica em `db.alertas`
  (`links`/`dias`, podado em 2000/90 chaves — é índice de deduplicação, não
  histórico).
- **Só marca depois do envio dar certo**: falha de rede não consome o alerta, a
  próxima repetição tenta de novo.
- **Marcar todos** é o mesmo mecanismo do agendamento `@todos` (participantes em
  `mentions`, sem encher a mensagem de `@número`). Falhar ao listar os membros
  **não** cancela o aviso — ele vai sem as marcações.
- **Pedido de Operador nunca dispara** (é o mesmo recorte da aba Brogueiras).
- **`POST /api/alertas/testar`** manda um exemplo agora, com a configuração
  salva, sem marcar nada como avisado — é o botão *Enviar alerta de teste* do
  painel.

## Serviços validados — a validação em 3 passos (`src/servicos.js`)

O Painel tem **dois quadros lado a lado**, e eles respondem perguntas
diferentes:

| Quadro | O que responde |
|--------|----------------|
| **A semana em ondas** (esquerda) | *Como foi a semana?* — o montante **validado** dia a dia, em área suave, com o lançado como véu translúcido atrás. |
| **Desempenho dos Operadores** (direita) | *Quem fez hoje?* — só o **serviço validado**, pessoa a pessoa. |

O desenho da onda gasta a ousadia em um lugar só — o traço, grosso, com brilho
e enchimento em três paradas — e recua em todo o resto: **três** linhas de grade
em vez de cinco, **um** ponto (o de hoje, com fio vertical até a base) em vez de
sete, valor escrito **só no pico e em hoje** (mais que isso vira tabela mal
desenhada, e a tabela de verdade está logo abaixo), e o montante lançado como
área translúcida sem traço — água atrás da água. A linha se desenha **uma vez**,
ao entrar: o snapshot chega a cada mensagem, e reanimar a cada chegada seria um
piscar sem fim.

> O quadro antigo, **"Desempenho por operador"** (toda mensagem financeira,
> validada ou não), **foi removido em 30/08 a pedido do dono**: media a mesma
> coisa que o de validados, com um número menos confiável — dois gráficos
> disputando a mesma pergunta. A onda ocupou o lugar dele.

Um serviço validado é isto, na ordem:

```
1. a Brogueira pede no grupo          →  link + "400 montante 2 contas"   (db.pedidos)
2. o Operador responde a ela          →  "Montante: R$ 400 · Valor R$ 8"  (db.messages)
3. ela manda o comprovante PIX        →  imagem ou PDF                    (só valida, não vira registro)
```

O passo 2 é **a mesma mensagem que sempre alimentou montante e contas** — nada
mudou na extração. O que é novo é a amarração entre as três.

### Como o passo 2 é reconhecido (cascata, configurável)

Da prova mais forte para a mais fraca — e o painel **mostra qual foi**, para dar
para desconfiar das fracas:

1. **citação** — o Operador usou "responder" na mensagem dela (`contextInfo.stanzaId`
   é o `msg.key.id` do pedido). Prova direta.
2. **valor** — o montante da mensagem dele bate com o pedido, ou a quantidade de
   contas bate num pedido de contas. A quantidade da resposta é o **"📊 Até N
   contas"** que ele anuncia (está em 89% das mensagens de Operador; é o único
   lugar onde a mensagem dele fala em quantidade — o "Valor: R$ x" é preço), e
   na falta dela, o nº de rótulos "Valor:".
3. **tempo** — o pedido em aberto mais recente do grupo dentro do prazo,
   **preferindo os do mesmo tipo da mensagem**: oferta com montante fecha pedido
   de montante, oferta só com "Valor" fecha pedido de conta. Sem nenhum do tipo,
   vale o mais recente de qualquer tipo. Sem esse desempate, a oferta de montante
   levava o pedido de conta que por acaso era o mais recente, e o pedido de conta
   expirava "ninguém atendeu" mesmo com o Operador tendo respondido.

`servicosModoCasamento` corta a cascata: `citacao` (só o passo 1), `valor` (1 e 2)
ou `cascata` (padrão, os três).

**Verificado em produção (27/08/2026, primeiras horas ligado):** 12 serviços
abertos, **7 validados de ponta a ponta** — comprovante em imagem e em PDF,
chegando de 1 a 10 min depois da resposta do Operador. **9 dos 11 atendimentos
casaram por citação** (os Operadores usam mesmo o "responder"), 2 por proximidade,
nenhum precisou do casamento por valor.

**Contas: medido no histórico real (29/08/2026)** — 2 435 lançamentos × 2 490
pedidos, regra nova × regra antiga, sem citação (o histórico não a guardou):
pedidos de conta atendidos vão de 397 para 402 de 479, e o que muda de verdade é
a **qualidade da prova** — os casados **por valor** saltam de 13 para 156, e os
por proximidade caem de 384 para 246. Montante fica igual (95% atendidos).

**Medido no histórico real** (2 221 lançamentos × 2 251 pedidos, janela de 60 min):
**2 057 casariam (93%)** — 1 396 pelo valor, 661 por proximidade; 164 mensagens de
Operador não tinham pedido nenhum em aberto. A citação não entrou na conta porque
o histórico não guardou as citações — daqui para frente ela vem primeiro e deve
comer parte dos 661.

### O passo 3

Vale **qualquer imagem ou PDF** que a autora do pedido mandar no grupo dentro do
prazo. O bot não lê o conteúdo do arquivo (não há OCR aqui) e **não exige legenda**:
comprovante quase sempre vem sem uma, e exigir "pix" no texto derrubaria a maioria.
Figurinha, áudio e vídeo não contam. Se ela citar o atendimento, é aquele que fecha;
senão, o atendimento mais recente dela naquele grupo.

Comprovante de **outra** pessoa não valida o serviço alheio.

### Prazos e status

`servicosJanelaAtendimentoMin` (padrão **60**) e `servicosJanelaComprovanteMin`
(padrão **120**), em Configurações. Estourou o prazo, o serviço não valida — casar
o comprovante de agora com o pedido de horas atrás seria pior do que não casar.

```
aguardando_atendimento → aguardando_comprovante → validado
          ↓                         ↓
 expirado_sem_atendimento   expirado_sem_comprovante
```

O funil do painel mostra exatamente esses cinco desfechos, e a tabela
**Serviços — os 3 passos** lista as três mensagens com hora, valor e o tipo de
casamento (é a prova do gráfico, e a leitura alternativa para quem não distingue
os dois tons da barra).

### Detalhes que custaram

- **Mensagem sem texto**: o handler saía cedo em `if (!text) return` — um
  comprovante sem legenda nunca chegaria ao processamento. Agora a saída só vale
  quando não há **nem texto nem arquivo**; em compensação a auto-resposta ganhou
  um `if (text)` para não passar a responder imagem solta.
- **Embrulhos do Baileys**: PDF com legenda chega como `documentWithCaptionMessage`,
  e mensagem temporária como `ephemeralMessage` — `conteudo()` descasca até 5
  camadas antes de olhar o tipo.
- **Dedupe**: o comprovante é conferido pelo `msg.key.id` (`comprovanteJaRegistrado`),
  como o resto — dois números no mesmo grupo não validam o mesmo serviço duas vezes.
- **Cor**: as duas partes da barra (validado x sem comprovante) são a **mesma
  medida** partida pelo desfecho, então é **uma hue em dois tons + hachura**, não
  duas cores categóricas — que ainda brigariam com o azul/laranja do quadro ao lado.
- **Duas pilhas por Operador** (pedido do usuário, 29/08): montante validado e
  **contas validadas**, as duas em **R$ e no MESMO eixo**. A série de contas é a
  MESMA "Contas (R$)" do quadro azul ao lado (`atendimento.contasTotal`, o valor
  rotulado "Valor:" — de todo serviço atendido, não só os de conta), aqui
  recortada pelo ciclo dos 3 passos: o quadro azul mostra tudo o que ele lançou,
  o verde só o que fechou. Uma escala só — duas fariam a coluna menor parecer do
  tamanho da maior. Cada pilha tem a sua hachura para o trecho sem comprovante
  (`#hachura` e `#hachura-contas`), e a laranja é a mesma cor que já significa
  "contas" no quadro azul. **Grupo que só faz montante não ganha a 2ª coluna**:
  o quadro fica exatamente como era. Cuidado: essa série é em R$; a *quantidade*
  de contas da aba Operadores é outro recorte (as contas PEDIDAS).

## Exportação para o DB Dashboard (site Lovable)

O bot **empurra** ranking e serviços para https://dbdashboard-o.lovable.app
(Supabase por trás). Os arquivos do lado que recebe — schema, edge function e o
passo a passo — estão em **`integracao-db/`**.

O sentido do fluxo não é arbitrário: o painel do bot está atrás de um
certificado **autoassinado num IP puro**, e uma edge function do Supabase
recusaria essa conexão. Empurrando, nada precisa ser aberto para a internet.

| | |
|---|---|
| Quando | em lote, a cada `exportIntervaloMin` (padrão **5 min**) |
| O que | serviços cujo **estado mudou** + ranking dos dias tocados (sempre hoje) |
| Como | `POST` JSON com `x-db-secret`; **HTTPS obrigatório** (o validador recusa http) |
| Idempotência | serviço vai pelo `id`; operador por `(dia, operador_id)` — o outro lado faz upsert |
| Falha | nada é marcado como enviado; espera **1, 2, 4, 8, 16, 30 min** e tenta de novo |

`src/exportador.js` guarda em cada serviço a **versão exportada**
(`status | msgId do atendimento | casamento | msgId do comprovante`): é ela que
faz o ciclo mandar só o que andou, em vez dos 240 serviços do dia a cada 5 min.
Os dias já enviados guardam uma **assinatura** do ranking (`db.export.dias`,
podada em 90 dias) pelo mesmo motivo.

Config (global, aba Configurações): `exportEnabled`, `exportUrl`,
`exportSegredo`, `exportApiKey` (só se a função exigir JWT) e
`exportIntervaloMin`. **O segredo e a chave não saem do servidor**: nem o
snapshot do Socket.IO nem `GET /api/config` os devolvem — só
`exportSegredoSet: true`. O card mostra último envio, fila, total e último erro,
com os botões **Testar conexão** (lote vazio marcado como `teste`, não grava
nada do lado de lá) e **Sincronizar agora**.

API: `GET /api/export` (status), `POST /api/export/testar`,
`POST /api/export/sincronizar`.

## Indicações (aba **Indicações**)

Rankeia as Brogueiras que trouxeram outras Brogueiras. O bot lê as
apresentações no grupo monitorado; quem manda a mensagem é a **indicada**, quem
está citada é a **indicadora**.

As duas formas são estruturalmente opostas, e é isso que `src/indicacoes.js`
separa — não há um regex só, há uma lista de padrões e cada um sabe de que lado
está a indicadora:

| Indicadora **depois** do gatilho | Indicadora **antes** do verbo |
|----------------------------------|-------------------------------|
| `Vim por @fulana`                | `@fulana me indicou`          |
| `Vim pela indicação da @fulana`  | `foi a @fulana que me trouxe` |
| `Fui indicada pela @fulana`      | `@fulana me chamou pro grupo` |
| `cheguei através da @fulana`     | `@fulana me add aqui`         |
| `entrei por causa da @fulana`    | `@fulana indicou`             |
| `quem me indicou foi a @fulana`  |                               |

Detalhes do comportamento:

- **A menção real vem do `contextInfo`**, não do texto: o `@5511999999999`
  escrito é só a grafia, e o JID de verdade chega em `mentionedJid`. Número sem
  código do país (ou com o nono dígito a mais) casa comparando pelo fim.
- **Sem `@` também conta**, mas só quando o nome parece nome próprio: começa com
  maiúscula (`Vim pela Ana`) **ou** já é alguém conhecido do grupo. Sem esses
  dois sinais, `vim pela ana` é indistinguível de `vim pelo grupo` — a mensagem
  é ignorada em vez de inventar uma indicadora. Essas entradas ficam marcadas
  com **?** no painel.
- **Fonte estilizada e caixa alta** passam pelo mesmo NFKC do parser financeiro
  (`𝗩𝗶𝗺 𝗽𝗼𝗿` é reconhecido).
- **Verbos só no passado** (`me chamou`, não `pode me chamar`) e conversa comum
  não vira indicação: `me passou o link @fulana`, `vim pelo grupo` e
  `minha amiga me indicou` (sem dizer quem) são ignorados.
- **Cada indicada conta uma vez.** Se ela se apresentar de novo, a repetição
  fica gravada com `duplicada: true` — aparece no histórico, fora do ranking.
- **Ninguém indica a si mesma**: citar o próprio número não registra nada.
- Havendo duas leituras possíveis na mesma mensagem, vale a que aparece
  **primeiro** — é o que a pessoa disse antes.

### Quem é quem (memória de nomes)

O WhatsApp só entrega o nome de **quem está falando** (`pushName`). A indicadora
citada quase sempre ainda não falou, então o par nome ↔ número é aprendido a
cada mensagem e guardado em `data/db.json` → `pessoas`.

O nome é resolvido **na hora do relatório**, não no registro: uma indicadora
gravada como `@5511999999999` passa a aparecer como "Ana" assim que a Ana
escreve qualquer coisa no grupo — inclusive nas indicações antigas. Enquanto
isso não acontece, ela é contada normalmente e marcada como *sem nome*.

### O relatório

`GET /api/indicacoes?period=today|geral` devolve:

| Campo | O que é |
|-------|---------|
| `ranking` | Indicadoras ordenadas por total (empate: quem indicou por último) |
| `ranking[].indicadas` | Quem cada uma trouxe, com data e a frase que registrou |
| `indicadas` | A memória das indicadas do período, da mais recente para a mais antiga |
| `resumo` | Totais, mais `duplicadas`, `semMencao` e `naoIdentificadas` |

No painel, a barra do ranking usa **uma hue só** e comprimento proporcional ao
topo: a cor segue a métrica, então a posição não repinta ninguém. Clicar numa
linha abre quem aquela indicadora trouxe.

Os dados ficam em `data/db.json` → `indicacoes` (últimas 5000) e `pessoas`
(20 000 mais recentes), separados de `messages` e `pedidos`. A limpeza da
**Zona de risco** não toca neles — ela age sobre o histórico financeiro.

## Agendamentos

Aba **Agendamentos** do painel. O horário é escolhido num **relógio de 24 h**
(anel de fora 1–12, anel de dentro 13–00): clique na hora, o mostrador passa
sozinho para os minutos; setas do teclado ajustam de 1 em 1. A frequência
(*Todo dia* / *Dias da semana* / *Intervalo*) vira a expressão cron, mostrada
junto do resumo em português. `Cron manual` continua disponível e, quando
preenchido, substitui o relógio.

O **destino** é escolhido numa lista dos **grupos monitorados** (conforme
`monitorMode`/`monitoredGroups` — aba *Grupos*): é onde a mensagem faz sentido, e
digitar o JID à mão era fácil de errar. A API ainda aceita qualquer destino, mas
recusa um valor sem `@` e sem dígitos, que só falharia na hora do disparo.
Ao salvar, o agendamento aparece **na hora** na lista ao lado (o `emitUpdate()`
do scheduler empurra o snapshot; antes só aparecia no próximo evento do bot).

Cada agendamento pode ser **editado** (✎ na tabela): o mesmo formulário carrega o
agendamento, o relógio assume o horário do cron (`lerCron()` é o caminho inverso do
construtor; o que não couber vai para o campo manual) e o botão vira *Salvar
alterações*. `PUT /api/schedules/:id` só altera os campos enviados.

**Marcar todos do grupo** (`mentionAll`): a cada disparo o bot lê os participantes
do grupo e os coloca em `mentions` — todo mundo é notificado sem que a mensagem
fique cheia de `@número`. A lista é buscada na hora do envio, então entradas e
saídas do grupo são respeitadas. Só vale para destino `@g.us`.

Cada agendamento pode levar uma **imagem** (JPG/PNG/WebP, até 5 MB): ela é enviada
como foto e a mensagem vai na **legenda** — uma mensagem só. O arquivo fica em
`uploads/` e é apagado junto com o agendamento. Falhas de disparo ficam gravadas
em `lastError` e aparecem como ⚠ na tabela.

Testado: `npm test` (141 casos — parser financeiro, filtro de pedidos das
Brogueiras, **links repetidos** (`repetidos.test.js`), **alerta automático**
(`alertas.test.js`), leitura das indicações e o ranking, classificação
Operador/Brogueira, **telemetria só de admin** (`handler.test.js`),
LID/autorização, boas-vindas, limpeza, mídia e o painel via jsdom).

## API REST (resumo)

`GET /api/status` (traz `sessoes[]`) · `GET /api/snapshot` · `GET /api/qr` ·
`GET/POST /api/config` · `GET /api/groups` · `GET /api/report` · `GET /api/operadores` ·
`POST /api/send` · `GET /api/brogueiras` · `GET /api/indicacoes` · `GET /api/servicos` ·
`GET /api/operadores/ranking` ·
`GET /api/groups/:id/membros` · `POST /api/alertas/testar` · `GET /api/dias`
(calendário do histórico: primeiro dia gravado, último e o que cada dia tem) ·

**Números:** `GET /api/sessoes` (estado + catálogo de recursos + conflitos) ·
`PATCH /api/sessoes/:id` (`{nome, ativa, recursos}`) · `GET /api/sessoes/:id/qr` ·
`POST /api/sessoes/:id/reconnect` · `POST /api/sessoes/:id/desvincular`.

> **Parâmetro `sessao`** (`?sessao=n2`, ou no corpo): escolhe o número em
> `/api/config`, `/api/groups`, `/api/groups/:id/membros`, `/api/send`, `/api/qr`,
> `/api/alertas/testar` e `/api/reconnect`. Nos relatórios (`/api/report`,
> `/api/operadores`, `/api/operadores/ranking`, `/api/brogueiras`, `/api/indicacoes`,
> `/api/servicos`, `/api/snapshot`) ele
> **filtra** os dados; `todas` ou ausente = os três somados. Sem o parâmetro, as
> rotas de configuração/envio caem no Número 1 — o comportamento de antes.

> **Parâmetro `period`**: vale em todos os relatórios **e em `/api/snapshot`** —
> é o que faz o painel abrir um dia anterior (`/api/snapshot?period=2026-08-28`).
> A resposta traz `periodo.historico: true` quando não é o dia corrente.

`GET/POST/PUT/PATCH/DELETE /api/schedules` (POST e PUT aceitam JSON ou multipart
com o campo `image`; PUT também aceita `removerImagem=true`; PATCH só liga/desliga)
· `GET /api/schedules/:id/media` · `POST /api/upload` ·
`POST /api/dados/limpar` · `GET /api/dados/backups`.

## Dados

- `data/db.json` — config **global**, `sessoes` (os 3 números: nome, ativo,
  recursos e config de cada um), stats, histórico de lançamentos (últimos 5000),
  pedidos das Brogueiras (últimos 5000), indicações (últimas 5000), **serviços em
  validação de 3 passos** (últimos 5000), o registro
  de pessoas (nome ↔ número), os agendamentos e `alertas` (o que já foi avisado
  em link repetido — deduplicação, não histórico).
- `data/backup-*.json` — cópias criadas antes de cada limpeza (10 mais recentes).
- `auth/n1`, `auth/n2`, `auth/n3` — uma sessão do WhatsApp (Baileys) por número.
  Re-parear um número: botão **Desvincular** na aba Números (ou `stop` →
  `rm -rf auth/n2/*` → `start`). Esvazie o diretório, **não o remova**: `auth/` está
  em `ReadWritePaths=` da unit e, sob `ProtectSystem=strict`, o serviço não sobe se
  o caminho não existir.
- `uploads/` — arquivos enviados pelo painel.

## Relatórios do coletor (Dash externo)

O Dash puxa o dia inteiro por GET, a cada 5 minutos, com
`Authorization: Bearer <RELATORIOS_TOKEN>` (chave própria no `.env`, diferente
do `API_TOKEN`). Sem esse token as rotas ficam desligadas.

| Rota | O que devolve |
| --- | --- |
| `GET /api/relatorios/montante` | pedidos do dia, salário pago pelas Brogueiras, comissão da casa e o montante validado, mais `por_hora` das 24 horas |
| `GET /api/relatorios/contas` | uma linha por pedido de conta, identificada pela Brogueira, com `status` (`aberta`/`zerou`/`sacou`) |
| `GET /api/relatorios/operadores` | um registro por Operador do dia, com `id` (@lid) estável, apelido, %, e o que sobra para ele |

As mesmas três atendem em **`/api/v1/relatorios/...`**, fora do namespace do
painel — é o caminho preferido para integração nova.

Parâmetros: `?data=YYYY-MM-DD` e, por compatibilidade com o Dash, `inicio`/`fim`
em ISO (usados só se `data` faltar). Erros: token ausente/errado →
`401 {"error":"unauthorized"}` nas três rotas; `?data=` ilegível (`abacaxi`,
`2026-13-45`) → `400`, nunca "hoje" em silêncio. Dia sem movimento → 200 zerado.

Quatro decisões que valem lembrar:

- **A fonte são os SERVIÇOS do WhatsApp** (`db.servicos`), não o livro-caixa
  manual (`db.operations`, a aba Relatórios do painel). O livro-caixa nunca foi
  usado — ligar o Dash nele devolvia 200 zerado todo dia.
- **`deposito` e `saque` vão sempre 0.** Não existem nessa fonte; o contrato do
  Dash pede os campos e devolver 0 é honesto. O que a fonte tem e o contrato não
  previa (`montante`, `validados`, `contas`, `operador`, `pct`, `isento`) vai
  como campo EXTRA — o Dash ignora o que não conhece.
- **O corte das 5h vale aqui, o `day` do serviço não.** O campo `day` é o dia de
  calendário (é o que as telas de serviços do painel usam), então um serviço das
  2h da madrugada cai no dia anterior no Dash e no dia seguinte no painel.
- **Operador isento entra no relatório com comissão 0.** Ele operou e o volume é
  dele; só não é cobrado. Por isso `blogueira`/`montante` do Dash são maiores que
  os do painel (que esconde isento), enquanto a `comissao` bate exatamente.

CORS só é preciso com o Dash chamando do navegador (desenvolvimento): defina
`RELATORIOS_CORS_ORIGIN` com a origem exata.

### Transporte

A porta 8080 é **TLS-only** (`TLS_CERT`/`TLS_KEY` no `.env`) — `http://` na 8080
não responde nada. O certificado é autoassinado para o IP
(`CN=179.197.231.192`, SHA-256 `2E:C7:B7:27:…:26:32`, válido até 2036) e o Dash
o fixa por pinning. **Regerar esse certificado quebra o Dash em silêncio** — se
for preciso trocar, avise o outro lado.
