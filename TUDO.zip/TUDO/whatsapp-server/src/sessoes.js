// Modelo das SESSÕES (números de WhatsApp). O bot opera até 3 números ao mesmo
// tempo, cada um com:
//   • sua própria sessão do Baileys (auth/n1, auth/n2, auth/n3);
//   • sua própria configuração completa (grupos, mensagens, limites, autorizados);
//   • seus próprios RECURSOS ligados/desligados — o que aquele número faz.
//
// Este módulo é PURO: recebe o `db` por argumento e não importa db.js. É o que
// permite db.js usá-lo na normalização do arquivo sem import circular.
//
// Regra de ouro contra duplicação: dois números no MESMO grupo com o mesmo
// recurso ligado processariam a mesma mensagem duas vezes. Três defesas:
//   1. números novos nascem SEM nenhum recurso e sem grupos monitorados;
//   2. `conflitos()` aponta as sobreposições para o painel avisar;
//   3. o registro no store deduplica pelo id da mensagem do WhatsApp
//      (store.jaRegistrado) — a rede de segurança que vale mesmo se alguém
//      ignorar o aviso.

export const MAX_SESSOES = 3;
export const IDS_SESSOES = ['n1', 'n2', 'n3'];
export const SESSAO_PADRAO = 'n1';

// Catálogo dos recursos. `chave` é o que fica gravado em sessao.recursos;
// `nome`/`descricao` alimentam o painel (fonte única, sem texto duplicado no HTML).
export const RECURSOS = [
  {
    chave: 'monitorar',
    nome: 'Monitoramento (montante e contas)',
    descricao: 'Registra os lançamentos dos Operadores (admins do grupo) que alimentam o Painel e os relatórios.',
  },
  {
    chave: 'pedidos',
    nome: 'Pedidos das Brogueiras',
    descricao: 'Registra pedidos de link (contas/montante) e detecta links repetidos.',
  },
  {
    chave: 'indicacoes',
    nome: 'Indicações',
    descricao: 'Registra "vim por @fulana" — quem trouxe quem.',
  },
  {
    chave: 'alertas',
    nome: 'Alerta de link repetido',
    descricao: 'Avisa num grupo escolhido quando o mesmo link passa do limite. Depende de "Pedidos".',
  },
  {
    chave: 'comandos',
    nome: 'Comandos (!RELATORIO, !STATUS…)',
    descricao: 'Responde aos comandos administrativos enviados pelo WhatsApp.',
  },
  {
    chave: 'autoResposta',
    nome: 'Resposta automática',
    descricao: 'Responde automaticamente às mensagens recebidas.',
  },
  {
    chave: 'boasVindas',
    nome: 'Boas-vindas',
    descricao: 'Saúda quem entra nos grupos.',
  },
  {
    chave: 'agendamentos',
    nome: 'Agendamentos',
    descricao: 'Permite que agendamentos sejam disparados por este número.',
  },
  {
    chave: 'envios',
    nome: 'Envio manual (painel/API)',
    descricao: 'Permite mandar mensagens por este número pela aba Enviar e pela API.',
  },
];

export const CHAVES_RECURSOS = RECURSOS.map((r) => r.chave);

// Recursos que consomem mensagens de grupo. Usados para detectar sobreposição
// entre dois números que estejam no mesmo grupo.
export const RECURSOS_DE_LEITURA = ['monitorar', 'pedidos', 'indicacoes'];

// Configuração de UM número. Tudo aqui é independente entre os números.
// (O que é global — fuso e janela de análise — fica em db.config; ver db.js.)
export const defaultConfigSessao = {
  // Resposta automática
  autoReplyEnabled: false,
  autoReplyMessage: 'Olá! Recebi sua mensagem.\nEm breve retornaremos.',
  autoReplyGroups: false,

  // Boas-vindas
  welcomeEnabled: false,
  welcomeMessage: 'Olá {mencao}, seja bem-vindo(a) ao {grupo}! 👋',
  welcomeMode: 'all', // 'all' | 'specific'
  welcomeGroups: [],

  // Monitoramento: 'none' | 'all' | 'specific'
  monitorMode: 'all',
  monitoredGroups: [],
  monitorPrivate: true,

  // Comandos
  commandAuthorizedNumbers: [],
  reportAuthorizedNumbers: [],
  commandPassword: '',

  // Alerta de link repetido
  alertaRepetidosEnabled: false,
  alertaRepetidosGrupo: '',
  alertaRepetidosMensagem: 'Alerta, link repetido',
  alertaRepetidosPorLink: 3,
  alertaRepetidosPorDia: 0,
  alertaRepetidosMarcarTodos: true,
};

export const CHAVES_CONFIG_SESSAO = Object.keys(defaultConfigSessao);

const ARRAYS_CONFIG = ['monitoredGroups', 'welcomeGroups', 'commandAuthorizedNumbers', 'reportAuthorizedNumbers'];

function numeroFinito(v, padrao = 0) {
  return Number.isFinite(Number(v)) ? Number(v) : padrao;
}

// Recursos de um número novo: TODOS desligados. Ligar um número sem escolher o
// que ele faz não pode, sozinho, duplicar o trabalho de outro.
export function recursosVazios() {
  return Object.fromEntries(CHAVES_RECURSOS.map((c) => [c, false]));
}

// Recursos do número 1 numa instalação que vem da versão de um número só:
// tudo ligado, que é exatamente o comportamento que ele já tinha.
export function recursosCompletos() {
  return Object.fromEntries(CHAVES_RECURSOS.map((c) => [c, true]));
}

export function normalizarRecursos(bruto, { padrao = recursosVazios() } = {}) {
  const out = { ...padrao };
  if (bruto && typeof bruto === 'object') {
    for (const chave of CHAVES_RECURSOS) {
      if (chave in bruto) out[chave] = Boolean(bruto[chave]);
    }
  }
  return out;
}

export function normalizarConfigSessao(bruta) {
  const out = { ...defaultConfigSessao, ...(bruta && typeof bruta === 'object' ? bruta : {}) };
  // Só as chaves conhecidas: um campo estranho vindo de um db antigo não pode
  // virar config viva (e nem aparecer no painel como se fosse ajustável).
  for (const chave of Object.keys(out)) {
    if (!CHAVES_CONFIG_SESSAO.includes(chave)) delete out[chave];
  }
  for (const chave of ARRAYS_CONFIG) {
    out[chave] = Array.isArray(out[chave]) ? out[chave].map(String).filter(Boolean) : [];
  }
  out.alertaRepetidosPorLink = numeroFinito(out.alertaRepetidosPorLink, 3);
  out.alertaRepetidosPorDia = numeroFinito(out.alertaRepetidosPorDia, 0);
  if (!['none', 'all', 'specific'].includes(out.monitorMode)) out.monitorMode = 'all';
  if (!['all', 'specific'].includes(out.welcomeMode)) out.welcomeMode = 'all';
  return out;
}

// Número novo (2 e 3): existe, mas nasce parado e sem monitorar nada. Só passa
// a fazer alguma coisa quando alguém liga um recurso no painel.
export function sessaoNova(id, indice = 0) {
  return {
    id,
    nome: `Número ${indice + 1}`,
    ativa: false,
    recursos: recursosVazios(),
    config: {
      ...normalizarConfigSessao({}),
      monitorMode: 'specific', // 'all' num número novo pegaria todos os grupos
      monitorPrivate: false,
    },
  };
}

export function normalizarSessao(bruta, indice = 0) {
  const id = IDS_SESSOES.includes(bruta?.id) ? bruta.id : IDS_SESSOES[indice] ?? IDS_SESSOES[0];
  const base = sessaoNova(id, indice);
  // Sem config gravada, valem os padrões cautelosos de sessaoNova (não monitora
  // nada) — e não os padrões "todos os grupos" da config de fábrica.
  const temConfig = bruta?.config && typeof bruta.config === 'object' && Object.keys(bruta.config).length > 0;
  return {
    id,
    nome: String(bruta?.nome ?? base.nome).trim().slice(0, 40) || base.nome,
    ativa: Boolean(bruta?.ativa),
    recursos: normalizarRecursos(bruta?.recursos),
    config: temConfig ? normalizarConfigSessao(bruta.config) : base.config,
  };
}

/**
 * Lista de sessões a partir do que veio do arquivo. Sempre devolve as 3 na
 * ordem n1, n2, n3 — o painel mostra os três lugares mesmo sem uso, e assim o
 * índice nunca depende do que foi salvo.
 */
export function normalizarSessoes(brutas) {
  const porId = new Map();
  if (Array.isArray(brutas)) {
    brutas.slice(0, MAX_SESSOES).forEach((s, i) => {
      const norm = normalizarSessao(s, i);
      if (!porId.has(norm.id)) porId.set(norm.id, norm);
    });
  }
  return IDS_SESSOES.map((id, i) => porId.get(id) ?? sessaoNova(id, i));
}

/**
 * Migração da instalação de um número só: a config global vira a config do
 * Número 1, que herda tudo ligado (o comportamento que já estava no ar).
 * `configAntiga` é o db.config do arquivo lido.
 */
export function sessoesIniciais(configAntiga = {}) {
  const sessoes = IDS_SESSOES.map((id, i) => sessaoNova(id, i));
  sessoes[0].nome = 'Número 1';
  sessoes[0].ativa = true;
  sessoes[0].recursos = recursosCompletos();
  sessoes[0].config = normalizarConfigSessao(configAntiga);
  return sessoes;
}

/* ═══════════ Acessores (recebem o db) ═══════════ */

export function sessoesDe(db) {
  if (!Array.isArray(db?.sessoes) || db.sessoes.length !== MAX_SESSOES) {
    db.sessoes = normalizarSessoes(db?.sessoes);
  }
  return db.sessoes;
}

// Sessão por id. Sem id (ou id desconhecido) devolve a primeira — é o que
// mantém rotas e registros antigos, que não sabem de sessão, apontando para o
// Número 1.
export function sessaoDe(db, id = SESSAO_PADRAO) {
  const sessoes = sessoesDe(db);
  return sessoes.find((s) => s.id === id) ?? sessoes[0];
}

export function existeSessao(id) {
  return IDS_SESSOES.includes(id);
}

// Config VIVA de um número (o objeto guardado, gravável).
export function configSessao(db, id = SESSAO_PADRAO) {
  return sessaoDe(db, id).config;
}

export function recursoLigado(db, id, recurso) {
  const s = sessaoDe(db, id);
  return Boolean(s?.ativa && s.recursos?.[recurso]);
}

export function sessoesAtivas(db) {
  return sessoesDe(db).filter((s) => s.ativa);
}

/**
 * Sobreposições entre números ativos: mesmo grupo (ou o privado) sendo lido
 * pelo mesmo recurso em mais de um número. É o que geraria contagem dobrada.
 *
 * `grupos` é opcional ({ [jid]: nome }) só para o aviso sair legível.
 * Devolve [{ recurso, alvo, nome, sessoes: ['n1','n2'], certeza }], onde
 * `certeza` é 'confirmado' (as configurações se sobrepõem) ou 'possivel'
 * (só há sobreposição se os dois números estiverem nos mesmos grupos —
 * daqui não dá para saber de que grupos cada número participa).
 */
export function conflitos(db, grupos = {}) {
  const ativas = sessoesAtivas(db);
  const achados = [];
  const nomeGrupo = (jid) => grupos[jid] ?? jid;

  // Sobreposição de escopo entre números, dado como cada um escolhe os grupos.
  // `escopo(s)` → { modo: 'all'|'specific'|'none', grupos: [] }
  function sobreposicoes(usando, escopo, recurso) {
    const out = [];
    const emTodos = usando.filter((s) => escopo(s).modo === 'all');
    if (emTodos.length >= 2) {
      out.push({
        recurso, alvo: '*', nome: 'todos os grupos',
        sessoes: emTodos.map((s) => s.id), certeza: 'confirmado',
      });
    }

    const porGrupo = new Map();
    for (const s of usando) {
      const e = escopo(s);
      if (e.modo !== 'specific') continue;
      for (const jid of e.grupos) {
        porGrupo.set(jid, [...(porGrupo.get(jid) ?? []), s.id]);
      }
    }
    // Quem está em 'all' cobre também os grupos escolhidos pelos outros.
    for (const s of usando) {
      if (escopo(s).modo !== 'all') continue;
      for (const [, ids] of porGrupo) if (!ids.includes(s.id)) ids.push(s.id);
    }
    for (const [jid, ids] of porGrupo) {
      if (ids.length >= 2) {
        out.push({ recurso, alvo: jid, nome: nomeGrupo(jid), sessoes: [...new Set(ids)], certeza: 'confirmado' });
      }
    }
    return out;
  }

  const escopoMonitor = (s) => ({ modo: s.config.monitorMode, grupos: s.config.monitoredGroups ?? [] });

  for (const recurso of RECURSOS_DE_LEITURA) {
    const usando = ativas.filter((s) => s.recursos?.[recurso]);
    if (usando.length < 2) continue;
    achados.push(...sobreposicoes(usando, escopoMonitor, recurso));

    // Privado (DM): "monitorar privado" ligado em dois números só duplica se as
    // duas contas receberem a mesma conversa — quem escreve escolhe o número.
    const privado = usando.filter((s) => s.config.monitorPrivate);
    if (privado.length >= 2) {
      achados.push({
        recurso, alvo: 'privado', nome: 'conversas privadas',
        sessoes: privado.map((s) => s.id), certeza: 'possivel',
      });
    }
  }

  // Boas-vindas duplicam MENSAGEM (não dado): o novato receberia duas saudações.
  const saudando = ativas.filter((s) => s.recursos?.boasVindas);
  if (saudando.length >= 2) {
    achados.push(...sobreposicoes(
      saudando,
      (s) => ({ modo: s.config.welcomeMode, grupos: s.config.welcomeGroups ?? [] }),
      'boasVindas',
    ));
  }

  // Resposta automática não tem lista de grupos: só dá para avisar que, se os
  // dois números estiverem no mesmo lugar, quem escrever recebe duas respostas.
  const respondendo = ativas.filter((s) => s.recursos?.autoResposta && s.config.autoReplyEnabled);
  if (respondendo.length >= 2) {
    achados.push({
      recurso: 'autoResposta', alvo: '*', nome: 'os mesmos chats',
      sessoes: respondendo.map((s) => s.id), certeza: 'possivel',
    });
  }

  return achados;
}

// Rótulo do recurso para mensagens/telas.
export function nomeRecurso(chave) {
  return RECURSOS.find((r) => r.chave === chave)?.nome ?? chave;
}
