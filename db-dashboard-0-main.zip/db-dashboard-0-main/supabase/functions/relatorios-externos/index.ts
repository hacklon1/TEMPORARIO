// Proxy dos relatórios do WhatsApp Server (Montante, Contas, Operadores).
//
// O navegador não consegue falar direto com o WhatsApp Server: ele não manda
// cabeçalhos de CORS. Esta função é o intermediário — chama o servidor de
// servidor para servidor, guarda o token como secret e devolve o JSON já com os
// cabeçalhos de CORS do Dash (inclusive no preflight OPTIONS).
//
// Duas ações:
//   {tipo, data}                     → um relatório
//   {acao:"diagnostico", data}       → teste de conexão nas três rotas, com
//                                      status, tempo e o payload de cada uma
//
// Secrets esperados:
//   WHATSAPP_SERVER_URL  base do servidor. É o ÚNICO lugar onde a URL fica: ela
//                        ainda é provisória (túnel Cloudflare) e vai trocar por
//                        um domínio fixo — troca-se aqui e em mais nenhum
//                        arquivo. `RELATORIOS_URL` é aceito como nome antigo.
//   RELATORIOS_TOKEN     token compartilhado, enviado como Bearer
import { createClient } from "https://esm.sh/@supabase/supabase-js@2.45.0";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers":
    "authorization, x-client-info, apikey, content-type",
  "Access-Control-Allow-Methods": "POST, OPTIONS",
};

const TIPOS = ["montante", "contas", "operadores"] as const;
type Tipo = (typeof TIPOS)[number];

/** Namespace versionado do servidor, fora do namespace do painel interno dele. */
const CAMINHO = "/api/v1/relatorios";

// O WhatsApp Server é uma máquina de terceiro atrás de um túnel: se ele travar,
// a requisição não pode segurar a Edge Function até o limite da plataforma.
const TIMEOUT_MS = 20_000;
// Uma nova tentativa antes de desistir — o túnel oscila e a segunda costuma passar.
const TENTATIVAS = 2;

/** Base do WhatsApp Server, lida do secret. Sem barra no fim para a URL montar
 *  sempre igual. */
function baseDoServidor(): string | undefined {
  const bruto = Deno.env.get("WHATSAPP_SERVER_URL") ?? Deno.env.get("RELATORIOS_URL");
  const base = bruto?.trim().replace(/\/+$/, "");
  return base || undefined;
}

type Codigo = "token_coletor" | "data_invalida" | "coletor_offline" | "json";

type Falha = { erro: string; status: number; codigo: Codigo; detalhe?: string };

const MSG_OFFLINE = "O WhatsApp Server não respondeu";
const MSG_TOKEN = "O token do coletor foi recusado";

/** Uma chamada ao servidor, já com token, timeout e nova tentativa em falha de
 *  rede/timeout ou 5xx. Só devolve `Response` quando ela é definitiva. */
async function chamarServidor(
  base: string,
  token: string,
  tipo: Tipo,
  data: string,
): Promise<Response> {
  const alvo = new URL(`${base}${CAMINHO}/${tipo}`);
  alvo.searchParams.set("data", data);

  let ultimoErro: unknown;
  for (let tentativa = 1; tentativa <= TENTATIVAS; tentativa++) {
    try {
      const res = await fetch(alvo, {
        method: "GET",
        signal: AbortSignal.timeout(TIMEOUT_MS),
        headers: {
          Accept: "application/json",
          ...(token ? { Authorization: `Bearer ${token}` } : {}),
          "X-Dash-Client": "dash-edge",
        },
      });
      if (res.status >= 500 && tentativa < TENTATIVAS) {
        const corpo = await res.text();
        console.warn(`relatorios-externos: ${tipo} ${data} → ${res.status} na tentativa ${tentativa}, repetindo`, corpo.slice(0, 300));
        continue;
      }
      return res;
    } catch (e) {
      ultimoErro = e;
      console.warn(`relatorios-externos: ${tipo} ${data} falhou na tentativa ${tentativa}:`, String(e));
    }
  }
  throw ultimoErro;
}

/** Traduz a resposta do servidor (ou a falta dela) para o que a tela precisa
 *  saber. Devolve `null` quando a resposta é boa. */
function classificarResposta(status: number, corpo: string): Falha | null {
  if (status === 401 || status === 403) {
    return { erro: MSG_TOKEN, status, codigo: "token_coletor", detalhe: corpo.slice(0, 200) };
  }
  if (status === 400) {
    let motivo = "";
    try {
      motivo = String((JSON.parse(corpo) as { error?: unknown })?.error ?? "");
    } catch { /* corpo não é JSON */ }
    return {
      erro: motivo ? `Data inválida: ${motivo}` : "Data inválida para o WhatsApp Server",
      status: 400,
      codigo: "data_invalida",
      detalhe: corpo.slice(0, 200),
    };
  }
  if (status >= 500) {
    return { erro: `${MSG_OFFLINE} (HTTP ${status})`, status, codigo: "coletor_offline", detalhe: corpo.slice(0, 300) };
  }
  if (status < 200 || status >= 300) {
    return { erro: `WhatsApp Server respondeu ${status}`, status, codigo: "coletor_offline", detalhe: corpo.slice(0, 300) };
  }
  return null;
}

function classificarFalhaDeRede(e: unknown): Falha {
  const msg = e instanceof Error ? `${e.name}: ${e.message}` : String(e);
  const timeout = /timeout|TimeoutError|aborted/i.test(msg);
  return {
    erro: timeout ? `${MSG_OFFLINE} em ${TIMEOUT_MS / 1000}s` : MSG_OFFLINE,
    status: 504,
    codigo: "coletor_offline",
    detalhe: msg.slice(0, 300),
  };
}

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  try {
    const authHeader = req.headers.get("Authorization") ?? "";
    const jwt = authHeader.replace("Bearer ", "");
    if (!jwt) return json({ error: "missing auth" }, 401);

    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const anonKey = Deno.env.get("SUPABASE_ANON_KEY")!;

    const userClient = createClient(supabaseUrl, anonKey, {
      global: { headers: { Authorization: `Bearer ${jwt}` } },
    });
    const { data: userData, error: userErr } = await userClient.auth.getUser();
    if (userErr || !userData.user) return json({ error: "unauthorized" }, 401);

    const { acao, tipo, data } = await req.json() as {
      acao?: string;
      tipo?: string;
      data?: string;
    };

    if (!data || !/^\d{4}-\d{2}-\d{2}$/.test(data)) {
      return json({ error: "data inválida: use YYYY-MM-DD" }, 400);
    }

    const base = baseDoServidor();
    if (!base) return json({ error: "WHATSAPP_SERVER_URL não configurada" }, 500);
    const token = Deno.env.get("RELATORIOS_TOKEN") ?? "";

    // --- Teste de conexão: as três rotas, com tempo e payload de cada uma ----
    if (acao === "diagnostico") {
      const comecoTotal = Date.now();
      const rotas = await Promise.all(
        TIPOS.map(async (t) => {
          const comeco = Date.now();
          try {
            const res = await chamarServidor(base, token, t, data);
            const corpo = await res.text();
            const ms = Date.now() - comeco;

            const falha = classificarResposta(res.status, corpo);
            if (falha) {
              console.error(`relatorios-externos[diagnostico]: ${t} ${data} → ${res.status}`, corpo.slice(0, 500));
              return { tipo: t, ok: false, status: res.status, ms, codigo: falha.codigo, erro: falha.erro, amostra: corpo.slice(0, 300) };
            }
            try {
              return { tipo: t, ok: true, status: res.status, ms, bytes: corpo.length, relatorio: JSON.parse(corpo) };
            } catch {
              return { tipo: t, ok: false, status: res.status, ms, codigo: "json", erro: "WhatsApp Server não devolveu JSON", amostra: corpo.slice(0, 300) };
            }
          } catch (e) {
            const f = classificarFalhaDeRede(e);
            console.error(`relatorios-externos[diagnostico]: ${t} ${data} inacessível`, f.detalhe);
            return { tipo: t, ok: false, status: f.status, ms: Date.now() - comeco, codigo: f.codigo, erro: f.erro, amostra: f.detalhe };
          }
        }),
      );

      return json({
        diagnostico: {
          base,
          caminho: CAMINHO,
          data,
          token_configurado: token.length > 0,
          timeout_ms: TIMEOUT_MS,
          tentativas: TENTATIVAS,
          ms_total: Date.now() - comecoTotal,
          rotas,
        },
      });
    }

    // --- Um relatório -------------------------------------------------------
    if (!tipo || !TIPOS.includes(tipo as Tipo)) {
      return json({ error: "tipo inválido: use montante, contas ou operadores" }, 400);
    }

    // Falhas do servidor voltam com HTTP 200 e `error` no corpo de propósito:
    // o supabase-js esconde o corpo de respostas não-2xx atrás de uma mensagem
    // genérica, e a tela precisa do motivo.
    let res: Response;
    try {
      res = await chamarServidor(base, token, tipo as Tipo, data);
    } catch (e) {
      const f = classificarFalhaDeRede(e);
      console.error(`relatorios-externos: ${tipo} ${data} inacessível —`, f.detalhe);
      return json({ error: f.erro, status: f.status, codigo: f.codigo, detalhe: f.detalhe }, 200);
    }

    const corpo = await res.text();
    const falha = classificarResposta(res.status, corpo);
    if (falha) {
      console.error(`relatorios-externos: ${tipo} ${data} → ${res.status}`, corpo.slice(0, 500));
      return json({ error: falha.erro, status: falha.status, codigo: falha.codigo, detalhe: falha.detalhe }, 200);
    }

    let relatorio: unknown;
    try {
      relatorio = JSON.parse(corpo);
    } catch {
      console.error(`relatorios-externos: ${tipo} ${data} não devolveu JSON`, corpo.slice(0, 500));
      return json({ error: "WhatsApp Server não devolveu JSON", status: 502, codigo: "json", detalhe: corpo.slice(0, 300) }, 200);
    }

    return json({ relatorio });
  } catch (e) {
    console.error("relatorios-externos error", e);
    return json({ error: "Não foi possível buscar os relatórios." }, 500);
  }
});

function json(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...corsHeaders, "Content-Type": "application/json" },
  });
}
