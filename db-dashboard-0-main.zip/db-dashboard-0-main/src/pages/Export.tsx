import { useEffect, useMemo, useState } from "react";
import { Download, FileSpreadsheet, FileJson, Users as UsersIcon, User as UserIcon } from "lucide-react";
import { supabase } from "@/integrations/supabase/client";
import { useAuth } from "@/contexts/AuthContext";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Input } from "@/components/ui/input";
import { formatBRL, formatDate } from "@/lib/format";
import { toast } from "sonner";

type Op = {
  id: string;
  user_id: string;
  deposito: number;
  saque: number;
  blogueira: number;
  comissao: number;
  lucro: number;
  nome_conta: string | null;
  link_casa: string | null;
  contas_solicitadas: number;
  zerou: number;
  sacou: number;
  observacao: string | null;
  data_operacao: string | null;
  created_at: string;
  updated_at: string;
};

type Profile = { id: string; nome: string; email: string };

export default function ExportPage() {
  const { user, isAdmin } = useAuth();
  const [ops, setOps] = useState<Op[]>([]);
  const [profiles, setProfiles] = useState<Record<string, Profile>>({});
  const [loading, setLoading] = useState(true);
  const [from, setFrom] = useState("");
  const [to, setTo] = useState("");

  useEffect(() => {
    (async () => {
      setLoading(true);
      const { data: opsData } = await supabase
        .from("operations")
        .select("*")
        .order("created_at", { ascending: false });
      setOps((opsData ?? []) as Op[]);

      if (isAdmin) {
        const { data: profData } = await supabase.from("profiles").select("id, nome, email");
        const map: Record<string, Profile> = {};
        (profData ?? []).forEach((p: any) => (map[p.id] = p));
        setProfiles(map);
      }
      setLoading(false);
    })();
  }, [isAdmin]);

  const filtered = useMemo(() => {
    return ops.filter((o) => {
      const t = new Date(o.created_at).getTime();
      if (from) {
        const f = new Date(from).getTime();
        if (t < f) return false;
      }
      if (to) {
        const tt = new Date(to).getTime() + 86_400_000;
        if (t > tt) return false;
      }
      return true;
    });
  }, [ops, from, to]);

  const buildRows = () =>
    filtered.map((o) => ({
      id: o.id,
      usuario: isAdmin ? profiles[o.user_id]?.nome ?? "—" : "",
      email: isAdmin ? profiles[o.user_id]?.email ?? "" : "",
      data_operacao: o.data_operacao ? formatDate(o.data_operacao) : "",
      criado_em: formatDate(o.created_at),
      atualizado_em: formatDate(o.updated_at),
      nome_conta: o.nome_conta ?? "",
      link_casa: o.link_casa ?? "",
      deposito: o.deposito,
      saque: o.saque,
      blogueira: o.blogueira,
      comissao: o.comissao,
      lucro: o.lucro,
      contas_solicitadas: o.contas_solicitadas,
      zerou: o.zerou,
      sacou: o.sacou,
      observacao: o.observacao ?? "",
    }));

  const exportCSV = () => {
    const rows = buildRows();
    if (rows.length === 0) {
      toast.error("Nenhum dado para exportar");
      return;
    }
    const headers = Object.keys(rows[0]);
    const escape = (v: any) => {
      const s = String(v ?? "");
      if (/[",\n;]/.test(s)) return `"${s.replace(/"/g, '""')}"`;
      return s;
    };
    const csv = [headers.join(";"), ...rows.map((r) => headers.map((h) => escape((r as any)[h])).join(";"))].join("\n");
    const blob = new Blob(["\uFEFF" + csv], { type: "text/csv;charset=utf-8;" });
    triggerDownload(blob, `exportacao-${stamp()}.csv`);
    toast.success(`${rows.length} registros exportados`);
  };

  const exportJSON = () => {
    const rows = buildRows();
    if (rows.length === 0) {
      toast.error("Nenhum dado para exportar");
      return;
    }
    const blob = new Blob([JSON.stringify(rows, null, 2)], { type: "application/json" });
    triggerDownload(blob, `exportacao-${stamp()}.json`);
    toast.success(`${rows.length} registros exportados`);
  };

  const triggerDownload = (blob: Blob, name: string) => {
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    a.click();
    URL.revokeObjectURL(url);
  };

  const stamp = () => new Date().toISOString().slice(0, 19).replace(/[:T]/g, "-");

  const totals = useMemo(() => {
    const dep = filtered.reduce((s, o) => s + Number(o.deposito || 0), 0);
    const saq = filtered.reduce((s, o) => s + Number(o.saque || 0), 0);
    const luc = filtered.reduce((s, o) => s + Number(o.lucro || 0), 0);
    return { dep, saq, luc };
  }, [filtered]);

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-2 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-3xl font-extrabold tracking-tight">Exportar dados</h1>
          <p className="text-sm text-muted-foreground">
            {isAdmin ? (
              <span className="inline-flex items-center gap-1.5">
                <UsersIcon className="h-3.5 w-3.5 text-primary" /> Modo administrador — todos os usuários e alterações
              </span>
            ) : (
              <span className="inline-flex items-center gap-1.5">
                <UserIcon className="h-3.5 w-3.5 text-primary" /> Apenas seus próprios dados
              </span>
            )}
          </p>
        </div>
      </div>

      <div className="glass-strong grid gap-4 rounded-2xl p-5 sm:grid-cols-3">
        <div>
          <Label className="text-xs">Data inicial</Label>
          <Input type="date" value={from} onChange={(e) => setFrom(e.target.value)} />
        </div>
        <div>
          <Label className="text-xs">Data final</Label>
          <Input type="date" value={to} onChange={(e) => setTo(e.target.value)} />
        </div>
        <div className="flex items-end">
          <Button variant="ghost" onClick={() => { setFrom(""); setTo(""); }} className="w-full">
            Limpar filtros
          </Button>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-3">
        <div className="glass-strong rounded-2xl p-5">
          <p className="text-xs uppercase text-muted-foreground">Registros</p>
          <p className="text-2xl font-bold">{filtered.length}</p>
        </div>
        <div className="glass-strong rounded-2xl p-5">
          <p className="text-xs uppercase text-muted-foreground">Depósitos</p>
          <p className="text-2xl font-bold">{formatBRL(totals.dep)}</p>
        </div>
        <div className="glass-strong rounded-2xl p-5">
          <p className="text-xs uppercase text-muted-foreground">Lucro líquido</p>
          <p className={`text-2xl font-bold ${totals.luc >= 0 ? "text-success" : "text-destructive"}`}>
            {formatBRL(totals.luc)}
          </p>
        </div>
      </div>

      <div className="glass-strong rounded-2xl p-5">
        <h2 className="text-lg font-semibold">Formatos disponíveis</h2>
        <p className="mb-4 text-sm text-muted-foreground">
          {isAdmin
            ? "Exporta dados completos de todos os usuários, incluindo datas de criação e alteração."
            : "Exporta apenas as suas operações registradas."}
        </p>
        <div className="flex flex-wrap gap-3">
          <Button onClick={exportCSV} disabled={loading} className="gap-2">
            <FileSpreadsheet className="h-4 w-4" /> Exportar CSV
          </Button>
          <Button onClick={exportJSON} disabled={loading} variant="outline" className="gap-2">
            <FileJson className="h-4 w-4" /> Exportar JSON
          </Button>
          <Button
            onClick={() => window.print()}
            variant="ghost"
            className="gap-2"
          >
            <Download className="h-4 w-4" /> Imprimir / PDF
          </Button>
        </div>
      </div>
    </div>
  );
}
