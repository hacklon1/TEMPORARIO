"""Cliente SSH (asyncssh) com autenticacao por chave RSA.

Usado tanto pelo terminal interativo (WebSocket + PTY) quanto pela execucao
de comandos pontuais vindos do painel.
"""
from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass

import asyncssh

from ..config import settings
from .. import db


@dataclass
class HostSpec:
    name: str
    hostname: str
    port: int
    username: str
    key_path: str

    @classmethod
    def local(cls) -> "HostSpec":
        return cls("local", settings.ssh_host, settings.ssh_port, settings.ssh_user, settings.ssh_key)


async def get_host(host_id: int | None) -> HostSpec:
    if not host_id:
        row = await db.fetch_one("SELECT * FROM hosts WHERE is_default=1 LIMIT 1")
    else:
        row = await db.fetch_one("SELECT * FROM hosts WHERE id=?", (host_id,))
    if not row:
        return HostSpec.local()
    return HostSpec(
        name=row["name"], hostname=row["hostname"], port=int(row["port"]),
        username=row["username"], key_path=row["key_path"] or settings.ssh_key,
    )


async def connect(host: HostSpec) -> asyncssh.SSHClientConnection:
    if not os.path.isfile(host.key_path):
        raise FileNotFoundError(f"chave SSH nao encontrada: {host.key_path}")
    return await asyncssh.connect(
        host.hostname,
        port=host.port,
        username=host.username,
        client_keys=[host.key_path],
        known_hosts=None,          # host confiavel definido pelo operador do painel
        keepalive_interval=30,
        keepalive_count_max=4,
        connect_timeout=15,
    )


async def run_command(host: HostSpec, command: str, timeout: int = 60) -> dict:
    """Executa um comando unico e devolve saida/codigo."""
    try:
        async with await connect(host) as conn:
            res = await asyncio.wait_for(conn.run(command, check=False), timeout=timeout)
            return {
                "ok": res.exit_status == 0,
                "exit_status": res.exit_status,
                "stdout": (res.stdout or "")[-200000:],
                "stderr": (res.stderr or "")[-20000:],
            }
    except asyncio.TimeoutError:
        return {"ok": False, "exit_status": 124, "stdout": "", "stderr": "tempo esgotado"}
    except Exception as exc:  # noqa: BLE001
        return {"ok": False, "exit_status": -1, "stdout": "", "stderr": str(exc)}


async def check(host: HostSpec) -> dict:
    res = await run_command(host, "id -un; hostname; uptime -p", timeout=20)
    return {"ok": res["ok"], "output": res["stdout"].strip() or res["stderr"].strip()}


class Terminal:
    """Sessao interativa com PTY, ligada a um WebSocket."""

    def __init__(self, host: HostSpec, cols: int = 120, rows: int = 32):
        self.host = host
        self.cols = cols
        self.rows = rows
        self.conn: asyncssh.SSHClientConnection | None = None
        self.proc: asyncssh.SSHClientProcess | None = None

    async def open(self) -> None:
        self.conn = await connect(self.host)
        self.proc = await self.conn.create_process(
            term_type="xterm-256color",
            term_size=(self.cols, self.rows),
            encoding="utf-8",
            errors="replace",
        )

    async def write(self, data: str) -> None:
        if self.proc and not self.proc.stdin.is_closing():
            self.proc.stdin.write(data)

    async def resize(self, cols: int, rows: int) -> None:
        self.cols, self.rows = cols, rows
        if self.proc:
            try:
                self.proc.change_terminal_size(cols, rows)
            except Exception:
                pass

    async def read(self) -> str | None:
        if not self.proc:
            return None
        try:
            data = await self.proc.stdout.read(8192)
        except (asyncssh.BreakReceived, asyncssh.TerminalSizeChanged):
            return ""
        except Exception:
            return None
        return data or None

    async def close(self) -> None:
        try:
            if self.proc:
                self.proc.terminate()
        except Exception:
            pass
        try:
            if self.conn:
                self.conn.close()
        except Exception:
            pass
