// Cliente dos relatórios do WhatsApp Server (o "coletor").
//
// O WhatsApp Server publica três relatórios do dia: Montante, Contas e
// Operadores. O Dash consome esses relatórios em modo somente-leitura — nada
// aqui escreve no servidor.
//
// Transporte: por padrão as chamadas passam pela Edge Function
// `relatorios-externos`. O servidor não manda cabeçalhos de CORS, então o
// navegador não pode chamá-lo direto — o front-end fala só com a Edge Function,
// e é ela quem guarda a URL (secret `WHATSAPP_SERVER_URL`) e o token. Por isso
// a URL não aparece em lugar nenhum deste bundle. `VITE_RELATORIOS_MODO=direto`
// existe só para desenvolvimento local contra um servidor com CORS liberado, e
// nesse caso `VITE_RELATORIOS_URL` precisa ser informada.
import { FunctionsFetchError, FunctionsHttpError, FunctionsRelayError } from "@supabase/supabase-js";
import { z } from "zod";
import { supabase } from "@/integrations/supabase/client";
import { guardarResposta, registrarLog, tamanhoJson } from "@/lib/coletorStore";

/** Base do servidor quando o modo é `direto`. Em modo `proxy` fica vazia: quem
 *  conhece a URL é a Edge Function. */
export const RELATORIOS_BASE_URL: string = import.meta.env.VITE_RELATORIOS_URL ?? "";

/** Namespace versionado do servidor. */
export const RELATORIOS_PATH = "/api/v1/relatorios";

export const RELATORIOS_MODO = (import.meta.env.VITE_RELATORIOS_MODO ?? "proxy") as "proxy" | "direto";
const MODO = RELATORIOS_MODO;
const TOKEN_DIRETO = import.meta.env.VITE_RELATORIOS_TOKEN ?? "";

export type RelatorioTipo = "montante" | "contas" | "operadores";

/** Fuso do dia operacional. O servidor fecha o dia neste fuso, não no do
 *  navegador de quem está olhando. */
export const FUSO_OPERACIONAL = "America/Sao_Paulo";
/** Hora em que o dia operacional vira (05:00 → 04:59 do dia seguinte). */
export const VIRADA_DO_DIA = 5;

const partesSP = new Intl.DateTimeFormat("en-CA", {
  timeZone: FUSO_OPERACIONAL,
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
  hour: "2-digit",
  hourCycle: "h23",
});

/** Dia operacional de um instante, em America/Sao_Paulo. Um serviço das 2h da
 *  madrugada pertence ao dia ANTERIOR. Serve só para escolher o dia padrão do
 *  seletor: a verdade sobre qual dia foi devolvido é o campo `data` da resposta. */
export function diaOperacional(ref: Date = new Date()): string {
  const partes = Object.fromEntries(partesSP.formatToParts(ref).map((p) => [p.type, p.value]));
  let y = Number(partes.year);
  let m = Number(partes.month);
  let d = Number(partes.day);
  if (Number(partes.hour) < VIRADA_DO_DIA) {
    // Volta um dia usando UTC para não depender do fuso do navegador.
    const ontem = new Date(Date.UTC(y, m - 1, d - 1));
    y = ontem.getUTCFullYear();
    m = ontem.getUTCMonth() + 1;
    d = ontem.getUTCDate();
  }
  return `${y}-${String(m).padStart(2, "0")}-${String(d).padStart(2, "0")}`;
}

// --- Contratos ------------------------------------------------------------
// Tudo que vem do servidor é dado de fora: validamos antes de deixar entrar na
// UI. Duas posturas deliberadas aqui:
//  - campos numéricos aceitam string (backends em PHP/Node serializam decimal
//    como string);
//  - chave desconhecida é ignorada, nunca motivo de rejeição. O servidor ganha
//    campos novos a cada troca de fonte de dados; derrubar a tela inteira por um
//    campo a mais seria trocar informação por nada. Só rejeitamos quando falta
//    algo que a UI realmente usa.
//
// `deposito` e `saque` sumiram daqui de propósito: a fonte atual (serviços do
// WhatsApp) não tem esses conceitos e o servidor manda 0 fixo nas três rotas.
// Continuam chegando no JSON e continuam sendo ignorados sem erro.

const numero = z.coerce.number().finite().catch(0);
const texto = z.string().trim();

const cabecalho = {
  /** Dia operacional que o servidor de fato devolveu — é a verdade sobre o dia,
   *  não a data que foi pedida. */
  data: texto,
  gerado_em: texto.optional(),
  moeda: texto.default("BRL"),
};

const horaSchema = z.object({
  hora: texto,
  montante: numero,
  blogueira: numero,
  lucro: numero,
});

export const montanteSchema = z.preprocess(
  // O contrato coloca `por_hora` na raiz e é assim que o servidor responde, mas a
  // especificação circula também com ele dentro de `totais`. Aceitamos os dois
  // lugares em vez de depender de qual versão está no ar.
  (bruto) => {
    if (!bruto || typeof bruto !== "object") return bruto;
    const o = bruto as Record<string, unknown>;
    const totais = o.totais as Record<string, unknown> | undefined;
    if (o.por_hora === undefined && totais && totais.por_hora !== undefined) {
      return { ...o, por_hora: totais.por_hora };
    }
    return o;
  },
  z.object({
    ...cabecalho,
    totais: z.object({
      pedidos: numero,
      validados: numero,
      montante: numero,
      blogueira: numero,
      comissao: numero,
      lucro: numero,
    }),
    // Vem sempre com as 24 horas do dia operacional, EM ORDEM OPERACIONAL
    // (05:00 → 04:00), zeradas inclusive. A UI desenha na ordem do array e
    // nunca reordena por string — senão o dia começaria à meia-noite.
    por_hora: z.array(horaSchema).catch([]).default([]),
  }),
);

export const contasSchema = z.object({
  ...cabecalho,
  totais: z.object({
    // `contas_solicitadas` conta CONTAS pedidas; `pedidos` conta as LINHAS da
    // tabela. Um dia com 24 pedidos pode ter 132 contas solicitadas — são
    // grandezas diferentes, nunca somar uma na outra.
    contas_solicitadas: numero,
    pedidos: numero,
    montante: numero,
    salario: numero,
    comissao: numero,
    lucro: numero,
    zerou: numero,
    sacou: numero,
    aberta: numero,
  }),
  // Uma linha por PEDIDO, não por conta: `nome_conta` (a blogueira que pediu)
  // repete entre linhas.
  itens: z
    .array(
      z.object({
        nome_conta: texto,
        contas: numero,
        montante: numero,
        salario: numero,
        lucro: numero,
        operador: texto.nullish(),
        status: z.enum(["aberta", "zerou", "sacou"]).catch("aberta"),
        atualizado_em: texto.nullish(),
      }),
    )
    .default([]),
});

const operadorSchema = z.preprocess(
  // O servidor chama a meta de `meta_dia`; a especificação anterior dizia
  // `meta_diaria`. Aceitamos os dois nomes e normalizamos para `meta_dia`.
  (bruto) => {
    if (!bruto || typeof bruto !== "object") return bruto;
    const o = bruto as Record<string, unknown>;
    if (o.meta_dia === undefined && o.meta_diaria !== undefined) {
      return { ...o, meta_dia: o.meta_diaria };
    }
    return o;
  },
  z.object({
    // Chave estável entre dias (formato "1234@lid"). É por ela que um operador
    // é identificado — nunca pelo nome, que é apelido e muda.
    id: texto,
    nome: texto,
    usuario: texto.nullish(),
    // O contrato prevê "bi", "montante" e "contas"; o servidor hoje só emite
    // os dois últimos. Guardamos como texto livre para que uma categoria
    // nova apareça como ela é, em vez de ser silenciosamente renomeada.
    categoria: texto.catch("").default(""),
    pedidos: numero,
    validados: numero,
    montante: numero,
    // blogueira = o que ele recebe; comissao = o que ele deve à casa;
    // lucro = blogueira - comissao.
    blogueira: numero,
    comissao: numero,
    lucro: numero,
    pct: numero,
    isento: z.coerce.boolean().catch(false),
    meta_dia: numero,
    /** Operou nos últimos 15 minutos. */
    online: z.coerce.boolean().catch(false),
    ultima_operacao: texto.nullish(),
  }),
);

export const operadoresSchema = z.object({
  ...cabecalho,
  // Lista única com TODOS os operadores cadastrados, inclusive os sem movimento
  // e os de cadastros apagados (`nome: "usuario_removido"`, `id` estável). Já
  // vem ordenada por lucro decrescente. O filtro é responsabilidade da tela — o
  // dinheiro de todos precisa fechar com o Montante.
  operadores: z.array(operadorSchema).default([]),
});

export type RelatorioMontante = z.infer<typeof montanteSchema>;
export type RelatorioContas = z.infer<typeof contasSchema>;
export type RelatorioOperadores = z.infer<typeof operadoresSchema>;
export type OperadorExterno = RelatorioOperadores["operadores"][number];
export type ContaExterna = RelatorioContas["itens"][number];

export type RelatoriosDoDia = {
  /** Dia pedido ao servidor. Compare com `montante.data` para saber o devolvido. */
  data: string;
  montante: RelatorioMontante;
  contas: RelatorioContas;
  operadores: RelatorioOperadores;
};

const schemas = {
  montante: montanteSchema,
  contas: contasSchema,
  operadores: operadoresSchema,
} as const;

/** Operadores de cadastros apagados chegam com este nome; o `id` continua estável. */
export const NOME_OPERADOR_REMOVIDO = "usuario_removido";

// --- Transporte -----------------------------------------------------------

export type RelatorioCodigo =
  | "token_coletor"
  | "data_invalida"
  | "coletor_offline"
  | "json"
  | "proxy"
  | "contrato";

export class RelatorioError extends Error {
  constructor(
    readonly tipo: RelatorioTipo,
    message: string,
    readonly status?: number,
    readonly codigo?: RelatorioCodigo,
    /** Trecho do corpo ou do erro original, para diagnóstico. */
    readonly detalhe?: string,
  ) {
    super(message);
    this.name = "RelatorioError";
  }
}

export const MSG_TOKEN = "O token do coletor foi recusado";
export const MSG_DATA = "Data inválida";
export const MSG_OFFLINE = "O WhatsApp Server não respondeu";
export const MSG_PROXY = "Não foi possível chamar a Edge Function relatorios-externos";

async function buscarDireto(tipo: RelatorioTipo, data: string, signal?: AbortSignal) {
  if (!RELATORIOS_BASE_URL) {
    throw new RelatorioError(tipo, "VITE_RELATORIOS_URL não configurada para o modo direto", undefined, "proxy");
  }
  const url = new URL(`${RELATORIOS_PATH}/${tipo}`, RELATORIOS_BASE_URL);
  url.searchParams.set("data", data);

  let res: Response;
  try {
    res = await fetch(url, {
      method: "GET",
      signal,
      headers: {
        Accept: "application/json",
        ...(TOKEN_DIRETO ? { Authorization: `Bearer ${TOKEN_DIRETO}` } : {}),
        "X-Dash-Client": "dash-web",
      },
    });
  } catch (e) {
    throw new RelatorioError(tipo, MSG_OFFLINE, undefined, "coletor_offline", String(e));
  }

  // 401/403 é sempre falha de autenticação, não importa o corpo.
  if (res.status === 401 || res.status === 403) {
    throw new RelatorioError(tipo, MSG_TOKEN, res.status, "token_coletor");
  }
  // 400 é dia recusado pelo servidor. O Dash mostra e fica parado nele — trocar
  // de dia sozinho esconderia o erro atrás de números de outro dia.
  if (res.status === 400) {
    throw new RelatorioError(tipo, MSG_DATA, 400, "data_invalida", (await res.text()).slice(0, 200));
  }
  if (!res.ok) {
    throw new RelatorioError(tipo, `${MSG_OFFLINE} (HTTP ${res.status})`, res.status, "coletor_offline");
  }
  return res.json();
}

/** O supabase-js esconde o corpo das respostas não-2xx da Edge Function atrás
 *  de uma mensagem genérica. Aqui recuperamos o motivo real. */
async function descreverErroDoProxy(error: unknown): Promise<{ mensagem: string; status?: number; detalhe?: string }> {
  if (error instanceof FunctionsHttpError) {
    const res = error.context as Response | undefined;
    let detalhe = "";
    try {
      const corpo = await res?.clone().json();
      detalhe = String(corpo?.error ?? corpo?.message ?? "");
    } catch { /* sem corpo JSON */ }
    const status = res?.status;
    const mensagem = detalhe
      ? `Edge Function respondeu ${status ?? "erro"}: ${detalhe}`
      : `Edge Function respondeu ${status ?? "erro"}`;
    return { mensagem, status, detalhe };
  }
  if (error instanceof FunctionsRelayError) {
    return { mensagem: `${MSG_PROXY}: o relay do Supabase não a alcançou` };
  }
  if (error instanceof FunctionsFetchError) {
    // É daqui que sai o "Failed to send a request to the Edge Function": rede
    // ou preflight CORS recusado antes de a função rodar.
    return { mensagem: `${MSG_PROXY} (rede ou CORS)`, detalhe: String(error.message) };
  }
  return { mensagem: (error as Error)?.message ?? MSG_PROXY };
}

async function buscarViaProxy(tipo: RelatorioTipo, data: string) {
  const { data: body, error } = await supabase.functions.invoke("relatorios-externos", {
    body: { tipo, data },
  });

  if (error) {
    const e = await descreverErroDoProxy(error);
    throw new RelatorioError(tipo, e.mensagem, e.status, "proxy", e.detalhe);
  }
  if (body?.error) {
    const codigo = body.codigo as RelatorioCodigo | undefined;
    const mensagem = codigo === "token_coletor" ? MSG_TOKEN : String(body.error);
    throw new RelatorioError(tipo, mensagem, body.status, codigo, body.detalhe);
  }
  return body?.relatorio ?? body;
}

/** Busca um relatório do dia e valida o formato antes de devolver.
 *
 *  Toda chamada — inclusive a que falha — deixa rastro no store do coletor: uma
 *  linha de log e, quando dá certo, o JSON cru guardado para outras telas. É o
 *  que alimenta o painel "Conexão com o coletor" no Dashboard. */
export async function buscarRelatorio<T extends RelatorioTipo>(
  tipo: T,
  data: string = diaOperacional(),
  signal?: AbortSignal,
): Promise<z.infer<(typeof schemas)[T]>> {
  const inicio = performance.now();
  let bruto: unknown;
  try {
    bruto = MODO === "direto" ? await buscarDireto(tipo, data, signal) : await buscarViaProxy(tipo, data);
  } catch (e) {
    const err = e as RelatorioError;
    registrarLog({
      origem: "relatorio",
      rota: tipo,
      nivel: "erro",
      ms: Math.round(performance.now() - inicio),
      status: err?.status,
      codigo: err?.codigo,
      mensagem: [err?.message ?? "falha desconhecida", err?.detalhe].filter(Boolean).join(" — "),
    });
    throw e;
  }

  const ms = Math.round(performance.now() - inicio);
  const bytes = tamanhoJson(bruto);

  const parsed = schemas[tipo].safeParse(bruto);
  if (!parsed.success) {
    const issue = parsed.error.issues[0];
    const caminho = issue?.path?.join(".");
    const mensagem = `Resposta fora do contrato em "${tipo}"${caminho ? ` (${caminho})` : ""}: ${issue?.message ?? "formato inválido"}`;
    // Guardamos o bruto mesmo assim: quando o contrato quebra, olhar o payload
    // que chegou é justamente o que resolve.
    guardarResposta(tipo, bruto, ms, bytes);
    registrarLog({ origem: "relatorio", rota: tipo, nivel: "erro", ms, bytes, codigo: "contrato", mensagem });
    throw new RelatorioError(tipo, mensagem, undefined, "contrato");
  }

  guardarResposta(tipo, bruto, ms, bytes);
  const devolvido = (parsed.data as { data?: string }).data;
  registrarLog({
    origem: "relatorio",
    rota: tipo,
    nivel: "ok",
    ms,
    bytes,
    status: 200,
    mensagem:
      devolvido && devolvido !== data
        ? `pedido ${data}, servidor devolveu ${devolvido}`
        : `${data} — resposta válida`,
  });
  return parsed.data as z.infer<(typeof schemas)[T]>;
}

/** Os três relatórios do dia, em paralelo. */
export async function buscarRelatoriosDoDia(
  data: string = diaOperacional(),
  signal?: AbortSignal,
): Promise<RelatoriosDoDia> {
  const [montante, contas, operadores] = await Promise.all([
    buscarRelatorio("montante", data, signal),
    buscarRelatorio("contas", data, signal),
    buscarRelatorio("operadores", data, signal),
  ]);
  return { data, montante, contas, operadores };
}
