// Registro de entradas financeiras processadas e consultas de agregação.
import dayjs from 'dayjs';
import utc from 'dayjs/plugin/utc.js';
import timezone from 'dayjs/plugin/timezone.js';
import { getDb, saveDb } from './db.js';
import { SESSAO_PADRAO } from './sessoes.js';
import { soDigitos } from './jid.js';
import { dobrar } from './indicacoes.js';
import { detectarRepeticoes, agruparRepetidos } from './repetidos.js';
import {
  configServicos, escolherAtendimento, escolherComprovante, STATUS,
} from './servicos.js';

dayjs.extend(utc);
dayjs.extend(timezone);

const MAX_HISTORY = 5000; // limita o histórico em memória/arquivo

// Converte para número finito; qualquer lixo vira 0. Sem isso um NaN vindo do
// parser ou de um db.json antigo contamina todos os totais acumulados.
export function num(v) {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

function tz() {
  const configurado = getDb().config.timezone || 'America/Sao_Paulo';
  // Um timezone inválido faz o dayjs lançar em toda agregação.
  try {
    dayjs().tz(configurado);
    return configurado;
  } catch {
    return 'America/Sao_Paulo';
  }
}

export function dayKey(ts = undefined) {
  return dayjs(ts).tz(tz()).format('YYYY-MM-DD');
}

/* ═══════════ Períodos ═══════════
   Todo relatório aceita o mesmo vocabulário de período:

     'today'  hoje                'week'   esta semana (a partir de segunda)
     'month'  este mês            'year'   este ano
     'all'    tudo o que existe   {day}    um dia exato ('YYYY-MM-DD')
                                  {de,ate} intervalo fechado

   Semana/mês/ano são de CALENDÁRIO, não janelas móveis: "no mês" no grupo
   quer dizer o mês corrente, não os últimos 30 dias. Como `day` já é
   'YYYY-MM-DD', a comparação de intervalo é textual — e cronológica.  */

export const PERIODOS = ['today', 'week', 'month', 'year', 'all'];

export function intervaloPeriodo(period = 'today') {
  if (period === 'all') return null; // sem recorte
  const hoje = dayjs().tz(tz());
  const ate = hoje.format('YYYY-MM-DD');

  if (period === 'today') return { de: ate, ate };
  if (period === 'week') {
    // Segunda-feira: dayjs().day() devolve 0 para domingo, então (d+6)%7 dá
    // quantos dias andar para trás até a segunda.
    const recuo = (hoje.day() + 6) % 7;
    return { de: hoje.subtract(recuo, 'day').format('YYYY-MM-DD'), ate };
  }
  if (period === 'month') return { de: hoje.startOf('month').format('YYYY-MM-DD'), ate };
  if (period === 'year') return { de: hoje.startOf('year').format('YYYY-MM-DD'), ate };

  if (period && typeof period === 'object') {
    if (period.de || period.ate) {
      return { de: period.de ?? '0000-01-01', ate: period.ate ?? '9999-12-31' };
    }
    if (period.day) return { de: period.day, ate: period.day };
  }
  // Período desconhecido cai em hoje — nunca em "tudo", que exageraria os números.
  return { de: ate, ate };
}

// Um registro cai no período? `intervalo` vem de intervaloPeriodo().
export function noIntervalo(day, intervalo) {
  if (!intervalo) return true;
  const d = String(day ?? '');
  return d >= intervalo.de && d <= intervalo.ate;
}

/**
 * Traduz o período escrito por uma pessoa (ou vindo na query string).
 *
 *   'hoje' | 'ontem' | 'semana' | 'mes' | 'ano' | 'geral'
 *   '2026-08-28' | '28/08' | '28/08/2026'
 *
 * É o mesmo vocabulário no comando do WhatsApp e na API — quem digita
 * "!RELATORIO ontem" no grupo e quem clica no dia no painel estão pedindo a
 * mesma coisa. Texto que não bate com nada devolve `padrao` (nunca 'all', que
 * exageraria os números de quem só errou a digitação).
 */
export function periodoDoTexto(bruto, { padrao = 'today' } = {}) {
  const t = String(bruto ?? '').trim().toLowerCase();
  if (!t) return padrao;

  const nomes = {
    hoje: 'today', today: 'today',
    semana: 'week', week: 'week',
    mes: 'month', mês: 'month', month: 'month',
    ano: 'year', year: 'year',
    geral: 'all', tudo: 'all', all: 'all',
  };
  if (nomes[t]) return nomes[t];
  if (t === 'ontem' || t === 'yesterday') {
    return { day: dayjs().tz(tz()).subtract(1, 'day').format('YYYY-MM-DD') };
  }
  if (/^\d{4}-\d{2}-\d{2}$/.test(t)) return { day: t };

  // 28/08 ou 28/08/2026 — como as pessoas escrevem data no grupo.
  const m = /^(\d{1,2})[/.](\d{1,2})(?:[/.](\d{2}|\d{4}))?$/.exec(t);
  if (m) {
    const dia = String(m[1]).padStart(2, '0');
    const mes = String(m[2]).padStart(2, '0');
    const hoje = dayjs().tz(tz());
    let ano = m[3] ? Number(m[3].length === 2 ? `20${m[3]}` : m[3]) : hoje.year();
    const iso = () => `${ano}-${mes}-${dia}`;
    // Sem ano, "28/12" em janeiro é o dezembro passado, não um dia no futuro.
    if (!m[3] && iso() > hoje.format('YYYY-MM-DD')) ano -= 1;
    const alvo = dayjs.tz(iso(), tz());
    if (alvo.isValid() && alvo.format('YYYY-MM-DD') === iso()) return { day: iso() };
  }
  return padrao;
}

// Rótulo humano do período, para títulos de relatório.
export function rotuloPeriodo(period = 'today') {
  if (period === 'all') return 'Geral';
  if (period === 'today') return `Hoje (${dayKey()})`;
  const i = intervaloPeriodo(period);
  const br = (d) => d.split('-').reverse().join('/');
  if (period === 'week') return `Esta semana (${br(i.de)} a ${br(i.ate)})`;
  if (period === 'month') return `Este mês (${br(i.de)} a ${br(i.ate)})`;
  if (period === 'year') return `Este ano (${br(i.de)} a ${br(i.ate)})`;
  return i.de === i.ate ? br(i.de) : `${br(i.de)} a ${br(i.ate)}`;
}

// Sequência por processo: o timestamp sozinho colide quando duas mensagens
// chegam no mesmo milissegundo (o sufixo antigo era derivado do próprio ts).
let seq = 0;

/* ═══════════ Deduplicação entre números ═══════════
   O id da mensagem do WhatsApp (`msg.key.id`) é o mesmo em todas as contas que
   a receberam. Se dois números estiverem no mesmo grupo com o mesmo recurso
   ligado, os dois chamariam registrar*() para a MESMA mensagem e tudo contaria
   em dobro. Esta é a rede de segurança: vale mesmo que alguém ignore o aviso de
   conflito do painel, e também pega a reentrega do próprio WhatsApp numa
   reconexão.

   A varredura olha só o fim da lista: as cópias chegam com segundos de
   diferença, e percorrer 5000 registros a cada mensagem seria desperdício. */
const JANELA_DEDUPE = 500;

export function jaRegistrado(colecao, msgId) {
  if (!msgId) return false;
  const lista = getDb()[colecao];
  if (!Array.isArray(lista) || !lista.length) return false;
  const inicio = Math.max(0, lista.length - JANELA_DEDUPE);
  for (let i = lista.length - 1; i >= inicio; i--) {
    if (lista[i]?.msgId === msgId) return true;
  }
  return false;
}

// Registros gravados antes dos múltiplos números não têm `sessaoId`: são todos
// do Número 1, que era o único que existia.
export const sessaoDoRegistro = (registro) => registro?.sessaoId ?? SESSAO_PADRAO;

// Filtro de número usado por todos os relatórios. Sem `sessaoId` (ou 'todas'),
// não filtra nada — a visão somada dos 3 números é o padrão.
export function daSessao(registro, sessaoId) {
  if (!sessaoId || sessaoId === 'todas') return true;
  return sessaoDoRegistro(registro) === sessaoId;
}

// Registra uma entrada analisada. `analise` vem de parser.analisarMensagem().
export function registrarEntrada({
  sessaoId, msgId, groupId, groupName, operatorId, operatorPn, operatorName, text, analise, ts,
}) {
  const db = getDb();
  const when = ts ? dayjs(ts) : dayjs();
  seq = (seq + 1) % 1_000_000;
  const entry = {
    id: `${when.valueOf()}-${seq.toString(36)}`,
    ts: when.toISOString(),
    day: dayKey(when.valueOf()),
    sessaoId: sessaoId ?? SESSAO_PADRAO,
    msgId: msgId ?? null,
    groupId: groupId ?? null,
    groupName: groupName ?? null,
    operatorId: operatorId ?? null,
    operatorPn: operatorPn ?? null,
    operatorName: operatorName ?? 'desconhecido',
    montante: num(analise.montante),
    contasQtd: num(analise.contasQtd),
    contasTotal: num(analise.contasTotal),
    // O que o Operador cobrou (base da comissão). Separado de contasTotal:
    // conta exige a palavra "Valor", salário aceita o "R$ x" solto do template
    // mais usado. Ver extractSalario() em parser.js.
    salario: num(analise.salario),
    // "Até N contas": quantas contas ele diz entregar. Não entra em nenhum
    // total — serve ao passo 2, para o pedido de conta casar por valor.
    contasOferecidas: num(analise.contasOferecidas),
    text: String(text ?? '').slice(0, 500),
  };

  db.messages.push(entry);
  if (db.messages.length > MAX_HISTORY) {
    db.messages.splice(0, db.messages.length - MAX_HISTORY);
  }

  // estatísticas acumuladas
  db.stats.totalMessages = num(db.stats.totalMessages) + 1;
  db.stats.totalMontante = num(db.stats.totalMontante) + entry.montante;
  db.stats.totalContasValor = num(db.stats.totalContasValor) + entry.contasTotal;
  db.stats.totalContasQtd = num(db.stats.totalContasQtd) + entry.contasQtd;

  saveDb();
  return entry;
}

/* ═══════════ Pedidos das Brogueiras (link + contas/montante) ═══════════
   Guardados separados de `messages`: são outra coisa (pedido de link, não
   lançamento financeiro) e têm seu próprio painel e sua própria retenção. */

const MAX_PEDIDOS = 5000;

export function registrarPedido({
  sessaoId, msgId, groupId, groupName, autorId, autorPn, autorNome, papel, pedido, text, ts,
}) {
  const db = getDb();
  if (!Array.isArray(db.pedidos)) db.pedidos = [];
  const when = ts ? dayjs(ts) : dayjs();
  seq = (seq + 1) % 1_000_000;
  const entry = {
    id: `p${when.valueOf()}-${seq.toString(36)}`,
    ts: when.toISOString(),
    day: dayKey(when.valueOf()),
    sessaoId: sessaoId ?? SESSAO_PADRAO,
    msgId: msgId ?? null,
    groupId: groupId ?? null,
    groupName: groupName ?? null,
    autorId: autorId ?? null,
    autorPn: autorPn ?? null,
    autorNome: autorNome || 'desconhecida',
    papel: papel ?? 'desconhecido',
    tipo: pedido.tipo, // 'conta' | 'montante' | 'indefinido'
    montante: num(pedido.montante),
    contas: pedido.contas == null ? null : num(pedido.contas),
    links: Array.isArray(pedido.links) ? pedido.links.slice(0, 10) : [],
    dominios: Array.isArray(pedido.dominios) ? pedido.dominios.slice(0, 10) : [],
    pedido: String(pedido.pedido ?? '').slice(0, 200),
    text: String(text ?? '').slice(0, 500),
  };

  // Este link já passou por aqui? Marcado no ato para o painel poder avisar na
  // hora ("fulana repetiu o link de ciclana"). O relatório recalcula tudo do
  // histórico na leitura — este campo é o que existe ANTES de alguém abrir a
  // aba, e é ele que vai no evento de tempo real.
  // O histórico comparado é o mesmo que o painel mostra: pedido de Operador
  // fica de fora (ele reposta link de divulgação o tempo todo). Sem isso o
  // aviso ao vivo apontaria uma repetição que a aba Brogueiras não teria como
  // exibir.
  const historico = entry.papel === 'operador' ? db.pedidos : db.pedidos.filter((p) => p.papel !== 'operador');
  entry.repeticoes = detectarRepeticoes(entry, historico, {
    janelaHoras: num(db.config?.repetidosJanelaHoras),
    agora: when.valueOf(),
  });
  entry.repetido = entry.repeticoes.length > 0;
  entry.repetidoDeOutra = entry.repeticoes.some((r) => r.deOutra);

  db.pedidos.push(entry);
  if (db.pedidos.length > MAX_PEDIDOS) db.pedidos.splice(0, db.pedidos.length - MAX_PEDIDOS);
  saveDb();
  return entry;
}

// period: 'today' | 'all' | {day:'YYYY-MM-DD'}
// sessaoId: filtra por número ('n1'|'n2'|'n3'); vazio = os três somados.
export function filtrarPedidos(period = 'today', sessaoId = null) {
  const db = getDb();
  const intervalo = intervaloPeriodo(period);
  return (Array.isArray(db.pedidos) ? db.pedidos : [])
    .filter((p) => daSessao(p, sessaoId) && noIntervalo(p.day, intervalo));
}

/**
 * Links repetidos no período.
 *
 * O agrupamento olha o histórico INTEIRO (limitado pela janela configurada),
 * não só o período: a graça é ver que o link de hoje já tinha sido mandado
 * ontem. O período só decide quais grupos aparecem — os que tiveram pelo menos
 * um envio nele.
 *
 * Recalculado na leitura, então vale também para os pedidos gravados antes
 * desta funcionalidade existir (o histórico já guarda os links).
 */
export function relatorioRepetidos(period = 'today', { incluirOperadores = false, sessao = null } = {}) {
  const db = getDb();
  const todos = (Array.isArray(db.pedidos) ? db.pedidos : [])
    .filter((p) => (incluirOperadores ? true : p.papel !== 'operador'))
    .filter((p) => daSessao(p, sessao));
  const noPeriodo = period === 'all' ? null : new Set(filtrarPedidos(period, sessao).map((p) => p.id));
  const janelaHoras = num(db.config?.repetidosJanelaHoras);

  const grupos = agruparRepetidos(todos, { noPeriodo, janelaHoras });

  // Quem repetiu (o envio que não foi o primeiro daquele link) e quantas vezes.
  const porAutor = new Map();
  const porPedido = new Map();
  const resumo = { links: grupos.length, envios: 0, repeticoes: 0, deOutras: 0, mesmaAutora: 0, brogueiras: 0 };

  for (const g of grupos) {
    resumo.envios += g.vezes;
    resumo.repeticoes += g.repeticoes;
    if (g.deOutras) resumo.deOutras += 1;
    else resumo.mesmaAutora += 1;

    const primeiro = g.envios[0];
    for (const e of g.envios.slice(1)) {
      const chave = e.autorChave ?? e.autorNome;
      const a = porAutor.get(chave) ?? { chave, nome: e.autorNome, repeticoes: 0, deOutras: 0, links: [] };
      a.nome = e.autorNome || a.nome;
      a.repeticoes += 1;
      const deOutra = (e.autorChave ?? e.autorNome) !== (primeiro.autorChave ?? primeiro.autorNome);
      if (deOutra) a.deOutras += 1;
      if (!a.links.includes(g.link)) a.links.push(g.link);
      porAutor.set(chave, a);

      // Índice pedido → repetição, usado para marcar a linha no detalhe da
      // Brogueira sem refazer o agrupamento lá.
      if (e.pedidoId) {
        porPedido.set(e.pedidoId, {
          vezes: g.vezes,
          ordem: e.ordem,
          deOutra,
          link: g.link,
          primeiroEm: primeiro.ts,
          primeiroPor: primeiro.autorNome,
        });
      }
    }
  }

  resumo.brogueiras = porAutor.size;

  return {
    resumo,
    grupos,
    autores: [...porAutor.values()].sort((a, b) => b.repeticoes - a.repeticoes),
    porPedido,
  };
}

// Relatório por Brogueira. Só quem NÃO é operador entra — é esse o recorte
// pedido: "as mensagens mandadas pelas Brogueiras".
//
// montanteTotal soma só pedidos de montante e contasTotal só pedidos de conta:
// em "200 2 contas" o 2 diz em quantas contas dividir o montante, não é um
// pedido de 2 contas. Misturar os dois inflaria os dois números.
export function relatorioBrogueiras(period = 'today', { incluirOperadores = false, sessao = null } = {}) {
  const pedidos = filtrarPedidos(period, sessao).filter((p) => (incluirOperadores ? true : p.papel !== 'operador'));
  const repetidos = relatorioRepetidos(period, { incluirOperadores, sessao });

  const porAutor = new Map();
  const resumo = { pedidos: 0, montanteTotal: 0, montantePedidos: 0, contasTotal: 0, contasPedidos: 0, indefinidos: 0, links: 0 };
  const dominios = new Map();

  for (const p of pedidos) {
    const chave = p.autorId ?? p.autorNome;
    const a = porAutor.get(chave) ?? {
      id: p.autorId, pn: p.autorPn, nome: p.autorNome, papel: p.papel,
      pedidos: 0, montanteTotal: 0, montantePedidos: 0, contasTotal: 0, contasPedidos: 0,
      indefinidos: 0, repetidos: 0, repetidosDeOutra: 0, links: [], dias: new Map(), ultimoEm: null,
    };
    a.nome = p.autorNome || a.nome;
    a.pedidos += 1;
    resumo.pedidos += 1;

    const repeticao = repetidos.porPedido.get(p.id) ?? null;
    if (repeticao) {
      a.repetidos += 1;
      if (repeticao.deOutra) a.repetidosDeOutra += 1;
    }

    if (p.tipo === 'montante') {
      a.montanteTotal += num(p.montante);
      a.montantePedidos += 1;
      resumo.montanteTotal += num(p.montante);
      resumo.montantePedidos += 1;
    } else if (p.tipo === 'conta') {
      a.contasTotal += num(p.contas);
      a.contasPedidos += 1;
      resumo.contasTotal += num(p.contas);
      resumo.contasPedidos += 1;
    } else {
      a.indefinidos += 1;
      resumo.indefinidos += 1;
    }

    for (const l of p.links) {
      if (!a.links.includes(l)) a.links.push(l);
      resumo.links += 1;
    }
    for (const d of p.dominios) dominios.set(d, (dominios.get(d) ?? 0) + 1);

    // "quais os links que cada uma mandou por dia"
    const dia = a.dias.get(p.day) ?? { day: p.day, pedidos: [] };
    dia.pedidos.push({
      id: p.id, ts: p.ts, tipo: p.tipo, montante: num(p.montante),
      contas: p.contas, links: p.links, pedido: p.pedido, groupName: p.groupName,
      repeticao, // null quando o link é inédito
    });
    a.dias.set(p.day, dia);
    if (!a.ultimoEm || p.ts > a.ultimoEm) a.ultimoEm = p.ts;

    porAutor.set(chave, a);
  }

  const brogueiras = [...porAutor.values()]
    .map((a) => ({
      ...a,
      links: a.links.slice(0, 200),
      dias: [...a.dias.values()].sort((x, y) => (x.day < y.day ? 1 : -1)),
    }))
    .sort((a, b) => b.montanteTotal - a.montanteTotal || b.contasTotal - a.contasTotal);

  return {
    resumo: {
      ...resumo,
      brogueirasAtivas: brogueiras.length,
      linksRepetidos: repetidos.resumo.links,
      repeticoes: repetidos.resumo.repeticoes,
      repeticoesDeOutras: repetidos.resumo.deOutras,
    },
    brogueiras,
    plataformas: [...dominios.entries()].map(([dominio, qtd]) => ({ dominio, qtd })).sort((a, b) => b.qtd - a.qtd),
    // porPedido é um Map (índice interno) e não sobrevive ao JSON — fica fora.
    repetidos: { resumo: repetidos.resumo, grupos: repetidos.grupos, autores: repetidos.autores },
  };
}

/**
 * O salário do Operador num atendimento: o que ele cobrou pelo serviço.
 *
 * Campo próprio desde 31/08/2026. Antes a comissão lia `contasTotal`, que só é
 * preenchido quando a mensagem traz a palavra "Valor" — e o template mais usado
 * no grupo escreve o preço como "💸 R$ 20" solto, o que zerava a comissão de
 * mais da metade dos serviços. O fallback para `contasTotal` cobre o registro
 * antigo que nunca passou pelo backfill.
 */
export function salarioDoAtendimento(a) {
  return num(a?.salario ?? a?.contasTotal);
}

/* ═══════════ Serviços validados em 3 passos ═══════════
   Um "serviço" amarra três mensagens diferentes:

     1. o pedido da Brogueira      (db.pedidos)
     2. a resposta do Operador     (db.messages — a mensagem com Montante/Valor)
     3. o comprovante PIX dela     (imagem ou PDF, que não vira registro nenhum)

   O serviço nasce no passo 1 e vai mudando de status. Só o que chega ao fim
   conta no quadro DESEMPENHO DOS OPERADORES — o quadro antigo continua
   somando toda mensagem financeira, tenha ela fechado o ciclo ou não.

   Por que um array próprio e não um campo no pedido: o serviço é a relação
   entre os três, tem status e prazo próprios, e é lido por outro relatório.
   Misturar isso no pedido embaralharia a aba Brogueiras, que fala de quem
   PEDE, não de quem ATENDE. */

const MAX_SERVICOS = 5000;
// Serviço em aberto vive horas, não dias: procurar candidato no fim da lista
// basta e evita varrer 5000 registros a cada mensagem do grupo.
const JANELA_SERVICOS = 400;

function listaServicos() {
  const db = getDb();
  if (!Array.isArray(db.servicos)) db.servicos = [];
  return db.servicos;
}

// Configuração viva da validação (prazos e modo de casamento).
export function cfgServicos() {
  return configServicos(getDb().config);
}

// Só a cauda da lista — ver JANELA_SERVICOS.
function recentes() {
  const lista = listaServicos();
  return lista.slice(Math.max(0, lista.length - JANELA_SERVICOS));
}

/**
 * Passo 1 — a Brogueira pediu. Abre o serviço a partir do pedido já gravado.
 * Devolve null para pedido de Operador (ele reposta divulgação; não é pedido
 * de serviço) e para pedido sem link legível.
 */
export function abrirServico(pedido) {
  if (!pedido || pedido.papel === 'operador') return null;
  const db = getDb();
  const lista = listaServicos();
  const when = dayjs(pedido.ts ?? undefined);
  seq = (seq + 1) % 1_000_000;
  const servico = {
    id: `s${when.valueOf()}-${seq.toString(36)}`,
    ts: when.toISOString(),
    day: pedido.day ?? dayKey(when.valueOf()),
    sessaoId: pedido.sessaoId ?? SESSAO_PADRAO,
    groupId: pedido.groupId ?? null,
    groupName: pedido.groupName ?? null,
    status: STATUS.AGUARDANDO_ATENDIMENTO,
    // Passo 1
    pedidoId: pedido.id,
    pedidoMsgId: pedido.msgId ?? null,
    pedidoTs: when.toISOString(),
    brogueiraId: pedido.autorId ?? null,
    brogueiraPn: pedido.autorPn ?? null,
    brogueiraChave: chavePessoa({ id: pedido.autorId, pn: pedido.autorPn }),
    brogueiraNome: pedido.autorNome || 'desconhecida',
    tipo: pedido.tipo,
    montantePedido: num(pedido.montante),
    contasPedidas: pedido.contas == null ? 0 : num(pedido.contas),
    links: Array.isArray(pedido.links) ? pedido.links.slice(0, 5) : [],
    pedidoTexto: String(pedido.pedido ?? '').slice(0, 200),
    // Passos 2 e 3 (preenchidos quando acontecerem)
    atendimento: null,
    comprovante: null,
    validadoEm: null,
  };
  lista.push(servico);
  if (lista.length > MAX_SERVICOS) lista.splice(0, lista.length - MAX_SERVICOS);
  saveDb();
  return servico;
}

/**
 * Passo 2 — o Operador respondeu. `entrada` é o lançamento já gravado em
 * db.messages. Devolve o serviço casado (ou null quando nada casa: o Operador
 * mandou uma mensagem financeira sem pedido correspondente).
 */
export function casarAtendimento(entrada, { citacao = null, agora = Date.now() } = {}) {
  const cfg = cfgServicos();
  if (!cfg.ligado || !entrada?.groupId) return null;
  expirarServicos(agora);

  const abertos = recentes().filter(
    (s) => s.groupId === entrada.groupId && s.status === STATUS.AGUARDANDO_ATENDIMENTO,
  );
  const escolha = escolherAtendimento(abertos, { entrada, citacao, agora, cfg });
  if (!escolha) return null;

  const { servico, casamento } = escolha;
  servico.atendimento = {
    entradaId: entrada.id,
    msgId: entrada.msgId ?? null,
    ts: entrada.ts,
    sessaoId: entrada.sessaoId ?? SESSAO_PADRAO,
    operatorId: entrada.operatorId ?? null,
    operatorPn: entrada.operatorPn ?? null,
    operatorName: entrada.operatorName || 'desconhecido',
    montante: num(entrada.montante),
    contasQtd: num(entrada.contasQtd),
    contasTotal: num(entrada.contasTotal),
    // Base da comissão. Cai em contasTotal para o registro antigo, gravado
    // antes de o salário existir como campo próprio.
    salario: num(entrada.salario ?? entrada.contasTotal),
    casamento, // 'citacao' | 'valor' | 'tempo'
  };
  servico.status = STATUS.AGUARDANDO_COMPROVANTE;
  saveDb();
  return servico;
}

// O mesmo comprovante já foi usado? O id da mensagem é o mesmo em todos os
// números, então sem isto dois números no grupo validariam duas vezes.
export function comprovanteJaRegistrado(msgId) {
  if (!msgId) return false;
  return recentes().some((s) => s.comprovante?.msgId === msgId);
}

/**
 * Passo 3 — a Brogueira mandou o comprovante (imagem ou PDF). Fecha o serviço.
 * `autor` é quem mandou o arquivo; só valida serviço DELA (é o pedido dela que
 * está sendo pago). Devolve o serviço validado ou null.
 */
export function casarComprovante({
  groupId, autor, comprovante, msgId, sessaoId, citacao = null, ts, agora = Date.now(),
}) {
  const cfg = cfgServicos();
  if (!cfg.ligado || !groupId) return null;
  if (comprovanteJaRegistrado(msgId)) return null;
  expirarServicos(agora);

  const chave = chavePessoa(autor ?? {});
  const digitos = new Set([soDigitos(autor?.id), soDigitos(autor?.pn)].filter(Boolean));
  const dela = (s) =>
    (chave && s.brogueiraChave === chave) ||
    (s.brogueiraId && s.brogueiraId === autor?.id) ||
    // LID x telefone: a mesma pessoa pode aparecer pelas duas formas.
    digitos.has(soDigitos(s.brogueiraId)) ||
    digitos.has(soDigitos(s.brogueiraPn));

  const pendentes = recentes().filter(
    (s) => s.groupId === groupId && s.status === STATUS.AGUARDANDO_COMPROVANTE && dela(s),
  );
  const escolha = escolherComprovante(pendentes, { citacao, agora, cfg });
  if (!escolha) return null;

  const { servico, casamento } = escolha;
  const when = ts ? dayjs(ts) : dayjs(agora);
  servico.comprovante = {
    msgId: msgId ?? null,
    ts: when.toISOString(),
    sessaoId: sessaoId ?? SESSAO_PADRAO,
    tipo: comprovante?.tipo ?? 'imagem', // 'imagem' | 'pdf'
    mime: comprovante?.mime ?? null,
    nome: comprovante?.nome ? String(comprovante.nome).slice(0, 120) : null,
    legenda: String(comprovante?.legenda ?? '').slice(0, 200),
    casamento,
  };
  servico.status = STATUS.VALIDADO;
  servico.validadoEm = when.toISOString();
  saveDb();
  return servico;
}

/**
 * Passa para 'expirado' o que estourou o prazo. Roda antes de casar e antes de
 * relatar — é o que impede a mensagem de agora de fechar um pedido de ontem.
 * A distinção importa no funil: ninguém atendeu x atenderam e não comprovou.
 */
export function expirarServicos(agora = Date.now()) {
  const cfg = cfgServicos();
  const lista = listaServicos();
  let mudou = false;
  for (let i = Math.max(0, lista.length - JANELA_SERVICOS); i < lista.length; i++) {
    const s = lista[i];
    if (s.status === STATUS.AGUARDANDO_ATENDIMENTO) {
      if (agora - Date.parse(s.pedidoTs) > cfg.janelaAtendimentoMs) {
        s.status = STATUS.SEM_ATENDIMENTO;
        mudou = true;
      }
    } else if (s.status === STATUS.AGUARDANDO_COMPROVANTE) {
      if (agora - Date.parse(s.atendimento?.ts ?? s.pedidoTs) > cfg.janelaComprovanteMs) {
        s.status = STATUS.SEM_COMPROVANTE;
        mudou = true;
      }
    }
  }
  if (mudou) saveDb();
  return mudou;
}

// period: 'today' | 'all' | {day:'YYYY-MM-DD'} — o dia é o do PEDIDO (passo 1).
export function filtrarServicos(period = 'today', sessaoId = null) {
  const intervalo = intervaloPeriodo(period);
  return listaServicos().filter((s) => daSessao(s, sessaoId) && noIntervalo(s.day, intervalo));
}

// Quantas contas um serviço vale, e por quanto. Só pedido de CONTA conta
// contas: em "400 montante 2 contas" o 2 é em quantas contas o montante é
// dividido, não um pedido de 2 contas — somá-lo misturaria as duas medidas.
// A quantidade vem do PEDIDO (o que a Brogueira pediu: "12 contas de 10" = 12);
// antes vinha de `contasQtd`, o nº de rótulos "Valor:" da resposta do Operador
// — quase sempre 1 —, e o painel mostrava 1 conta por serviço no lugar de 12.
// O valor continua sendo o que ele cobrou (o "Valor: R$ x" da resposta).
function contasDoServico(s) {
  return s?.tipo === 'conta' ? num(s.contasPedidas) : 0;
}

function contasValorDoServico(s) {
  return s?.tipo === 'conta' ? num(s.atendimento?.contasTotal) : 0;
}

// A medida do quadro AZUL do Painel ("Contas (R$)"): o valor rotulado "Valor:"
// na mensagem do Operador, de TODO serviço atendido — não só os de conta. É a
// série que o quadro verde mostra ao lado do montante validado, para os dois
// quadros falarem da mesma coisa. Não confundir com contasDoServico(), que é
// quantidade de contas pedidas.
function contasRsDoServico(s) {
  return num(s?.atendimento?.contasTotal);
}

/**
 * DESEMPENHO DOS OPERADORES — só o que passou pelos 3 passos.
 *
 * Por operador: quanto ele fechou (validado) x quanto ele atendeu e não fechou.
 * Os dois na mesma unidade (R$) para o gráfico empilhar um sobre o outro e a
 * taxa de conclusão ser lida direto da barra.
 */
export function relatorioServicos(period = 'today', { sessao = null, limiteDetalhe = 200 } = {}) {
  expirarServicos();
  const servicos = filtrarServicos(period, sessao);

  const ops = new Map();
  const resumo = {
    pedidos: servicos.length,
    atendidos: 0,
    validados: 0,
    aguardandoAtendimento: 0,
    aguardandoComprovante: 0,
    semAtendimento: 0,
    semComprovante: 0,
    montanteValidado: 0,
    montanteNaoValidado: 0,
    // Quantos MONTANTES o quadro está contando — o placar acima do gráfico.
    // "Pego" = o Operador respondeu e disse um montante; "validado" = a
    // Brogueira ainda comprovou. Conta o serviço que tem montante de verdade
    // (atendimento.montante > 0), não o de tipo 'montante': um pedido de conta
    // às vezes é respondido com montante, e é esse dinheiro que as barras deste
    // mesmo quadro somam. Contagem e R$ têm de falar do mesmo conjunto.
    montantesPegos: 0,
    montantesValidados: 0,
    contasValidadasQtd: 0,
    contasValidadasValor: 0,
    contasNaoValidadasQtd: 0,
    contasNaoValidadasValor: 0,
    // em R$, a série do quadro azul (validada x atendida sem comprovante)
    contasRsValidado: 0,
    contasRsNaoValidado: 0,
    porCasamento: { citacao: 0, valor: 0, tempo: 0 },
    brogueiras: 0,
  };
  const brogueiras = new Set();

  for (const s of servicos) {
    if (s.brogueiraChave) brogueiras.add(s.brogueiraChave);
    if (s.status === STATUS.AGUARDANDO_ATENDIMENTO) resumo.aguardandoAtendimento += 1;
    if (s.status === STATUS.AGUARDANDO_COMPROVANTE) resumo.aguardandoComprovante += 1;
    if (s.status === STATUS.SEM_ATENDIMENTO) resumo.semAtendimento += 1;
    if (s.status === STATUS.SEM_COMPROVANTE) resumo.semComprovante += 1;
    if (!s.atendimento) continue;

    const a = s.atendimento;
    const validado = s.status === STATUS.VALIDADO;
    const temMontante = num(a.montante) > 0;
    resumo.atendidos += 1;
    if (temMontante) resumo.montantesPegos += 1;
    if (validado) {
      resumo.validados += 1;
      if (temMontante) resumo.montantesValidados += 1;
      resumo.montanteValidado += num(a.montante);
      resumo.contasValidadasQtd += contasDoServico(s);
      resumo.contasValidadasValor += contasValorDoServico(s);
      resumo.contasRsValidado += contasRsDoServico(s);
      resumo.porCasamento[a.casamento] = (resumo.porCasamento[a.casamento] ?? 0) + 1;
    } else {
      resumo.montanteNaoValidado += num(a.montante);
      resumo.contasNaoValidadasQtd += contasDoServico(s);
      resumo.contasNaoValidadasValor += contasValorDoServico(s);
      resumo.contasRsNaoValidado += contasRsDoServico(s);
    }

    const chave = a.operatorId ?? a.operatorName;
    const o = ops.get(chave) ?? {
      id: a.operatorId, pn: a.operatorPn, nome: a.operatorName || 'desconhecido',
      atendidos: 0, validados: 0, montanteValidado: 0, montanteNaoValidado: 0,
      contasQtd: 0, contasValor: 0, contasNaoValidadasQtd: 0, contasNaoValidadasValor: 0,
      contasRsValidado: 0, contasRsNaoValidado: 0,
      aguardando: 0, semComprovante: 0,
      casamento: { citacao: 0, valor: 0, tempo: 0 }, serie: [], ultimoEm: null,
    };
    o.nome = a.operatorName || o.nome;
    o.atendidos += 1;
    if (validado) {
      o.validados += 1;
      o.montanteValidado += num(a.montante);
      o.contasQtd += contasDoServico(s);
      o.contasValor += contasValorDoServico(s);
      o.contasRsValidado += contasRsDoServico(s);
      o.casamento[a.casamento] = (o.casamento[a.casamento] ?? 0) + 1;
      o.serie.push(num(a.montante));
    } else {
      o.montanteNaoValidado += num(a.montante);
      // As contas do serviço que ele pegou e ainda não fechou — é o trecho de
      // cima da coluna de contas no quadro DESEMPENHO DOS OPERADORES.
      o.contasNaoValidadasQtd += contasDoServico(s);
      o.contasNaoValidadasValor += contasValorDoServico(s);
      o.contasRsNaoValidado += contasRsDoServico(s);
      if (s.status === STATUS.AGUARDANDO_COMPROVANTE) o.aguardando += 1;
      if (s.status === STATUS.SEM_COMPROVANTE) o.semComprovante += 1;
    }
    if (!o.ultimoEm || a.ts > o.ultimoEm) o.ultimoEm = a.ts;
    ops.set(chave, o);
  }

  resumo.brogueiras = brogueiras.size;
  resumo.taxa = resumo.atendidos ? resumo.validados / resumo.atendidos : 0;

  const operadores = [...ops.values()]
    .map((o) => ({
      ...o,
      taxa: o.atendidos ? o.validados / o.atendidos : 0,
      serie: o.serie.slice(-10),
    }))
    .sort((a, b) => b.montanteValidado - a.montanteValidado || b.validados - a.validados);

  // Linha do tempo dos 3 passos, do mais recente para o mais antigo. É a prova
  // que o painel mostra na tabela — sem ela o gráfico seria só um número.
  const detalhe = servicos
    .filter((s) => s.atendimento)
    .sort((a, b) => String(b.atendimento.ts).localeCompare(String(a.atendimento.ts)))
    .slice(0, Math.max(0, limiteDetalhe))
    .map((s) => ({
      id: s.id,
      status: s.status,
      day: s.day,
      groupName: s.groupName,
      brogueiraNome: s.brogueiraNome,
      tipo: s.tipo,
      montantePedido: s.montantePedido,
      contasPedidas: s.contasPedidas,
      pedidoTs: s.pedidoTs,
      pedidoTexto: s.pedidoTexto,
      links: s.links,
      operatorName: s.atendimento.operatorName,
      operatorId: s.atendimento.operatorId,
      atendimentoTs: s.atendimento.ts,
      montante: s.atendimento.montante,
      // as contas DO SERVIÇO (o que ela pediu), a mesma medida dos KPIs — o
      // nº de rótulos "Valor:" da resposta continua em contasCotadas.
      contasQtd: contasDoServico(s),
      contasTotal: contasValorDoServico(s),
      contasCotadas: s.atendimento.contasQtd,
      casamento: s.atendimento.casamento,
      comprovanteTs: s.comprovante?.ts ?? null,
      comprovanteTipo: s.comprovante?.tipo ?? null,
      comprovanteCasamento: s.comprovante?.casamento ?? null,
    }));

  return { resumo, operadores, servicos: detalhe };
}

/* ═══════════ Ranking dos Operadores ═══════════
   "Quais e quanto os Operadores pegaram de serviço" no período.

   Duas fontes, porque medem coisas diferentes e as duas interessam:

     • db.servicos → o que ele PEGOU: pedido de Brogueira que ele atendeu, e
       quantos desses fecharam com comprovante (a validação de 3 passos).
     • db.messages → o que ele LANÇOU: toda mensagem financeira dele, tenha
       casado com um pedido ou não. É o número do quadro antigo do Painel.

   Um Operador aparece se tiver qualquer uma das duas — quem lançou sem pedido
   em aberto não pode sumir do ranking. */

export function rankingOperadores(period = 'today', { sessao = null } = {}) {
  expirarServicos();
  const entradas = filtrarEntradas(period, sessao);
  const servicos = filtrarServicos(period, sessao).filter((s) => s.atendimento);

  const ops = new Map();
  const novo = (id, pn, nome) => ({
    id: id ?? null, pn: pn ?? null, nome: nome || 'desconhecido',
    // pegos
    servicos: 0, validados: 0, aguardando: 0, semComprovante: 0,
    montanteValidado: 0, montanteAtendido: 0,
    // Contas em dois recortes: as que ele PEGOU (todo serviço atendido) e as
    // que fecharam com comprovante. O painel mostra uma ou outra conforme o
    // filtro — misturar as duas daria um número que não é nem um nem outro.
    contasPegasQtd: 0, contasPegasValor: 0,
    contasValidadasQtd: 0, contasValidadasValor: 0,
    casamento: { citacao: 0, valor: 0, tempo: 0 },
    // lançados (o quadro antigo)
    lancamentos: 0, montanteLancado: 0, contasQtd: 0, contasValor: 0,
    brogueiras: new Set(), dias: new Map(),
    primeiroEm: null, ultimoEm: null, ultimosServicos: [],
  });

  const pegar = (id, pn, nome) => {
    const chave = id ?? nome ?? 'desconhecido';
    const o = ops.get(chave) ?? novo(id, pn, nome);
    if (nome) o.nome = nome;
    if (pn && !o.pn) o.pn = pn;
    ops.set(chave, o);
    return o;
  };

  const dia = (o, day) => {
    const d = o.dias.get(day) ?? {
      day, servicos: 0, validados: 0, montanteValidado: 0,
      contasPegasQtd: 0, contasValidadasQtd: 0, lancamentos: 0, montanteLancado: 0, contasQtd: 0,
    };
    o.dias.set(day, d);
    return d;
  };

  // ── o que cada um lançou ──
  for (const e of entradas) {
    const o = pegar(e.operatorId, e.operatorPn, e.operatorName);
    o.lancamentos += 1;
    o.montanteLancado += num(e.montante);
    o.contasQtd += num(e.contasQtd);
    o.contasValor += num(e.contasTotal);
    const d = dia(o, e.day);
    d.lancamentos += 1;
    d.montanteLancado += num(e.montante);
    d.contasQtd += num(e.contasQtd);
    if (!o.primeiroEm || e.ts < o.primeiroEm) o.primeiroEm = e.ts;
    if (!o.ultimoEm || e.ts > o.ultimoEm) o.ultimoEm = e.ts;
  }

  // ── o que cada um pegou ──
  for (const s of servicos) {
    const a = s.atendimento;
    const o = pegar(a.operatorId, a.operatorPn, a.operatorName);
    const validado = s.status === STATUS.VALIDADO;
    o.servicos += 1;
    o.montanteAtendido += num(a.montante);
    o.contasPegasQtd += contasDoServico(s);
    o.contasPegasValor += contasValorDoServico(s);
    if (s.brogueiraChave) o.brogueiras.add(s.brogueiraChave);
    if (validado) {
      o.validados += 1;
      o.montanteValidado += num(a.montante);
      o.contasValidadasQtd += contasDoServico(s);
      o.contasValidadasValor += contasValorDoServico(s);
      o.casamento[a.casamento] = (o.casamento[a.casamento] ?? 0) + 1;
    } else if (s.status === STATUS.AGUARDANDO_COMPROVANTE) o.aguardando += 1;
    else if (s.status === STATUS.SEM_COMPROVANTE) o.semComprovante += 1;

    const d = dia(o, s.day);
    d.servicos += 1;
    d.contasPegasQtd += contasDoServico(s);
    if (validado) {
      d.validados += 1;
      d.montanteValidado += num(a.montante);
      d.contasValidadasQtd += contasDoServico(s);
    }

    o.ultimosServicos.push({
      id: s.id, status: s.status, day: s.day,
      brogueiraNome: s.brogueiraNome, groupName: s.groupName,
      pedidoTs: s.pedidoTs, pedidoTexto: s.pedidoTexto, tipo: s.tipo,
      atendimentoTs: a.ts, montante: num(a.montante), contasQtd: contasDoServico(s),
      casamento: a.casamento, comprovanteTs: s.comprovante?.ts ?? null,
      comprovanteTipo: s.comprovante?.tipo ?? null,
    });
    if (!o.ultimoEm || a.ts > o.ultimoEm) o.ultimoEm = a.ts;
  }

  // O detalhe é do último para o primeiro e tem teto: no "Este ano" um
  // Operador sozinho pode ter milhares, e a lista inteira só pesaria a resposta.
  const MAX_DETALHE = 120;
  const operadores = [...ops.values()]
    .map((o) => ({
      ...o,
      brogueiras: o.brogueiras.size,
      taxa: o.servicos ? o.validados / o.servicos : 0,
      dias: [...o.dias.values()].sort((a, b) => (a.day < b.day ? 1 : -1)),
      ultimosServicos: o.ultimosServicos
        .sort((a, b) => String(b.atendimentoTs).localeCompare(String(a.atendimentoTs)))
        .slice(0, MAX_DETALHE),
    }))
    // "Quantos pegou" é o que o ranking mede; o valor validado desempata, e o
    // montante lançado ainda segura quem só tem lançamento sem pedido casado.
    .sort((a, b) => b.servicos - a.servicos || b.montanteValidado - a.montanteValidado || b.montanteLancado - a.montanteLancado);

  const resumo = operadores.reduce((r, o) => ({
    operadores: r.operadores + 1,
    servicos: r.servicos + o.servicos,
    validados: r.validados + o.validados,
    aguardando: r.aguardando + o.aguardando,
    semComprovante: r.semComprovante + o.semComprovante,
    montanteValidado: r.montanteValidado + o.montanteValidado,
    montanteAtendido: r.montanteAtendido + o.montanteAtendido,
    montanteLancado: r.montanteLancado + o.montanteLancado,
    lancamentos: r.lancamentos + o.lancamentos,
    contasPegasQtd: r.contasPegasQtd + o.contasPegasQtd,
    contasPegasValor: r.contasPegasValor + o.contasPegasValor,
    contasValidadasQtd: r.contasValidadasQtd + o.contasValidadasQtd,
    contasValidadasValor: r.contasValidadasValor + o.contasValidadasValor,
    contasQtd: r.contasQtd + o.contasQtd,
    contasValor: r.contasValor + o.contasValor,
  }), {
    operadores: 0, servicos: 0, validados: 0, aguardando: 0, semComprovante: 0,
    montanteValidado: 0, montanteAtendido: 0, montanteLancado: 0, lancamentos: 0,
    contasPegasQtd: 0, contasPegasValor: 0, contasValidadasQtd: 0, contasValidadasValor: 0,
    contasQtd: 0, contasValor: 0,
  });
  resumo.taxa = resumo.servicos ? resumo.validados / resumo.servicos : 0;
  resumo.periodo = rotuloPeriodo(period);

  return { resumo, operadores };
}

/* ═══════════ Quem é quem (memória de nomes) ═══════════
   O WhatsApp só entrega o nome de quem ESTÁ falando (`pushName`). Numa
   indicação a pessoa citada é outra — e quase sempre uma que ainda não falou.
   Guardando cada remetente conforme ele aparece, "@5511999999999" vira "Ana"
   assim que a Ana escreve qualquer coisa no grupo, inclusive retroativamente:
   o painel resolve o nome na hora de montar o relatório, não na hora do
   registro. */

// Chave estável de uma pessoa: o JID quando existe, senão os dígitos.
export function chavePessoa({ id, pn, digitos } = {}) {
  if (id) return String(id);
  const d = digitos || soDigitos(pn);
  return d ? `d:${d}` : null;
}

// Todas as formas em dígitos de uma pessoa (LID e telefone são diferentes).
function digitosDe({ id, pn, digitos }) {
  const out = new Set(Array.isArray(digitos) ? digitos : digitos ? [digitos] : []);
  for (const forma of [id, pn]) {
    const d = soDigitos(forma);
    if (d) out.add(d);
  }
  return [...out];
}

let nomesCache = null; // invalidado a cada escrita em db.pessoas

// Registra/atualiza alguém visto num grupo. `nome` só sobrescreve quando vem
// preenchido: uma mensagem sem pushName não pode apagar o nome já conhecido.
export function registrarPessoa({ id, pn, nome, groupId } = {}) {
  const chave = chavePessoa({ id, pn });
  if (!chave) return null;
  const db = getDb();
  if (!db.pessoas || typeof db.pessoas !== 'object') db.pessoas = {};

  const atual = db.pessoas[chave] ?? { chave, id: id ?? null, pn: null, nome: null, digitos: [], vistaEm: null };
  if (id && !atual.id) atual.id = String(id);
  if (pn) atual.pn = String(pn);
  const limpo = String(nome ?? '').trim().slice(0, 80);
  // O cache de nomes só cai quando o nome muda de verdade: registrarPessoa()
  // roda a cada mensagem do grupo, e recalcular o índice sempre seria caro.
  if (limpo && limpo !== atual.nome) {
    atual.nome = limpo;
    nomesCache = null;
  }
  atual.digitos = [...new Set([...atual.digitos, ...digitosDe({ id, pn })])];
  atual.vistaEm = new Date().toISOString();
  if (groupId) atual.groupId = groupId;

  db.pessoas[chave] = atual;
  podarPessoas(db);
  saveDb();
  return atual;
}

// O registro é limitado por quantas pessoas distintas falam nos grupos — na
// prática, centenas. O teto existe para o db.json não crescer sem fim se o bot
// for posto para monitorar tudo: sai quem não fala há mais tempo.
const MAX_PESSOAS = 20000;

function podarPessoas(db) {
  const chaves = Object.keys(db.pessoas);
  if (chaves.length <= MAX_PESSOAS) return;
  const ordenadas = chaves.sort((a, b) => String(db.pessoas[a].vistaEm).localeCompare(String(db.pessoas[b].vistaEm)));
  for (const chave of ordenadas.slice(0, chaves.length - MAX_PESSOAS)) delete db.pessoas[chave];
  nomesCache = null;
}

// Nomes já vistos, dobrados (minúsculos e sem acento) — é o que permite
// aceitar "vim pela ana" escrito sem maiúscula e sem menção.
export function nomesConhecidos() {
  if (nomesCache) return nomesCache;
  const db = getDb();
  nomesCache = new Set();
  for (const p of Object.values(db.pessoas ?? {})) {
    if (!p?.nome) continue;
    // Guarda o nome inteiro e cada parte: no grupo chamam pelo primeiro nome.
    nomesCache.add(dobrar(p.nome));
    for (const parte of dobrar(p.nome).split(/\s+/)) if (parte.length >= 3) nomesCache.add(parte);
  }
  return nomesCache;
}

// Encontra uma pessoa por JID, por dígitos ou por nome — nessa ordem, da
// identificação mais forte para a mais frágil.
export function resolverPessoa({ id, digitos, nome } = {}) {
  const db = getDb();
  const pessoas = Object.values(db.pessoas ?? {});
  if (id && db.pessoas?.[String(id)]) return db.pessoas[String(id)];

  const alvo = digitos || soDigitos(id);
  if (alvo) {
    const exata = pessoas.find((p) => p.digitos?.includes(alvo));
    if (exata) return exata;
    // Número com/sem código do país ou com o nono dígito a mais.
    const parcial = pessoas.find((p) =>
      p.digitos?.some((d) => d.length >= 8 && (d.endsWith(alvo) || alvo.endsWith(d))));
    if (parcial) return parcial;
  }

  const chave = nome ? dobrar(String(nome)) : null;
  if (chave && chave.length >= 3) {
    return (
      pessoas.find((p) => p.nome && dobrar(p.nome) === chave) ??
      pessoas.find((p) => p.nome && dobrar(p.nome).split(/\s+/).includes(chave)) ??
      null
    );
  }
  return null;
}

/* ═══════════ Indicações (quem trouxe quem) ═══════════ */

const MAX_INDICACOES = 5000;

// Rótulo de uma indicadora que ainda não foi identificada: o número cru é
// melhor do que "desconhecida" — dá para procurar por ele no grupo.
function rotuloIndicadora({ nome, digitos, id }) {
  if (nome) return String(nome).slice(0, 80);
  if (digitos) return `@${digitos}`;
  return id ? String(id).split('@')[0] : 'desconhecida';
}

/**
 * Registra uma indicação. `indicada` é quem enviou a mensagem; `indicadora` é
 * quem foi citada (já resolvida contra as menções reais, em indicacoes.js).
 *
 * Devolve null quando não há indicação a registrar (auto-indicação).
 * Uma indicada que se apresenta duas vezes não conta duas: a repetição fica
 * gravada com `duplicada: true` — visível no painel, fora do ranking.
 */
export function registrarIndicacao({ sessaoId, msgId, groupId, groupName, indicada, indicadora, analise, text, ts }) {
  const db = getDb();
  if (!Array.isArray(db.indicacoes)) db.indicacoes = [];

  const chaveIndicada = chavePessoa(indicada ?? {});
  const conhecida = resolverPessoa(indicadora ?? {});
  const chaveIndicadora = chavePessoa(conhecida ?? indicadora ?? {});
  if (!chaveIndicada || !chaveIndicadora) return null;
  // Ninguém indica a si mesma. Acontece quando a pessoa cita o próprio número.
  if (chaveIndicada === chaveIndicadora) return null;

  const when = ts ? dayjs(ts) : dayjs();
  seq = (seq + 1) % 1_000_000;
  const entry = {
    id: `i${when.valueOf()}-${seq.toString(36)}`,
    ts: when.toISOString(),
    day: dayKey(when.valueOf()),
    sessaoId: sessaoId ?? SESSAO_PADRAO,
    msgId: msgId ?? null,
    groupId: groupId ?? null,
    groupName: groupName ?? null,
    // A indicada — quem chegou. É o registro que responde "quem foi indicada".
    indicadaChave: chaveIndicada,
    indicadaId: indicada?.id ?? null,
    indicadaPn: indicada?.pn ?? null,
    indicadaNome: indicada?.nome || 'desconhecida',
    indicadaPapel: indicada?.papel ?? 'desconhecido',
    // A indicadora — quem trouxe. Pode não ter nome ainda.
    indicadoraChave: chaveIndicadora,
    indicadoraId: conhecida?.id ?? indicadora?.id ?? null,
    indicadoraPn: conhecida?.pn ?? null,
    indicadoraDigitos: indicadora?.digitos ?? null,
    indicadoraNome: rotuloIndicadora({
      nome: conhecida?.nome ?? indicadora?.nome,
      digitos: indicadora?.digitos,
      id: indicadora?.id,
    }),
    padrao: analise?.padrao ?? null,
    viaMencao: Boolean(analise?.viaMencao),
    frase: String(analise?.frase ?? '').slice(0, 120),
    // Repetição da mesma indicada: gravada, mas fora da contagem.
    duplicada: db.indicacoes.some((i) => i.indicadaChave === chaveIndicada && !i.duplicada),
    text: String(text ?? '').slice(0, 500),
  };

  db.indicacoes.push(entry);
  if (db.indicacoes.length > MAX_INDICACOES) db.indicacoes.splice(0, db.indicacoes.length - MAX_INDICACOES);
  saveDb();
  return entry;
}

// period: 'today' | 'all' | {day:'YYYY-MM-DD'}
export function filtrarIndicacoes(period = 'today', sessaoId = null) {
  const db = getDb();
  const intervalo = intervaloPeriodo(period);
  return (Array.isArray(db.indicacoes) ? db.indicacoes : [])
    .filter((i) => daSessao(i, sessaoId) && noIntervalo(i.day, intervalo));
}

/**
 * Ranking das indicadoras + a memória de quem foi indicada.
 *
 * Só indicações não duplicadas contam para o ranking: uma Brogueira que se
 * apresenta três vezes valeria três pontos para quem a trouxe.
 *
 * O nome da indicadora é resolvido AGORA, não no registro: quem foi citada
 * antes de falar pela primeira vez aparece com nome assim que fala.
 */
export function relatorioIndicacoes(period = 'today', { sessao = null } = {}) {
  const todas = filtrarIndicacoes(period, sessao);
  const validas = todas.filter((i) => !i.duplicada);

  const porIndicadora = new Map();
  const indicadas = [];
  let semMencao = 0;
  let semNome = 0;

  for (const i of validas) {
    const pessoa = resolverPessoa({ id: i.indicadoraId, digitos: i.indicadoraDigitos, nome: i.indicadoraNome });
    const nome = pessoa?.nome || i.indicadoraNome;
    const a = porIndicadora.get(i.indicadoraChave) ?? {
      chave: i.indicadoraChave,
      id: i.indicadoraId,
      pn: pessoa?.pn ?? i.indicadoraPn ?? null,
      digitos: i.indicadoraDigitos,
      nome,
      identificada: Boolean(pessoa?.nome),
      indicacoes: 0,
      semMencao: 0,
      indicadas: [],
      primeiraEm: null,
      ultimaEm: null,
    };
    a.nome = nome;
    a.identificada = a.identificada || Boolean(pessoa?.nome);
    a.indicacoes += 1;
    if (!i.viaMencao) a.semMencao += 1;

    const registro = {
      id: i.id,
      ts: i.ts,
      day: i.day,
      chave: i.indicadaChave,
      nome: i.indicadaNome,
      papel: i.indicadaPapel,
      groupName: i.groupName,
      frase: i.frase,
      viaMencao: i.viaMencao,
      indicadoraChave: i.indicadoraChave,
      indicadoraNome: nome,
    };
    a.indicadas.push(registro);
    indicadas.push(registro);

    if (!a.primeiraEm || i.ts < a.primeiraEm) a.primeiraEm = i.ts;
    if (!a.ultimaEm || i.ts > a.ultimaEm) a.ultimaEm = i.ts;
    if (!i.viaMencao) semMencao += 1;
    if (!pessoa?.nome) semNome += 1;

    porIndicadora.set(i.indicadoraChave, a);
  }

  const ranking = [...porIndicadora.values()]
    .map((a) => ({ ...a, indicadas: a.indicadas.sort((x, y) => (x.ts < y.ts ? 1 : -1)) }))
    // Empate no total resolve por quem indicou mais recentemente.
    .sort((a, b) => b.indicacoes - a.indicacoes || String(b.ultimaEm).localeCompare(String(a.ultimaEm)));

  return {
    resumo: {
      indicacoes: validas.length,
      indicadoras: ranking.length,
      indicadas: indicadas.length,
      duplicadas: todas.length - validas.length,
      semMencao,
      naoIdentificadas: semNome,
    },
    ranking,
    indicadas: indicadas.sort((a, b) => (a.ts < b.ts ? 1 : -1)),
  };
}

export const ESCOPOS_LIMPEZA = ['historico', 'estatisticas', 'tudo'];

// Recalcula os totais a partir do histórico que restou, para os números do
// painel não continuarem contando lançamentos que já não existem.
function recomputarStats(db) {
  const t = { totalMessages: 0, totalMontante: 0, totalContasValor: 0, totalContasQtd: 0 };
  for (const m of db.messages) {
    t.totalMessages += 1;
    t.totalMontante += num(m.montante);
    t.totalContasValor += num(m.contasTotal);
    t.totalContasQtd += num(m.contasQtd);
  }
  Object.assign(db.stats, t);
}

function zerarStats(db) {
  Object.assign(db.stats, {
    totalMessages: 0,
    totalMontante: 0,
    totalContasValor: 0,
    totalContasQtd: 0,
    totalGroups: 0,
  });
}

// Apaga dados coletados. Operação destrutiva — quem chama deve fazer backup antes.
//   escopo 'historico'    → remove lançamentos; totais recalculados do que sobrou
//   escopo 'estatisticas' → zera os totais acumulados; histórico intacto
//   escopo 'tudo'         → remove lançamentos e zera os totais
// `antesDe` ('YYYY-MM-DD') restringe a remoção a entradas anteriores à data.
// Valida os parâmetros sem tocar em nada. Separado de limparDados() para quem
// chama poder recusar um pedido inválido antes de gastar um backup.
export function validarLimpeza({ escopo = 'tudo', antesDe = null } = {}) {
  if (!ESCOPOS_LIMPEZA.includes(escopo)) {
    throw new Error(`escopo inválido: ${escopo} (use ${ESCOPOS_LIMPEZA.join(', ')})`);
  }
  if (antesDe != null && !/^\d{4}-\d{2}-\d{2}$/.test(String(antesDe))) {
    throw new Error('antesDe deve estar no formato YYYY-MM-DD');
  }
}

export function limparDados({ escopo = 'tudo', antesDe = null } = {}) {
  validarLimpeza({ escopo, antesDe });

  const db = getDb();
  if (!Array.isArray(db.messages)) db.messages = [];
  const antes = db.messages.length;
  let removidas = 0;

  if (escopo === 'historico' || escopo === 'tudo') {
    if (antesDe) {
      const corte = String(antesDe);
      // `day` já é 'YYYY-MM-DD', então a comparação textual é cronológica.
      db.messages = db.messages.filter((m) => String(m.day ?? '') >= corte);
    } else {
      db.messages = [];
    }
    removidas = antes - db.messages.length;
  }

  if (escopo === 'tudo') zerarStats(db);
  else if (escopo === 'estatisticas') zerarStats(db);
  else recomputarStats(db); // escopo 'historico'

  saveDb({ immediate: true });
  return {
    escopo,
    antesDe: antesDe ?? null,
    removidas,
    restantes: db.messages.length,
    statsZeradas: escopo !== 'historico',
  };
}

// Filtra entradas por período e (opcionalmente) por número.
// period: 'today' | 'all' | {day:'YYYY-MM-DD'}
export function filtrarEntradas(period = 'today', sessaoId = null) {
  const db = getDb();
  const intervalo = intervaloPeriodo(period);
  return (Array.isArray(db.messages) ? db.messages : [])
    .filter((m) => daSessao(m, sessaoId) && noIntervalo(m.day, intervalo));
}

/**
 * MONTANTE VALIDADO do período — o número que o Painel e o bot mostram.
 *
 * O lançamento sozinho é intenção: o Operador respondeu um pedido e disse um
 * montante. Validado é o que fechou os 3 passos (pedido da Brogueira → resposta
 * do Operador → comprovante PIX dela). Somar lançamento como se fosse dinheiro
 * fechado inflava o painel e as respostas do bot, então "Montante" passou a
 * significar sempre o validado.
 *
 * Devolve o total e a quebra por grupo e por operador nas MESMAS chaves que
 * agregarTotais()/agregarOperadores() usam (groupId e operatorId ?? nome), para
 * que quem já tem essas listas só precise trocar o valor de `montante`.
 */
export function montantesValidados(period = 'today', sessaoId = null) {
  expirarServicos();
  const grupos = new Map();
  const operadores = new Map();
  let total = 0;
  let servicos = 0;

  for (const s of filtrarServicos(period, sessaoId)) {
    if (s.status !== STATUS.VALIDADO || !s.atendimento) continue;
    const a = s.atendimento;
    const m = num(a.montante);
    total += m;
    servicos += 1;
    const gid = s.groupId ?? null;
    grupos.set(gid, (grupos.get(gid) ?? 0) + m);
    const key = a.operatorId ?? a.operatorName;
    operadores.set(key, (operadores.get(key) ?? 0) + m);
  }

  return {
    total: Math.round(total * 100) / 100,
    servicos,
    grupos,
    operadores,
    // Quantos Operadores fecharam pelo menos um serviço no período.
    qtdOperadores: operadores.size,
  };
}

// Agrega totais gerais de um conjunto de entradas.
export function agregarTotais(entradas) {
  const grupos = new Map();
  let montante = 0;
  let contasValor = 0;
  let contasQtd = 0;
  const operadores = new Set();

  for (const e of entradas) {
    montante += num(e.montante);
    contasValor += num(e.contasTotal);
    contasQtd += num(e.contasQtd);
    if (e.operatorId) operadores.add(e.operatorId);
    const g = grupos.get(e.groupId) ?? { id: e.groupId ?? null, nome: e.groupName || 'privado', montante: 0, contasValor: 0, contasQtd: 0 };
    g.montante += num(e.montante);
    g.contasValor += num(e.contasTotal);
    g.contasQtd += num(e.contasQtd);
    grupos.set(e.groupId, g);
  }

  return {
    qtdEntradas: entradas.length,
    montante,
    contasValor,
    contasQtd,
    qtdOperadores: operadores.size,
    grupos: [...grupos.values()].sort((a, b) => b.montante - a.montante),
  };
}

// Agrega por operador. Inclui uma pequena série (últimos montantes) p/ sparkline.
export function agregarOperadores(entradas) {
  const ops = new Map();
  for (const e of entradas) {
    const key = e.operatorId ?? e.operatorName;
    const o = ops.get(key) ?? { id: key ?? null, nome: e.operatorName || 'desconhecido', montante: 0, contasValor: 0, contasQtd: 0, entradas: 0, serie: [] };
    o.montante += num(e.montante);
    o.contasValor += num(e.contasTotal);
    o.contasQtd += num(e.contasQtd);
    o.entradas += 1;
    o.serie.push(num(e.montante));
    ops.set(key, o);
  }
  return [...ops.values()]
    .map((o) => ({ ...o, serie: o.serie.slice(-10) }))
    .sort((a, b) => b.montante - a.montante);
}

/**
 * Calendário do histórico: quais dias têm dados e quanto.
 *
 * O navegador de dias do painel usa isto para não deixar o usuário caminhar às
 * cegas — ele já abre sabendo qual foi o primeiro dia gravado, quais dias têm
 * movimento e o que cada um tem. Varre as quatro coleções porque um dia pode
 * ter tido indicação sem lançamento (e vice-versa).
 */
export function diasComDados(sessaoId = null) {
  const db = getDb();
  const dias = new Map();
  const conta = (registro, campo) => {
    const day = registro?.day;
    if (!day || !daSessao(registro, sessaoId)) return;
    const acc = dias.get(day) ?? { day, lancamentos: 0, pedidos: 0, servicos: 0, indicacoes: 0, montante: 0 };
    acc[campo] += 1;
    if (campo === 'lancamentos') acc.montante += num(registro.montante);
    dias.set(day, acc);
  };
  for (const m of db.messages ?? []) conta(m, 'lancamentos');
  for (const p of db.pedidos ?? []) conta(p, 'pedidos');
  for (const sv of db.servicos ?? []) conta(sv, 'servicos');
  for (const i of db.indicacoes ?? []) conta(i, 'indicacoes');

  const lista = [...dias.values()].sort((a, b) => b.day.localeCompare(a.day));
  return {
    hoje: dayKey(),
    primeiro: lista.length ? lista[lista.length - 1].day : dayKey(),
    ultimo: lista.length ? lista[0].day : dayKey(),
    dias: lista,
  };
}

/**
 * Montante validado por dia — a série da "onda" do Painel.
 *
 * Só serviço que fechou os 3 passos entra. Diferente da aba Relatórios, aqui
 * NÃO se tira Operador isento: o Painel mostra a operação inteira; a isenção é
 * regra de cobrança, não de movimento.
 */
export function validadosPorDia(dias = 7, sessaoId = null, ate = null) {
  const db = getDb();
  // `ate` = modo histórico: a série de 7 dias termina no dia escolhido, como
  // em mensagensPorDia(). Sem ele a série termina hoje.
  const base = ate && /^\d{4}-\d{2}-\d{2}$/.test(String(ate))
    ? dayjs.tz(String(ate), tz())
    : dayjs().tz(tz());
  const porDia = new Map();
  for (const sv of db.servicos ?? []) {
    if (sv.status !== 'validado' || !sv.atendimento) continue;
    if (sessaoId && (sv.sessaoId ?? SESSAO_PADRAO) !== sessaoId) continue;
    const acc = porDia.get(sv.day) ?? { servicos: 0, montante: 0, salario: 0, contas: 0 };
    acc.servicos += 1;
    acc.montante += num(sv.atendimento.montante);
    acc.salario += salarioDoAtendimento(sv.atendimento);
    acc.contas += num(sv.atendimento.contasTotal);
    porDia.set(sv.day, acc);
  }
  const out = [];
  for (let i = dias - 1; i >= 0; i--) {
    const d = base.subtract(i, 'day');
    const day = d.format('YYYY-MM-DD');
    const acc = porDia.get(day) ?? { servicos: 0, montante: 0, salario: 0, contas: 0 };
    out.push({
      day,
      label: d.format('DD/MM'),
      // Dia da semana abreviado: é o que responde "como foi a semana".
      diaSemana: ['dom', 'seg', 'ter', 'qua', 'qui', 'sex', 'sáb'][d.day()],
      hoje: i === 0,
      ...acc,
      montante: Math.round(acc.montante * 100) / 100,
      salario: Math.round(acc.salario * 100) / 100,
      contas: Math.round(acc.contas * 100) / 100,
    });
  }
  return out;
}

// Atividade por hora (0..23) do período — nº de lançamentos por hora.
export function atividadePorHora(period = 'today', sessaoId = null) {
  const entradas = filtrarEntradas(period, sessaoId);
  const horas = Array(24).fill(0);
  for (const e of entradas) {
    const h = dayjs(e.ts).tz(tz()).hour();
    horas[h] += 1;
  }
  return horas;
}

/**
 * Série dos últimos N dias: { day, label, count, montante, contas }.
 *
 * `ate` ('YYYY-MM-DD') termina a janela num dia do passado — é o que faz o
 * Painel em modo histórico mostrar os 7 dias que ANTECEDEM o dia escolhido,
 * em vez de uma série que sempre acaba em hoje (a comparação com "ontem" só
 * quer dizer alguma coisa se "ontem" for o dia anterior ao que está na tela).
 */
export function mensagensPorDia(dias = 7, sessaoId = null, ate = null) {
  const db = getDb();
  const todas = (Array.isArray(db.messages) ? db.messages : []).filter((m) => daSessao(m, sessaoId));
  const base = ate && /^\d{4}-\d{2}-\d{2}$/.test(String(ate))
    ? dayjs.tz(String(ate), tz())
    : dayjs().tz(tz());
  // Um único agrupamento em vez de N varreduras do histórico completo.
  const porDia = new Map();
  for (const m of todas) {
    const acc = porDia.get(m.day) ?? { count: 0, montante: 0, contas: 0, contasValor: 0 };
    acc.count += 1;
    acc.montante += num(m.montante);
    acc.contas += num(m.contasQtd);
    acc.contasValor += num(m.contasTotal);
    porDia.set(m.day, acc);
  }
  const out = [];
  for (let i = dias - 1; i >= 0; i--) {
    const dRef = base.subtract(i, 'day');
    const dia = dRef.format('YYYY-MM-DD');
    const acc = porDia.get(dia) ?? { count: 0, montante: 0, contas: 0, contasValor: 0 };
    out.push({ day: dia, label: dRef.format('DD/MM'), ...acc });
  }
  return out;
}
