"""Configuracao central do VPS Manager (lida de /etc/vps-manager/.env)."""
from __future__ import annotations

from functools import lru_cache

from pydantic_settings import BaseSettings, SettingsConfigDict


class Settings(BaseSettings):
    model_config = SettingsConfigDict(
        env_file="/opt/vps-manager/.env", env_file_encoding="utf-8", extra="ignore"
    )

    app_name: str = "VPS Manager"
    app_env: str = "production"
    debug: bool = False

    db_path: str = "/opt/vps-manager/var/vpsmgr.db"

    jwt_secret: str
    jwt_alg: str = "HS256"
    access_ttl_min: int = 240

    # Raizes que o painel pode navegar/baixar. Separadas por ":".
    project_roots: str = "/opt"
    # Diretorio livre para o gerenciador de arquivos ("/" = disco inteiro).
    browse_root: str = "/"

    excludes_default: str = ".venv,node_modules,__pycache__,.git,.pytest_cache,.npm,*.pyc,venv,dist,build"

    tmp_dir: str = "/opt/vps-manager/var/tmp"
    upload_dir: str = "/opt/vps-manager/var/uploads"
    max_upload_mb: int = 512

    # SSH padrao (host local desta VPS)
    ssh_host: str = "127.0.0.1"
    ssh_port: int = 22
    ssh_user: str = "root"
    ssh_key: str = "/etc/vps-manager/keys/id_rsa"

    # Unidades systemd que o painel gerencia (vazio = descobre automaticamente)
    managed_units: str = "delta-cpa,findash,whatsapp-server,nginx,postgresql,redis-server,vps-manager"

    rate_login_per_min: int = 8
    max_failed_logins: int = 8
    lockout_minutes: int = 15

    timezone: str = "America/Sao_Paulo"
    public_url: str = ""

    @property
    def roots(self) -> list[str]:
        return [p for p in (x.strip() for x in self.project_roots.split(":")) if p]

    @property
    def excludes(self) -> list[str]:
        return [p for p in (x.strip() for x in self.excludes_default.split(",")) if p]

    @property
    def units(self) -> list[str]:
        return [p for p in (x.strip() for x in self.managed_units.split(",")) if p]


@lru_cache
def get_settings() -> Settings:
    return Settings()  # type: ignore[call-arg]


settings = get_settings()
