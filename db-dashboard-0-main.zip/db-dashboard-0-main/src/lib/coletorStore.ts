// Memória viva da conversa com o coletor externo.
//
// Duas coisas moram aqui, e as duas existem porque a informação já passava pelo
// Dash e era jogada fora:
//   - o LOG: uma linha por chamada (rota, resultado, status, tempo, tamanho),
//     para diagnosticar sem abrir o DevTools;
//   - as RESPOSTAS: o último JSON cru de cada rota, do jeito que chegou, para
//     que outras telas possam reaproveitar o dado sem refazer a requisição.
//
// É estado de processo, não de banco: some no F5. Serve para diagnóstico e para
// leitura oportunista, nunca como fonte de verdade — quem precisa do dado
// garantido chama `buscarRelatorio` e espera a resposta.

import type { RelatorioTipo } from "@/lib/relatoriosExternos";

export type LogNivel = "ok" | "erro" | "info";

export type LogEntrada = {
  id: number;
  ts: string;
  /** De onde veio a chamada: a tela de relatórios ou o botão de teste. */
  origem: "relatorio" | "diagnostico";
  rota: string;
  nivel: LogNivel;
  ms: number;
  status?: number;
  bytes?: number;
  codigo?: string;
  mensagem: string;
};

export type RespostaGuardada = {
  ts: string;
  ms: number;
  bytes: number;
  /** JSON exatamente como o coletor mandou, sem normalização. */
  bruto: unknown;
};

export type EstadoColetor = {
  log: LogEntrada[];
  respostas: Partial<Record<RelatorioTipo, RespostaGuardada>>;
};

/** O log é para olhar, não para arquivar: passou disso, a linha mais velha cai. */
const LIMITE_LOG = 200;

let estado: EstadoColetor = { log: [], respostas: {} };
let proximoId = 1;

const ouvintes = new Set<() => void>();

function publicar(novo: EstadoColetor) {
  estado = novo;
  ouvintes.forEach((f) => f());
}

export function assinarColetor(ouvinte: () => void): () => void {
  ouvintes.add(ouvinte);
  return () => ouvintes.delete(ouvinte);
}

/** Snapshot estável: só muda de identidade quando algo de fato mudou —
 *  `useSyncExternalStore` entra em laço infinito se este objeto for recriado. */
export function lerColetor(): EstadoColetor {
  return estado;
}

export function registrarLog(entrada: Omit<LogEntrada, "id" | "ts">): LogEntrada {
  const completa: LogEntrada = { ...entrada, id: proximoId++, ts: new Date().toISOString() };
  publicar({ ...estado, log: [completa, ...estado.log].slice(0, LIMITE_LOG) });
  return completa;
}

export function limparLog() {
  publicar({ ...estado, log: [] });
}

export function guardarResposta(tipo: RelatorioTipo, bruto: unknown, ms: number, bytes: number) {
  publicar({
    ...estado,
    respostas: { ...estado.respostas, [tipo]: { ts: new Date().toISOString(), ms, bytes, bruto } },
  });
}

/** Último JSON cru de uma rota, ou `undefined` se ela ainda não foi buscada
 *  nesta sessão. Ponto de entrada para outras telas reaproveitarem o dado. */
export function ultimaResposta(tipo: RelatorioTipo): RespostaGuardada | undefined {
  return estado.respostas[tipo];
}

/** Tamanho aproximado do payload, para o log. JSON.stringify é o suficiente
 *  aqui — se falhar (ciclo, BigInt), o tamanho vira 0 e ninguém quebra. */
export function tamanhoJson(valor: unknown): number {
  try {
    return JSON.stringify(valor)?.length ?? 0;
  } catch {
    return 0;
  }
}
