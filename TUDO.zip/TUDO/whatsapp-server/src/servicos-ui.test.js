// O 2º quadro do Painel (DESEMPENHO DOS OPERADORES) num DOM real.
//
// O quadro é desenhado à mão em SVG dentro do app.js: sem este teste, um erro
// ali só apareceria no navegador do usuário — e um erro de sintaxe no app.js
// derruba o painel INTEIRO, não só este quadro.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const PUBLIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

const REL = {
  resumo: {
    pedidos: 10, atendidos: 6, validados: 4,
    aguardandoAtendimento: 1, aguardandoComprovante: 1,
    semAtendimento: 2, semComprovante: 1,
    montanteValidado: 1200, montanteNaoValidado: 500,
    contasValidadasQtd: 7, contasValidadasValor: 42,
    contasNaoValidadasQtd: 2, contasNaoValidadasValor: 12,
    contasRsValidado: 390, contasRsNaoValidado: 100,
    porCasamento: { citacao: 2, valor: 1, tempo: 1 },
    // 5 dos 6 atendidos vieram com montante; 3 deles fecharam. Os dois pares
    // (atendidos/validados x pegos/validados) são medidas diferentes de
    // propósito: nem todo serviço atendido traz montante.
    montantesPegos: 5, montantesValidados: 3,
    brogueiras: 3, taxa: 4 / 6,
  },
  operadores: [
    {
      id: 'OP1@lid', nome: 'Carlos', atendidos: 4, validados: 3,
      montanteValidado: 900, montanteNaoValidado: 200, contasQtd: 5, contasValor: 30,
      contasNaoValidadasQtd: 2, contasNaoValidadasValor: 12,
      contasRsValidado: 300, contasRsNaoValidado: 100,
      aguardando: 1, semComprovante: 0, casamento: { citacao: 2, valor: 1, tempo: 0 }, taxa: 0.75,
    },
    {
      id: 'OP2@lid', nome: 'Ana', atendidos: 2, validados: 1,
      montanteValidado: 300, montanteNaoValidado: 300, contasQtd: 2, contasValor: 12,
      contasNaoValidadasQtd: 0, contasNaoValidadasValor: 0,
      contasRsValidado: 90, contasRsNaoValidado: 0,
      aguardando: 0, semComprovante: 1, casamento: { citacao: 0, valor: 0, tempo: 1 }, taxa: 0.5,
    },
  ],
  servicos: [
    {
      id: 's1', status: 'validado', brogueiraNome: 'Bia', operatorName: 'Carlos',
      pedidoTs: '2026-08-27T12:00:00.000Z', atendimentoTs: '2026-08-27T12:05:00.000Z',
      comprovanteTs: '2026-08-27T12:40:00.000Z', comprovanteTipo: 'pdf',
      montante: 400, contasQtd: 2, montantePedido: 400, contasPedidas: 2,
      tipo: 'montante', pedidoTexto: '400 montante 2 contas', casamento: 'citacao', links: [],
    },
    {
      id: 's2', status: 'aguardando_comprovante', brogueiraNome: 'Duda', operatorName: 'Ana',
      pedidoTs: '2026-08-27T13:00:00.000Z', atendimentoTs: '2026-08-27T13:02:00.000Z',
      comprovanteTs: null, comprovanteTipo: null,
      montante: 300, contasQtd: 0, montantePedido: 300, contasPedidas: 0,
      tipo: 'montante', pedidoTexto: '300', casamento: 'tempo', links: [],
    },
  ],
};

async function montarPainel() {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;
  window.Element.prototype.getBoundingClientRect = () => ({
    left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0,
  });
  // O catálogo de recursos vem do servidor; devolver vazio faria o painel
  // tentar de novo (com teto) e deixaria timers pendurados no teste.
  window.fetch = async (url) => ({
    ok: true,
    status: 200,
    json: async () => (String(url).includes('/api/sessoes')
      ? { ok: true, recursos: [{ chave: 'monitorar', nome: 'Monitoramento', descricao: 'x' }], sessoes: [], conflitos: [] }
      : { ok: true }),
  });

  const tag = window.document.createElement('script');
  tag.textContent = fs.readFileSync(path.join(PUBLIC, 'app.js'), 'utf8');
  window.document.body.appendChild(tag);
  // Quem chama fecha a janela no fim — jsdom mantém timers vivos e o processo
  // de teste não terminaria. O respiro antes do close deixa terminar o que o
  // painel disparou sozinho (o fetch do catálogo de recursos); fechar no meio
  // faria esse código achar o `document` já destruído.
  return {
    window,
    doc: window.document,
    fechar: async () => {
      await new Promise((r) => setTimeout(r, 30));
      dom.window.close();
    },
  };
}

test('o gráfico desenha uma coluna por operador, com hachura no não validado', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
  window.lerCores();
  window.chartServicos(REL);

  const svg = doc.querySelector('#chart-servicos svg');
  assert.ok(svg, 'o SVG do quadro 2 tem que existir');
  // Uma área de hover por operador (é o alvo grande, maior que a barra).
  assert.equal(svg.querySelectorAll('rect.hit').length, 2);
  // O trecho não validado é hachurado — a distinção não pode depender só da cor.
  assert.ok(svg.querySelector('pattern#hachura'), 'falta o padrão de hachura');
  assert.ok(svg.innerHTML.includes('url(#hachura)'));
  // Rótulo direto com a contagem de serviços (o eixo é em R$, não em serviços).
  assert.ok(svg.textContent.includes('3/4 serv.'));
  assert.ok(svg.textContent.includes('Carlos'));
  // Legenda com as três séries — nunca só a cor.
  assert.match(doc.getElementById('sv-legend').textContent, /Montante validado/i);
  assert.match(doc.getElementById('sv-legend').textContent, /Contas validadas \(R\$\)/i);
  assert.match(doc.getElementById('sv-legend').textContent, /sem comprovante/i);
  // Resumo no cabeçalho do card.
  assert.equal(doc.getElementById('sv-resumo').textContent, '4/6 fechados · 67%');
  } finally { await fechar(); }
});

test('as contas validadas ganham coluna própria, na MESMA escala do montante', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.lerCores();
    window.chartServicos(REL);
    const svg = doc.querySelector('#chart-servicos svg');

    // Uma pilha de montante e uma de contas por operador.
    assert.equal(svg.querySelectorAll('.seg-ok').length, 2);
    assert.equal(svg.querySelectorAll('.seg-contas-ok').length, 2);
    // O trecho sem comprovante das contas também é hachurado (só o Carlos tem).
    assert.ok(svg.querySelector('.seg-contas-pend.hachurado'));
    assert.ok(svg.querySelector('pattern#hachura-contas'), 'falta a hachura das contas');

    // Um eixo só, em R$ — as duas séries são a mesma unidade (é o pedido: a
    // mesma "Contas (R$)" do quadro azul, aqui recortada pelo ciclo).
    const eixo = [...svg.querySelectorAll('text[text-anchor="end"]')].map((t) => t.textContent);
    assert.equal(eixo.length, 5);
    assert.equal(eixo.every((t) => /R\$/.test(t)), true, 'todo rótulo do eixo é em R$');
    assert.equal(svg.querySelectorAll('text[text-anchor="start"]').length, 0, 'não há 2º eixo');

    // Mesma escala: 300 de contas do Carlos tem de ser 1/3 dos 900 de montante
    // dele (a mesma régua, senão a comparação entre as colunas mentiria).
    const altura = (el) => (el.tagName.toLowerCase() === 'rect'
      ? Number(el.getAttribute('height'))
      : (() => { const d = el.getAttribute('d'); const [, b, t] = /^M[\d.]+ ([\d.]+) V([\d.]+)/.exec(d); return Number(b) - Number(t); })());
    const hMont = altura(svg.querySelector('.seg-ok'));
    const hContas = altura(svg.querySelector('.seg-contas-ok'));
    assert.ok(Math.abs(hContas / hMont - 300 / 900) < 0.02, `contas ${hContas} x montante ${hMont}`);
  } finally { await fechar(); }
});

test('grupo que só faz montante não ganha coluna de contas', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.lerCores();
    window.chartServicos({
      ...REL,
      operadores: REL.operadores.map((o) => ({ ...o, contasRsValidado: 0, contasRsNaoValidado: 0 })),
    });
    const svg = doc.querySelector('#chart-servicos svg');
    assert.equal(svg.querySelectorAll('.seg-contas-ok').length, 0);
    assert.equal(svg.querySelectorAll('.seg-ok').length, 2); // o quadro segue igual
  } finally { await fechar(); }
});

test('sem serviço nenhum, o quadro mostra o vazio em vez de um SVG quebrado', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
  window.lerCores();
  window.chartServicos({ resumo: { pedidos: 0, atendidos: 0, validados: 0 }, operadores: [], servicos: [] });
  assert.match(doc.getElementById('chart-servicos').textContent, /Nenhum serviço/);
  assert.equal(doc.getElementById('sv-resumo').textContent, '');
  } finally { await fechar(); }
});

test('o funil mostra os 3 passos e onde os pedidos se perderam', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
  window.renderFunil(REL);
  const texto = doc.getElementById('sv-funil').textContent;
  assert.match(texto, /Pedidos das Brogueiras/);
  assert.match(texto, /Atendidos por um Operador/);
  assert.match(texto, /Com comprovante PIX/);
  assert.match(texto, /Ninguém atendeu/);
  assert.equal(doc.querySelectorAll('#sv-funil .funil-passo').length, 6);
  assert.match(doc.getElementById('sv-casamento').textContent, /Respondeu citando/);
  } finally { await fechar(); }
});

test('a tabela começa nos validados e o filtro abre os demais atendidos', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
  window.tabelaServicos(REL);
  let linhas = doc.querySelectorAll('#tbl-servicos tbody tr');
  assert.equal(linhas.length, 1);
  assert.match(linhas[0].textContent, /Bia/);
  assert.match(linhas[0].textContent, /PDF/);
  assert.match(linhas[0].textContent, /citou/);

  // O filtro precisa do snapshot em memória (é dele que a tabela relê).
  window.renderSnapshot({ hoje: {}, stats: {}, analytics: {}, servicos: REL, sessoes: [] });
  doc.querySelector('#sv-filtro button[data-filtro="todos"]').onclick({});
  linhas = doc.querySelectorAll('#tbl-servicos tbody tr');
  assert.equal(linhas.length, 2);
  assert.match(linhas[1].textContent, /aguardando/);
  } finally { await fechar(); }
});

test('os montantes pegos e validados são KPIs do topo, ao lado do valor validado', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderSnapshot({ hoje: {}, stats: {}, analytics: {}, servicos: REL, sessoes: [] });

    // O número grande é a SOMA em R$ (1200 validados + 500 sem comprovante),
    // na mesma unidade do KPI vizinho; as contagens ficam no rodapé.
    assert.equal(doc.getElementById('s-pegos').textContent, 'R$ 1,7 mil');
    assert.equal(doc.getElementById('d-pegos').textContent, '5 montantes · 3 validados');
    // Cor de validado, não de variação (não é um "subiu/desceu").
    assert.ok(doc.getElementById('d-pegos').classList.contains('ok'));

    // E o card fica MESMO à esquerda do "Montante validado" — a ordem é o que
    // o usuário pediu, e um reflow que a trocasse passaria despercebido.
    const cards = [...doc.querySelectorAll('#tab-painel .kpis .card.stat')];
    const iPegos = cards.findIndex((c) => c.querySelector('#s-pegos'));
    const iValor = cards.findIndex((c) => c.querySelector('#s-montante'));
    assert.equal(iPegos, iValor - 1);
    // Nada de placar dentro do quadro dos Operadores.
    assert.equal(doc.getElementById('sv-placar'), null);
  } finally { await fechar(); }
});

test('o último KPI é Contas validadas — o de Operadores saiu da fileira', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.lerCores();
    window.renderSnapshot({
      hoje: { totais: { contasValor: 490 } }, stats: {}, sessoes: [], servicos: REL,
      analytics: {
        porDia: [{ contasValor: 300, count: 1 }, { contasValor: 490, count: 2 }],
        // `contas` = o "Valor:" das contas nos serviços validados (o que o KPI
        // lê); `salario` é outra medida — o que o Operador cobrou.
        validadoPorDia: [
          { day: '2026-08-30', label: '30/08', diaSemana: 'dom', montante: 800, salario: 420, contas: 300, servicos: 2 },
          { day: '2026-08-31', label: '31/08', diaSemana: 'seg', hoje: true, montante: 1200, salario: 550, contas: 390, servicos: 3 },
        ],
      },
    });

    // Do que foi cobrado, quanto fechou os 3 passos (contasRsValidado = 390).
    assert.equal(doc.getElementById('s-cval').textContent, 'R$ 390');
    // Fica ao lado do "Contas hoje", que segue mostrando TUDO o que foi cobrado.
    assert.equal(doc.getElementById('s-contas').textContent, 'R$ 490');
    // A variação compara com o MESMO recorte do dia anterior (300 → 390).
    assert.match(doc.getElementById('d-cval').textContent, /30/);
    assert.ok(doc.getElementById('spark-cval').innerHTML.includes('<svg'));

    assert.equal(doc.getElementById('s-ops'), null);
    const cards = [...doc.querySelectorAll('#tab-painel .kpis .card.stat')];
    assert.equal(cards.length, 5);
    assert.ok(cards.at(-1).querySelector('#s-cval'), 'entrou no lugar do de Operadores');
  } finally { await fechar(); }
});

test('sem montante pego, o KPI mostra R$ 0 e o rodapé fica vazio', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.renderSnapshot({
      hoje: {}, stats: {}, analytics: {}, sessoes: [],
      servicos: { resumo: { atendidos: 0, validados: 0, montantesPegos: 0, montantesValidados: 0 }, operadores: [], servicos: [] },
    });
    assert.equal(doc.getElementById('s-pegos').textContent, 'R$ 0');
    assert.equal(doc.getElementById('d-pegos').textContent, '');
  } finally { await fechar(); }
});

test('o snapshot desenha o quadro 2 sem quebrar quando o servidor não manda serviços', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
  window.renderSnapshot({ hoje: {}, stats: {}, analytics: {}, sessoes: [] });
  assert.match(doc.getElementById('chart-servicos').textContent, /Nenhum serviço/);
  assert.equal(doc.querySelectorAll('#tbl-servicos tbody tr').length, 1); // a linha do "vazio"
  } finally { await fechar(); }
});

/* ═══════════ Orientação: COLUNAS verticais, uma por usuário ═══════════
   Os dois quadros do Painel eram barras deitadas. Um refactor que voltasse a
   deitá-las passaria despercebido sem estas checagens de geometria. */

const OPS_PAINEL = [
  { nome: 'Panda', montante: 5400, contasValor: 186, contasQtd: 31, entradas: 24, serie: [] },
  { nome: 'Rafa', montante: 2700, contasValor: 132, contasQtd: 22, entradas: 18, serie: [] },
  { nome: 'Léo', montante: 900, contasValor: 96, contasQtd: 16, entradas: 12, serie: [] },
];

// Base de cada coluna: o "M x base" com que colunaV() começa o caminho.
const basesDasColunas = (svg) => [...svg.querySelectorAll('path[d^="M"]')]
  .map((p) => Number(/^M[\d.]+ ([\d.]+)/.exec(p.getAttribute('d'))?.[1]))
  .filter(Number.isFinite);

// A linha do zero: horizontal (y1 === y2) num gráfico de colunas; vertical
// (x1 === x2) num de barras deitadas.
function eixoZero(svg) {
  return [...svg.querySelectorAll('line')].find((l) => l.getAttribute('stroke-width') === '1'
    && l.getAttribute('x1') !== l.getAttribute('x2')
    && l.getAttribute('y1') === l.getAttribute('y2')
    && Number(l.getAttribute('x2')) > 400);
}



test('Painel: os serviços validados empilham na vertical, com a contagem no eixo', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.lerCores();
    window.chartServicos(REL);
    const svg = doc.querySelector('#chart-servicos svg');

    assert.ok(eixoZero(svg), 'a linha do zero deveria ser horizontal');

    // O trecho validado de todo mundo nasce na MESMA linha de base…
    // (o trecho de baixo de uma pilha é um <rect> — só o topo vira <path>
    //  arredondado, então a base se lê de um jeito em cada um)
    const baseY = (el) => (el.tagName.toLowerCase() === 'rect'
      ? Number(el.getAttribute('y')) + Number(el.getAttribute('height'))
      : Number(/^M[\d.]+ ([\d.]+)/.exec(el.getAttribute('d'))[1]));
    const validados = [...svg.querySelectorAll('.seg-ok')];
    assert.equal(validados.length, 2);
    assert.equal(new Set(validados.map(baseY)).size, 1, 'as colunas deveriam compartilhar a base');

    // …e o trecho sem comprovante fica EMPILHADO em cima dele (base mais alta
    // na tela = y menor), não ao lado.
    const pendentes = [...svg.querySelectorAll('.seg-pend')];
    assert.ok(pendentes.length, 'faltou o trecho sem comprovante');
    assert.ok(baseY(pendentes[0]) < baseY(validados[0]), 'o pendente deveria ficar em cima do validado');
    assert.ok(svg.querySelector('.hachurado'), 'o trecho de cima precisa da hachura');
    // Nome e contagem, um embaixo do outro, no eixo.
    assert.ok(svg.textContent.includes('Carlos'));
    assert.ok(svg.textContent.includes('3/4 serv.'));
  } finally { await fechar(); }
});

test('nome em fonte estilizada não quebra ao ser cortado no eixo', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.lerCores();
    // É o nome real do número do bot no grupo: bloco Mathematical Bold (U+1D400),
    // em que cada letra ocupa DUAS unidades UTF-16 — um slice() cru parte o par.
    window.chartServicos({
      ...REL,
      operadores: [
        { ...REL.operadores[0], nome: '𝐀𝐒𝐒𝐈𝐒𝐓𝐄𝐍𝐓𝐄 𝐏𝐀𝐍𝐃𝐀 🐼' },
        { ...REL.operadores[0], id: 'OP9@lid', nome: 'Rafa', montanteValidado: 300 },
      ],
    });
    const texto = doc.querySelector('#chart-servicos svg').textContent;
    assert.doesNotMatch(texto, /�/, 'apareceu caractere de substituição no rótulo');
    // Nenhum meio-par solto sobrou.
    assert.doesNotMatch(texto, /[\uD800-\uDBFF](?![\uDC00-\uDFFF])/, 'sobrou metade de um par substituto');
    assert.match(texto, /𝐀𝐒𝐒𝐈𝐒𝐓/);
  } finally { await fechar(); }
});

test('a semana à esquerda, o dia à direita — cada um com o seu card de apoio', async () => {
  const { doc, fechar } = await montarPainel();
  try {
    const onda = doc.getElementById('chart-onda');
    const validados = doc.getElementById('chart-servicos');
    const linha = onda.closest('.grid');

    assert.equal(validados.closest('.grid'), linha, 'os dois deveriam dividir a mesma linha');
    assert.equal(linha.classList.contains('c2'), true);

    const colunas = [...linha.children];
    assert.equal(colunas.length, 2);
    assert.ok(colunas[0].contains(onda), 'a onda da semana é a coluna da esquerda');
    assert.ok(colunas[1].contains(validados), 'o quadro de validados é a da direita');
    assert.ok(colunas[0].querySelector('#top-ops'));
    assert.ok(colunas[1].querySelector('#sv-funil'));
  } finally { await fechar(); }
});

test('os dois gráficos têm a MESMA altura de área de plotagem (dá para comparar)', async () => {
  const { window, doc, fechar } = await montarPainel();
  try {
    window.lerCores();
    window.ondaDaSemana([
      { day: '2026-08-24', label: '24/08', diaSemana: 'seg', hoje: false, servicos: 2, montante: 900, salario: 40 },
      { day: '2026-08-25', label: '25/08', diaSemana: 'ter', hoje: true, servicos: 1, montante: 300, salario: 20 },
    ]);
    window.chartServicos(REL);

    // A área de plotagem vai do topo da grade até a linha do zero. Se as duas
    // forem iguais, uma coluna de mesma altura vale o mesmo nos dois quadros.
    const plot = (sel) => {
      const svg = doc.querySelector(`${sel} svg`);
      const grade = [...svg.querySelectorAll('line')].filter((l) => l.getAttribute('y1') === l.getAttribute('y2'));
      const ys = grade.map((l) => Number(l.getAttribute('y1')));
      return Math.max(...ys) - Math.min(...ys);
    };
    assert.equal(plot('#chart-onda'), plot('#chart-servicos'));

    // E os dois são baixos: menos da metade da largura da caixa.
    for (const sel of ['#chart-onda', '#chart-servicos']) {
      const [, , w, h] = doc.querySelector(`${sel} svg`).getAttribute('viewBox').split(' ').map(Number);
      assert.ok(h / w < 0.45, `${sel} está alto demais (${h}/${w})`);
    }
  } finally { await fechar(); }
});
