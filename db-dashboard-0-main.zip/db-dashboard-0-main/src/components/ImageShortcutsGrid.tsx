import { useEffect, useState } from "react";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Images, ImageIcon } from "lucide-react";

type Shortcut = {
  id: string;
  titulo: string;
  image_url: string;
  ordem: number;
};

export function ImageShortcutsGrid() {
  const [open, setOpen] = useState<Shortcut | null>(null);

  const { data: shortcuts = [] } = useQuery({
    queryKey: ["image-shortcuts"],
    queryFn: async () => {
      const { data } = await supabase
        .from("image_shortcuts")
        .select("id, titulo, image_url, ordem")
        .order("ordem", { ascending: true })
        .order("created_at", { ascending: true });
      return (data ?? []) as Shortcut[];
    },
  });

  const qc = useQueryClient();
  useEffect(() => {
    const ch = supabase
      .channel("image-shortcuts")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "image_shortcuts" },
        () => qc.invalidateQueries({ queryKey: ["image-shortcuts"] }),
      )
      .subscribe();
    return () => {
      supabase.removeChannel(ch);
    };
  }, [qc]);

  if (shortcuts.length === 0) return null;

  return (
    <>
      <div className="glass-strong rounded-2xl p-4">
        <div className="mb-3 flex items-center gap-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-lg bg-accent/15 text-accent ring-1 ring-accent/30">
            <Images className="h-3.5 w-3.5" />
          </div>
          <h2 className="text-sm font-bold uppercase tracking-wider">Atalhos rápidos</h2>
        </div>
        <div className="grid grid-cols-2 gap-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6">
          {shortcuts.map((s) => (
            <button
              key={s.id}
              type="button"
              onClick={() => setOpen(s)}
              className="group flex items-center gap-2 rounded-xl border border-border bg-background/40 px-3 py-2 text-left text-xs font-medium transition hover:-translate-y-0.5 hover:border-accent/60 hover:bg-accent/5 hover:shadow-elegant"
            >
              <ImageIcon className="h-4 w-4 shrink-0 text-accent" />
              <span className="truncate">{s.titulo}</span>
            </button>
          ))}
        </div>
      </div>

      <Dialog open={!!open} onOpenChange={(v) => !v && setOpen(null)}>
        <DialogContent className="max-w-3xl">
          <DialogHeader>
            <DialogTitle>{open?.titulo}</DialogTitle>
          </DialogHeader>
          {open && (
            <img
              src={open.image_url}
              alt={open.titulo}
              className="max-h-[70vh] w-full rounded-lg object-contain"
            />
          )}
        </DialogContent>
      </Dialog>
    </>
  );
}
