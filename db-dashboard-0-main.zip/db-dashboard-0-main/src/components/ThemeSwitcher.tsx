import { useEffect, useState } from "react";
import { Palette, Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

type Theme = "theme-dark" | "theme-light" | "theme-blue";

const THEMES: { id: Theme; label: string; swatch: string[] }[] = [
  { id: "theme-blue", label: "Azul & Vermelho (padrão)", swatch: ["#0b1d4a", "#3b82f6", "#ef4444", "#ffffff"] },
  { id: "theme-dark", label: "Escuro", swatch: ["#0d0d0d", "#1e40af", "#e0b34a", "#dc2626"] },
  { id: "theme-light", label: "Branco & Dourado", swatch: ["#ffffff", "#e0b34a", "#0d0d0d", "#dc2626"] },
];

function applyTheme(t: Theme) {
  const root = document.documentElement;
  root.classList.remove("theme-dark", "theme-light", "theme-blue");
  root.classList.add(t);
}

export function ThemeSwitcher() {
  const [theme, setTheme] = useState<Theme>(() => {
    if (typeof window === "undefined") return "theme-light";
    return (localStorage.getItem("db:theme") as Theme) || "theme-light";
  });


  useEffect(() => {
    applyTheme(theme);
    try {
      localStorage.setItem("db:theme", theme);
    } catch {}
  }, [theme]);

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon" aria-label="Trocar tema" className="h-9 w-9">
          <Palette className="h-4 w-4" />
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        {THEMES.map((t) => (
          <DropdownMenuItem
            key={t.id}
            onClick={() => setTheme(t.id)}
            className="flex items-center justify-between gap-2"
          >
            <div className="flex items-center gap-2">
              <div className="flex gap-0.5">
                {t.swatch.map((c, i) => (
                  <span
                    key={i}
                    className="h-3 w-3 rounded-sm border border-border/40"
                    style={{ backgroundColor: c }}
                  />
                ))}
              </div>
              <span className="text-sm">{t.label}</span>
            </div>
            {theme === t.id && <Check className="h-3.5 w-3.5 text-primary" />}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
