// Indicações: da mensagem crua ("Vim por @fulana") até o ranking.
// DATA_DIR aponta para um diretório temporário ANTES de importar db.js.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-indic-'));
process.env.DATA_DIR = DIR_TEMP;

const { loadDb, getDb } = await import('./db.js');
const { analisarIndicacao, extrairMencoes, resolverIndicadora } = await import('./indicacoes.js');
const {
  registrarIndicacao, registrarPessoa, resolverPessoa, nomesConhecidos,
  relatorioIndicacoes, filtrarIndicacoes, dayKey,
} = await import('./store.js');
const { relatorioIndicacoesTexto } = await import('./reports.js');

loadDb();

const ANA = '5511111111111';
const BIA = '5522222222222';

function limpar() {
  getDb().indicacoes = [];
  getDb().pessoas = {};
}

/* ── Leitura da mensagem ─────────────────────────────────────────── */

test('as duas formas básicas são reconhecidas', () => {
  const a = analisarIndicacao(`Vim por @${ANA}`);
  assert.equal(a.token, ANA);
  assert.equal(a.onde, 'depois');
  assert.equal(a.viaMencao, true);

  const b = analisarIndicacao(`@${ANA} me indicou`);
  assert.equal(b.token, ANA);
  assert.equal(b.onde, 'antes');
});

test('as variações do grupo passam o mesmo sentido', () => {
  const frases = [
    `vim pela @${ANA}`,
    `Oi meninas, vim pela indicação da @${ANA}`,
    `Fui indicada pela @${ANA}`,
    `cheguei aqui através da @${ANA}`,
    `entrei no grupo por causa da @${ANA}`,
    `quem me indicou foi a @${ANA}`,
    `Boa noite, indicação da @${ANA}`,
    `to aqui pela @${ANA} ❤`,
    `foi a @${ANA} que me trouxe`,
    `@${ANA} me chamou pro grupo`,
    `@${ANA} me add aqui`,
    `@${ANA} me convidou`,
    `@${ANA} indicou`,
  ];
  for (const f of frases) {
    const r = analisarIndicacao(f);
    assert.ok(r, `não reconheceu: ${f}`);
    assert.equal(r.token, ANA, `indicadora errada em: ${f}`);
  }
});

test('fonte estilizada e caixa alta não escondem a indicação', () => {
  // O mesmo NFKC do parser financeiro: 𝐕𝐢𝐦 não casa com /vim/ sem ele.
  assert.equal(analisarIndicacao(`𝗩𝗶𝗺 𝗽𝗼𝗿 @${ANA}`)?.token, ANA);
  assert.equal(analisarIndicacao(`VIM POR @${ANA}`)?.token, ANA);
  assert.equal(analisarIndicacao(`Vim Pela Indicação Da @${ANA}`)?.token, ANA);
});

test('conversa comum não vira indicação', () => {
  const ignorar = [
    'Bom dia meninas',
    'Montante: 233',
    'https://670win.me/?id=357497224\n7 contas variadas',
    `@${ANA} pode me chamar depois?`,
    `me passou o link @${ANA}`,
    'vim pelo grupo',
    'vim por causa do meu marido',
    'minha amiga me indicou', // sem dizer quem
    'alguém me indica um bom site?',
    'o pagamento foi pela conta',
  ];
  for (const f of ignorar) assert.equal(analisarIndicacao(f), null, `falso positivo: ${f}`);
});

test('nome sem "@" só conta quando parece nome próprio', () => {
  assert.equal(analisarIndicacao('Vim pela Ana')?.token, 'Ana');
  assert.equal(analisarIndicacao('Vim por indicação da Bia Souza')?.token, 'Bia');
  assert.equal(analisarIndicacao('A Carla me indicou')?.token, 'Carla');
  assert.equal(analisarIndicacao('Vim pela Ana')?.viaMencao, false);
  // Minúsculo e sem menção: indistinguível de "vim pelo grupo".
  assert.equal(analisarIndicacao('vim pela ana'), null);
  // ...a não ser que o nome já seja conhecido do grupo.
  const conhecidos = new Set(['ana']);
  assert.equal(analisarIndicacao('vim pela ana', { nomesConhecidos: conhecidos })?.token, 'ana');
});

test('entre duas leituras possíveis vence a que vem primeiro', () => {
  const r = analisarIndicacao(`@${ANA} me indicou, e eu vim pela @${BIA}`);
  assert.equal(r.token, ANA);
});

/* ── Menção real x texto ─────────────────────────────────────────── */

test('o JID da menção vem do contextInfo, não do texto', () => {
  const msg = {
    message: {
      extendedTextMessage: {
        text: `Vim por @${ANA}`,
        contextInfo: { mentionedJid: [`${ANA}@s.whatsapp.net`] },
      },
    },
  };
  assert.deepEqual(extrairMencoes(msg), [`${ANA}@s.whatsapp.net`]);

  const alvo = resolverIndicadora(analisarIndicacao(`Vim por @${ANA}`), extrairMencoes(msg));
  assert.equal(alvo.id, `${ANA}@s.whatsapp.net`);
  assert.equal(alvo.digitos, ANA);
});

test('número sem código do país ainda casa com a menção', () => {
  const analise = analisarIndicacao('Vim por @11111111111');
  const alvo = resolverIndicadora(analise, [`${ANA}@s.whatsapp.net`]);
  assert.equal(alvo.id, `${ANA}@s.whatsapp.net`, 'comparar pelo fim resolve 55 + DDD');
});

test('sem menção alguma a indicadora fica só com o nome escrito', () => {
  const alvo = resolverIndicadora(analisarIndicacao('Vim pela Ana'), []);
  assert.equal(alvo.id, null);
  assert.equal(alvo.nome, 'Ana');
});

/* ── Registro e ranking ──────────────────────────────────────────── */

// Simula a chegada de uma mensagem de indicação no grupo.
function receber(indicada, texto, { mencoes = [], dia = null } = {}) {
  const analise = analisarIndicacao(texto, { nomesConhecidos: nomesConhecidos() });
  assert.ok(analise, `texto não reconhecido como indicação: ${texto}`);
  registrarPessoa({ id: `${indicada}@lid`, nome: indicada });
  const entrada = registrarIndicacao({
    groupId: 'g1@g.us',
    groupName: 'DB Contas e Montantes',
    indicada: { id: `${indicada}@lid`, nome: indicada, papel: 'brogueira' },
    indicadora: resolverIndicadora(analise, mencoes),
    analise,
    text: texto,
  });
  if (entrada && dia) entrada.day = dia;
  return entrada;
}

test('o ranking conta quantas cada uma trouxe', () => {
  limpar();
  registrarPessoa({ id: `${ANA}@s.whatsapp.net`, pn: `${ANA}@s.whatsapp.net`, nome: 'Ana' });
  registrarPessoa({ id: `${BIA}@s.whatsapp.net`, pn: `${BIA}@s.whatsapp.net`, nome: 'Bia' });

  receber('Duda', `Vim por @${ANA}`, { mencoes: [`${ANA}@s.whatsapp.net`] });
  receber('Elis', `@${ANA} me indicou`, { mencoes: [`${ANA}@s.whatsapp.net`] });
  receber('Fabi', `vim pela indicação da @${ANA}`, { mencoes: [`${ANA}@s.whatsapp.net`] });
  receber('Gabi', `foi a @${BIA} que me trouxe`, { mencoes: [`${BIA}@s.whatsapp.net`] });

  const r = relatorioIndicacoes('today');
  assert.equal(r.resumo.indicacoes, 4);
  assert.equal(r.resumo.indicadoras, 2);

  const [primeira, segunda] = r.ranking;
  assert.equal(primeira.nome, 'Ana');
  assert.equal(primeira.indicacoes, 3);
  assert.deepEqual(primeira.indicadas.map((x) => x.nome).sort(), ['Duda', 'Elis', 'Fabi']);
  assert.equal(segunda.nome, 'Bia');
  assert.equal(segunda.indicacoes, 1);
});

test('as indicadas ficam memorizadas com quem as trouxe', () => {
  limpar();
  registrarPessoa({ id: `${ANA}@s.whatsapp.net`, nome: 'Ana' });
  receber('Duda', `Vim por @${ANA}`, { mencoes: [`${ANA}@s.whatsapp.net`] });

  const { indicadas } = relatorioIndicacoes('today');
  assert.equal(indicadas.length, 1);
  assert.equal(indicadas[0].nome, 'Duda');
  assert.equal(indicadas[0].indicadoraNome, 'Ana');
  assert.match(indicadas[0].frase, /vim por/i);
  // A indicada também entra na memória de pessoas do grupo.
  assert.equal(resolverPessoa({ id: 'Duda@lid' })?.nome, 'Duda');
});

test('a mesma indicada não conta duas vezes', () => {
  limpar();
  registrarPessoa({ id: `${ANA}@s.whatsapp.net`, nome: 'Ana' });
  receber('Duda', `Vim por @${ANA}`, { mencoes: [`${ANA}@s.whatsapp.net`] });
  const repetida = receber('Duda', `@${ANA} me indicou`, { mencoes: [`${ANA}@s.whatsapp.net`] });

  assert.equal(repetida.duplicada, true);
  const r = relatorioIndicacoes('today');
  assert.equal(r.resumo.indicacoes, 1, 'a repetição não vira ponto');
  assert.equal(r.resumo.duplicadas, 1);
  assert.equal(r.ranking[0].indicacoes, 1);
});

test('ninguém indica a si mesma', () => {
  limpar();
  const entrada = registrarIndicacao({
    groupId: 'g1@g.us',
    indicada: { id: `${ANA}@s.whatsapp.net`, nome: 'Ana' },
    indicadora: resolverIndicadora(analisarIndicacao(`Vim por @${ANA}`), [`${ANA}@s.whatsapp.net`]),
    analise: analisarIndicacao(`Vim por @${ANA}`),
    text: 'Vim por mim mesma',
  });
  assert.equal(entrada, null);
  assert.equal(relatorioIndicacoes('today').resumo.indicacoes, 0);
});

test('a indicadora ganha nome quando fala pela primeira vez', () => {
  limpar();
  // Citada antes de ter dito qualquer coisa: só o número é conhecido.
  receber('Duda', `Vim por @${ANA}`, { mencoes: [`${ANA}@s.whatsapp.net`] });
  assert.equal(relatorioIndicacoes('today').ranking[0].nome, `@${ANA}`);
  assert.equal(relatorioIndicacoes('today').resumo.naoIdentificadas, 1);

  // Ana manda uma mensagem qualquer no grupo → o nome aparece retroativamente.
  registrarPessoa({ id: `${ANA}@s.whatsapp.net`, pn: `${ANA}@s.whatsapp.net`, nome: 'Ana' });
  const r = relatorioIndicacoes('today');
  assert.equal(r.ranking[0].nome, 'Ana');
  assert.equal(r.ranking[0].identificada, true);
  assert.equal(r.resumo.naoIdentificadas, 0);
});

test('filtro por período separa hoje do histórico', () => {
  limpar();
  registrarPessoa({ id: `${ANA}@s.whatsapp.net`, nome: 'Ana' });
  receber('Duda', `Vim por @${ANA}`, { mencoes: [`${ANA}@s.whatsapp.net`], dia: '2020-01-01' });
  receber('Elis', `Vim por @${ANA}`, { mencoes: [`${ANA}@s.whatsapp.net`] });

  assert.equal(filtrarIndicacoes('today').length, 1);
  assert.equal(filtrarIndicacoes('all').length, 2);
  assert.equal(relatorioIndicacoes('today').indicadas[0].nome, 'Elis');
  assert.equal(relatorioIndicacoes('all').ranking[0].indicacoes, 2);
  assert.equal(relatorioIndicacoes('today').indicadas[0].day, dayKey());
});

test('indicação sem menção fica marcada como tal', () => {
  limpar();
  registrarPessoa({ id: 'ana@lid', nome: 'Ana' });
  const e = receber('Duda', 'Vim pela Ana');
  assert.equal(e.viaMencao, false);
  // Casou com a Ana já conhecida em vez de criar uma indicadora nova.
  assert.equal(e.indicadoraChave, 'ana@lid');
  const r = relatorioIndicacoes('today');
  assert.equal(r.resumo.semMencao, 1);
  assert.equal(r.ranking[0].nome, 'Ana');
});

test('o relatório em texto lista o pódio', () => {
  limpar();
  registrarPessoa({ id: `${ANA}@s.whatsapp.net`, nome: 'Ana' });
  receber('Duda', `Vim por @${ANA}`, { mencoes: [`${ANA}@s.whatsapp.net`] });
  receber('Elis', `Vim por @${ANA}`, { mencoes: [`${ANA}@s.whatsapp.net`] });

  const texto = relatorioIndicacoesTexto('today');
  assert.match(texto, /INDICAÇÕES/);
  assert.match(texto, /🥇 \*Ana\* — 2 indicações/);
  assert.match(texto, /Duda|Elis/);
  assert.match(relatorioIndicacoesTexto('all'), /Total: 2 indicações · 1 indicadoras/);
});

test('sem indicações o texto diz isso em vez de quebrar', () => {
  limpar();
  assert.match(relatorioIndicacoesTexto('today'), /Nenhuma indicação/);
  assert.deepEqual(relatorioIndicacoes('today').ranking, []);
});

/* ── Painel ──────────────────────────────────────────────────────────
   O index.html e o app.js sobem num DOM real: o que se quer garantir é o
   contrato entre os dois (os ids da aba) e a leitura do relatório na tela. */

const { JSDOM } = await import('jsdom');
const PUBLIC = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', 'public');

async function montarPainel() {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;
  window.Element.prototype.getBoundingClientRect = () => ({
    left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0,
  });
  window.Element.prototype.setPointerCapture = () => {};
  window.Element.prototype.releasePointerCapture = () => {};
  window.Element.prototype.scrollIntoView = () => {}; // jsdom não tem rolagem
  const tag = window.document.createElement('script');
  tag.textContent = fs.readFileSync(path.join(PUBLIC, 'app.js'), 'utf8');
  window.document.body.appendChild(tag);
  return { window, doc: window.document };
}

test('a aba de Indicações desenha o ranking e as indicadas', async () => {
  const { window, doc } = await montarPainel();
  window.renderIndicacoes({
    ok: true,
    resumo: { indicacoes: 4, indicadoras: 2, indicadas: 4, duplicadas: 1, semMencao: 1, naoIdentificadas: 1 },
    ranking: [
      {
        chave: 'ana@lid', nome: 'Ana', indicacoes: 3, identificada: true, ultimaEm: '2026-08-04T12:00:00.000Z',
        indicadas: [{ id: 'i1', ts: '2026-08-04T12:00:00.000Z', nome: 'Duda', frase: 'vim por @ana', viaMencao: true, groupName: 'DB' }],
      },
      {
        chave: 'd:5522222222222', nome: '@5522222222222', indicacoes: 1, identificada: false, ultimaEm: '2026-08-04T11:00:00.000Z',
        indicadas: [{ id: 'i2', ts: '2026-08-04T11:00:00.000Z', nome: 'Gabi', frase: 'me trouxe', viaMencao: true, groupName: 'DB' }],
      },
    ],
    indicadas: [
      { id: 'i1', ts: '2026-08-04T12:00:00.000Z', nome: 'Duda', indicadoraNome: 'Ana', viaMencao: true },
      { id: 'i2', ts: '2026-08-04T11:00:00.000Z', nome: 'Gabi', indicadoraNome: '@5522222222222', viaMencao: false },
    ],
  });

  assert.equal(doc.getElementById('ind-kpi-total').textContent, '4');
  assert.match(doc.getElementById('ind-kpi-lider').textContent, /Ana \(3\)/);
  assert.equal(doc.getElementById('ind-kpi-repetidas').textContent, '1 repetidas');

  const linhas = doc.querySelectorAll('#tbl-ind tbody tr');
  assert.equal(linhas.length, 2);
  assert.match(linhas[0].textContent, /Ana/);
  assert.equal(linhas[0].querySelector('.pos').textContent, '1');
  // Barra proporcional ao topo: a segunda tem 1/3 do comprimento da primeira.
  assert.match(linhas[0].querySelector('.plat-barra i').getAttribute('style'), /width:100%/);
  assert.match(linhas[1].querySelector('.plat-barra i').getAttribute('style'), /width:33\./);
  // Indicadora que ainda não falou vem marcada para conferência.
  assert.equal(linhas[0].querySelectorAll('.tag-aviso').length, 0);
  assert.equal(linhas[1].querySelectorAll('.tag-aviso').length, 1);

  assert.equal(doc.querySelectorAll('#ind-indicadas .ind-item').length, 2);
  assert.match(doc.getElementById('ind-indicadas').textContent, /Duda\s*por Ana/);

  // Clicar na linha abre o detalhe com quem ela indicou.
  linhas[0].dispatchEvent(new window.Event('click', { bubbles: true }));
  assert.equal(doc.getElementById('ind-detalhe').classList.contains('hidden'), false);
  assert.match(doc.getElementById('ind-detalhe-nome').textContent, /Ana — 3 indicações/);
  assert.match(doc.getElementById('ind-detalhe-corpo').textContent, /Duda/);

  doc.getElementById('ind-fechar').dispatchEvent(new window.Event('click', { bubbles: true }));
  assert.equal(doc.getElementById('ind-detalhe').classList.contains('hidden'), true);
});

test('sem indicações a tabela explica o vazio em vez de sumir', async () => {
  const { window, doc } = await montarPainel();
  window.renderIndicacoes({ ok: true, resumo: {}, ranking: [], indicadas: [] });
  assert.match(doc.querySelector('#tbl-ind tbody').textContent, /Nenhuma indicação/);
  assert.match(doc.getElementById('ind-indicadas').textContent, /Nenhuma indicada/);
  assert.equal(doc.getElementById('ind-kpi-lider').textContent, '—');
});
