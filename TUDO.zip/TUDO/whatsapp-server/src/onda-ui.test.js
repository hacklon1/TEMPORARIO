// A onda da semana — o gráfico que substituiu o "Desempenho por operador".
//
// O que se protege aqui: a série certa (montante VALIDADO por dia), a curva
// passando por todos os pontos, o dia de hoje marcado e o estado vazio. Um
// gráfico que desenha errado não quebra nada — só mente, que é pior.
import test from 'node:test';
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { JSDOM } from 'jsdom';

const PUBLIC = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..', 'public');

/* ── a série que alimenta a onda ── */
const DIR_TEMP = fs.mkdtempSync(path.join(os.tmpdir(), 'ws-onda-'));
process.env.DATA_DIR = DIR_TEMP;
const { loadDb, getDb, saveDb } = await import('./db.js');
const { validadosPorDia, dayKey } = await import('./store.js');
loadDb();

test('validadosPorDia soma só o que fechou os 3 passos, dia a dia', () => {
  const db = getDb();
  const hoje = dayKey();
  const svc = (id, day, status, montante, valor) => ({
    id, day, status, sessaoId: 'n1',
    atendimento: { operatorId: 'op1', operatorName: 'Ana', montante, contasTotal: valor },
  });
  db.servicos = [
    svc('a', hoje, 'validado', 500, 40),
    svc('b', hoje, 'validado', 300, 20),
    svc('c', hoje, 'aguardando_comprovante', 9999, 999),
    { id: 'd', day: hoje, status: 'validado', sessaoId: 'n1' },   // sem atendimento
  ];
  saveDb();

  const serie = validadosPorDia(7);
  assert.equal(serie.length, 7, 'sete dias, mesmo os vazios');
  const dia = serie.at(-1);
  assert.equal(dia.day, hoje);
  assert.equal(dia.hoje, true, 'o último ponto é hoje');
  assert.equal(dia.montante, 800, 'só os validados');
  assert.equal(dia.servicos, 2);
  assert.equal(dia.salario, 60);
  assert.match(dia.diaSemana, /^(dom|seg|ter|qua|qui|sex|sáb)$/);
  assert.equal(serie[0].montante, 0, 'dia sem serviço vem zerado, não some');
});

/* ── o desenho ── */
async function montar() {
  const html = fs.readFileSync(path.join(PUBLIC, 'index.html'), 'utf8');
  const dom = new JSDOM(html, { runScripts: 'dangerously', url: 'https://localhost/' });
  const { window } = dom;
  window.Element.prototype.getBoundingClientRect = () => ({ left: 0, top: 0, right: 240, bottom: 240, width: 240, height: 240, x: 0, y: 0 });
  window.Element.prototype.scrollIntoView = () => {};
  window.fetch = async () => ({ ok: true, status: 200, json: async () => ({ ok: true, recursos: [], sessoes: [], conflitos: [] }) });
  for (const arquivo of ['app.js', 'relatorios.js']) {
    const tag = window.document.createElement('script');
    tag.textContent = fs.readFileSync(path.join(PUBLIC, arquivo), 'utf8');
    window.document.body.appendChild(tag);
  }
  return { window, doc: window.document, fechar: async () => { await new Promise((r) => setTimeout(r, 20)); dom.window.close(); } };
}

const SERIE = [
  { day: '2026-08-24', label: '24/08', diaSemana: 'seg', hoje: false, servicos: 3, montante: 900, salario: 60 },
  { day: '2026-08-25', label: '25/08', diaSemana: 'ter', hoje: false, servicos: 0, montante: 0, salario: 0 },
  { day: '2026-08-26', label: '26/08', diaSemana: 'qua', hoje: false, servicos: 5, montante: 2400, salario: 120 },
  { day: '2026-08-27', label: '27/08', diaSemana: 'qui', hoje: false, servicos: 4, montante: 1500, salario: 90 },
  { day: '2026-08-28', label: '28/08', diaSemana: 'sex', hoje: false, servicos: 6, montante: 3000, salario: 150 },
  { day: '2026-08-29', label: '29/08', diaSemana: 'sáb', hoje: false, servicos: 2, montante: 700, salario: 40 },
  { day: '2026-08-30', label: '30/08', diaSemana: 'dom', hoje: true, servicos: 1, montante: 300, salario: 20 },
];

test('o quadro antigo saiu e a onda ocupou o lugar', async () => {
  const { doc, fechar } = await montar();
  try {
    assert.equal(doc.getElementById('chart-ops'), null, 'o "Desempenho por operador" saiu');
    assert.equal(doc.getElementById('ops-legend'), null);
    assert.ok(doc.getElementById('chart-onda'), 'a onda entrou no lugar');
    // O quadro de validados, que o dono quis manter, continua.
    assert.ok(doc.getElementById('chart-servicos'));
  } finally { await fechar(); }
});

test('a onda desenha a curva por todos os dias, marca hoje e resume o período', async () => {
  const { window, doc, fechar } = await montar();
  try {
    window.lerCores();
    window.ondaDaSemana(SERIE);
    const svg = doc.querySelector('#chart-onda svg');
    assert.ok(svg, 'deveria ter desenhado');

    // A onda é uma curva (bezier), não uma linha quebrada.
    const linha = svg.querySelector('.onda-linha');
    assert.ok(linha, 'a linha da onda deveria existir');
    assert.match(linha.getAttribute('d'), /^M[\d.]+ [\d.]+ C/, 'a linha é curva, não reta');
    assert.ok(svg.querySelector('path[fill^="url(#ondaGrad"]'), 'o enchimento em gradiente');

    // UM ponto só: o dia de hoje. Sete bolinhas viravam ruído.
    assert.equal(svg.querySelectorAll('circle').length, 1, 'só hoje ganha ponto');

    // Rótulo de dia por dia, numa linha só ("seg 24").
    assert.match(svg.textContent, /seg 24/);
    assert.match(svg.textContent, /dom 30/);

    // Cada dia tem um alvo de hover com o valor.
    const alvos = [...svg.querySelectorAll('rect.hit')];
    assert.equal(alvos.length, 7);
    assert.match(alvos[4].dataset.tip, /Montante validado/);
    assert.match(alvos[4].dataset.tip, /3\.000,00/);
    assert.match(alvos[4].dataset.tip, /Serviços/);

    // Nenhum valor escrito DENTRO da onda (pedido do usuário): nem no pico,
    // nem em hoje. O texto do SVG é só o eixo — dias embaixo, escala à
    // esquerda. Os valores ficam na dica e no resumo do card.
    assert.equal(svg.querySelectorAll('.onda-tag').length, 0);
    assert.doesNotMatch(svg.textContent, /R\$ 3 mil/, 'o pico não pode vir escrito no gráfico');

    assert.match(doc.getElementById('onda-resumo').textContent, /8\.800,00 em 21 serviços/);
    assert.match(doc.getElementById('onda-legend').textContent, /Montante validado/);
  } finally { await fechar(); }
});

test('o montante lançado entra como véu atrás, sem competir com a onda', async () => {
  const { window, doc, fechar } = await montar();
  try {
    window.lerCores();
    window.ondaDaSemana(SERIE, SERIE.map((d) => ({ ...d, montante: d.montante * 2 })));
    const svg = doc.querySelector('#chart-onda svg');

    // Água atrás da água: área preenchida e translúcida, sem traço próprio.
    const veu = [...svg.querySelectorAll('path')].find((p) => Number(p.getAttribute('opacity')) < .3);
    assert.ok(veu, 'o lançado deveria entrar como área translúcida');
    assert.equal(veu.getAttribute('stroke'), null, 'sem traço: ele é referência, não protagonista');
    assert.match(doc.getElementById('onda-legend').textContent, /Montante lançado/);

    // A escala cabe os dois: o topo segue o MAIOR (6 mil do lançado).
    assert.match(svg.textContent, /6 mil/);
  } finally { await fechar(); }
});

test('a onda se desenha uma vez só — o snapshot chega a cada mensagem', async () => {
  const { window, doc, fechar } = await montar();
  try {
    window.lerCores();
    window.ondaDaSemana(SERIE);
    // jsdom não tem getTotalLength: o desenho animado é ignorado sem quebrar.
    const primeira = doc.querySelector('#chart-onda .onda-linha');
    assert.ok(primeira);
    window.ondaDaSemana(SERIE);
    window.ondaDaSemana(SERIE);
    assert.equal(doc.querySelectorAll('#chart-onda svg').length, 1, 'redesenha no lugar, sem empilhar');
  } finally { await fechar(); }
});

test('semana sem nada validado mostra o vazio, não uma onda reta', async () => {
  const { window, doc, fechar } = await montar();
  try {
    window.lerCores();
    window.ondaDaSemana(SERIE.map((d) => ({ ...d, montante: 0, servicos: 0 })));
    assert.equal(doc.querySelector('#chart-onda svg'), null);
    assert.match(doc.getElementById('chart-onda').textContent, /Nenhum montante validado/);
    assert.equal(doc.getElementById('onda-resumo').textContent, '');
  } finally { await fechar(); }
});
