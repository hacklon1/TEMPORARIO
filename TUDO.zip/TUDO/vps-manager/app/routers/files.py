"""Gerenciador de arquivos: navegar, visualizar, baixar e enviar."""
from __future__ import annotations

import os
import shutil

from fastapi import APIRouter, Depends, File, Form, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, StreamingResponse

from .. import db
from ..config import settings
from ..deps import admin_user, client_ip
from ..services import archiver
from ..services import files as fsvc

router = APIRouter(prefix="/api/files", tags=["files"])


@router.get("/list")
async def list_dir(path: str = "/opt", hidden: bool = True, user: dict = Depends(admin_user)):
    try:
        return fsvc.listdir(path, show_hidden=hidden)
    except fsvc.PathError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except OSError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/view")
async def view_file(path: str, user: dict = Depends(admin_user)):
    try:
        return fsvc.read_text(path)
    except fsvc.PathError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except OSError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/download")
async def download(path: str, request: Request, fmt: str = "tar.gz", full: bool = True,
                   user: dict = Depends(admin_user)):
    """Baixa um arquivo isolado ou compacta um diretorio inteiro."""
    try:
        p = fsvc.safe_path(path)
    except fsvc.PathError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc

    await db.audit("file.download", username=user["username"], ip=client_ip(request), target=p)

    if os.path.isdir(p):
        base = os.path.dirname(p.rstrip("/")) or "/"
        name = os.path.basename(p.rstrip("/")) or "raiz"
        ext = "zip" if fmt == "zip" else "tar.gz"
        return StreamingResponse(
            archiver.stream_archive([p], base, "zip" if fmt == "zip" else "tar.gz", full),
            media_type="application/zip" if fmt == "zip" else "application/gzip",
            headers={"Content-Disposition": f'attachment; filename="{name}.{ext}"',
                     "X-Accel-Buffering": "no", "Cache-Control": "no-store"},
        )
    if not os.path.isfile(p):
        raise HTTPException(status_code=404, detail="arquivo nao encontrado")
    return FileResponse(p, filename=os.path.basename(p), media_type="application/octet-stream")


@router.post("/upload")
async def upload(request: Request, dest: str = Form(...), file: UploadFile = File(...),
                 user: dict = Depends(admin_user)):
    try:
        target_dir = fsvc.safe_path(dest)
    except fsvc.PathError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    if not os.path.isdir(target_dir):
        raise HTTPException(status_code=400, detail="destino nao e um diretorio")

    name = os.path.basename(file.filename or "arquivo")
    if not name or name in (".", ".."):
        raise HTTPException(status_code=400, detail="nome de arquivo invalido")
    target = os.path.join(target_dir, name)

    limit = settings.max_upload_mb * 1024 * 1024
    written = 0
    with open(target, "wb") as out:
        while chunk := await file.read(1024 * 1024):
            written += len(chunk)
            if written > limit:
                out.close()
                os.remove(target)
                raise HTTPException(status_code=413, detail=f"arquivo maior que {settings.max_upload_mb} MB")
            out.write(chunk)

    await db.audit("file.upload", username=user["username"], ip=client_ip(request),
                   target=target, detail=f"{written} bytes")
    return {"ok": True, "path": target, "size": written}


@router.get("/stat")
async def stat(path: str, user: dict = Depends(admin_user)):
    try:
        return fsvc.stat_path(path)
    except (fsvc.PathError, OSError) as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc


@router.get("/disk")
async def disk(path: str = "/", user: dict = Depends(admin_user)):
    try:
        p = fsvc.safe_path(path)
    except fsvc.PathError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    du = shutil.disk_usage(p)
    return {"path": p, "total": du.total, "used": du.used, "free": du.free}
