import { test } from 'node:test';
import assert from 'node:assert/strict';
import {
  normalizeText,
  parseBrazilianNumber,
  extractMontante,
  extractContas,
  contasOferecidas,
  extractSalario,
  analisarMensagem,
} from './parser.js';

test('normalizeText remove acentos e baixa caixa', () => {
  assert.equal(normalizeText('Montante É  Válido'), 'montante e valido');
});

test('parseBrazilianNumber — formatos', () => {
  assert.equal(parseBrazilianNumber('100'), 100);
  assert.equal(parseBrazilianNumber('100,50'), 100.5);
  assert.equal(parseBrazilianNumber('1.000'), 1000);
  assert.equal(parseBrazilianNumber('1.500,99'), 1500.99);
  assert.equal(parseBrazilianNumber('R$ 500'), 500);
  assert.equal(parseBrazilianNumber('350,00'), 350);
  assert.equal(parseBrazilianNumber('1.500.000'), 1500000);
  assert.equal(parseBrazilianNumber('100.50'), 100.5); // ponto decimal
  assert.equal(parseBrazilianNumber('sem numero'), null);
});

test('extractMontante — variações', () => {
  assert.equal(extractMontante('Montante: 200').total, 200);
  assert.equal(extractMontante('Montante: R$200').total, 200);
  assert.equal(extractMontante('🔸 Montante: 350').total, 350);
  assert.equal(extractMontante('Montante: R$ 350,00').total, 350);
  const multi = extractMontante('Montante: 100\nMontante: 250');
  assert.equal(multi.total, 350);
  assert.equal(multi.valores.length, 2);
  assert.equal(extractMontante('sem nada').total, 0);
});

test('extractMontante — fonte estilizada (negrito unicode do WhatsApp)', () => {
  const msg = '🔸 𝐌𝐨𝐧𝐭𝐚𝐧𝐭𝐞: 233\n💸 R$ 46,60\n📊 𝗔𝘁é 2 𝗰𝗼𝗻𝘁𝗮𝘀';
  assert.equal(extractMontante(msg).total, 233);
  const r = analisarMensagem(msg);
  assert.equal(r.montante, 233); // antes pegava 46,60 (o valor depois do R$)
  assert.equal(r.contasTotal, 0); // "R$ 46,60" solto é o valor a pagar, não uma conta
});

test('contas — só conta o valor rotulado com "Valor"', () => {
  const conta =
    '📌 PIX TELEFONE\n💠 74923843836\n━━━━━━━━━━━━━━━\n💸 𝗩𝗮𝗹𝗼𝗿 R$ 6,00\n\n' +
    '⚠️ 𝐌𝐀𝐑𝐂𝐀𝐑 𝐄 𝐄𝐍𝐕𝐈𝐀𝐑 𝐎 𝐂𝐎𝐌𝐏𝐑𝐎𝐕𝐀𝐍𝐓𝐄\n━━━━━━━━━━━━━━━';
  const r = analisarMensagem(conta);
  assert.equal(r.contasTotal, 6);
  assert.equal(r.contasQtd, 1);
  assert.equal(r.montante, 0);

  // sem a palavra "Valor" não vira conta
  assert.equal(extractContas('📌 PIX CELULAR\n💠 13991202750\n💸 R$ 70,00').total, 0);
});

test('extractMontante — valor antes da palavra', () => {
  assert.equal(extractMontante('300 de montante 2 contas').total, 300);
  assert.equal(extractMontante('600 de montante \n\n3 contas').total, 600);
  assert.equal(extractMontante('Montante 300').total, 300);
  assert.equal(extractMontante('500 Montante 1,5\n3 contas').total, 500);
  assert.equal(extractMontante('1 montante 500\n5 contas variadas').total, 500);
});

test('extractMontante — não pega número da linha seguinte', () => {
  // "Montante alto" é um aviso sem valor; o R$ abaixo é conta, não montante
  const t = '⚠️ Montante alto feito em uma conta\n💸 Valor: R$ 60,00';
  assert.equal(extractMontante(t).total, 0);
  assert.equal(extractContas(t).total, 60);
});

test('formato real "ATENDIMENTO DE MONTANTE"', () => {
  const r = analisarMensagem(
    '💰 ATENDIMENTO DE MONTANTE\n📌 PIX CELULAR\n💠 21920284928\n🏷️ Caio Henrique\n' +
      '━━━━━━━━━━━━━━━\n🔸 Montante: R$ 1000,00\n💸 Valor a pagar: R$ 170,00\n📊 Até 5 contas',
  );
  assert.equal(r.montante, 1000);
  // "Valor a pagar" é o preço do montante, não uma conta
  assert.equal(r.contasTotal, 0);
});

test('extractContas — valores e pix', () => {
  assert.equal(extractContas('💸 Valor R$ 25').total, 25);
  assert.equal(extractContas('Valor final: R$50').total, 50);
  const c = extractContas('PIX CELULAR\nValor R$ 25\nValor final: R$ 50');
  assert.equal(c.qtd, 2);
  assert.equal(c.total, 75);
});

test('extractContas não conta o montante como conta', () => {
  const c = extractContas('Montante: R$ 350\nValor R$ 25');
  assert.equal(c.total, 25);
  assert.equal(c.qtd, 1);
});

test('analisarMensagem devolve null quando não há dados', () => {
  assert.equal(analisarMensagem('bom dia pessoal'), null);
});

test('analisarMensagem agrega montante + contas', () => {
  const r = analisarMensagem('🔸 Montante: R$ 350,00\n💸 Valor R$ 25\nValor final: R$50');
  assert.equal(r.montante, 350);
  assert.equal(r.contasQtd, 2);
  assert.equal(r.contasTotal, 75);
});

test('contasOferecidas: lê o "Até N contas" que o Operador anuncia', () => {
  // É a única quantidade de contas na mensagem dele — o "Valor: R$ x" é preço.
  assert.equal(contasOferecidas('🔸 Montante: 200\n💸 Valor: R$ 40,00\n📊 Até 2 contas'), 2);
  assert.equal(contasOferecidas('📊 𝗔𝘁é 1 𝗰𝗼𝗻𝘁𝗮'), 1); // fonte estilizada
  assert.equal(contasOferecidas('ate 15 contas'), 15); // sem acento
  assert.equal(contasOferecidas('💸 Valor: R$ 25'), 0);
  assert.equal(contasOferecidas(''), 0);
});

test('analisarMensagem devolve as contas anunciadas junto do resto', () => {
  const a = analisarMensagem('🔸 Montante: 200\n💸 Valor: R$ 40,00\n📊 Até 2 contas');
  assert.equal(a.montante, 200);
  assert.equal(a.contasQtd, 1); // um rótulo "Valor:" = uma cotação
  assert.equal(a.contasOferecidas, 2);
});

/* ═══════════ Salário do Operador (bug de 31/08/2026) ═══════════
   A comissão lia `contasTotal`, que exige a palavra "Valor". O template mais
   usado no grupo escreve o preço solto — 167 dos 315 serviços do histórico
   ficaram com salário 0 e nunca foram cobrados. */

const MSG_SEM_VALOR = [
  '📌 PIX NÚMERO',
  '💠 21976747133',
  '🏷️ MATHEUS HENRIQUE',
  '🏦 DIGIO',
  '━━━━━━━━━━━━━━━',
  '🔸 Montante: 100',
  '💸 R$ 20,00',
  '📊 Até 1 conta',
  '⚡ Envio após confirmação do pagamento',
].join('\n');

test('salário: o "R$ x" solto do template sem rótulo é o preço do Operador', () => {
  const a = analisarMensagem(MSG_SEM_VALOR);
  assert.equal(a.montante, 100);
  assert.equal(a.salario, 20);
  // E a regra de CONTA não mudou: sem a palavra "Valor" não é conta.
  assert.equal(a.contasTotal, 0);
  assert.equal(a.contasQtd, 0);
});

test('salário: com a palavra "Valor" continua sendo o rotulado', () => {
  const a = analisarMensagem('🔸 Montante: 300\n💸 𝗩𝗮𝗹𝗼𝗿 R$ 6,00');
  assert.equal(a.salario, 6);
  assert.equal(a.contasTotal, 6, 'aqui é conta também — o rótulo está lá');
});

test('salário: o montante NÃO vira salário, mesmo escrito com R$', () => {
  // O span do montante é mascarado antes de procurar o preço. Sem isso um
  // "Montante: R$ 500" cobraria comissão sobre os 500.
  assert.equal(analisarMensagem('Montante: R$ 500').salario, 0);
  assert.equal(extractSalario('🔸 Montante: 3\n💸 R$ 17'), 17);
});

test('salário: só o PRIMEIRO R$ solto — o texto promocional não inventa preço', () => {
  // Vários "R$" numa linha só de divulgação não podem virar um salário somado.
  assert.equal(extractSalario('🔸 Montante: 50\n💸 R$ 10\nPromo R$ 90 R$ 80'), 10);
  assert.equal(extractSalario('sem dinheiro nenhum aqui'), 0);
});

test('salário: o preço marcado só pelo emoji ("💸 20", sem R$) também conta', () => {
  // 4 serviços do Luís no histórico usavam este formato e ficavam com 0.
  const msg = '📌 PIX CPF\n💠 08831620320\n🏷️ LUIS\n🔸 𝐌𝐨𝐧𝐭𝐚𝐧𝐭𝐞: 100\n💸 20\n📊 𝗔𝘁é 1 contas';
  assert.equal(extractSalario(msg), 20);
  // A chave PIX é um número grande logo acima — não pode virar salário.
  assert.equal(extractSalario('📌 PIX\n💠 08831620320\n🔸 Montante: 100'), 0);
  // "💸 R" sem valor nenhum continua 0 — não inventa preço.
  assert.equal(extractSalario('🔸 Montante: 100\n💸 R'), 0);
  // E o emoji não atrapalha o formato com R$: o mesmo número sai por qualquer
  // dos caminhos.
  assert.equal(extractSalario('🔸 Montante: 100\n💸 R$ 20'), 20);
});
