"""Empacotamento de projetos para download (tar.gz / zip em streaming)."""
from __future__ import annotations

import asyncio
import os
import re
from typing import AsyncIterator

from ..config import settings

SAFE_NAME = re.compile(r"^[A-Za-z0-9._-]+$")


class ArchiveError(Exception):
    pass


def resolve_project(root: str, name: str) -> str:
    """Valida root+nome e devolve o caminho absoluto do projeto."""
    if root not in settings.roots:
        raise ArchiveError("raiz nao permitida")
    if not SAFE_NAME.match(name) or name in (".", ".."):
        raise ArchiveError("nome invalido")
    path = os.path.realpath(os.path.join(root, name))
    if not (path == os.path.realpath(root) or path.startswith(os.path.realpath(root) + os.sep)):
        raise ArchiveError("caminho fora da raiz")
    if not os.path.isdir(path):
        raise ArchiveError("projeto nao encontrado")
    return path


def list_projects() -> list[dict]:
    items = []
    for root in settings.roots:
        if not os.path.isdir(root):
            continue
        for entry in sorted(os.scandir(root), key=lambda e: e.name.lower()):
            if not entry.is_dir(follow_symlinks=False):
                continue
            st = entry.stat(follow_symlinks=False)
            items.append({
                "name": entry.name,
                "root": root,
                "path": entry.path,
                "modified": st.st_mtime,
                "owner": _owner(st.st_uid),
                "mode": oct(st.st_mode & 0o777)[2:],
            })
    return items


def _owner(uid: int) -> str:
    try:
        import pwd
        return pwd.getpwuid(uid).pw_name
    except Exception:
        return str(uid)


async def dir_size(path: str) -> dict:
    """Tamanho total e tamanho 'enxuto' (sem os padroes de exclusao)."""
    proc = await asyncio.create_subprocess_exec(
        "du", "-sb", path, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL
    )
    out, _ = await proc.communicate()
    total = int(out.split()[0]) if out.split() else 0

    args = ["du", "-sb"]
    for pat in settings.excludes:
        args += ["--exclude", pat]
    args.append(path)
    proc = await asyncio.create_subprocess_exec(
        *args, stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL
    )
    out, _ = await proc.communicate()
    slim = int(out.split()[0]) if out.split() else 0
    return {"total_bytes": total, "slim_bytes": slim}


async def file_count(path: str) -> int:
    proc = await asyncio.create_subprocess_shell(
        f"find {_q(path)} -type f 2>/dev/null | wc -l", stdout=asyncio.subprocess.PIPE
    )
    out, _ = await proc.communicate()
    try:
        return int(out.strip())
    except ValueError:
        return 0


def _q(p: str) -> str:
    import shlex
    return shlex.quote(p)


def build_command(paths: list[str], base_dir: str, fmt: str, full: bool) -> list[str]:
    """Monta o comando que escreve o arquivo compactado em stdout."""
    names = [os.path.relpath(p, base_dir) for p in paths]
    if fmt == "zip":
        args = ["zip", "-r", "-q", "-", *names]
        if not full:
            args.append("-x")
            for pat in settings.excludes:
                if pat.startswith("*."):
                    args += [pat, f"*/{pat}"]
                else:
                    args += [f"{pat}/*", f"*/{pat}/*", pat, f"*/{pat}"]
        return args
    args = ["tar", "-czf", "-", "--warning=no-file-changed", "--ignore-failed-read"]
    if not full:
        for pat in settings.excludes:
            args += [f"--exclude={pat}"]
    args += ["--"] + names
    return args


async def stream_archive(paths: list[str], base_dir: str, fmt: str, full: bool) -> AsyncIterator[bytes]:
    cmd = build_command(paths, base_dir, fmt, full)
    proc = await asyncio.create_subprocess_exec(
        *cmd, cwd=base_dir,
        stdout=asyncio.subprocess.PIPE, stderr=asyncio.subprocess.DEVNULL,
    )
    assert proc.stdout is not None
    try:
        while True:
            chunk = await proc.stdout.read(256 * 1024)
            if not chunk:
                break
            yield chunk
    finally:
        if proc.returncode is None:
            try:
                proc.kill()
            except ProcessLookupError:
                pass
        await proc.wait()
