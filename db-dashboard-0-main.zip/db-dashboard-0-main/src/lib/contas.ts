// Regra de divisão de contas por montante
const TIERS: Array<{ upTo: number; max: number }> = [
  { upTo: 198, max: 1 },
  { upTo: 350, max: 2 },
  { upTo: 450, max: 3 },
  { upTo: 550, max: 3 },
  { upTo: 650, max: 4 },
  { upTo: 750, max: 5 },
  { upTo: 950, max: 6 },
  { upTo: 1050, max: 7 },
  { upTo: 1250, max: 8 },
  { upTo: 1450, max: 9 },
  { upTo: 1650, max: 10 },
  { upTo: 1850, max: 10 },
  { upTo: 2050, max: 11 },
];

export function maxContasFromMontante(montante: number): number {
  const m = Math.max(0, Number(montante) || 0);
  if (m <= 0) return 1;
  for (const tier of TIERS) {
    if (m <= tier.upTo) return tier.max;
  }
  const extra = Math.ceil((m - 700) / 200);
  return 3 + extra;
}

// Distribuição aleatória — gera N valores que somam total, cada um >= min.
// Cada chamada produz um resultado diferente.
export function distribuirAleatorio(total: number, n: number, min: number = 1): number[] {
  const T = Math.max(0, Math.round(Number(total) || 0));
  const N = Math.max(1, Math.floor(n));
  const M = Math.max(1, Math.floor(Number(min) || 1));
  if (N === 1) return [T];
  // Se o total não permitir o mínimo em todas as contas, cai para divisão simples
  if (T < M * N) {
    const arr = Array(N).fill(0);
    const baseShare = Math.floor(T / N);
    for (let i = 0; i < N; i++) arr[i] = baseShare;
    let rest = T - baseShare * N;
    for (let i = 0; rest > 0; i = (i + 1) % N, rest--) arr[i] += 1;
    // embaralha
    for (let i = arr.length - 1; i > 0; i--) {
      const j = Math.floor(Math.random() * (i + 1));
      [arr[i], arr[j]] = [arr[j], arr[i]];
    }
    return arr;
  }
  // Reserva M por conta e distribui o restante aleatoriamente
  const weights = Array.from({ length: N }, () => Math.random() + 0.1);
  const sum = weights.reduce((a, b) => a + b, 0);
  const restante = T - M * N;
  const raw = weights.map((w) => Math.floor((w / sum) * restante));
  let assigned = raw.reduce((a, b) => a + b, 0);
  let diff = restante - assigned;
  while (diff > 0) {
    raw[Math.floor(Math.random() * N)] += 1;
    diff--;
  }
  return raw.map((v) => v + M);
}
